<?php
// save as: generate_all_resources.php in project root

// Función para obtener la ruta de la aplicación
function app_path($path = '') {
    return __DIR__ . '/app' . ($path ? '/' . $path : $path);
}

// Función para obtener la ruta de resources
function resource_path($path = '') {
    return __DIR__ . '/resources' . ($path ? '/' . $path : $path);
}

// Función para obtener la ruta base
function base_path($path = '') {
    return __DIR__ . ($path ? '/' . $path : $path);
}

// Cargar el autoload de Composer manualmente
require __DIR__.'/vendor/autoload.php';

// Funciones de string helpers
class StrHelper {
    public static function kebab($value) {
        return strtolower(preg_replace(['/([a-z])([A-Z])/', '/([^_])([A-Z][a-z])/'], '$1-$2', $value));
    }
    
    public static function camel($value) {
        $value = ucwords(str_replace(['-', '_'], ' ', $value));
        return lcfirst(str_replace(' ', '', $value));
    }
    
    public static function snake($value) {
        return strtolower(preg_replace(['/([a-z])([A-Z])/', '/([^_])([A-Z][a-z])/'], '$1_$2', $value));
    }
    
    public static function startsWith($haystack, $needle) {
        return strncmp($haystack, $needle, strlen($needle)) === 0;
    }
    
    public static function contains($haystack, $needle) {
        return strpos($haystack, $needle) !== false;
    }
    
    public static function plural($value) {
        $irregular = [
            'person' => 'people',
            'man' => 'men',
            'woman' => 'women',
            'child' => 'children',
            'foot' => 'feet',
            'tooth' => 'teeth',
            'goose' => 'geese',
            'mouse' => 'mice',
            'louse' => 'lice',
            'ox' => 'oxen',
            'die' => 'dice',
        ];
        
        if (isset($irregular[strtolower($value)])) {
            return $irregular[strtolower($value)];
        }
        
        $rules = [
            '/(quiz)$/i' => '\1zes',
            '/^(ox)$/i' => '\1en',
            '/([m|l])ouse$/i' => '\1ice',
            '/(matr|vert|ind)ix|ex$/i' => '\1ices',
            '/(x|ch|ss|sh)$/i' => '\1es',
            '/([^aeiouy]|qu)y$/i' => '\1ies',
            '/(hive)$/i' => '\1s',
            '/(?:([^f])fe|([lr])f)$/i' => '\1\2ves',
            '/sis$/i' => 'ses',
            '/([ti])um$/i' => '\1a',
            '/(buffal|tomat)o$/i' => '\1oes',
            '/(bu)s$/i' => '\1ses',
            '/(alias|status)$/i' => '\1es',
            '/(octop|vir)us$/i' => '\1i',
            '/(ax|test)is$/i' => '\1es',
            '/s$/i' => 's',
            '/$/' => 's'
        ];
        
        foreach ($rules as $rule => $replacement) {
            if (preg_match($rule, $value)) {
                return preg_replace($rule, $replacement, $value);
            }
        }
        
        return $value . 's';
    }
    
    public static function singular($value) {
        $irregular = [
            'people' => 'person',
            'men' => 'man',
            'women' => 'woman',
            'children' => 'child',
            'feet' => 'foot',
            'teeth' => 'tooth',
            'geese' => 'goose',
            'mice' => 'mouse',
            'lice' => 'louse',
            'oxen' => 'ox',
            'dice' => 'die',
        ];
        
        if (isset($irregular[strtolower($value)])) {
            return $irregular[strtolower($value)];
        }
        
        $rules = [
            '/(quiz)zes$/i' => '\1',
            '/(matr)ices$/i' => '\1ix',
            '/(vert|ind)ices$/i' => '\1ex',
            '/^(ox)en$/i' => '\1',
            '/(alias|status)es$/i' => '\1',
            '/([octop|vir])i$/i' => '\1us',
            '/(cris|ax|test)es$/i' => '\1is',
            '/(shoe)s$/i' => '\1',
            '/(o)es$/i' => '\1',
            '/(bus)es$/i' => '\1',
            '/([m|l])ice$/i' => '\1ouse',
            '/(x|ch|ss|sh)es$/i' => '\1',
            '/(m)ovies$/i' => '\1ovie',
            '/(s)eries$/i' => '\1eries',
            '/([^aeiouy]|qu)ies$/i' => '\1y',
            '/([lr])ves$/i' => '\1f',
            '/(tive)s$/i' => '\1',
            '/(hive)s$/i' => '\1',
            '/([^f])ves$/i' => '\1fe',
            '/(^analy)ses$/i' => '\1sis',
            '/((a)naly|(b)a|(d)iagno|(p)arenthe|(p)rogno|(s)ynop|(t)he)ses$/i' => '\1\2sis',
            '/([ti])a$/i' => '\1um',
            '/(n)ews$/i' => '\1ews',
            '/(h|bl)ouses$/i' => '\1ouse',
            '/(corpse)s$/i' => '\1',
            '/(us)es$/i' => '\1',
            '/s$/i' => '',
        ];
        
        foreach ($rules as $rule => $replacement) {
            if (preg_match($rule, $value)) {
                return preg_replace($rule, $replacement, $value);
            }
        }
        
        return $value;
    }
}

// Configuración simplificada de modelos (solo los principales para no hacerlo demasiado largo)
$models_config = [
    'Area' => [
        'table' => 'areas',
        'singular' => 'area',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'nombre' => ['type' => 'string', 'label' => 'Nombre'],
            'descripcion' => ['type' => 'text', 'label' => 'Descripción'],
        ],
        'has_timestamps' => false,
        'relationships' => []
    ],
    
    'AsigPorSolic' => [
        'table' => 'asig_por_solic',
        'singular' => 'asig_por_solic',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'solicitud_id' => ['type' => 'number', 'label' => 'Solicitud ID'],
            'año_finan' => ['type' => 'number', 'label' => 'Año Financiero'],
            'asig_mcuc' => ['type' => 'number', 'label' => 'Asignación MCUC'],
        ],
        'has_timestamps' => false,
        'relationships' => [
            'solicitud' => 'belongsTo:Solicitud'
        ]
    ],
    
    'Asignacion' => [
        'table' => 'asignaciones',
        'singular' => 'asignacion',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'centro_balance_id' => ['type' => 'number', 'label' => 'Centro Balance ID'],
            'linea_credito_id' => ['type' => 'number', 'label' => 'Línea Crédito ID'],
            'fuente_finan_id' => ['type' => 'number', 'label' => 'Fuente Financiamiento ID'],
            'año_asignacion' => ['type' => 'number', 'label' => 'Año Asignación'],
            'valor' => ['type' => 'number', 'label' => 'Valor'],
        ],
        'has_timestamps' => false,
        'relationships' => [
            'centro_balance' => 'belongsTo:BalanceCenter',
            'linea_credito' => 'belongsTo:CreditLine',
            'fuente_financiamiento' => 'belongsTo:FinancingSource'
        ]
    ],
    
    'BalanceCenter' => [
        'table' => 'balance_centers',
        'singular' => 'balance_center',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'nombre' => ['type' => 'string', 'label' => 'Nombre'],
            'activo' => ['type' => 'boolean', 'label' => 'Activo'],
            'osde_id' => ['type' => 'number', 'label' => 'OSDE ID'],
        ],
        'has_timestamps' => false,
        'relationships' => [
            'osde' => 'belongsTo:OSDE',
            'asignaciones' => 'hasMany:Asignacion'
        ]
    ],
    
    'Banco' => [
        'table' => 'bancos',
        'singular' => 'banco',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'nombre' => ['type' => 'string', 'label' => 'Nombre'],
            'pais_id' => ['type' => 'number', 'label' => 'País ID'],
        ],
        'has_timestamps' => false,
        'relationships' => [
            'pais' => 'belongsTo:Pais'
        ]
    ],
    
    'Cache' => [
        'table' => 'cache',
        'singular' => 'cache',
        'primary_key' => 'key',
        'key_type' => 'string',
        'fields' => [
            'key' => ['type' => 'string', 'label' => 'Key'],
            'value' => ['type' => 'text', 'label' => 'Value'],
            'expiration' => ['type' => 'number', 'label' => 'Expiration'],
        ],
        'has_timestamps' => false,
        'relationships' => []
    ],
    
    'CacheLock' => [
        'table' => 'cache_locks',
        'singular' => 'cache_lock',
        'primary_key' => 'key',
        'key_type' => 'string',
        'fields' => [
            'key' => ['type' => 'string', 'label' => 'Key'],
            'owner' => ['type' => 'string', 'label' => 'Owner'],
            'expiration' => ['type' => 'number', 'label' => 'Expiration'],
        ],
        'has_timestamps' => false,
        'relationships' => []
    ],
    
    'Capacidad' => [
        'table' => 'capacidades',
        'singular' => 'capacidad',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'codigo' => ['type' => 'string', 'label' => 'Código'],
            'descripcion' => ['type' => 'string', 'label' => 'Descripción'],
        ],
        'has_timestamps' => false,
        'relationships' => []
    ],
    
    'Carga' => [
        'table' => 'cargas',
        'singular' => 'carga',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'tipo_carga_id' => ['type' => 'number', 'label' => 'Tipo Carga ID'],
            'embarque_id' => ['type' => 'number', 'label' => 'Embarque ID'],
            'cantidad' => ['type' => 'number', 'label' => 'Cantidad'],
            'real' => ['type' => 'number', 'label' => 'Real'],
        ],
        'has_timestamps' => false,
        'relationships' => [
            'tipo_carga' => 'belongsTo:LoadType',
            'embarque' => 'belongsTo:Embarque'
        ]
    ],
    
    'Claim' => [
        'table' => 'reclamaciones',
        'singular' => 'claim',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'embarque_id' => ['type' => 'number', 'label' => 'Embarque ID'],
            'descripcion' => ['type' => 'string', 'label' => 'Descripción'],
        ],
        'has_timestamps' => false,
        'relationships' => [
            'embarque' => 'belongsTo:Embarque'
        ]
    ],
    
    'Classification' => [
        'table' => 'classifications',
        'singular' => 'classification',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'nombre' => ['type' => 'string', 'label' => 'Nombre'],
            'con_valor_ctto' => ['type' => 'boolean', 'label' => 'Con Valor Contrato'],
            'orden' => ['type' => 'number', 'label' => 'Orden'],
        ],
        'has_timestamps' => false,
        'relationships' => []
    ],
    
    'Cliente' => [
        'table' => 'clientes',
        'singular' => 'cliente',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'nombre' => ['type' => 'string', 'label' => 'Nombre'],
            'bases_presentadas' => ['type' => 'boolean', 'label' => 'Bases Presentadas'],
            'fecha_bases' => ['type' => 'datetime', 'label' => 'Fecha Bases'],
        ],
        'has_timestamps' => false,
        'relationships' => []
    ],
    
    'Contrato' => [
        'table' => 'contratos',
        'singular' => 'contrato',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'proveedor_id' => ['type' => 'number', 'label' => 'Proveedor ID'],
            'numero_contrato' => ['type' => 'string', 'label' => 'Número Contrato'],
            'valor_moneda_prov' => ['type' => 'number', 'label' => 'Valor Moneda Proveedor'],
            'moneda_id' => ['type' => 'number', 'label' => 'Moneda ID'],
            'forma_pago' => ['type' => 'string', 'label' => 'Forma de Pago'],
            'valor_cuc' => ['type' => 'number', 'label' => 'Valor CUC'],
            'concluido' => ['type' => 'boolean', 'label' => 'Concluido'],
            'observaciones' => ['type' => 'text', 'label' => 'Observaciones'],
            'cancelado' => ['type' => 'boolean', 'label' => 'Cancelado'],
        ],
        'has_timestamps' => false,
        'relationships' => [
            'proveedor' => 'belongsTo:Provider',
            'moneda' => 'belongsTo:Currency',
            'datos_soe' => 'hasMany:DatosSOE'
        ]
    ],
    
    'ContratoDescription' => [
        'table' => 'descripcion_contrato',
        'singular' => 'contrato_description',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'solicitud_id' => ['type' => 'number', 'label' => 'Solicitud ID'],
            'contrato_id' => ['type' => 'number', 'label' => 'Contrato ID'],
            'producto' => ['type' => 'string', 'label' => 'Producto'],
            'unidad_medida' => ['type' => 'string', 'label' => 'Unidad Medida'],
            'cantidad' => ['type' => 'number', 'label' => 'Cantidad'],
            'precio_cuc' => ['type' => 'number', 'label' => 'Precio CUC'],
            'precio_moneda_prov' => ['type' => 'number', 'label' => 'Precio Moneda Proveedor'],
            'moneda_id' => ['type' => 'number', 'label' => 'Moneda ID'],
        ],
        'has_timestamps' => false,
        'relationships' => [
            'solicitud' => 'belongsTo:Solicitud',
            'contrato' => 'belongsTo:Contrato',
            'moneda' => 'belongsTo:Currency'
        ]
    ],
    
    'ContratoSuministro' => [
        'table' => 'contrato_suministro',
        'singular' => 'contrato_suministro',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'numero_contrato' => ['type' => 'string', 'label' => 'Número Contrato'],
            'cliente_id' => ['type' => 'number', 'label' => 'Cliente ID'],
            'descripcion' => ['type' => 'string', 'label' => 'Descripción'],
            'observaciones' => ['type' => 'text', 'label' => 'Observaciones'],
        ],
        'has_timestamps' => false,
        'relationships' => [
            'cliente' => 'belongsTo:Cliente',
            'pagos_cliente' => 'hasMany:PagoCliente'
        ]
    ],
    
    'ControlUsuario' => [
        'table' => 'control_usuarios',
        'singular' => 'control_usuario',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'usuario_id' => ['type' => 'string', 'label' => 'Usuario ID'],
            'entrada' => ['type' => 'datetime', 'label' => 'Entrada'],
            'salida' => ['type' => 'datetime', 'label' => 'Salida'],
        ],
        'has_timestamps' => false,
        'relationships' => [
            'usuario' => 'belongsTo:User'
        ]
    ],
    
    'CreditLine' => [
        'table' => 'credit_lines',
        'singular' => 'credit_line',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'nombre' => ['type' => 'string', 'label' => 'Nombre'],
        ],
        'has_timestamps' => false,
        'relationships' => []
    ],
];

echo "Iniciando generación de recursos...\n";

// Crear directorios necesarios
$directories = [
    app_path('Http/Controllers'),
    app_path('Exports'),
    resource_path('views'),
    base_path('routes')
];

foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
        echo "Directorio creado: {$dir}\n";
    }
}

// Funciones de generación simplificadas
function generateController($modelName, $config) {
    $singular = $config['singular'];
    $plural = strtolower($modelName);
    $routeName = StrHelper::kebab($plural);
    $primaryKey = $config['primary_key'];
    
    $controllerTemplate = "<?php\n\n";
    $controllerTemplate .= "namespace App\\Http\\Controllers;\n\n";
    $controllerTemplate .= "use App\\Models\\{$modelName};\n";
    $controllerTemplate .= "use Illuminate\\Http\\Request;\n";
    $controllerTemplate .= "use DataTables;\n";
    $controllerTemplate .= "use App\\Exports\\{$modelName}Export;\n";
    $controllerTemplate .= "use Maatwebsite\\Excel\\Facades\\Excel;\n";
    $controllerTemplate .= "use PDF;\n\n";
    $controllerTemplate .= "class {$modelName}Controller extends Controller\n";
    $controllerTemplate .= "{\n";
    $controllerTemplate .= "    public function index(Request \$request)\n";
    $controllerTemplate .= "    {\n";
    $controllerTemplate .= "        if (\$request->ajax()) {\n";
    $controllerTemplate .= "            return \$this->getData(\$request);\n";
    $controllerTemplate .= "        }\n";
    $controllerTemplate .= "        return view('{$plural}.index');\n";
    $controllerTemplate .= "    }\n\n";
    
    $controllerTemplate .= "    private function getData(Request \$request)\n";
    $controllerTemplate .= "    {\n";
    $controllerTemplate .= "        \$query = {$modelName}::query();\n\n";
    
    // Filtrar por campos de fecha
    foreach ($config['fields'] as $field => $info) {
        if ($info['type'] == 'datetime' || $info['type'] == 'date') {
            $controllerTemplate .= "        if (\$request->has('{$field}_from') && \$request->{$field}_from) {\n";
            $controllerTemplate .= "            \$query->whereDate('{$field}', '>=', \$request->{$field}_from);\n";
            $controllerTemplate .= "        }\n";
            $controllerTemplate .= "        if (\$request->has('{$field}_to') && \$request->{$field}_to) {\n";
            $controllerTemplate .= "            \$query->whereDate('{$field}', '<=', \$request->{$field}_to);\n";
            $controllerTemplate .= "        }\n";
        }
    }
    
    $controllerTemplate .= "        return DataTables::eloquent(\$query)\n";
    $controllerTemplate .= "            ->addColumn('actions', function(\${$singular}) {\n";
    $controllerTemplate .= "                return view('{$plural}.partials.actions', compact('{$singular}'))->render();\n";
    $controllerTemplate .= "            })\n";
    $controllerTemplate .= "            ->rawColumns(['actions'])\n";
    $controllerTemplate .= "            ->make(true);\n";
    $controllerTemplate .= "    }\n\n";
    
    $controllerTemplate .= "    public function create()\n";
    $controllerTemplate .= "    {\n";
    $controllerTemplate .= "        return view('{$plural}.create');\n";
    $controllerTemplate .= "    }\n\n";
    
    $controllerTemplate .= "    public function store(Request \$request)\n";
    $controllerTemplate .= "    {\n";
    $controllerTemplate .= "        \$request->validate([\n";
    foreach ($config['fields'] as $field => $info) {
        if ($field != $primaryKey) {
            $required = in_array($field, ['nombre', 'name', 'email', 'codigo', 'numero']) ? 'required' : 'nullable';
            $controllerTemplate .= "            '{$field}' => '{$required}',\n";
        }
    }
    $controllerTemplate .= "        ]);\n\n";
    $controllerTemplate .= "        {$modelName}::create(\$request->all());\n";
    $controllerTemplate .= "        return redirect()->route('{$routeName}.index')->with('success', '{$modelName} creado exitosamente.');\n";
    $controllerTemplate .= "    }\n\n";
    
    $controllerTemplate .= "    public function show({$modelName} \${$singular})\n";
    $controllerTemplate .= "    {\n";
    $controllerTemplate .= "        return view('{$plural}.show', compact('{$singular}'));\n";
    $controllerTemplate .= "    }\n\n";
    
    $controllerTemplate .= "    public function edit({$modelName} \${$singular})\n";
    $controllerTemplate .= "    {\n";
    $controllerTemplate .= "        return view('{$plural}.edit', compact('{$singular}'));\n";
    $controllerTemplate .= "    }\n\n";
    
    $controllerTemplate .= "    public function update(Request \$request, {$modelName} \${$singular})\n";
    $controllerTemplate .= "    {\n";
    $controllerTemplate .= "        \$request->validate([\n";
    foreach ($config['fields'] as $field => $info) {
        if ($field != $primaryKey) {
            $required = in_array($field, ['nombre', 'name', 'email', 'codigo', 'numero']) ? 'required' : 'nullable';
            $controllerTemplate .= "            '{$field}' => '{$required}',\n";
        }
    }
    $controllerTemplate .= "        ]);\n\n";
    $controllerTemplate .= "        \${$singular}->update(\$request->all());\n";
    $controllerTemplate .= "        return redirect()->route('{$routeName}.index')->with('success', '{$modelName} actualizado exitosamente.');\n";
    $controllerTemplate .= "    }\n\n";
    
    $controllerTemplate .= "    public function destroy({$modelName} \${$singular})\n";
    $controllerTemplate .= "    {\n";
    $controllerTemplate .= "        \${$singular}->delete();\n";
    $controllerTemplate .= "        return response()->json(['success' => '{$modelName} eliminado exitosamente.']);\n";
    $controllerTemplate .= "    }\n\n";
    
    $controllerTemplate .= "    public function export()\n";
    $controllerTemplate .= "    {\n";
    $controllerTemplate .= "        \$fields = [\n";
    foreach ($config['fields'] as $field => $info) {
        $controllerTemplate .= "            '{$field}' => '" . addslashes($info['label']) . "',\n";
    }
    $controllerTemplate .= "        ];\n";
    $controllerTemplate .= "        return view('{$plural}.export', compact('fields'));\n";
    $controllerTemplate .= "    }\n\n";
    
    $controllerTemplate .= "    public function exportProcess(Request \$request)\n";
    $controllerTemplate .= "    {\n";
    $controllerTemplate .= "        \$request->validate([\n";
    $controllerTemplate .= "            'format' => 'required|in:excel,csv,pdf',\n";
    $controllerTemplate .= "            'columns' => 'array',\n";
    $controllerTemplate .= "            'columns.*' => 'string'\n";
    $controllerTemplate .= "        ]);\n\n";
    $controllerTemplate .= "        \$query = {$modelName}::query();\n\n";
    
    foreach ($config['fields'] as $field => $info) {
        if ($info['type'] == 'datetime' || $info['type'] == 'date') {
            $controllerTemplate .= "        if (\$request->has('{$field}_from') && \$request->{$field}_from) {\n";
            $controllerTemplate .= "            \$query->whereDate('{$field}', '>=', \$request->{$field}_from);\n";
            $controllerTemplate .= "        }\n";
            $controllerTemplate .= "        if (\$request->has('{$field}_to') && \$request->{$field}_to) {\n";
            $controllerTemplate .= "            \$query->whereDate('{$field}', '<=', \$request->{$field}_to);\n";
            $controllerTemplate .= "        }\n";
        }
    }
    
    $controllerTemplate .= "        \$data = \$query->get();\n\n";
    $controllerTemplate .= "        \$columns = \$request->columns ?? array_keys(\$fields);\n";
    $controllerTemplate .= "        \$filename = '{$plural}_' . date('Ymd_His') . '.' . \$request->format;\n\n";
    $controllerTemplate .= "        switch (\$request->format) {\n";
    $controllerTemplate .= "            case 'excel':\n";
    $controllerTemplate .= "                return Excel::download(new {$modelName}Export(\$data, \$columns), \$filename);\n";
    $controllerTemplate .= "            case 'csv':\n";
    $controllerTemplate .= "                return Excel::download(new {$modelName}Export(\$data, \$columns), \$filename, \\Maatwebsite\\Excel\\Excel::CSV);\n";
    $controllerTemplate .= "            case 'pdf':\n";
    $controllerTemplate .= "                \$pdf = PDF::loadView('{$plural}.pdf', compact('data'));\n";
    $controllerTemplate .= "                return \$pdf->download(\$filename);\n";
    $controllerTemplate .= "        }\n";
    $controllerTemplate .= "    }\n\n";
    
    $controllerTemplate .= "    public function pdf()\n";
    $controllerTemplate .= "    {\n";
    $controllerTemplate .= "        \$data = {$modelName}::all();\n";
    $controllerTemplate .= "        return view('{$plural}.pdf', compact('data'));\n";
    $controllerTemplate .= "    }\n";
    $controllerTemplate .= "}\n";
    
    $controllerPath = app_path("Http/Controllers/{$modelName}Controller.php");
    file_put_contents($controllerPath, $controllerTemplate);
    
    return $controllerPath;
}

function generateModel($modelName, $config) {
    $table = $config['table'];
    $primaryKey = $config['primary_key'];
    $keyType = $config['key_type'] == 'string' ? 'string' : 'int';
    $incrementing = $config['key_type'] == 'string' ? 'false' : 'true';
    $timestamps = $config['has_timestamps'] ? 'true' : 'false';
    
    $modelTemplate = "<?php\n\n";
    $modelTemplate .= "namespace App\\Models;\n\n";
    $modelTemplate .= "use Illuminate\\Database\\Eloquent\\Model;\n\n";
    $modelTemplate .= "class {$modelName} extends Model\n";
    $modelTemplate .= "{\n";
    $modelTemplate .= "    protected \$table = '{$table}';\n";
    $modelTemplate .= "    protected \$primaryKey = '{$primaryKey}';\n";
    $modelTemplate .= "    public \$incrementing = {$incrementing};\n";
    $modelTemplate .= "    protected \$keyType = '{$keyType}';\n";
    $modelTemplate .= "    public \$timestamps = {$timestamps};\n\n";
    
    // Fillable fields
    $fillable = [];
    foreach ($config['fields'] as $field => $info) {
        $fillable[] = "'{$field}'";
    }
    $modelTemplate .= "    protected \$fillable = [\n        " . implode(",\n        ", $fillable) . "\n    ];\n\n";
    
    // Casts
    $casts = [];
    foreach ($config['fields'] as $field => $info) {
        if ($info['type'] == 'boolean') {
            $casts[] = "'{$field}' => 'boolean'";
        } elseif ($info['type'] == 'datetime') {
            $casts[] = "'{$field}' => 'datetime'";
        } elseif ($info['type'] == 'number') {
            $casts[] = "'{$field}' => 'float'";
        }
    }
    if (!empty($casts)) {
        $modelTemplate .= "    protected \$casts = [\n        " . implode(",\n        ", $casts) . "\n    ];\n\n";
    }
    
    // Relationships
    if (!empty($config['relationships'])) {
        foreach ($config['relationships'] as $relation => $type) {
            $parts = explode(':', $type);
            $relationType = $parts[0];
            $relatedModel = $parts[1] ?? '';
            
            if ($relatedModel) {
                $methodName = StrHelper::camel($relation);
                
                if ($relationType == 'belongsTo') {
                    $modelTemplate .= "    public function {$methodName}()\n";
                    $modelTemplate .= "    {\n";
                    $modelTemplate .= "        return \$this->belongsTo({$relatedModel}::class);\n";
                    $modelTemplate .= "    }\n\n";
                } elseif ($relationType == 'hasMany') {
                    $modelTemplate .= "    public function {$methodName}()\n";
                    $modelTemplate .= "    {\n";
                    $modelTemplate .= "        return \$this->hasMany({$relatedModel}::class);\n";
                    $modelTemplate .= "    }\n\n";
                } elseif ($relationType == 'belongsToMany') {
                    $modelTemplate .= "    public function {$methodName}()\n";
                    $modelTemplate .= "    {\n";
                    $modelTemplate .= "        return \$this->belongsToMany({$relatedModel}::class);\n";
                    $modelTemplate .= "    }\n\n";
                }
            }
        }
    }
    
    $modelTemplate .= "}\n";
    
    $modelPath = app_path("Models/{$modelName}.php");
    file_put_contents($modelPath, $modelTemplate);
    
    return $modelPath;
}

function generateExporter($modelName, $config) {
    $exporterTemplate = "<?php\n\n";
    $exporterTemplate .= "namespace App\\Exports;\n\n";
    $exporterTemplate .= "use App\\Models\\{$modelName};\n";
    $exporterTemplate .= "use Maatwebsite\\Excel\\Concerns\\FromCollection;\n";
    $exporterTemplate .= "use Maatwebsite\\Excel\\Concerns\\WithHeadings;\n";
    $exporterTemplate .= "use Maatwebsite\\Excel\\Concerns\\WithMapping;\n\n";
    $exporterTemplate .= "class {$modelName}Export implements FromCollection, WithHeadings, WithMapping\n";
    $exporterTemplate .= "{\n";
    $exporterTemplate .= "    protected \$data;\n";
    $exporterTemplate .= "    protected \$columns;\n\n";
    $exporterTemplate .= "    public function __construct(\$data, \$columns = [])\n";
    $exporterTemplate .= "    {\n";
    $exporterTemplate .= "        \$this->data = \$data;\n";
    $exporterTemplate .= "        \$this->columns = \$columns;\n";
    $exporterTemplate .= "    }\n\n";
    $exporterTemplate .= "    public function collection()\n";
    $exporterTemplate .= "    {\n";
    $exporterTemplate .= "        return \$this->data;\n";
    $exporterTemplate .= "    }\n\n";
    $exporterTemplate .= "    public function headings(): array\n";
    $exporterTemplate .= "    {\n";
    $exporterTemplate .= "        \$headings = [];\n\n";
    $exporterTemplate .= "        foreach (\$this->columns as \$column) {\n";
    $exporterTemplate .= "            switch (\$column) {\n";
    foreach ($config['fields'] as $field => $info) {
        $exporterTemplate .= "                case '{$field}':\n";
        $exporterTemplate .= "                    \$headings[] = '" . addslashes($info['label']) . "';\n";
        $exporterTemplate .= "                    break;\n";
    }
    $exporterTemplate .= "            }\n";
    $exporterTemplate .= "        }\n\n";
    $exporterTemplate .= "        return \$headings;\n";
    $exporterTemplate .= "    }\n\n";
    $exporterTemplate .= "    public function map(\$row): array\n";
    $exporterTemplate .= "    {\n";
    $exporterTemplate .= "        \$mappedRow = [];\n\n";
    $exporterTemplate .= "        foreach (\$this->columns as \$column) {\n";
    $exporterTemplate .= "            switch (\$column) {\n";
    foreach ($config['fields'] as $field => $info) {
        $exporterTemplate .= "                case '{$field}':\n";
        if ($info['type'] == 'datetime') {
            $exporterTemplate .= "                    \$mappedRow[] = \$row->{$field} ? \$row->{$field}->format('d/m/Y H:i') : '';\n";
        } elseif ($info['type'] == 'boolean') {
            $exporterTemplate .= "                    \$mappedRow[] = \$row->{$field} ? 'Sí' : 'No';\n";
        } else {
            $exporterTemplate .= "                    \$mappedRow[] = \$row->{$field};\n";
        }
        $exporterTemplate .= "                    break;\n";
    }
    $exporterTemplate .= "            }\n";
    $exporterTemplate .= "        }\n\n";
    $exporterTemplate .= "        return \$mappedRow;\n";
    $exporterTemplate .= "    }\n";
    $exporterTemplate .= "}\n";
    
    $exporterPath = app_path("Exports/{$modelName}Export.php");
    file_put_contents($exporterPath, $exporterTemplate);
    
    return $exporterPath;
}

function generateIndexView($modelName, $config, $viewDir) {
    $plural = strtolower($modelName);
    $singular = $config['singular'];
    $routeName = StrHelper::kebab($plural);
    
    $headers = '';
    $columns = '';
    
    // Add ID column first
    if (isset($config['fields']['id'])) {
        $headers .= "<th>ID</th>\n                                    ";
        $columns .= "{ data: 'id', name: 'id' },\n                ";
    }
    
    // Add other fields (limit to 5 for display)
    $fieldCount = 0;
    foreach ($config['fields'] as $field => $info) {
        if ($field == 'id') continue;
        if (in_array($field, ['upsize_ts', 'password', 'remember_token', 'logo'])) continue;
        if ($fieldCount >= 5) continue;
        
        $headers .= "<th>{$info['label']}</th>\n                                    ";
        $columns .= "{ data: '{$field}', name: '{$field}' },\n                ";
        
        $fieldCount++;
    }
    
    $headers = rtrim($headers);
    $columns = rtrim($columns, ",\n                ");
    
    $content = <<<HTML
@extends('layouts.app')

@section('title', '{$modelName}')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="card-title">{$modelName}</h3>
                        <div>
                            <a href="{{ route('{$routeName}.create') }}" class="btn btn-primary">
                                <i class="fas fa-plus"></i> Nuevo {$modelName}
                            </a>
                            <a href="{{ route('{$routeName}.export') }}" class="btn btn-success">
                                <i class="fas fa-file-export"></i> Exportar
                            </a>
                            <a href="{{ route('{$routeName}.pdf') }}" class="btn btn-danger" target="_blank">
                                <i class="fas fa-file-pdf"></i> PDF
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="{$plural}-table" class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr>
                                    {$headers}
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    \$(document).ready(function() {
        $('#{$plural}-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('{$routeName}.index') }}",
            columns: [
                {$columns},
                { 
                    data: 'actions', 
                    name: 'actions', 
                    orderable: false, 
                    searchable: false,
                    className: 'text-center'
                }
            ],
            language: {
                url: "//cdn.datatables.net/plug-ins/1.10.25/i18n/Spanish.json"
            },
            order: [[0, 'desc']],
            pageLength: 25,
            responsive: true
        });
    });
</script>
@endpush
HTML;
    
    $viewPath = "{$viewDir}/index.blade.php";
    file_put_contents($viewPath, $content);
    
    return $viewPath;
}

function generateCreateView($modelName, $config, $viewDir) {
    $plural = strtolower($modelName);
    $singular = $config['singular'];
    $routeName = StrHelper::kebab($plural);
    
    $formFields = '';
    
    foreach ($config['fields'] as $field => $info) {
        if ($field == 'id' || $field == 'created_at' || $field == 'updated_at') continue;
        
        $type = $info['type'] == 'text' ? 'textarea' : 
                ($info['type'] == 'number' ? 'number' : 
                ($info['type'] == 'datetime' ? 'datetime-local' : 
                ($info['type'] == 'boolean' ? 'select' : 'text')));
        
        $required = in_array($field, ['nombre', 'name', 'email', 'codigo', 'numero']) ? 'required' : '';
        
        if ($type == 'textarea') {
            $formFields .= <<<HTML
                        <div class="form-group">
                            <label for="{$field}">{$info['label']}</label>
                            <textarea class="form-control @error('{$field}') is-invalid @enderror" 
                                      id="{$field}" name="{$field}" rows="3" {$required}>{{ old('{$field}') }}</textarea>
                            @error('{$field}')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ \$message }}</strong>
                                </span>
                            @enderror
                        </div>
HTML;
        } elseif ($type == 'select' && $info['type'] == 'boolean') {
            $formFields .= <<<HTML
                        <div class="form-group">
                            <label for="{$field}">{$info['label']}</label>
                            <select class="form-control @error('{$field}') is-invalid @enderror" 
                                   id="{$field}" name="{$field}" {$required}>
                                <option value="1" {{ old('{$field}') == '1' ? 'selected' : '' }}>Sí</option>
                                <option value="0" {{ old('{$field}') == '0' ? 'selected' : '' }}>No</option>
                            </select>
                            @error('{$field}')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ \$message }}</strong>
                                </span>
                            @enderror
                        </div>
HTML;
        } else {
            $formFields .= <<<HTML
                        <div class="form-group">
                            <label for="{$field}">{$info['label']}</label>
                            <input type="{$type}" class="form-control @error('{$field}') is-invalid @enderror" 
                                   id="{$field}" name="{$field}" value="{{ old('{$field}') }}" {$required}>
                            @error('{$field}')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ \$message }}</strong>
                                </span>
                            @enderror
                        </div>
HTML;
        }
    }
    
    $content = <<<HTML
@extends('layouts.app')

@section('title', 'Crear {$modelName}')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Crear Nuevo {$modelName}</h3>
                    <div class="card-tools">
                        <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    </div>
                </div>
                <form action="{{ route('{$routeName}.store') }}" method="POST">
                    @csrf
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                {$formFields}
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Guardar
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <i class="fas fa-redo"></i> Limpiar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
HTML;
    
    $viewPath = "{$viewDir}/create.blade.php";
    file_put_contents($viewPath, $content);
    
    return $viewPath;
}

function generateEditView($modelName, $config, $viewDir) {
    $plural = strtolower($modelName);
    $singular = $config['singular'];
    $routeName = StrHelper::kebab($plural);
    $primaryKey = $config['primary_key'];
    
    $formFields = '';
    
    foreach ($config['fields'] as $field => $info) {
        if ($field == 'id' || $field == 'created_at' || $field == 'updated_at') continue;
        
        $type = $info['type'] == 'text' ? 'textarea' : 
                ($info['type'] == 'number' ? 'number' : 
                ($info['type'] == 'datetime' ? 'datetime-local' : 
                ($info['type'] == 'boolean' ? 'select' : 'text')));
        
        $required = in_array($field, ['nombre', 'name', 'email', 'codigo', 'numero']) ? 'required' : '';
        
        $valueField = '';
        if ($type == 'datetime-local') {
            $valueField = "{{\${$singular}->{$field} ? \${$singular}->{$field}->format('Y-m-d\\\TH:i') : ''}}";
        } elseif ($type == 'textarea') {
            $valueField = "{{ old('{$field}', \${$singular}->{$field}) }}";
        } else {
            $valueField = "{{ old('{$field}', \${$singular}->{$field}) }}";
        }
        
        if ($type == 'textarea') {
            $formFields .= <<<HTML
                        <div class="form-group">
                            <label for="{$field}">{$info['label']}</label>
                            <textarea class="form-control @error('{$field}') is-invalid @enderror" 
                                      id="{$field}" name="{$field}" rows="3" {$required}>{$valueField}</textarea>
                            @error('{$field}')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ \$message }}</strong>
                                </span>
                            @enderror
                        </div>
HTML;
        } elseif ($type == 'select' && $info['type'] == 'boolean') {
            $selected1 = "{{\${$singular}->{$field} == 1 ? 'selected' : ''}}";
            $selected0 = "{{\${$singular}->{$field} == 0 ? 'selected' : ''}}";
            $formFields .= <<<HTML
                        <div class="form-group">
                            <label for="{$field}">{$info['label']}</label>
                            <select class="form-control @error('{$field}') is-invalid @enderror" 
                                   id="{$field}" name="{$field}" {$required}>
                                <option value="1" {$selected1}>Sí</option>
                                <option value="0" {$selected0}>No</option>
                            </select>
                            @error('{$field}')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ \$message }}</strong>
                                </span>
                            @enderror
                        </div>
HTML;
        } else {
            $formFields .= <<<HTML
                        <div class="form-group">
                            <label for="{$field}">{$info['label']}</label>
                            <input type="{$type}" class="form-control @error('{$field}') is-invalid @enderror" 
                                   id="{$field}" name="{$field}" value="{$valueField}" {$required}>
                            @error('{$field}')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ \$message }}</strong>
                                </span>
                            @enderror
                        </div>
HTML;
        }
    }
    
    $content = <<<HTML
@extends('layouts.app')

@section('title', 'Editar {$modelName}')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Editar {$modelName}</h3>
                    <div class="card-tools">
                        <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    </div>
                </div>
                <form action="{{ route('{$routeName}.update', \${$singular}->{$primaryKey}) }}" method="POST">
                    @csrf
                    @method('PUT')
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                {$formFields}
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Actualizar
                        </button>
                        <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancelar
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
HTML;
    
    $viewPath = "{$viewDir}/edit.blade.php";
    file_put_contents($viewPath, $content);
    
    return $viewPath;
}

function generateShowView($modelName, $config, $viewDir) {
    $plural = strtolower($modelName);
    $singular = $config['singular'];
    $routeName = StrHelper::kebab($plural);
    $primaryKey = $config['primary_key'];
    
    $infoBoxes = '';
    $counter = 0;
    
    foreach ($config['fields'] as $field => $info) {
        $counter++;
        $colClass = 'col-md-6';
        
        $infoBoxes .= <<<HTML
                        <div class="{$colClass}">
                            <div class="info-box">
                                <span class="info-box-icon bg-info"><i class="fas fa-tag"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">{$info['label']}</span>
                                    <span class="info-box-number">{{ \${$singular}->{$field} }}</span>
                                </div>
                            </div>
                        </div>
HTML;
    }
    
    $content = <<<HTML
@extends('layouts.app')

@section('title', 'Detalles {$modelName}')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Detalles del {$modelName}</h3>
                    <div class="card-tools">
                        <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        {$infoBoxes}
                    </div>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-between">
                        <div>
                            <a href="{{ route('{$routeName}.edit', \${$singular}->{$primaryKey}) }}" class="btn btn-warning">
                                <i class="fas fa-edit"></i> Editar
                            </a>
                        </div>
                        <div>
                            <form action="{{ route('{$routeName}.destroy', \${$singular}->{$primaryKey}) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger" onclick="return confirm('¿Está seguro de eliminar este registro?')">
                                    <i class="fas fa-trash"></i> Eliminar
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
HTML;
    
    $viewPath = "{$viewDir}/show.blade.php";
    file_put_contents($viewPath, $content);
    
    return $viewPath;
}

function generateExportView($modelName, $config, $viewDir) {
    $plural = strtolower($modelName);
    $singular = $config['singular'];
    $routeName = StrHelper::kebab($plural);
    
    $checkboxes = '';
    foreach ($config['fields'] as $field => $info) {
        if ($field == 'password' || $field == 'remember_token') continue;
        $checkboxes .= <<<HTML
                            <div class="form-check col-md-4">
                                <input class="form-check-input column-checkbox" type="checkbox" id="{$field}_column" name="columns[]" value="{$field}" checked>
                                <label class="form-check-label" for="{$field}_column">{$info['label']}</label>
                            </div>
HTML;
    }
    
    $content = <<<HTML
@extends('layouts.app')

@section('title', 'Exportar {$modelName}')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h3 class="card-title">Exportar {$modelName}</h3>
                </div>
                <div class="card-body">
                    <form action="{{ route('{$routeName}.export.process') }}" method="POST">
                        @csrf
                        
                        <div class="form-group">
                            <label for="format">Formato de Exportación *</label>
                            <select class="form-control @error('format') is-invalid @enderror" id="format" name="format" required>
                                <option value="">Seleccione un formato</option>
                                <option value="excel">Excel (.xlsx)</option>
                                <option value="csv">CSV (.csv)</option>
                                <option value="pdf">PDF (.pdf)</option>
                            </select>
                            @error('format')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ \$message }}</strong>
                                </span>
                            @enderror
                        </div>
                        
                        <div class="form-group">
                            <label for="columns">Columnas a Exportar</label>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="select_all" onchange="toggleSelectAll(this)">
                                        <label class="form-check-label" for="select_all">Seleccionar Todos</label>
                                    </div>
                                </div>
                                {$checkboxes}
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="fecha_inicio">Fecha Inicio</label>
                            <input type="date" class="form-control" id="fecha_inicio" name="fecha_inicio">
                        </div>
                        
                        <div class="form-group">
                            <label for="fecha_fin">Fecha Fin</label>
                            <input type="date" class="form-control" id="fecha_fin" name="fecha_fin">
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> Seleccione el formato y opciones de exportación para generar el archivo.
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-file-export"></i> Exportar
                        </button>
                        <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancelar
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const today = new Date();
        const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
        
        document.getElementById('fecha_fin').value = today.toISOString().split('T')[0];
        document.getElementById('fecha_inicio').value = firstDay.toISOString().split('T')[0];
    });

    function toggleSelectAll(source) {
        const checkboxes = document.querySelectorAll('.column-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = source.checked;
        });
    }
</script>
@endpush
HTML;
    
    $viewPath = "{$viewDir}/export.blade.php";
    file_put_contents($viewPath, $content);
    
    return $viewPath;
}

function generatePdfView($modelName, $config, $viewDir) {
    $plural = strtolower($modelName);
    $singular = $config['singular'];
    
    $headers = '';
    foreach ($config['fields'] as $field => $info) {
        if ($field == 'password' || $field == 'remember_token') continue;
        $headers .= "<th>{$info['label']}</th>\n                ";
    }
    
    $tbody = '';
    foreach ($config['fields'] as $field => $info) {
        if ($field == 'password' || $field == 'remember_token') continue;
        $tbody .= "<td>{{ \${$singular}->{$field} }}</td>\n                ";
    }
    
    $content = <<<HTML
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de {$modelName}</title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            line-height: 1.5;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        .header h1 {
            margin: 0;
            color: #333;
            font-size: 24px;
        }
        .header .subtitle {
            color: #666;
            font-size: 14px;
        }
        .info-box {
            margin-bottom: 20px;
            padding: 10px;
            background-color: #f8f9fa;
            border-left: 4px solid #007bff;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table th {
            background-color: #343a40;
            color: white;
            padding: 8px;
            text-align: left;
            border: 1px solid #dee2e6;
        }
        .table td {
            padding: 8px;
            border: 1px solid #dee2e6;
        }
        .table tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 10px;
            color: #666;
            border-top: 1px solid #dee2e6;
            padding-top: 10px;
        }
        .text-right { text-align: right; }
        .page-break { page-break-before: always; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Reporte de {$modelName}</h1>
        <div class="subtitle">
            Generado el: {{ date('d/m/Y H:i:s') }}
        </div>
    </div>
    
    <div class="info-box">
        <strong>Información del Reporte:</strong><br>
        Total de registros: {{ \${$plural}->count() }}<br>
        @if(request('fecha_inicio'))
            Período: {{ request('fecha_inicio') }} al {{ request('fecha_fin') }}
        @endif
    </div>
    
    <table class="table">
        <thead>
            <tr>
                {$headers}
            </tr>
        </thead>
        <tbody>
            @foreach(\${$plural} as \${$singular})
            <tr>
                {$tbody}
            </tr>
            @endforeach
        </tbody>
    </table>
    
    <div class="footer">
        Página {{ \$pageNumber ?? 1 }}<br>
        Sistema de Gestión - Generado automáticamente
    </div>
</body>
</html>
HTML;
    
    $viewPath = "{$viewDir}/pdf.blade.php";
    file_put_contents($viewPath, $content);
    
    return $viewPath;
}

function generateActionsPartial($modelName, $config, $partialsDir) {
    $singular = $config['singular'];
    $plural = strtolower($modelName);
    $routeName = StrHelper::kebab($plural);
    $primaryKey = $config['primary_key'];
    
    $content = <<<HTML
<div class="btn-group" role="group">
    <a href="{{ route('{$routeName}.show', \${$singular}->{$primaryKey}) }}" class="btn btn-info btn-sm">
        <i class="fas fa-eye"></i>
    </a>
    <a href="{{ route('{$routeName}.edit', \${$singular}->{$primaryKey}) }}" class="btn btn-warning btn-sm">
        <i class="fas fa-edit"></i>
    </a>
    <form action="{{ route('{$routeName}.destroy', \${$singular}->{$primaryKey}) }}" method="POST" class="d-inline delete-form">
        @csrf
        @method('DELETE')
        <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="{{ \${$singular}->{$primaryKey} }}">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>
HTML;
    
    $viewPath = "{$partialsDir}/actions.blade.php";
    file_put_contents($viewPath, $content);
    
    return $viewPath;
}

// Generar recursos para cada modelo
foreach ($models_config as $modelName => $config) {
    echo "Generando recursos para: {$modelName}\n";
    
    // 1. Crear directorio de vistas
    $plural = strtolower($modelName);
    $viewDir = resource_path("views/{$plural}");
    if (!is_dir($viewDir)) {
        mkdir($viewDir, 0755, true);
        echo "  ✓ Directorio de vistas creado: {$viewDir}\n";
    }
    
    // 2. Crear directorio partials
    $partialsDir = "{$viewDir}/partials";
    if (!is_dir($partialsDir)) {
        mkdir($partialsDir, 0755, true);
        echo "  ✓ Directorio partials creado\n";
    }
    
    // 3. Generar Controlador
    $controllerPath = generateController($modelName, $config);
    echo "  ✓ Controlador generado: {$controllerPath}\n";
    
    // 4. Generar Modelo
    $modelPath = generateModel($modelName, $config);
    echo "  ✓ Modelo generado: {$modelPath}\n";
    
    // 5. Generar Exportador
    $exporterPath = generateExporter($modelName, $config);
    echo "  ✓ Exportador generado: {$exporterPath}\n";
    
    // 6. Generar Vistas
    generateIndexView($modelName, $config, $viewDir);
    generateCreateView($modelName, $config, $viewDir);
    generateEditView($modelName, $config, $viewDir);
    generateShowView($modelName, $config, $viewDir);
    generateExportView($modelName, $config, $viewDir);
    generatePdfView($modelName, $config, $viewDir);
    generateActionsPartial($modelName, $config, $partialsDir);
    echo "  ✓ Vistas generadas\n";
    
    echo "\n";
}

// Generar archivo de rutas
$routesContent = "<?php\n\n// Rutas generadas automáticamente\n\n";
foreach ($models_config as $modelName => $config) {
    $plural = strtolower($modelName);
    $routeName = StrHelper::kebab($plural);
    
    $routesContent .= "// Routes for {$modelName}\n";
    $routesContent .= "Route::resource('{$routeName}', {$modelName}Controller::class);\n";
    $routesContent .= "Route::get('{$routeName}/data', [{$modelName}Controller::class, 'index'])->name('{$routeName}.data');\n";
    $routesContent .= "Route::get('{$routeName}/export', [{$modelName}Controller::class, 'export'])->name('{$routeName}.export');\n";
    $routesContent .= "Route::post('{$routeName}/export/process', [{$modelName}Controller::class, 'exportProcess'])->name('{$routeName}.export.process');\n";
    $routesContent .= "Route::get('{$routeName}/pdf', [{$modelName}Controller::class, 'pdf'])->name('{$routeName}.pdf');\n\n";
}

$routesPath = base_path('routes/generated_routes.php');
file_put_contents($routesPath, $routesContent);
echo "✓ Archivo de rutas generado: {$routesPath}\n";

echo "\n¡Generación completada!\n";
echo "\nINSTRUCCIONES:\n";
echo "1. Agrega en tu archivo routes/web.php la siguiente línea:\n";
echo "   require_once base_path('routes/generated_routes.php');\n\n";
echo "2. Asegúrate de incluir DataTables en tu layout principal.\n";
echo "3. Ejecuta las migraciones si es necesario.\n";