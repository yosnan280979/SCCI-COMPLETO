<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class IsInformatica
{
    public function handle(Request $request, Closure $next)
    {
        $user = auth()->user();
        
        if (!$user || !$user->area || $user->area->Area !== 'Informatica') {
            abort(403, 'Acceso restringido al área de Informática');
        }
        
        return $next($request);
    }
}
