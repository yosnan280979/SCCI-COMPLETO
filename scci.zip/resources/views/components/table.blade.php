<!-- resources/views/components/table.blade.php -->
@push('styles')
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">
@endpush

<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h3 class="card-title">@yield('title', 'Listado')</h3>
            <div class="btn-group">
                @if(Route::has(request()->route()->getName().'.create') && auth()->user()->userType->{'Id Tipo Usuario'} != 3)
                <a href="{{ route(request()->route()->getName().'.create') }}" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i> Nuevo
                </a>
                @endif
                @if(Route::has(request()->route()->getName().'.export'))
                <a href="{{ route(request()->route()->getName().'.export') }}" class="btn btn-success btn-sm">
                    <i class="fas fa-file-excel"></i> Excel
                </a>
                @endif
                @if(Route::has(request()->route()->getName().'.pdf'))
                <a href="{{ route(request()->route()->getName().'.pdf') }}" class="btn btn-danger btn-sm" target="_blank">
                    <i class="fas fa-file-pdf"></i> PDF
                </a>
                @endif
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered table-striped table-hover w-100">
                <thead>
                    <tr>
                        @yield('table-headers')
                    </tr>
                </thead>
                <tbody>
                    @yield('table-content')
                </tbody>
            </table>
        </div>
    </div>
</div>

@push('scripts')
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.colVis.min.js"></script>

<script>
$(document).ready(function() {
    $('#dataTable').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
        },
        dom: "<'row'<'col-sm-12 col-md-6'l><'col-sm-12 col-md-6'f>>" +
             "<'row'<'col-sm-12'tr>>" +
             "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        buttons: [
            {
                extend: 'copy',
                className: 'btn btn-secondary'
            },
            {
                extend: 'excel',
                className: 'btn btn-success'
            },
            {
                extend: 'pdf',
                className: 'btn btn-danger'
            },
            {
                extend: 'print',
                className: 'btn btn-info'
            },
            {
                extend: 'colvis',
                className: 'btn btn-warning'
            }
        ],
        pageLength: 25,
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'Todos']],
        responsive: true,
        order: [[0, 'desc']],
        @if(isset($ajax) && $ajax)
        processing: true,
        serverSide: true,
        ajax: "{{ $ajax }}",
        @endif
        columns: [
            @yield('table-columns')
        ]
    });
});
</script>
@endpush