@extends('layouts.app')

@section('title', 'Detalle Certificado de Compra')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Detalle Certificado de Compra #{{ $item->{'Id CC'} }}</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>ID:</strong> {{ $item->{'Id CC'} }}</p>
                    <p><strong>No. CC:</strong> {{ $item->{'No CC'} }}</p>
                    <p><strong>ID SOE:</strong> {{ $item->{'Id SOE'} }}</p>
                    <p><strong>Valor CC:</strong> ${{ number_format($item->{'Valor CC'}, 2) }}</p>
                    <p><strong>Moneda:</strong> {{ $item->moneda->Moneda ?? 'N/A' }}</p>
                    <p><strong>Capacidad:</strong> {{ $item->capacidad->Capacidad ?? 'N/A' }}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Momento CC:</strong> {{ $item->momentoCC->{'Momento CC'} ?? 'N/A' }}</p>
                    <p><strong>Fecha Pedido Capacidad:</strong> {{ $item->{'Fecha Pedido Cap'} ? \Carbon\Carbon::parse($item->{'Fecha Pedido Cap'})->format('d/m/Y') : '' }}</p>
                    <p><strong>Fecha Asignada Capacidad:</strong> {{ $item->{'Fecha Asignada Cap'} ? \Carbon\Carbon::parse($item->{'Fecha Asignada Cap'})->format('d/m/Y') : '' }}</p>
                    <p><strong>Fecha Presentada CC:</strong> {{ $item->{'Fecha Presentada CC'} ? \Carbon\Carbon::parse($item->{'Fecha Presentada CC'})->format('d/m/Y') : '' }}</p>
                    <p><strong>Fecha Apertura CC:</strong> {{ $item->{'Fecha Apertura CC'} ? \Carbon\Carbon::parse($item->{'Fecha Apertura CC'})->format('d/m/Y') : '' }}</p>
                    <p><strong>Año Financiero:</strong> {{ $item->{'Año finan'} }}</p>
                </div>
            </div>
            
            <div class="row mt-3">
                <div class="col-12">
                    <p><strong>Observaciones:</strong></p>
                    <div class="border p-2 rounded">
                        {{ $item->{'Observaciones CC'} ?: 'Sin observaciones' }}
                    </div>
                </div>
            </div>
            
            <div class="mt-3">
                <a href="{{ route('datos-cc.index') }}" class="btn btn-secondary">Volver</a>
                <a href="{{ route('datos-cc.edit', $item->{'Id CC'}) }}" class="btn btn-warning">Editar</a>
                <form action="{{ route('datos-cc.destroy', $item->{'Id CC'}) }}" method="POST" style="display:inline-block">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger" onclick="return confirm('¿Eliminar este certificado?')">Eliminar</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection