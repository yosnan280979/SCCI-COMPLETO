@extends('layouts.app')

@section('title', 'Detalle Datos Contrato Suministro')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Detalle de Datos Contrato Suministro #{{ $item->{'Id Supsum'} }}</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label"><strong>ID:</strong></label>
                        <p class="form-control-static">{{ $item->{'Id Supsum'} }}</p>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><strong>Contrato Suministro:</strong></label>
                        <p class="form-control-static">
                            @if($item->contratoSuministro)
                                {{ $item->contratoSuministro->{'No Ctto Suministro'} }} - {{ $item->contratoSuministro->Descripcion }}
                            @else
                                N/A
                            @endif
                        </p>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><strong>No. Suplemento:</strong></label>
                        <p class="form-control-static">{{ $item->{'No Suplemento'} }}</p>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><strong>Fecha Firma Contrato:</strong></label>
                        <p class="form-control-static">
                            {{ $item->{'Fecha firma Ctto'} ? \Carbon\Carbon::parse($item->{'Fecha firma Ctto'})->format('d/m/Y') : '' }}
                        </p>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><strong>Forma de Pago:</strong></label>
                        <p class="form-control-static">{{ $item->{'Forma de Pago'} ?? 'No especificada' }}</p>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><strong>Importe CUC:</strong></label>
                            <p class="form-control-static" style="font-weight: bold; color: #28a745;">
                                {{ number_format($item->{'Importe CUC'} ?? 0, 2) }}
                            </p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><strong>Importe CUP:</strong></label>
                            <p class="form-control-static" style="font-weight: bold; color: #28a745;">
                                {{ number_format($item->{'Importe CUP'} ?? 0, 2) }}
                            </p>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><strong>Pendiente Financiar CUC:</strong></label>
                            <p class="form-control-static" style="font-weight: bold; color: #dc3545;">
                                {{ number_format($item->{'Pendiente Finan CUC'} ?? 0, 2) }}
                            </p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><strong>Pendiente CUP:</strong></label>
                            <p class="form-control-static" style="font-weight: bold; color: #dc3545;">
                                {{ number_format($item->{'Pendiente CUP'} ?? 0, 2) }}
                            </p>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><strong>Total CUC (Importe + Pendiente):</strong></label>
                            <p class="form-control-static" style="font-weight: bold; color: #17a2b8;">
                                @php
                                    $totalCUC = ($item->{'Importe CUC'} ?? 0) + ($item->{'Pendiente Finan CUC'} ?? 0);
                                @endphp
                                {{ number_format($totalCUC, 2) }}
                            </p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><strong>Total CUP (Importe + Pendiente):</strong></label>
                            <p class="form-control-static" style="font-weight: bold; color: #17a2b8;">
                                @php
                                    $totalCUP = ($item->{'Importe CUP'} ?? 0) + ($item->{'Pendiente CUP'} ?? 0);
                                @endphp
                                {{ number_format($totalCUP, 2) }}
                            </p>
                        </div>
                    </div>
                    
                    @if($item->upsize_ts)
                    <div class="mb-3">
                        <label class="form-label"><strong>Última Actualización:</strong></label>
                        <p class="form-control-static">
                            {{ \Carbon\Carbon::parse($item->upsize_ts)->format('d/m/Y H:i:s') }}
                        </p>
                    </div>
                    @endif
                </div>
            </div>
            
            <!-- Información adicional si existe -->
            @if($item->contratoSuministro && $item->contratoSuministro->{'Observaciones Ctto Sum'})
            <div class="row mt-3">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Observaciones del Contrato Suministro</h5>
                        </div>
                        <div class="card-body">
                            <p>{{ $item->contratoSuministro->{'Observaciones Ctto Sum'} }}</p>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            
            <!-- Información del cliente relacionado -->
            @if($item->contratoSuministro && $item->contratoSuministro->cliente)
            <div class="row mt-3">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Información del Cliente</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <label><strong>Cliente:</strong></label>
                                    <p>{{ $item->contratoSuministro->cliente->Cliente }}</p>
                                </div>
                                @if($item->contratoSuministro->cliente->{'Bases Presentadas'})
                                <div class="col-md-4">
                                    <label><strong>Bases Presentadas:</strong></label>
                                    <p>Sí</p>
                                </div>
                                @endif
                                @if($item->contratoSuministro->cliente->{'Fecha Bases'})
                                <div class="col-md-4">
                                    <label><strong>Fecha Bases:</strong></label>
                                    <p>{{ \Carbon\Carbon::parse($item->contratoSuministro->cliente->{'Fecha Bases'})->format('d/m/Y') }}</p>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            
            <!-- Botones de acción -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="d-flex justify-content-between">
                        <div>
                            <a href="{{ route('datos-ctto-suministro.index') }}" class="btn btn-secondary">
                                ← Volver al Listado
                            </a>
                        </div>
                        <div class="btn-group" role="group">
                            <a href="{{ route('datos-ctto-suministro.edit', $item->{'Id Supsum'}) }}" 
                               class="btn btn-warning">
                                ✏️ Editar
                            </a>
                            <form action="{{ route('datos-ctto-suministro.destroy', $item->{'Id Supsum'}) }}" 
                                  method="POST" 
                                  style="display:inline-block"
                                  onsubmit="return confirm('¿Estás seguro de eliminar este registro?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">
                                    🗑️ Eliminar
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Información de auditoría si existe -->
            @if($item->created_at || $item->updated_at)
            <div class="row mt-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Información de Auditoría</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                @if($item->created_at)
                                <div class="col-md-6">
                                    <label><strong>Creado:</strong></label>
                                    <p>{{ \Carbon\Carbon::parse($item->created_at)->format('d/m/Y H:i:s') }}</p>
                                </div>
                                @endif
                                @if($item->updated_at)
                                <div class="col-md-6">
                                    <label><strong>Última modificación:</strong></label>
                                    <p>{{ \Carbon\Carbon::parse($item->updated_at)->format('d/m/Y H:i:s') }}</p>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>

<!-- Script para formatear números -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Formatear todos los números con separadores de miles
    document.querySelectorAll('.form-control-static').forEach(element => {
        const text = element.textContent.trim();
        // Verificar si es un número con decimales
        if (/^\d+(\.\d+)?$/.test(text)) {
            const num = parseFloat(text);
            if (!isNaN(num)) {
                element.textContent = num.toLocaleString('es-ES', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            }
        }
    });
});
</script>

<style>
.form-control-static {
    background-color: #f8f9fa;
    padding: 0.75rem;
    border-radius: 0.25rem;
    border: 1px solid #e9ecef;
    margin-bottom: 0;
    min-height: calc(1.5em + 1.5rem);
    display: block;
}

.form-label {
    font-weight: 600;
    color: #495057;
    margin-bottom: 0.5rem;
    display: block;
}

.card {
    border: 1px solid rgba(0,0,0,.125);
    border-radius: 0.25rem;
    margin-bottom: 1rem;
}

.card-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid rgba(0,0,0,.125);
    padding: 0.75rem 1.25rem;
}

.card-body {
    padding: 1.25rem;
}

.btn-group .btn {
    margin-right: 0.5rem;
}

.btn-group .btn:last-child {
    margin-right: 0;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .col-md-6, .col-md-4, .col-md-3 {
        margin-bottom: 1rem;
    }
    
    .btn-group {
        flex-direction: column;
        width: 100%;
    }
    
    .btn-group .btn {
        margin-bottom: 0.5rem;
        margin-right: 0;
        width: 100%;
    }
}
</style>
@endsection