<?php

namespace App\Exports;

use App\Models\TipoProveedor;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class TipoProveedorExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $tipoProveedores;

    public function __construct($tipoProveedores)
    {
        $this->tipoProveedores = $tipoProveedores;
    }

    public function collection()
    {
        return $this->tipoProveedores;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Tipo Proveedor',
        ];
    }

    public function map($tipoProveedor): array
    {
        return [
            $tipoProveedor->{'Id Tipo Prov'},
            $tipoProveedor->{'Tipo Proveedor'},
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}