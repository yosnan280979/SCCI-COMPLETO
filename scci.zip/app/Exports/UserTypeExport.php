<?php

namespace App\Exports;

use App\Models\UserType;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class UserTypeExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $userTypes;

    public function __construct($userTypes)
    {
        $this->userTypes = $userTypes;
    }

    public function collection()
    {
        return $this->userTypes;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Tipo de Usuario',
        ];
    }

    public function map($userType): array
    {
        return [
            $userType->{'Id Tipo Usuario'},
            $userType->{'Tipo Usuario'},
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}