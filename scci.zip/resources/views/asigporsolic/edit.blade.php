@extends('layouts.app')

@section('title', 'Editar Asignación por Solicitud')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Editar Asignación por Solicitud</h5>
        </div>
        <div class="card-body">
            <form action="{{ route('asigporsolic.update', $asigporsolic->{'Id Solicitud'}) }}" method="POST">
                @csrf
                @method('PUT')
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Id Solicitud" class="form-label">ID Solicitud *</label>
                        <input type="number" class="form-control" id="Id Solicitud" name="Id Solicitud" 
                               value="{{ old('Id Solicitud', $asigporsolic->{'Id Solicitud'}) }}" required>
                        @error('Id Solicitud')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <div class="col-md-6">
                        <label for="Año finan" class="form-label">Año financiero *</label>
                        <input type="number" class="form-control" id="Año finan" name="Año finan" 
                               value="{{ old('Año finan', $asigporsolic->{'Año finan'}) }}" required>
                        @error('Año finan')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Asig MCUC" class="form-label">Asignación MCUC</label>
                        <input type="number" step="0.01" class="form-control" id="Asig MCUC" name="Asig MCUC" 
                               value="{{ old('Asig MCUC', $asigporsolic->{'Asig MCUC'}) }}">
                        @error('Asig MCUC')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="{{ route('asigporsolic.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection