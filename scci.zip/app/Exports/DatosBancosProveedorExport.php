<?php

namespace App\Exports;

use App\Models\DatosBancosProveedor;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class DatosBancosProveedorExport implements FromCollection, WithHeadings, WithMapping
{
    protected $datos;

    // Constructor para pasar registros filtrados si lo deseas
    public function __construct($datos = null)
    {
        $this->datos = $datos;
    }

    /**
     * Devuelve la colección de registros
     */
    public function collection()
    {
        if ($this->datos) {
            return $this->datos;
        }

        return DatosBancosProveedor::with(['proveedor', 'banco', 'moneda'])->get();
    }

    /**
     * Encabezados de las columnas
     */
    public function headings(): array
    {
        return [
            'ID',
            'Proveedor',
            'Banco',
            'Moneda',
            'Número de Cuenta',
            'Titular',
        ];
    }

    /**
     * Mapeo de cada fila
     */
    public function map($dato): array
    {
        return [
            $dato->Id,
            $dato->proveedor?->{'Proveedor'} ?? '',
            $dato->banco?->{'Banco'} ?? '',
            $dato->moneda?->{'Moneda'} ?? '',
            $dato->{'Numero Cuenta'},
            $dato->Titular ?? '',
        ];
    }
}
