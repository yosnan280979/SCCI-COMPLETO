<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Certificados de Compra (CC) - Reporte PDF</title>
    <style>
        body {
            font-family: DejaVu Sans, Arial, sans-serif;
            font-size: 10px;
            margin: 0;
            padding: 5px;
        }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 5px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        h1 { text-align: center; color: #333; font-size: 16px; }
        .header { text-align: center; margin-bottom: 20px; }
        .footer { margin-top: 30px; padding-top: 10px; border-top: 1px solid #ddd; text-align: center; font-size: 9px; color: #666; }
        .text-end { text-align: right; }
        .text-center { text-align: center; }
        .badge { padding: 2px 6px; border-radius: 3px; font-size: 9px; }
        .badge-success { background-color: #d4edda; color: #155724; }
        .badge-danger { background-color: #f8d7da; color: #721c24; }
        .badge-warning { background-color: #fff3cd; color: #856404; }
        .badge-info { background-color: #d1ecf1; color: #0c5460; }
        .badge-secondary { background-color: #e2e3e5; color: #383d41; }
        .page-break { page-break-after: always; }
        .small-text { font-size: 9px; }
        .column-group { page-break-inside: avoid; }
        .section-break { margin: 15px 0; border-top: 1px dashed #ddd; }
        .nowrap { white-space: nowrap; }
        .valor { font-family: 'Courier New', monospace; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Reporte de Certificados de Compra (CC)</h1>
        <p>Fecha de generación: {{ now()->format('d/m/Y H:i:s') }}</p>
        <p>Total de registros: {{ $items->count() }}</p>
        
        @if(!empty($filtros) && count($filtros) > 0)
            <div style="margin-top: 10px; text-align: left; font-size: 9px;">
                <strong>Filtros aplicados:</strong><br>
                @foreach($filtros as $filtro)
                    @if(!empty($filtro))
                        • {{ $filtro }}<br>
                    @endif
                @endforeach
            </div>
        @endif
    </div>
    
    @if($items && $items->count() > 0)
        @foreach($items as $item)
        <div class="column-group">
            <table style="margin-bottom: 20px;">
                <thead>
                    <tr>
                        <th colspan="4" style="background-color: #e9ecef; text-align: center;">
                            Certificado de Compra #{{ $item->{'No CC'} }}
                            <span style="float: right; font-size: 9px;">
                                @if($item->{'Activo'} == 1)
                                    <span class="badge badge-success">Activo</span>
                                @elseif($item->{'Activo'} == 0)
                                    <span class="badge badge-danger">Inactivo</span>
                                @else
                                    <span class="badge badge-secondary">{{ $item->{'Activo'} ?? 'N/A' }}</span>
                                @endif
                            </span>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Información Básica -->
                    <tr>
                        <td width="20%"><strong>ID CC:</strong></td>
                        <td width="30%">{{ $item->{'Id CC'} }}</td>
                        <td width="20%"><strong>No. CC:</strong></td>
                        <td width="30%">{{ $item->{'No CC'} }}</td>
                    </tr>
                    
                    <tr>
                        <td><strong>SOE Relacionado:</strong></td>
                        <td>{{ $item->{'Id SOE'} }} - {{ $item->soe->{'Id SOE'} ?? 'N/A' }}</td>
                        <td><strong>Valor CC:</strong></td>
                        <td class="text-end valor">{{ number_format($item->{'Valor CC'}, 2) }}</td>
                    </tr>
                    
                    <tr>
                        <td><strong>Moneda:</strong></td>
                        <td>{{ $item->moneda->Moneda ?? 'N/A' }}</td>
                        <td><strong>Capacidad:</strong></td>
                        <td>{{ $item->capacidad->Capacidad ?? 'N/A' }}</td>
                    </tr>
                    
                    <!-- Fechas -->
                    <tr>
                        <td><strong>Fecha Presentada:</strong></td>
                        <td class="nowrap">{{ $item->{'Fecha Presentada CC'} ? \Carbon\Carbon::parse($item->{'Fecha Presentada CC'})->format('d/m/Y') : 'N/A' }}</td>
                        <td><strong>Fecha Apertura:</strong></td>
                        <td class="nowrap">{{ $item->{'Fecha Apertura CC'} ? \Carbon\Carbon::parse($item->{'Fecha Apertura CC'})->format('d/m/Y') : 'N/A' }}</td>
                    </tr>
                    
                    <tr>
                        <td><strong>Fecha Pedido Capacidad:</strong></td>
                        <td class="nowrap">{{ $item->{'Fecha Pedido Cap'} ? \Carbon\Carbon::parse($item->{'Fecha Pedido Cap'})->format('d/m/Y') : 'N/A' }}</td>
                        <td><strong>Fecha Asignada Capacidad:</strong></td>
                        <td class="nowrap">{{ $item->{'Fecha Asignada Cap'} ? \Carbon\Carbon::parse($item->{'Fecha Asignada Cap'})->format('d/m/Y') : 'N/A' }}</td>
                    </tr>
                    
                    <!-- Información Adicional -->
                    <tr>
                        <td><strong>Momento CC:</strong></td>
                        <td>{{ $item->momentoCC->{'Momento CC'} ?? 'N/A' }}</td>
                        <td><strong>Año Financiamiento:</strong></td>
                        <td>{{ $item->{'Año finan'} ?? 'N/A' }}</td>
                    </tr>
                    
                    <tr>
                        <td><strong>Línea de Crédito:</strong></td>
                        <td colspan="3">{{ $item->lineaCredito->{'Linea de Crédito'} ?? 'N/A' }}</td>
                    </tr>
                    
                    <!-- Usuario -->
                    <tr>
                        <td><strong>Usuario:</strong></td>
                        <td>{{ $item->{'Usuario'} ?? 'N/A' }}</td>
                        <td><strong>Estado:</strong></td>
                        <td>
                            @if($item->{'Activo'} == 1)
                                <span class="badge badge-success">Activo</span>
                            @elseif($item->{'Activo'} == 0)
                                <span class="badge badge-danger">Inactivo</span>
                            @else
                                <span class="badge badge-secondary">{{ $item->{'Activo'} ?? 'N/A' }}</span>
                            @endif
                        </td>
                    </tr>
                    
                    <!-- Observaciones -->
                    @if($item->{'Observaciones CC'})
                    <tr>
                        <td colspan="4" style="background-color: #f8f9fa;">
                            <strong>Observaciones:</strong><br>
                            {{ $item->{'Observaciones CC'} }}
                        </td>
                    </tr>
                    @endif
                </tbody>
            </table>
            
            @if(!$loop->last)
                <div class="section-break"></div>
            @endif
        </div>
        @endforeach
        
        <!-- Totales generales -->
        <div style="margin-top: 30px;">
            <table>
                <thead>
                    <tr>
                        <th colspan="6" style="background-color: #e9ecef; text-align: center;">
                            Resumen General
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Total Registros:</strong></td>
                        <td>{{ $items->count() }}</td>
                        <td><strong>Activos:</strong></td>
                        <td>{{ $items->where('Activo', 1)->count() }}</td>
                        <td><strong>Inactivos:</strong></td>
                        <td>{{ $items->where('Activo', 0)->count() }}</td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align: right;"><strong>Valor Total CC:</strong></td>
                        <td colspan="4" class="text-end valor" style="font-weight: bold;">
                            {{ number_format($items->sum('Valor CC'), 2) }}
                        </td>
                    </tr>
                    @if($items->groupBy('moneda.Moneda')->count() > 0)
                    <tr>
                        <td colspan="6" style="background-color: #f8f9fa; padding: 8px;">
                            <strong>Distribución por Moneda:</strong><br>
                            @foreach($items->groupBy('moneda.Moneda') as $moneda => $itemsMoneda)
                                @if($moneda)
                                    • {{ $moneda }}: {{ $itemsMoneda->count() }} registros, 
                                      {{ number_format($itemsMoneda->sum('Valor CC'), 2) }}<br>
                                @endif
                            @endforeach
                        </td>
                    </tr>
                    @endif
                </tbody>
            </table>
        </div>
        
        <div class="footer">
            <p>Exportación generada por SCCI - Sistema de Control de Contratación e Importaciones</p>
            <p>© {{ date('Y') }} Exportadora e Importadora de la Construcción</p>
            <p>Generado por: {{ auth()->user()->{'Usuario'} ?? 'Sistema' }}</p>
        </div>
    @else
        <div style="margin-top: 50px; padding: 20px; text-align: center; border: 1px solid #ddd; border-radius: 5px; background-color: #f8f9fa;">
            <p style="font-size: 12px; font-style: italic; color: #666;">
                No hay datos para mostrar con los filtros aplicados.
            </p>
        </div>
    @endif
</body>
</html>