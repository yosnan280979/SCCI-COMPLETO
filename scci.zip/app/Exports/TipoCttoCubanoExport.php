<?php

namespace App\Exports;

use App\Models\TipoCttoCubano;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class TipoCttoCubanoExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $tipos;

    public function __construct($tipos)
    {
        $this->tipos = $tipos;
    }

    public function collection()
    {
        return $this->tipos;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Tipo de Contrato',
        ];
    }

    public function map($tipo): array
    {
        return [
            $tipo->{'Id Tipo Ctto'},
            $tipo->{'Tipo Ctto'},
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}