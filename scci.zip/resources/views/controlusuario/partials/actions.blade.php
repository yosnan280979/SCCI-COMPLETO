<div class="btn-group" role="group">
    <a href="{{ route('controlusuario.show', $control_usuario->id) }}" class="btn btn-info btn-sm">
        <i class="fas fa-eye"></i>
    </a>
    <a href="{{ route('controlusuario.edit', $control_usuario->id) }}" class="btn btn-warning btn-sm">
        <i class="fas fa-edit"></i>
    </a>
    <form action="{{ route('controlusuario.destroy', $control_usuario->id) }}" method="POST" class="d-inline delete-form">
        @csrf
        @method('DELETE')
        <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="{{ $control_usuario->id }}">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>