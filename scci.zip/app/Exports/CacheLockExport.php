<?php

namespace App\Exports;

use App\Models\CacheLock;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class CacheLockExport implements FromCollection, WithHeadings, WithMapping
{
    protected $data;
    protected $columns;

    public function __construct($data, $columns = [])
    {
        $this->data = $data;
        $this->columns = $columns;
    }

    public function collection()
    {
        return $this->data;
    }

    public function headings(): array
    {
        $headings = [];

        foreach ($this->columns as $column) {
            switch ($column) {
                case 'key':
                    $headings[] = 'Key';
                    break;
                case 'owner':
                    $headings[] = 'Owner';
                    break;
                case 'expiration':
                    $headings[] = 'Expiration';
                    break;
            }
        }

        return $headings;
    }

    public function map($row): array
    {
        $mappedRow = [];

        foreach ($this->columns as $column) {
            switch ($column) {
                case 'key':
                    $mappedRow[] = $row->key;
                    break;
                case 'owner':
                    $mappedRow[] = $row->owner;
                    break;
                case 'expiration':
                    $mappedRow[] = $row->expiration;
                    break;
            }
        }

        return $mappedRow;
    }
}
