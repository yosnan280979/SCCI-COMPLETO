#!/bin/bash
# Script para importar REGISTRO DE CLIENTES FGNE desde Excel a MySQL/MariaDB
# Autor: Yosnan (SIGEH ERP)

# Configuración
EXCEL_FILE="REGISTRO DE CLIENTES FGNE 2026.xlsx"
CSV_FILE="/tmp/clientes_fgne.csv"
MYSQL_DB="scci_db"
MYSQL_TABLE="clientes_fgne"
MYSQL_USER="root"
MYSQL_PASS="I* 1m3c0 *"

echo "=== Instalando dependencias necesarias ==="
sudo apt update
sudo apt install -y gnumeric mariadb-client-compat

echo "=== Conversión Excel → CSV ==="
ssconvert "$EXCEL_FILE" "$CSV_FILE"

if [ ! -f "$CSV_FILE" ]; then
  echo "Error: No se generó el CSV en $CSV_FILE"
  exit 1
fi

echo "=== Creando tabla en MySQL/MariaDB (si no existe) ==="
mysql -u"$MYSQL_USER" -p"$MYSQL_PASS" "$MYSQL_DB" <<EOF
DROP TABLE IF EXISTS $MYSQL_TABLE;

CREATE TABLE $MYSQL_TABLE (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fgne VARCHAR(50),              -- FGNE (TCP-CNA-MIPYME)
    nombre VARCHAR(255) NOT NULL,  -- NOMBRE
    codigo_nit VARCHAR(50),        -- CÓDIGO NIT
    objeto_social TEXT,            -- OBJETO SOCIAL
    direccion TEXT,                -- DIRECCIÓN
    telefonos VARCHAR(150),        -- TELÉFONOS
    email VARCHAR(200),            -- E-MAIL
    cuenta_mn VARCHAR(100),        -- MN
    cuenta_usd VARCHAR(100),       -- USD
    cuenta_mlc VARCHAR(100),       -- MLC
    sucursal_banco VARCHAR(150),   -- SUCURSAL-BANCO
    representante VARCHAR(150),    -- Representación
    ficha VARCHAR(50),             -- FICHA
    actualizacion VARCHAR(50),     -- Actualiz.
    bases_generales TEXT,          -- BASES GENERALES
    fecha_actualizacion VARCHAR(50), -- Fecha Actualización (texto para flexibilidad)
    ctto_consignacion VARCHAR(50), -- CTTO. CONSIGNACIÓN
    fecha_consignacion VARCHAR(50), -- Fecha
    ctto_inbond VARCHAR(50),       -- CTTO. IN BOND
    fecha_inbond VARCHAR(50)       -- Fecha
);
EOF

echo "=== Importando CSV a MySQL/MariaDB ==="
mysql --local-infile=1 -u"$MYSQL_USER" -p"$MYSQL_PASS" "$MYSQL_DB" <<EOF
LOAD DATA LOCAL INFILE '$CSV_FILE'
INTO TABLE $MYSQL_TABLE
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(fgne, nombre, codigo_nit, objeto_social, direccion, telefonos, email, cuenta_mn, cuenta_usd, cuenta_mlc, sucursal_banco, representante, ficha, actualizacion, bases_generales, fecha_actualizacion, ctto_consignacion, fecha_consignacion, ctto_inbond, fecha_inbond);
EOF

echo "=== Importación finalizada ==="
