<!DOCTYPE html>
<html>
<head>
    <title>Cargas - {{ date('Y-m-d') }}</title>
    <style>
        body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 30px; }
        .header h1 { margin: 0; font-size: 20px; color: #333; }
        .header p { margin: 5px 0; color: #666; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 6px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .footer { margin-top: 30px; text-align: center; font-size: 10px; color: #666; }
        .info-box { margin-bottom: 20px; padding: 10px; background-color: #f8f9fa; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Reporte de Cargas</h1>
        <p>Sistema de Control de Contratos e Importaciones</p>
        <p>Fecha de generación: {{ date('d/m/Y H:i:s') }}</p>
    </div>
    
    <div class="info-box">
        <p><strong>Total de registros:</strong> {{ $cargas->count() }}</p>
        @if(request()->has('search') && request('search'))
            <p><strong>Búsqueda aplicada:</strong> "{{ request('search') }}"</p>
        @endif
    </div>
    
    <table>
        <thead>
            <tr>
                <th>ID Carga</th>
                <th>Tipo Carga</th>
                <th>ID Embarque</th>
                <th>Cantidad</th>
                <th>Real</th>
            </tr>
        </thead>
        <tbody>
            @foreach($cargas as $carga)
            <tr>
                <td>{{ $carga->{'Id Carga'} }}</td>
                <td>{{ $carga->tipoCarga->{'Tipo Carga'} ?? 'N/A' }}</td>
                <td>{{ $carga->{'Id Embarque'} }}</td>
                <td>{{ $carga->Cantidad }}</td>
                <td>{{ $carga->Real }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
    
    <div class="footer">
        <p>Documento generado automáticamente por el Sistema SCCI</p>
    </div>
</body>
</html>