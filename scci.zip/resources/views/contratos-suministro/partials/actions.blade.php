<div class="btn-group" role="group">
    <a href="{{ route('contratosuministro.show', $contrato_suministro->id) }}" class="btn btn-info btn-sm">
        <i class="fas fa-eye"></i>
    </a>
    <a href="{{ route('contratosuministro.edit', $contrato_suministro->id) }}" class="btn btn-warning btn-sm">
        <i class="fas fa-edit"></i>
    </a>
    <form action="{{ route('contratosuministro.destroy', $contrato_suministro->id) }}" method="POST" class="d-inline delete-form">
        @csrf
        @method('DELETE')
        <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="{{ $contrato_suministro->id }}">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>