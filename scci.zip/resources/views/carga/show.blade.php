@extends('layouts.app')

@section('title', 'Ver Carga')
@section('header', 'Ver Carga')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="mb-0">Carga</h3>
                    <a href="{{ route('cargas.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Volver
                    </a>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th width="40%">ID Carga:</th>
                                    <td>{{ $carga->{'Id Carga'} }}</td>
                                </tr>
                                <tr>
                                    <th>Tipo Carga:</th>
                                    <td>{{ $carga->tipoCarga->{'Tipo Carga'} ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <th>ID Embarque:</th>
                                    <td>{{ $carga->{'Id Embarque'} }}</td>
                                </tr>
                                <tr>
                                    <th>Cantidad:</th>
                                    <td>{{ $carga->Cantidad }}</td>
                                </tr>
                                <tr>
                                    <th>Real:</th>
                                    <td>{{ $carga->Real }}</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-between">
                        <div>
                            @if(auth()->user()->userType->{'Id Tipo Usuario'} != 3)
                            <a href="{{ route('cargas.edit', $carga->{'Id Carga'}) }}" 
                               class="btn btn-warning">
                                <i class="fas fa-edit"></i> Editar
                            </a>
                            @endif
                        </div>
                        <div>
                            <form action="{{ route('cargas.destroy', $carga->{'Id Carga'}) }}" 
                                  method="POST" class="d-inline"
                                  onsubmit="return confirm('¿Está seguro de eliminar esta carga?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-trash"></i> Eliminar
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection