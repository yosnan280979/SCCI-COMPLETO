<?php
// save as: generate_views.php in project root

$models = [
    'cache' => [
        'singular' => 'cache',
        'primary_key' => 'key',
        'key_type' => 'string',
        'fields' => [
            'key' => ['type' => 'string', 'label' => 'Key'],
            'value' => ['type' => 'text', 'label' => 'Value'],
            'expiration' => ['type' => 'number', 'label' => 'Expiration'],
        ],
        'has_timestamps' => false,
    ],
    'cache_locks' => [
        'singular' => 'cache_lock',
        'primary_key' => 'key',
        'key_type' => 'string',
        'fields' => [
            'key' => ['type' => 'string', 'label' => 'Key'],
            'owner' => ['type' => 'string', 'label' => 'Owner'],
            'expiration' => ['type' => 'number', 'label' => 'Expiration'],
        ],
        'has_timestamps' => false,
    ],
    'dtproperties' => [
        'singular' => 'dtproperty',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'objectid' => ['type' => 'number', 'label' => 'Object ID'],
            'property' => ['type' => 'string', 'label' => 'Property'],
            'value' => ['type' => 'string', 'label' => 'Value'],
            'uvalue' => ['type' => 'string', 'label' => 'UValue'],
            'lvalue' => ['type' => 'text', 'label' => 'LValue'],
            'version' => ['type' => 'number', 'label' => 'Version'],
        ],
        'has_timestamps' => false,
    ],
    'jobs' => [
        'singular' => 'job',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'queue' => ['type' => 'string', 'label' => 'Queue'],
            'payload' => ['type' => 'text', 'label' => 'Payload'],
            'attempts' => ['type' => 'number', 'label' => 'Attempts'],
            'reserved_at' => ['type' => 'number', 'label' => 'Reserved At'],
            'available_at' => ['type' => 'number', 'label' => 'Available At'],
            'created_at' => ['type' => 'number', 'label' => 'Created At'],
        ],
        'has_timestamps' => false,
        'readonly' => true, // Solo lectura
    ],
    'job_batches' => [
        'singular' => 'job_batch',
        'primary_key' => 'id',
        'key_type' => 'string',
        'fields' => [
            'id' => ['type' => 'string', 'label' => 'ID'],
            'name' => ['type' => 'string', 'label' => 'Name'],
            'total_jobs' => ['type' => 'number', 'label' => 'Total Jobs'],
            'pending_jobs' => ['type' => 'number', 'label' => 'Pending Jobs'],
            'failed_jobs' => ['type' => 'number', 'label' => 'Failed Jobs'],
            'failed_job_ids' => ['type' => 'text', 'label' => 'Failed Job IDs'],
            'options' => ['type' => 'text', 'label' => 'Options'],
            'cancelled_at' => ['type' => 'number', 'label' => 'Cancelled At'],
            'created_at' => ['type' => 'number', 'label' => 'Created At'],
            'finished_at' => ['type' => 'number', 'label' => 'Finished At'],
        ],
        'has_timestamps' => false,
        'readonly' => true,
    ],
    'migrations' => [
        'singular' => 'migration',
        'primary_key' => 'id',
        'key_type' => 'number',
        'fields' => [
            'id' => ['type' => 'number', 'label' => 'ID'],
            'migration' => ['type' => 'string', 'label' => 'Migration'],
            'batch' => ['type' => 'number', 'label' => 'Batch'],
        ],
        'has_timestamps' => false,
        'readonly' => true,
    ],
    'password_reset_tokens' => [
        'singular' => 'password_reset_token',
        'primary_key' => 'Usuario',
        'key_type' => 'string',
        'fields' => [
            'Usuario' => ['type' => 'string', 'label' => 'Usuario'],
            'token' => ['type' => 'string', 'label' => 'Token'],
            'created_at' => ['type' => 'datetime', 'label' => 'Created At'],
        ],
        'has_timestamps' => false,
        'readonly' => true,
    ],
    'sessions' => [
        'singular' => 'session',
        'primary_key' => 'id',
        'key_type' => 'string',
        'fields' => [
            'id' => ['type' => 'string', 'label' => 'ID'],
            'user_id' => ['type' => 'number', 'label' => 'User ID'],
            'ip_address' => ['type' => 'string', 'label' => 'IP Address'],
            'user_agent' => ['type' => 'text', 'label' => 'User Agent'],
            'payload' => ['type' => 'text', 'label' => 'Payload'],
            'last_activity' => ['type' => 'number', 'label' => 'Last Activity'],
        ],
        'has_timestamps' => false,
        'readonly' => true,
    ],
];

function generateIndexView($modelName, $config) {
    $singular = $config['singular'];
    $title = ucwords(str_replace('_', ' ', $modelName));
    $routeName = str_replace('_', '-', $modelName);
    $fields = $config['fields'];
    $readonly = $config['readonly'] ?? false;
    
    $headers = '';
    $columns = '';
    
    foreach ($fields as $field => $info) {
        $headers .= "<th>{$info['label']}</th>\n                                    ";
        $columns .= "{ data: '{$field}', name: '{$field}' },\n                ";
    }
    
    $headers = rtrim($headers);
    $columns = rtrim($columns, ",\n                ");
    
    $createButton = !$readonly ? 
        '<a href="{{ route(\'' . $routeName . '.create\') }}" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Nuevo ' . ucfirst($singular) . '
                        </a>' : '';
    
    $editButton = !$readonly ? 
        '<a href="{{ route(\'' . $routeName . '.edit\', $' . $singular . '->' . $config['primary_key'] . ') }}" class="btn btn-warning btn-sm">
                                                <i class="fas fa-edit"></i>
                                            </a>' : '';
    
    $deleteButton = !$readonly ? 
        '<form action="{{ route(\'' . $routeName . '.destroy\', $' . $singular . '->' . $config['primary_key'] . ') }}" method="POST" class="d-inline">
            @csrf
            @method(\'DELETE\')
            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm(\'¿Está seguro de eliminar este registro?\')">
                <i class="fas fa-trash"></i>
            </button>
        </form>' : '';
    
    return <<<HTML
@extends('layouts.app')

@section('title', '{$title}')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="card-title">{$title}</h3>
                        <div>
                            {$createButton}
                            <a href="{{ route('{$routeName}.export') }}" class="btn btn-success">
                                <i class="fas fa-file-export"></i> Exportar
                            </a>
                            <a href="{{ route('{$routeName}.pdf') }}" class="btn btn-danger" target="_blank">
                                <i class="fas fa-file-pdf"></i> PDF
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="{$modelName}-table" class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr>
                                    {$headers}
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    \$(document).ready(function() {
        $('#{$modelName}-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('{$routeName}.index') }}",
            columns: [
                {$columns},
                { 
                    data: 'actions', 
                    name: 'actions', 
                    orderable: false, 
                    searchable: false,
                    className: 'text-center'
                }
            ],
            language: {
                url: "//cdn.datatables.net/plug-ins/1.10.25/i18n/Spanish.json"
            },
            order: [[0, 'desc']],
            pageLength: 25,
            responsive: true
        });
    });
</script>
@endpush
HTML;
}

function generateCreateView($modelName, $config) {
    if ($config['readonly'] ?? false) return null;
    
    $singular = $config['singular'];
    $title = ucwords(str_replace('_', ' ', $modelName));
    $routeName = str_replace('_', '-', $modelName);
    $fields = $config['fields'];
    
    $formFields = '';
    
    foreach ($fields as $field => $info) {
        $type = $info['type'] == 'text' ? 'textarea' : 
                ($info['type'] == 'number' ? 'number' : 
                ($info['type'] == 'datetime' ? 'datetime-local' : 'text'));
        
        $required = in_array($field, [$config['primary_key']]) ? 'required' : '';
        
        if ($type == 'textarea') {
            $formFields .= <<<HTML
                        <div class="form-group">
                            <label for="{$field}">{$info['label']} *</label>
                            <textarea class="form-control @error('{$field}') is-invalid @enderror" 
                                      id="{$field}" name="{$field}" rows="3" {$required}>{{ old('{$field}') }}</textarea>
                            @error('{$field}')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ \$message }}</strong>
                                </span>
                            @enderror
                        </div>
HTML;
        } else {
            $formFields .= <<<HTML
                        <div class="form-group">
                            <label for="{$field}">{$info['label']} *</label>
                            <input type="{$type}" class="form-control @error('{$field}') is-invalid @enderror" 
                                   id="{$field}" name="{$field}" value="{{ old('{$field}') }}" {$required}>
                            @error('{$field}')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ \$message }}</strong>
                                </span>
                            @enderror
                        </div>
HTML;
        }
    }
    
    return <<<HTML
@extends('layouts.app')

@section('title', 'Crear {$title}')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Crear Nuevo {$title}</h3>
                    <div class="card-tools">
                        <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    </div>
                </div>
                <form action="{{ route('{$routeName}.store') }}" method="POST">
                    @csrf
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                {$formFields}
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Guardar
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <i class="fas fa-redo"></i> Limpiar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
HTML;
}

function generateEditView($modelName, $config) {
    if ($config['readonly'] ?? false) return null;
    
    $singular = $config['singular'];
    $title = ucwords(str_replace('_', ' ', $modelName));
    $routeName = str_replace('_', '-', $modelName);
    $fields = $config['fields'];
    $primaryKey = $config['primary_key'];
    
    $formFields = '';
    
    foreach ($fields as $field => $info) {
        $type = $info['type'] == 'text' ? 'textarea' : 
                ($info['type'] == 'number' ? 'number' : 
                ($info['type'] == 'datetime' ? 'datetime-local' : 'text'));
        
        $required = in_array($field, [$primaryKey]) ? 'required' : '';
        
        if ($type == 'textarea') {
            $formFields .= <<<HTML
                        <div class="form-group">
                            <label for="{$field}">{$info['label']} *</label>
                            <textarea class="form-control @error('{$field}') is-invalid @enderror" 
                                      id="{$field}" name="{$field}" rows="3" {$required}>{{ old('{$field}', \${$singular}->{$field}) }}</textarea>
                            @error('{$field}')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ \$message }}</strong>
                                </span>
                            @enderror
                        </div>
HTML;
        } else {
            $valueField = $type == 'datetime-local' ? "{{\${$singular}->{$field} ? \${$singular}->{$field}->format('Y-m-d\\\TH:i') : ''}}" : "{{ old('{$field}', \${$singular}->{$field}) }}";
            
            $formFields .= <<<HTML
                        <div class="form-group">
                            <label for="{$field}">{$info['label']} *</label>
                            <input type="{$type}" class="form-control @error('{$field}') is-invalid @enderror" 
                                   id="{$field}" name="{$field}" value="{$valueField}" {$required}>
                            @error('{$field}')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ \$message }}</strong>
                                </span>
                            @enderror
                        </div>
HTML;
        }
    }
    
    return <<<HTML
@extends('layouts.app')

@section('title', 'Editar {$title}')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Editar {$title}</h3>
                    <div class="card-tools">
                        <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    </div>
                </div>
                <form action="{{ route('{$routeName}.update', \${$singular}->{$primaryKey}) }}" method="POST">
                    @csrf
                    @method('PUT')
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                {$formFields}
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Actualizar
                        </button>
                        <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancelar
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
HTML;
}

function generateShowView($modelName, $config) {
    $singular = $config['singular'];
    $title = ucwords(str_replace('_', ' ', $modelName));
    $routeName = str_replace('_', '-', $modelName);
    $fields = $config['fields'];
    $primaryKey = $config['primary_key'];
    $readonly = $config['readonly'] ?? false;
    
    $infoBoxes = '';
    $counter = 0;
    
    foreach ($fields as $field => $info) {
        $counter++;
        $colClass = $counter <= 2 ? 'col-md-6' : 'col-md-4';
        
        $infoBoxes .= <<<HTML
                        <div class="{$colClass}">
                            <div class="info-box">
                                <span class="info-box-icon bg-info"><i class="fas fa-tag"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">{$info['label']}</span>
                                    <span class="info-box-number">{{ \${$singular}->{$field} }}</span>
                                </div>
                            </div>
                        </div>
HTML;
    }
    
    $editButton = !$readonly ? 
        '<a href="{{ route(\'' . $routeName . '.edit\', $' . $singular . '->' . $primaryKey . ') }}" class="btn btn-warning">
                            <i class="fas fa-edit"></i> Editar
                        </a>' : '';
    
    $deleteButton = !$readonly ? 
        '<form action="{{ route(\'' . $routeName . '.destroy\', $' . $singular . '->' . $primaryKey . ') }}" method="POST" class="d-inline">
            @csrf
            @method(\'DELETE\')
            <button type="submit" class="btn btn-danger" onclick="return confirm(\'¿Está seguro de eliminar este registro?\')">
                <i class="fas fa-trash"></i> Eliminar
            </button>
        </form>' : '';
    
    return <<<HTML
@extends('layouts.app')

@section('title', 'Detalles {$title}')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Detalles del {$title}</h3>
                    <div class="card-tools">
                        <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        {$infoBoxes}
                    </div>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-between">
                        <div>
                            {$editButton}
                        </div>
                        <div>
                            {$deleteButton}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
HTML;
}

function generateExportView($modelName, $config) {
    $title = ucwords(str_replace('_', ' ', $modelName));
    $routeName = str_replace('_', '-', $modelName);
    $fields = $config['fields'];
    
    $checkboxes = '';
    foreach ($fields as $field => $info) {
        $checkboxes .= <<<HTML
                            <div class="form-check">
                                <input class="form-check-input column-checkbox" type="checkbox" id="{$field}_column" name="columns[]" value="{$field}" checked>
                                <label class="form-check-label" for="{$field}_column">{$info['label']}</label>
                            </div>
HTML;
    }
    
    return <<<HTML
@extends('layouts.app')

@section('title', 'Exportar {$title}')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h3 class="card-title">Exportar {$title}</h3>
                </div>
                <div class="card-body">
                    <form action="{{ route('{$routeName}.export.process') }}" method="POST">
                        @csrf
                        
                        <div class="form-group">
                            <label for="format">Formato de Exportación *</label>
                            <select class="form-control @error('format') is-invalid @enderror" id="format" name="format" required>
                                <option value="">Seleccione un formato</option>
                                <option value="excel">Excel (.xlsx)</option>
                                <option value="csv">CSV (.csv)</option>
                                <option value="pdf">PDF (.pdf)</option>
                            </select>
                            @error('format')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ \$message }}</strong>
                                </span>
                            @enderror
                        </div>
                        
                        <div class="form-group">
                            <label for="columns">Columnas a Exportar</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="select_all" onchange="toggleSelectAll(this)">
                                <label class="form-check-label" for="select_all">Seleccionar Todos</label>
                            </div>
                            {$checkboxes}
                        </div>
                        
                        <div class="form-group">
                            <label for="fecha_inicio">Fecha Inicio</label>
                            <input type="date" class="form-control" id="fecha_inicio" name="fecha_inicio">
                        </div>
                        
                        <div class="form-group">
                            <label for="fecha_fin">Fecha Fin</label>
                            <input type="date" class="form-control" id="fecha_fin" name="fecha_fin">
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> Seleccione el formato y opciones de exportación para generar el archivo.
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-file-export"></i> Exportar
                        </button>
                        <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancelar
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Establecer fechas por defecto
        const today = new Date();
        const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
        
        document.getElementById('fecha_fin').value = today.toISOString().split('T')[0];
        document.getElementById('fecha_inicio').value = firstDay.toISOString().split('T')[0];
    });

    function toggleSelectAll(source) {
        const checkboxes = document.querySelectorAll('.column-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = source.checked;
        });
    }
</script>
@endpush
HTML;
}

function generatePdfView($modelName, $config) {
    $singular = $config['singular'];
    $title = ucwords(str_replace('_', ' ', $modelName));
    $fields = $config['fields'];
    
    $headers = '';
    foreach ($fields as $field => $info) {
        $headers .= "<th>{$info['label']}</th>\n                ";
    }
    
    $tbody = '';
    foreach ($fields as $field => $info) {
        $tbody .= "<td>{{ \${$singular}->{$field} }}</td>\n                ";
    }
    
    return <<<HTML
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de {$title}</title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            line-height: 1.5;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        .header h1 {
            margin: 0;
            color: #333;
            font-size: 24px;
        }
        .header .subtitle {
            color: #666;
            font-size: 14px;
        }
        .info-box {
            margin-bottom: 20px;
            padding: 10px;
            background-color: #f8f9fa;
            border-left: 4px solid #007bff;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table th {
            background-color: #343a40;
            color: white;
            padding: 8px;
            text-align: left;
            border: 1px solid #dee2e6;
        }
        .table td {
            padding: 8px;
            border: 1px solid #dee2e6;
        }
        .table tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 10px;
            color: #666;
            border-top: 1px solid #dee2e6;
            padding-top: 10px;
        }
        .text-right { text-align: right; }
        .page-break { page-break-before: always; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Reporte de {$title}</h1>
        <div class="subtitle">
            Generado el: {{ date('d/m/Y H:i:s') }}
        </div>
    </div>
    
    <div class="info-box">
        <strong>Información del Reporte:</strong><br>
        Total de registros: {{ \${$modelName}->count() }}<br>
        @if(request('fecha_inicio'))
            Período: {{ request('fecha_inicio') }} al {{ request('fecha_fin') }}
        @endif
    </div>
    
    <table class="table">
        <thead>
            <tr>
                {$headers}
            </tr>
        </thead>
        <tbody>
            @foreach(\${$modelName} as \${$singular})
            <tr>
                {$tbody}
            </tr>
            @endforeach
        </tbody>
    </table>
    
    <div class="footer">
        Página {{ \$pageNumber ?? 1 }}<br>
        Sistema de Gestión - Generado automáticamente
    </div>
</body>
</html>
HTML;
}

// Crear directorios y archivos
foreach ($models as $modelName => $config) {
    $directory = "resources/views/{$modelName}";
    
    // Crear directorio si no existe
    if (!is_dir($directory)) {
        mkdir($directory, 0755, true);
    }
    
    // Crear partials directory para acciones
    $partialsDir = "{$directory}/partials";
    if (!is_dir($partialsDir)) {
        mkdir($partialsDir, 0755, true);
    }
    
    // Generar vistas
    $indexContent = generateIndexView($modelName, $config);
    file_put_contents("{$directory}/index.blade.php", $indexContent);
    
    $createContent = generateCreateView($modelName, $config);
    if ($createContent) {
        file_put_contents("{$directory}/create.blade.php", $createContent);
    }
    
    $editContent = generateEditView($modelName, $config);
    if ($editContent) {
        file_put_contents("{$directory}/edit.blade.php", $editContent);
    }
    
    $showContent = generateShowView($modelName, $config);
    file_put_contents("{$directory}/show.blade.php", $showContent);
    
    $exportContent = generateExportView($modelName, $config);
    file_put_contents("{$directory}/export.blade.php", $exportContent);
    
    $pdfContent = generatePdfView($modelName, $config);
    file_put_contents("{$directory}/pdf.blade.php", $pdfContent);
    
    // Generar partial de acciones para DataTables
    $actionsContent = generateActionsPartial($modelName, $config);
    file_put_contents("{$partialsDir}/actions.blade.php", $actionsContent);
    
    echo "Vistas generadas para: {$modelName}\n";
}

function generateActionsPartial($modelName, $config) {
    $singular = $config['singular'];
    $routeName = str_replace('_', '-', $modelName);
    $primaryKey = $config['primary_key'];
    $readonly = $config['readonly'] ?? false;
    
    if ($readonly) {
        return <<<HTML
<div class="btn-group" role="group">
    <a href="{{ route('{$routeName}.show', \${$singular}->{$primaryKey}) }}" class="btn btn-info btn-sm">
        <i class="fas fa-eye"></i>
    </a>
</div>
HTML;
    }
    
    return <<<HTML
<div class="btn-group" role="group">
    <a href="{{ route('{$routeName}.show', \${$singular}->{$primaryKey}) }}" class="btn btn-info btn-sm">
        <i class="fas fa-eye"></i>
    </a>
    <a href="{{ route('{$routeName}.edit', \${$singular}->{$primaryKey}) }}" class="btn btn-warning btn-sm">
        <i class="fas fa-edit"></i>
    </a>
    <form action="{{ route('{$routeName}.destroy', \${$singular}->{$primaryKey}) }}" method="POST" class="d-inline delete-form">
        @csrf
        @method('DELETE')
        <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="{{ \${$singular}->{$primaryKey} }}">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>
HTML;
}

echo "\n¡Todas las vistas han sido generadas!\n";
echo "Recuerda configurar DataTables en tu layout:\n";
echo "1. Agrega los CDN de DataTables en tu layout principal\n";
echo "2. Agrega el script de confirmación para eliminaciones\n";

// Script para agregar a layout
echo "\nAgrega esto a tu layout principal (app.blade.php) en la sección de scripts:\n";
echo <<<SCRIPT
<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap4.min.css">

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap4.min.js"></script>

<script>
    // Confirmación para eliminaciones
    \$(document).on('click', '.delete-btn', function(e) {
        e.preventDefault();
        var form = \$(this).closest('form');
        if (confirm('¿Está seguro de eliminar este registro?')) {
            \$.ajax({
                url: form.attr('action'),
                type: 'POST',
                data: {
                    _token: form.find('input[name="_token"]').val(),
                    _method: 'DELETE'
                },
                success: function(response) {
                    // Recargar la tabla DataTables
                    $('.dataTable').DataTable().ajax.reload();
                    // Mostrar mensaje de éxito
                    showToast('success', response.success);
                },
                error: function(xhr) {
                    showToast('error', 'Error al eliminar el registro');
                }
            });
        }
    });

    function showToast(type, message) {
        // Implementa tu función de toast aquí
        alert(message);
    }
</script>
SCRIPT;