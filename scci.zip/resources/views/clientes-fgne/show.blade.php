@extends('layouts.app')

@section('title', 'Detalle Cliente FGNE')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Detalle del Cliente FGNE</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Nombre:</strong> {{ $item->nombre }}</p>
                    <p><strong>Código FGNE:</strong> {{ $item->fgne_codigo ?? '-' }}</p>
                    <p><strong>NIT:</strong> {{ $item->codigo_nit ?? '-' }}</p>
                    <p><strong>Objeto Social:</strong> {{ $item->objeto_social ?? '-' }}</p>
                    <p><strong>Dirección:</strong> {{ $item->direccion ?? '-' }}</p>
                    <p><strong>Teléfonos:</strong> {{ $item->telefonos ?? '-' }}</p>
                </div>
                <div>
                    <div class="col-md-6">
                        <p><strong>Email:</strong> {{ $item->email ?? '-' }}</p>
                        <p><strong>Representación:</strong> {{ $item->representacion ?? '-' }}</p>
                        <p><strong>Banco:</strong> {{ $item->sucursal_banco ?? '-' }}</p>
                        <p><strong>Cuentas:</strong> MN: {{ $item->cuenta_mn }} | MLC: {{ $item->cuenta_mlc }}</p>
                        <p><strong>Ficha:</strong> {{ $item->ficha ?? '-' }}</p>
                    </div>
                </div>
            </div>
            
            <div class="mt-4">
                <a href="{{ route('clientes-fgne.index') }}" class="btn btn-secondary">Volver</a>
                <a href="{{ route('clientes-fgne.edit', $item->id) }}" class="btn btn-warning">Editar</a>
                <form action="{{ route('clientes-fgne.destroy', $item->id) }}" method="POST" style="display:inline-block;">
                    @csrf @method('DELETE')
                    <button type="submit" class="btn btn-danger" onclick="return confirm('¿Eliminar este registro?')">Eliminar</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection