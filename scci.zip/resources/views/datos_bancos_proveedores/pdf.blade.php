<!DOCTYPE html>
<html>
<head>
    <title>Datos Bancos de Proveedores - Reporte PDF</title>
    <style>
        body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 5px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        h1 { text-align: center; color: #333; font-size: 16px; }
        .header { text-align: center; margin-bottom: 20px; }
        .footer { margin-top: 30px; padding-top: 10px; border-top: 1px solid #ddd; text-align: center; font-size: 9px; color: #666; }
        .text-end { text-align: right; }
        .text-center { text-align: center; }
        .badge { padding: 2px 6px; border-radius: 3px; font-size: 9px; }
        .badge-success { background-color: #d4edda; color: #155724; }
        .badge-danger { background-color: #f8d7da; color: #721c24; }
        .badge-secondary { background-color: #e2e3e5; color: #383d41; }
        .page-break { page-break-after: always; }
        .small-text { font-size: 9px; }
        .column-group { page-break-inside: avoid; }
        .section-break { margin: 15px 0; border-top: 1px dashed #ddd; }
        .bank-info { background-color: #e6f3ff; padding: 10px; border-radius: 5px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Reporte de Datos Bancos de Proveedores</h1>
        <p>Fecha de generación: {{ now()->format('d/m/Y H:i:s') }}</p>
        <p>Total de registros: {{ $datosBancos->count() }}</p>
        
        @if(!empty($filtros))
            <div style="margin-top: 10px; text-align: left; font-size: 9px;">
                <strong>Filtros aplicados:</strong><br>
                @foreach($filtros as $filtro)
                    • {{ $filtro }}<br>
                @endforeach
            </div>
        @endif
    </div>
    
    @foreach($datosBancos as $dato)
    <div class="column-group">
        <table style="margin-bottom: 20px;">
            <thead>
                <tr>
                    <th colspan="4" style="background-color: #e9ecef; text-align: center;">
                        Información Bancaria #{{ $dato->Id }}
                        <span style="float: right; font-size: 9px;">
                            @if($dato->Activo)
                                <span class="badge badge-success">Activo</span>
                            @else
                                <span class="badge badge-secondary">Inactivo</span>
                            @endif
                        </span>
                    </th>
                </tr>
            </thead>
            <tbody>
                <!-- Información del Proveedor -->
                <tr>
                    <td width="20%"><strong>ID Registro:</strong></td>
                    <td width="30%">{{ $dato->Id }}</td>
                    <td width="20%"><strong>Proveedor:</strong></td>
                    <td width="30%">{{ $dato->proveedor?->{'Proveedor'} ?? 'N/A' }}</td>
                </tr>
                
                <!-- Información del Banco -->
                <tr>
                    <td><strong>Banco:</strong></td>
                    <td>{{ $dato->banco?->{'Banco'} ?? 'N/A' }}</td>
                    <td><strong>Moneda:</strong></td>
                    <td>{{ $dato->moneda?->{'Moneda'} ?? 'N/A' }}</td>
                </tr>
                
                <!-- Información de la Cuenta -->
                <tr>
                    <td><strong>Número de Cuenta:</strong></td>
                    <td>{{ $dato->{'Numero Cuenta'} ?? 'N/A' }}</td>
                    <td><strong>Tipo de Cuenta:</strong></td>
                    <td>{{ $dato->{'Tipo Cuenta'} ?? 'N/A' }}</td>
                </tr>
                
                <tr>
                    <td><strong>Titular:</strong></td>
                    <td>{{ $dato->Titular ?? 'N/A' }}</td>
                    <td><strong>SWIFT/BIC:</strong></td>
                    <td>{{ $dato->{'SWIFT_BIC'} ?? 'N/A' }}</td>
                </tr>
                
                <!-- Dirección del Banco -->
                <tr>
                    <td colspan="4" style="background-color: #f8f9fa;">
                        <strong>Dirección del Banco:</strong><br>
                        {{ $dato->{'Direccion Banco'} ?? 'N/A' }}
                    </td>
                </tr>
                
                <!-- Contacto del Banco -->
                <tr>
                    <td><strong>Teléfono Banco:</strong></td>
                    <td>{{ $dato->{'Telefono Banco'} ?? 'N/A' }}</td>
                    <td><strong>Email Banco:</strong></td>
                    <td>{{ $dato->{'Email Banco'} ?? 'N/A' }}</td>
                </tr>
                
                <tr>
                    <td><strong>Contacto Banco:</strong></td>
                    <td>{{ $dato->{'Contacto Banco'} ?? 'N/A' }}</td>
                    <td><strong>Estado:</strong></td>
                    <td class="text-center">
                        @if($dato->Activo)
                            <span class="badge badge-success">Activo</span>
                        @else
                            <span class="badge badge-danger">Inactivo</span>
                        @endif
                    </td>
                </tr>
                
                <!-- Observaciones -->
                @if($dato->Observaciones)
                <tr>
                    <td colspan="4" style="background-color: #f8f9fa;">
                        <strong>Observaciones:</strong><br>
                        {{ $dato->Observaciones }}
                    </td>
                </tr>
                @endif
            </tbody>
        </table>
        
        @if(!$loop->last)
            <div class="section-break"></div>
        @endif
    </div>
    @endforeach
    
    <!-- Totales generales -->
    <div style="margin-top: 30px;">
        <table>
            <thead>
                <tr>
                    <th colspan="6" style="background-color: #e9ecef; text-align: center;">
                        Resumen General
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Total Registros:</strong></td>
                    <td>{{ $datosBancos->count() }}</td>
                    <td><strong>Activos:</strong></td>
                    <td>{{ $datosBancos->where('Activo', 1)->count() }}</td>
                    <td><strong>Inactivos:</strong></td>
                    <td>{{ $datosBancos->where('Activo', 0)->count() }}</td>
                </tr>
                <tr>
                    <td colspan="6" style="text-align: center; font-weight: bold;">
                        Proveedores con Datos Bancarios Registrados: {{ $datosBancos->unique('Id_Proveedor')->count() }}
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    
    <div class="footer">
        <p>Exportación generada por SCCI - Sistema de Control de Contratación e Importaciones</p>
        <p>© {{ date('Y') }} Exportadora e Importadora de la Construcción</p>
        <p>Generado por: {{ auth()->user()->{'Usuario'} ?? 'Sistema' }}</p>
    </div>
</body>
</html>