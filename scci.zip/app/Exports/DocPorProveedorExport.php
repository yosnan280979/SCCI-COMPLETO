<?php

namespace App\Exports;

use App\Models\DocPorProveedor;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class DocPorProveedorExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function collection()
    {
        return $this->items;
    }

    public function headings(): array
    {
        return [
            'Proveedor',
            'Documento',
            'Caduca',
            'Fecha Caducidad',
        ];
    }

    public function map($item): array
    {
        return [
            $item->proveedor?->Proveedor ?? '',
            $item->documento?->Documento ?? '',
            $item->Caduca ? 'Sí' : 'No',
            $item->{'Fecha Caducidad'} ? \Carbon\Carbon::parse($item->{'Fecha Caducidad'})->format('d/m/Y') : '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}