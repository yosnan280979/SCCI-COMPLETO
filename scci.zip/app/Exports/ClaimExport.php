<?php

namespace App\Exports;

use App\Models\Claim;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class ClaimExport implements FromCollection, WithHeadings, WithMapping
{
    protected $data;
    protected $columns;

    public function __construct($data, $columns = [])
    {
        $this->data = $data;
        $this->columns = $columns;
    }

    public function collection()
    {
        return $this->data;
    }

    public function headings(): array
    {
        $headings = [];

        foreach ($this->columns as $column) {
            switch ($column) {
                case 'id':
                    $headings[] = 'ID';
                    break;
                case 'embarque_id':
                    $headings[] = 'Embarque ID';
                    break;
                case 'descripcion':
                    $headings[] = 'Descripción';
                    break;
            }
        }

        return $headings;
    }

    public function map($row): array
    {
        $mappedRow = [];

        foreach ($this->columns as $column) {
            switch ($column) {
                case 'id':
                    $mappedRow[] = $row->id;
                    break;
                case 'embarque_id':
                    $mappedRow[] = $row->embarque_id;
                    break;
                case 'descripcion':
                    $mappedRow[] = $row->descripcion;
                    break;
            }
        }

        return $mappedRow;
    }
}
