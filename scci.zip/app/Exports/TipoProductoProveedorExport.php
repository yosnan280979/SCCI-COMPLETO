<?php

namespace App\Exports;

use App\Models\TipoProductoProveedor;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class TipoProductoProveedorExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function collection()
    {
        return $this->items;
    }

    public function headings(): array
    {
        return [
            'ID Tipo Producto',
            'Tipo Producto',
            'ID Proveedor',
            'Proveedor',
            'Datos',
        ];
    }

    public function map($item): array
    {
        return [
            $item->{'Id Tipo Producto'},
            $item->tipoProducto?->{'Tipo Producto'} ?? 'N/A',
            $item->{'Id Proveedor'},
            $item->proveedor?->Proveedor ?? 'N/A',
            $item->Datos ?? '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}