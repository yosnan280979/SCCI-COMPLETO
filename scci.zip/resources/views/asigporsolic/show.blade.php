@extends('layouts.app')

@section('title', 'Detalle de Asignación por Solicitud')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Asignación por Solicitud #{{ $asigporsolic->{'Id Solicitud'} }}</h5>
            <div class="d-flex gap-2">
                <a href="{{ route('asigporsolic.edit', $asigporsolic->{'Id Solicitud'}) }}" class="btn btn-warning btn-sm">✏️ Editar</a>
                <form action="{{ route('asigporsolic.destroy', $asigporsolic->{'Id Solicitud'}) }}" method="POST" style="display:inline-block">
                    @csrf @method('DELETE')
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar esta asignación?')">🗑️ Eliminar</button>
                </form>
                <a href="{{ route('asigporsolic.index') }}" class="btn btn-secondary btn-sm">⬅️ Volver</a>
            </div>
        </div>

        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>ID Solicitud:</strong> {{ $asigporsolic->{'Id Solicitud'} }}</p>
                    <p><strong>Año financiero:</strong> {{ $asigporsolic->{'Año finan'} }}</p>
                    <p><strong>Asignación MCUC:</strong> {{ $asigporsolic->{'Asig MCUC'} }}</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection