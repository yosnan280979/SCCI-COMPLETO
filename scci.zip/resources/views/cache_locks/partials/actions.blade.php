<div class="btn-group" role="group">
    <a href="{{ route('cache-locks.show', $cache_lock->key) }}" class="btn btn-info btn-sm">
        <i class="fas fa-eye"></i>
    </a>
    <a href="{{ route('cache-locks.edit', $cache_lock->key) }}" class="btn btn-warning btn-sm">
        <i class="fas fa-edit"></i>
    </a>
    <form action="{{ route('cache-locks.destroy', $cache_lock->key) }}" method="POST" class="d-inline delete-form">
        @csrf
        @method('DELETE')
        <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="{{ $cache_lock->key }}">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>