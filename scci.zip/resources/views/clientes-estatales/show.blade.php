@extends('layouts.app')

@section('title', 'Detalle Cliente Estatal')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Detalle del Cliente Estatal</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Empresa:</strong> {{ $item->nombre_empresa }}</p>
                    <p><strong>Ministerio:</strong> {{ $item->ministerio ?? 'No especificado' }}</p>
                    <p><strong>NIT / REEUP:</strong> {{ $item->codigo_nit ?? '-' }}</p>
                    <p><strong>Dirección:</strong> {{ $item->direccion ?? '-' }}</p>
                    <p><strong>Teléfono:</strong> {{ $item->telefono ?? '-' }}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Director:</strong> {{ $item->nombre_director ?? '-' }}</p>
                    <p><strong>Email:</strong> {{ $item->email ?? '-' }}</p>
                    <p><strong>Cuentas Bancarias:</strong> <br> {{ nl2br($item->cuentas_bancarias ?? '-') }}</p>
                    <p><strong>Convenios:</strong> <br> {{ nl2br($item->convenios_firmados ?? '-') }}</p>
                </div>
            </div>
            
            <div class="mt-4">
                <a href="{{ route('clientes-estatales.index') }}" class="btn btn-secondary">Volver</a>
                <a href="{{ route('clientes-estatales.edit', $item->id) }}" class="btn btn-warning">Editar</a>
            </div>
        </div>
    </div>
</div>
@endsection