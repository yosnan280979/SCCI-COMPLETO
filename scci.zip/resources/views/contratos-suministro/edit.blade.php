@extends('layouts.app')

@section('title', 'Editar Contrato Suministro')

@section('content')
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3>Editar Contrato Suministro #{{ $contratoSuministro->{'Id Cttosuministro'} }}</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('contratos-suministro.update', $contratoSuministro->{'Id Cttosuministro'}) }}" method="POST">
                @csrf
                @method('PUT')
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="No Ctto Suministro" class="form-label">No. Contrato Suministro *</label>
                        <input type="text" class="form-control" id="No Ctto Suministro" name="No Ctto Suministro" 
                               value="{{ $contratoSuministro->{'No Ctto Suministro'} }}" required>
                    </div>
                    <div class="col-md-6">
                        <label for="Id Cliente" class="form-label">Cliente *</label>
                        <select class="form-select" id="Id Cliente" name="Id Cliente" required>
                            <option value="">Seleccionar Cliente</option>
                            @foreach($clientes as $cliente)
                                <option value="{{ $cliente->{'Id Cliente'} }}" 
                                    {{ $contratoSuministro->{'Id Cliente'} == $cliente->{'Id Cliente'} ? 'selected' : '' }}>
                                    {{ $cliente->{'Cliente'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Descripcion" class="form-label">Descripción</label>
                        <input type="text" class="form-control" id="Descripcion" name="Descripcion" 
                               value="{{ $contratoSuministro->{'Descripcion'} }}">
                    </div>
                    <div class="col-md-6">
                        <label for="Observaciones Ctto Sum" class="form-label">Observaciones</label>
                        <textarea class="form-control" id="Observaciones Ctto Sum" name="Observaciones Ctto Sum" rows="3">{{ $contratoSuministro->{'Observaciones Ctto Sum'} }}</textarea>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="{{ route('contratos-suministro.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Actualizar Contrato</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection