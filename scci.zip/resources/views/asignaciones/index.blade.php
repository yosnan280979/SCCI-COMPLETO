@extends('layouts.app')

@section('title','Listado de Asignaciones')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Asignaciones</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('asignaciones.create') }}" class="btn btn-primary btn-sm">➕ Nuevo</a>
                <!-- Formularios de exportación separados (GET) - ELIMINADO @csrf -->
                <form method="GET" action="{{ route('asignaciones.export.excel') }}" style="display: inline" id="exportExcelForm">
                    <input type="hidden" name="selected" id="exportSelectedExcel" value="">
                    <input type="hidden" name="Id_Centro_Balance" value="{{ request('Id_Centro_Balance') }}">
                    <input type="hidden" name="Id_Lineacredito" value="{{ request('Id_Lineacredito') }}">
                    <input type="hidden" name="Id_Fuentafinan" value="{{ request('Id_Fuentafinan') }}">
                    <input type="hidden" name="Año_Asignacion" value="{{ request('Año_Asignacion') }}">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                <form method="GET" action="{{ route('asignaciones.export.pdf') }}" style="display: inline" id="exportPdfForm">
                    <input type="hidden" name="selected" id="exportSelectedPdf" value="">
                    <input type="hidden" name="Id_Centro_Balance" value="{{ request('Id_Centro_Balance') }}">
                    <input type="hidden" name="Id_Lineacredito" value="{{ request('Id_Lineacredito') }}">
                    <input type="hidden" name="Id_Fuentafinan" value="{{ request('Id_Fuentafinan') }}">
                    <input type="hidden" name="Año_Asignacion" value="{{ request('Año_Asignacion') }}">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                <form method="GET" action="{{ route('asignaciones.print') }}" style="display: inline" id="printForm" target="_blank">
                    <input type="hidden" name="selected" id="exportSelectedPrint" value="">
                    <input type="hidden" name="Id_Centro_Balance" value="{{ request('Id_Centro_Balance') }}">
                    <input type="hidden" name="Id_Lineacredito" value="{{ request('Id_Lineacredito') }}">
                    <input type="hidden" name="Id_Fuentafinan" value="{{ request('Id_Fuentafinan') }}">
                    <input type="hidden" name="Año_Asignacion" value="{{ request('Año_Asignacion') }}">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Filtros -->
            <form method="GET" action="{{ route('asignaciones.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" name="search" class="form-control" placeholder="Buscar (Centro, Línea, Fuente...)" 
                               value="{{ request('search') }}">
                    </div>
                    <div class="col-md-2">
                        <select name="Id_Centro_Balance" class="form-select">
                            <option value="">Centro de Balance</option>
                            @foreach($centrosBalance as $centro)
                                <option value="{{ $centro->{'Id Centro Balnce'} }}" {{ request('Id_Centro_Balance') == $centro->{'Id Centro Balnce'} ? 'selected' : '' }}>
                                    {{ $centro->{'Centro Balance'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="Id_Lineacredito" class="form-select">
                            <option value="">Línea de Crédito</option>
                            @foreach($lineasCredito as $linea)
                                <option value="{{ $linea->{'Id Lineacredito'} }}" {{ request('Id_Lineacredito') == $linea->{'Id Lineacredito'} ? 'selected' : '' }}>
                                    {{ $linea->{'Linea de Crédito'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="Id_Fuentafinan" class="form-select">
                            <option value="">Fuente Financiamiento</option>
                            @foreach($fuentesFinanciamiento as $fuente)
                                <option value="{{ $fuente->{'Id Fuentefinan'} }}" {{ request('Id_Fuentafinan') == $fuente->{'Id Fuentefinan'} ? 'selected' : '' }}>
                                    {{ $fuente->{'Fuente Financiamiento'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-1">
                        <select name="Año_Asignacion" class="form-select">
                            <option value="">Año</option>
                            @foreach($anios as $anio)
                                <option value="{{ $anio }}" {{ request('Año_Asignacion') == $anio ? 'selected' : '' }}>
                                    {{ $anio }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('asignaciones.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
                <!-- Campos ocultos para ordenación -->
                <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
            </form>

            @if($items->isEmpty())
                <div class="alert alert-info">No hay asignaciones registradas.</div>
            @else
                <!-- Formulario para eliminación múltiple (DELETE) -->
                <form id="deleteForm" method="POST" action="{{ route('asignaciones.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <!-- Tabla con scroll horizontal -->
                    <div class="table-responsive" style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
                        <table class="table table-bordered table-hover table-sm align-middle" style="min-width: 1200px;">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="selectAll">
                                    </th>
                                    <th width="200">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Centro Balance';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Centro Balance' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('asignaciones.index', $queryParams) }}">
                                            Centro Balance
                                            @if(request('sort_by') == 'Centro Balance')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="200">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Linea Credito';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Linea Credito' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('asignaciones.index', $queryParams) }}">
                                            Línea de Crédito
                                            @if(request('sort_by') == 'Linea Credito')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="200">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Fuente Financiamiento';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Fuente Financiamiento' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('asignaciones.index', $queryParams) }}">
                                            Fuente Financiamiento
                                            @if(request('sort_by') == 'Fuente Financiamiento')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="100">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Año Asignacion';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Año Asignacion' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('asignaciones.index', $queryParams) }}">
                                            Año
                                            @if(request('sort_by') == 'Año Asignacion')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="150" class="text-end">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Valor';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Valor' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('asignaciones.index', $queryParams) }}">
                                            Valor (CUC)
                                            @if(request('sort_by') == 'Valor')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="200">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($items as $item)
                                    @php
                                        // Verificar que todos los campos existan
                                        $cb = $item->{'Id Centro Balance'} ?? null;
                                        $lc = $item->{'Id Lineacredito'} ?? null;
                                        $ff = $item->{'Id Fuentafinan'} ?? null;
                                        $anio = $item->{'Año Asignacion'} ?? null;
                                    @endphp
                                    
                                    @if($cb && $lc && $ff && $anio)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="selected[]" value="{{ $cb }}-{{ $lc }}-{{ $ff }}-{{ $anio }}" class="select-item">
                                        </td>
                                        <td>{{ $item->centroBalance?->{'Centro Balance'} ?? '---' }}</td>
                                        <td>{{ $item->lineaCredito?->{'Linea de Crédito'} ?? '---' }}</td>
                                        <td>{{ $item->fuenteFinanciamiento?->{'Fuente Financiamiento'} ?? '---' }}</td>
                                        <td class="text-center">{{ $anio }}</td>
                                        <td class="text-end">
                                            @if($item->Valor)
                                                ${{ number_format($item->Valor, 2) }}
                                            @else
                                                $0.00
                                            @endif
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="{{ route('asignaciones.show', [
                                                    'cb' => $cb,
                                                    'lc' => $lc,
                                                    'ff' => $ff,
                                                    'anio' => $anio
                                                ]) }}" class="btn btn-info btn-sm">Ver</a>
                                                <a href="{{ route('asignaciones.edit', [
                                                    'cb' => $cb,
                                                    'lc' => $lc,
                                                    'ff' => $ff,
                                                    'anio' => $anio
                                                ]) }}" class="btn btn-warning btn-sm">Editar</a>
                                                <form action="{{ route('asignaciones.destroy', [
                                                    'cb' => $cb,
                                                    'lc' => $lc,
                                                    'ff' => $ff,
                                                    'anio' => $anio
                                                ]) }}" method="POST" style="display:inline-block;">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar esta asignación?')">Eliminar</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    @endif
                                @endforeach
                            </tbody>
                            @if($items->isNotEmpty())
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="5" class="text-end"><strong>Total:</strong></td>
                                    <td class="text-end">
                                        <strong>
                                            @php
                                                $totalValor = $items->sum('Valor');
                                            @endphp
                                            ${{ number_format($totalValor, 2) }}
                                        </strong>
                                    </td>
                                    <td></td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar las asignaciones seleccionadas?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación corregida -->
                @if($items->hasPages())
                    @php 
                        // Preservar todos los parámetros de búsqueda en la paginación
                        $queryParams = request()->all();
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $items->firstItem() }}–{{ $items->lastItem() }} de {{ $items->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <!-- Primera página -->
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('asignaciones.index', $queryParams) }}">« Primera</a>
                                </li>
                                
                                <!-- Página anterior -->
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = $items->currentPage() - 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('asignaciones.index', $queryParams) }}">‹</a>
                                </li>
                                
                                <!-- Página actual -->
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $items->currentPage() }} de {{ $items->lastPage() }}</span>
                                </li>
                                
                                <!-- Página siguiente -->
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $items->currentPage() + 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('asignaciones.index', $queryParams) }}">›</a>
                                </li>
                                
                                <!-- Última página -->
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $items->lastPage();
                                    @endphp
                                    <a class="page-link" href="{{ route('asignaciones.index', $queryParams) }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<style>
/* Estilos para la tabla con scroll horizontal */
.table-responsive {
    border: 1px solid #dee2e6;
    border-radius: 4px;
    margin-bottom: 1rem;
}

/* Asegurar que las celdas mantengan su tamaño */
.table th, .table td {
    white-space: nowrap;
    vertical-align: middle;
    padding: 0.5rem;
}

/* Estilo para columnas numéricas */
.text-end {
    font-family: 'Courier New', monospace;
    font-weight: 500;
}

/* Mejorar visualización de botones */
.btn-group .btn-sm {
    padding: 0.25rem 0.5rem;
}

/* Scroll suave en móviles */
@media (max-width: 768px) {
    .table-responsive {
        -webkit-overflow-scrolling: touch;
    }
    
    .card-body {
        padding: 0.75rem;
    }
}

/* Hover para filas */
.table-hover tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.075);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar exportSelected cuando cambian las selecciones
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportSelectedExcel').value = selectedString;
        document.getElementById('exportSelectedPdf').value = selectedString;
        document.getElementById('exportSelectedPrint').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
});
</script>
@endsection