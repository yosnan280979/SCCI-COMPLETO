<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call(ModuleSeeder::class);        // Crea módulos y permisos base
        $this->call(AreaPermissionsSeeder::class); // Ajusta permisos específicos por área
        $this->call(UserSeeder::class);           // Usuarios (después de que existan áreas y permisos)
    }
}