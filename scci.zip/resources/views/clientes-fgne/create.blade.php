@extends('layouts.app')

@section('title', 'Crear Cliente FGNE')

@section('content')
<div class="container-fluid">
    @include('partials.messages')  <!-- <--- AQUÍ ESTÁ EL ERROR, CAMBIA 'apses' POR 'partials.messages' -->
    
    <div class="card">
        <div class="card-header">
            <h3>Crear Cliente FGNE</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('clientes-fgne.store') }}" method="POST">
                @csrf
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">No. Registro</label>
                        <input type="number" name="no_registro" class="form-control" value="{{ old('no_registro') }}">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">FGNE (TCP/CNA/MIPYME)</label>
                        <input type="text" name="fgne_codigo" class="form-control" value="{{ old('fgne_codigo') }}">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Nombre *</label>
                        <input type="text" name="nombre" class="guardar form-control" required value="{{ old('nombre') }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Código NIT</label>
                        <input type="text" name="codigo_nit" class="form-control" value="{{ old('codigo_nit') }}">
                    </div>
                    <div class="col-md-8">
                        <label class="form-label">Objeto Social</label>
                        <textarea name="objeto_social" class="form-control" rows="2">{{ old('objeto_social') }}</textarea>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-12">
                        <label class="form-label">Dirección</label>
                        <input type="text" name="direccion" class="form-control" value="{{ old('direccion') }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Teléfonos</label>
                        <input type="text" name="telefonos" class="form-control" value="{{ old('turnos') }}">
                    </div>
                    <div class="clientes-fgne.form-label">Email</label>
                        <input type="email" name="email" class="form-control" value="{{ old('email') }}">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Representación</label>
                        <input type="text" name="representacion" class="form-control" value="{{ old('representacion') }}">
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-12">
                        <h6>Datos Bancarios</h6>
                        <hr>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <label class="form-label">Cta. MN</label>
                            <input type="text" name="cuenta_mn" class="form-control" value="{{ old('cuenta_mn') }}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Cta. USD</label>
                            <input type="text" name="cuenta_usd" class="form-control" value="{{ old('cuenta_usd') }}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Cta. MLC</label>
                            <input type="text" name="cuenta_mlc" class="form-control" value="{{ old('cuenta_mlc') }}">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <label class="form-label">Sucursal Banco</label>
                            <input type="text" name="sucursal_banco" class="form-control" value="{{ old('sucursal_banco') }}">
                        </div>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-3">
                        <label class="form-label">Ficha</label>
                        <input type="text" name="ficha" class="form-control" value="{{ old('ficha') }}">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Actualiz</label>
                        <input type="text" name="actualiz" class="form-control" value="{{ old('actualiz') }}">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Bases Generales</label>
                        <input type="text" name="bases_generales" class="form-control" value="{{ old('bases_generales') }}">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Fecha Actualización</label>
                        <input type="date" name="fecha_actualizacion" class="form-control" value="{{ old('fecha_actualizacion') }}">
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Ctto. Consignación</label>
                        <input type="text" name="ctto_consignacion" class="form-control" value="{{ old('ctto_consignacion') }}">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Fecha Ctto. Consignación</label>
                        <input type="date" name="fecha_ctto_consignacion" class="form-control" value="{{ old('fecha_ctto_consignacion') }}">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Ctto. In Bond</label>
                        <input type="text" name="ctto_in_bond" class="form-control" value="{{ old('ctto_in_bond') }}">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Fecha Ctto. In Bond</label>
                        <input type="date" name="fecha_ctto_in_bond" class="form-control" value="{{ old('fecha_ctto_in_bond') }}">
                    </div>
                </div>
                
                <div class="d-flex justify-content-end mt-4">
                    <a href="{{ route('clientes-fgne.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar Cliente</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection