@props(['module' => '', 'selectedId' => '', 'filters' => []])

<div class="d-flex gap-2">
    <form method="GET" action="{{ route($module . '.export.excel') }}" style="display: inline">
        @csrf
        <input type="hidden" name="selected" value="{{ $selectedId }}">
        @foreach($filters as $key => $value)
            @if($value)
                <input type="hidden" name="{{ $key }}" value="{{ $value }}">
            @endif
        @endforeach
        <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
    </form>
    <form method="GET" action="{{ route($module . '.export.pdf') }}" style="display: inline">
        @csrf
        <input type="hidden" name="selected" value="{{ $selectedId }}">
        @foreach($filters as $key => $value)
            @if($value)
                <input type="hidden" name="{{ $key }}" value="{{ $value }}">
            @endif
        @endforeach
        <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
    </form>
    <form method="GET" action="{{ route($module . '.print') }}" style="display: inline" target="_blank">
        @csrf
        <input type="hidden" name="selected" value="{{ $selectedId }}">
        @foreach($filters as $key => $value)
            @if($value)
                <input type="hidden" name="{{ $key }}" value="{{ $value }}">
            @endif
        @endforeach
        <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
    </form>
</div>