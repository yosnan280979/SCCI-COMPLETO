<!DOCTYPE html>
<html>
<head>
    <title>Datos SOE - Reporte PDF</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 5px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        h1 { text-align: center; color: #333; font-size: 16px; }
        .header { text-align: center; margin-bottom: 20px; }
        .footer { margin-top: 30px; padding-top: 10px; border-top: 1px solid #ddd; text-align: center; font-size: 9px; color: #666; }
        .text-end { text-align: right; }
        .text-center { text-align: center; }
        .badge { padding: 2px 6px; border-radius: 3px; font-size: 9px; }
        .badge-success { background-color: #d4edda; color: #155724; }
        .badge-danger { background-color: #f8d7da; color: #721c24; }
        .badge-secondary { background-color: #e2e3e5; color: #383d41; }
        .page-break { page-break-after: always; }
        .small-text { font-size: 9px; }
        .column-group { page-break-inside: avoid; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Reporte de Datos SOE</h1>
        <p>Fecha: {{ date('d/m/Y H:i:s') }}</p>
        <p>Total de registros: {{ $datosSOE->count() }}</p>
        
        @if(!empty($filtros))
            <div style="margin-top: 10px; text-align: left; font-size: 9px;">
                <strong>Filtros aplicados:</strong><br>
                @foreach($filtros as $filtro)
                    • {{ $filtro }}<br>
                @endforeach
            </div>
        @endif
    </div>
    
    @foreach($datosSOE as $soe)
    <div class="column-group">
        <table style="margin-bottom: 20px;">
            <thead>
                <tr>
                    <th colspan="4" style="background-color: #e9ecef; text-align: center;">
                        Datos SOE #{{ $soe->{'Id SOE'} }}
                    </th>
                </tr>
            </thead>
            <tbody>
                <!-- Primera fila -->
                <tr>
                    <td><strong>ID SOE:</strong></td>
                    <td>{{ $soe->{'Id SOE'} }}</td>
                    <td><strong>Contrato:</strong></td>
                    <td>
                        {{ $soe->{'Id Ctto'} }}
                        @if($soe->contrato)
                            - {{ $soe->contrato->{'No Ctto'} }}
                        @endif
                    </td>
                </tr>
                
                <!-- Segunda fila -->
                <tr>
                    <td><strong>Suplemento:</strong></td>
                    <td>{{ $soe->{'No Suplemento'} ?? 'N/A' }}</td>
                    <td><strong>Fecha Comité:</strong></td>
                    <td>{{ $soe->{'Fecha Comite'} ? \Carbon\Carbon::parse($soe->{'Fecha Comite'})->format('d/m/Y') : 'N/A' }}</td>
                </tr>
                
                <!-- Tercera fila -->
                <tr>
                    <td><strong>No. Acta:</strong></td>
                    <td>{{ $soe->{'No Acta'} ?? 'N/A' }}</td>
                    <td><strong>No. Acuerdo:</strong></td>
                    <td>{{ $soe->{'No Acuerdo'} ?? 'N/A' }}</td>
                </tr>
                
                <!-- Cuarta fila -->
                <tr>
                    <td><strong>Valor Mercancía:</strong></td>
                    <td class="text-end">{{ $soe->{'Valor Mercancia'} ? number_format($soe->{'Valor Mercancia'}, 2) : '0.00' }}</td>
                    <td><strong>Valor Ctto CUC:</strong></td>
                    <td class="text-end">{{ $soe->{'Valor Ctto CUC'} ? number_format($soe->{'Valor Ctto CUC'}, 2) : '0.00' }}</td>
                </tr>
                
                <!-- Quinta fila -->
                <tr>
                    <td><strong>ID Moneda:</strong></td>
                    <td>{{ $soe->{'Id Moneda'} ?? 'N/A' }}</td>
                    <td><strong>Valor Mon Prov:</strong></td>
                    <td class="text-end">{{ $soe->{'Valor Mon Prov'} ? number_format($soe->{'Valor Mon Prov'}, 2) : '0.00' }}</td>
                </tr>
                
                <!-- Sexta fila -->
                <tr>
                    <td><strong>No. Referencia:</strong></td>
                    <td>{{ $soe->{'No Referencia'} ?? 'N/A' }}</td>
                    <td><strong>Fecha CAD Gescons:</strong></td>
                    <td>{{ $soe->{'Fecha CAD Gescons'} ? \Carbon\Carbon::parse($soe->{'Fecha CAD Gescons'})->format('d/m/Y') : 'N/A' }}</td>
                </tr>
                
                <!-- Séptima fila -->
                <tr>
                    <td><strong>Fecha CAD MICONS:</strong></td>
                    <td>{{ $soe->{'Fecha CAD MICONS'} ? \Carbon\Carbon::parse($soe->{'Fecha CAD MICONS'})->format('d/m/Y') : 'N/A' }}</td>
                    <td><strong>No. Acta MICONS:</strong></td>
                    <td>{{ $soe->{'No Acta MICONS'} ?? 'N/A' }}</td>
                </tr>
                
                <!-- Octava fila -->
                <tr>
                    <td><strong>Fecha firma Ctto:</strong></td>
                    <td>{{ $soe->{'Fecha firma Ctto'} ? \Carbon\Carbon::parse($soe->{'Fecha firma Ctto'})->format('d/m/Y') : 'N/A' }}</td>
                    <td><strong>Fecha emisión certif:</strong></td>
                    <td>{{ $soe->{'Fecha emision certif'} ? \Carbon\Carbon::parse($soe->{'Fecha emision certif'})->format('d/m/Y') : 'N/A' }}</td>
                </tr>
                
                <!-- Novena fila -->
                <tr>
                    <td><strong>Pendiente finan CUC:</strong></td>
                    <td class="text-end">{{ $soe->{'Pendiente finan CUC'} ? number_format($soe->{'Pendiente finan CUC'}, 2) : '0.00' }}</td>
                    <td><strong>Pendiente finan CUP:</strong></td>
                    <td class="text-end">{{ $soe->{'Pendiente finan CUP'} ? number_format($soe->{'Pendiente finan CUP'}, 2) : '0.00' }}</td>
                </tr>
                
                <!-- Décima fila -->
                <tr>
                    <td><strong>Total embarques:</strong></td>
                    <td>{{ $soe->{'Total embarques'} ?? 'N/A' }}</td>
                    <td><strong>Cancelado SOE:</strong></td>
                    <td class="text-center">
                        @if($soe->{'Cancelado SOE'})
                            <span class="badge badge-danger">Sí</span>
                        @else
                            <span class="badge badge-success">No</span>
                        @endif
                    </td>
                </tr>
                
                <!-- Undécima fila -->
                <tr>
                    <td><strong>Forma de Pago:</strong></td>
                    <td>{{ $soe->{'Forma de Pago'} ?? 'N/A' }}</td>
                    <td><strong>Anular Valores:</strong></td>
                    <td class="text-center">
                        @if($soe->{'Anular Valores'})
                            <span class="badge badge-danger">Sí</span>
                        @else
                            <span class="badge badge-success">No</span>
                        @endif
                    </td>
                </tr>
                
                <!-- Duodécima fila -->
                <tr>
                    <td><strong>ID MomentoSOE:</strong></td>
                    <td>{{ $soe->{'Id MomentoSOE'} ?? 'N/A' }}</td>
                    <td><strong>Año finan:</strong></td>
                    <td>{{ $soe->{'Año finan'} ?? 'N/A' }}</td>
                </tr>
                
                <!-- Decimotercera fila -->
                <tr>
                    <td><strong>ID Línea Crédito:</strong></td>
                    <td>{{ $soe->{'Id Linea credito'} ?? 'N/A' }}</td>
                    <td></td>
                    <td></td>
                </tr>
                
                <!-- Observaciones -->
                <tr>
                    <td colspan="4" style="background-color: #f8f9fa;">
                        <strong>Observaciones Jurídico:</strong><br>
                        {{ $soe->{'Observaciones Juridico'} ?? 'N/A' }}
                    </td>
                </tr>
                
                <tr>
                    <td colspan="4" style="background-color: #f8f9fa;">
                        <strong>Observaciones SOE:</strong><br>
                        {{ $soe->{'Observaciones SOE'} ?? 'N/A' }}
                    </td>
                </tr>
                
                <tr>
                    <td colspan="4" style="background-color: #f8f9fa;">
                        <strong>Observaciones Especialista:</strong><br>
                        {{ $soe->{'Observaciones Especialista'} ?? 'N/A' }}
                    </td>
                </tr>
                
                <tr>
                    <td colspan="4" style="background-color: #f8f9fa;">
                        <strong>Observaciones Generales:</strong><br>
                        {{ $soe->Observaciones ?? 'N/A' }}
                    </td>
                </tr>
            </tbody>
        </table>
        
        @if(!$loop->last)
            <div style="border-top: 1px dashed #ddd; margin: 20px 0;"></div>
        @endif
    </div>
    @endforeach
    
    <!-- Totales generales -->
    <div style="margin-top: 30px;">
        <table>
            <thead>
                <tr>
                    <th colspan="8" style="background-color: #e9ecef; text-align: center;">
                        Totales Generales
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Total Registros:</strong></td>
                    <td>{{ $datosSOE->count() }}</td>
                    <td><strong>Valor Mercancía Total:</strong></td>
                    <td class="text-end">{{ number_format($datosSOE->sum('Valor Mercancia'), 2) }}</td>
                    <td><strong>Valor Ctto CUC Total:</strong></td>
                    <td class="text-end">{{ number_format($datosSOE->sum('Valor Ctto CUC'), 2) }}</td>
                    <td><strong>Cancelados:</strong></td>
                    <td>{{ $datosSOE->where('Cancelado SOE', 1)->count() }}</td>
                </tr>
            </tbody>
        </table>
    </div>
    
    <div class="footer">
        <p>Exportación generada por SCCI - Sistema de Control de Contratación e Importaciones</p>
        <p>© {{ date('Y') }} Exportadora e Importadora de la Construcción</p>
        <p>Página 1 de 1</p>
    </div>
</body>
</html>