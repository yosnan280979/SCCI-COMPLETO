@extends('layouts.app')

@section('title', 'Editar Personal Cubano')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header">
            <h3>Editar Personal Cubano</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('datos-personal-cubano.update', $item->Id) }}">
                @csrf
                @method('PUT')
                
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="Funcionario_cubano" class="form-label">Funcionario Cubano *</label>
                        <input type="text" class="form-control" id="Funcionario_cubano" name="Funcionario_cubano" 
                               value="{{ old('Funcionario_cubano', $item->Funcionario_cubano) }}" required>
                    </div>
                    
                    <div class="col-md-6">
                        <label for="Cargo" class="form-label">Cargo</label>
                        <input type="text" class="form-control" id="Cargo" name="Cargo" 
                               value="{{ old('Cargo', $item->Cargo) }}">
                    </div>
                    
                    <div class="col-md-6">
                        <label for="Id_Proveedor" class="form-label">Proveedor</label>
                        <select class="form-select" id="Id_Proveedor" name="Id_Proveedor">
                            <option value="">Seleccionar proveedor...</option>
                            @foreach($providers as $provider)
                                <option value="{{ $provider->{'Id Proveedor'} }}" 
                                    {{ (old('Id_Proveedor', $item->Id_Proveedor) == $provider->{'Id Proveedor'}) ? 'selected' : '' }}>
                                    {{ $provider->Proveedor }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label for="Id_Tipo_Ctto" class="form-label">Tipo de Contrato</label>
                        <select class="form-select" id="Id_Tipo_Ctto" name="Id_Tipo_Ctto">
                            <option value="">Seleccionar tipo de contrato...</option>
                            @foreach($tiposContrato as $tipo)
                                <option value="{{ $tipo->{'Id Tipo Ctto'} }}" 
                                    {{ (old('Id_Tipo_Ctto', $item->Id_Tipo_Ctto) == $tipo->{'Id Tipo Ctto'}) ? 'selected' : '' }}>
                                    {{ $tipo->{'Tipo Ctto'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label for="Carnet_Acorec" class="form-label">Carnet Acorec</label>
                        <input type="text" class="form-control" id="Carnet_Acorec" name="Carnet_Acorec" 
                               value="{{ old('Carnet_Acorec', $item->Carnet_Acorec) }}">
                    </div>
                    
                    <div class="col-md-6">
                        <label for="Vigencia" class="form-label">Vigencia</label>
                        <input type="date" class="form-control" id="Vigencia" name="Vigencia" 
                               value="{{ old('Vigencia', $item->Vigencia ? \Carbon\Carbon::parse($item->Vigencia)->format('Y-m-d') : '') }}">
                    </div>
                    
                    <div class="col-md-6">
                        <label for="telef" class="form-label">Teléfono</label>
                        <input type="text" class="form-control" id="telef" name="telef" 
                               value="{{ old('telef', $item->telef) }}">
                    </div>
                    
                    <div class="col-md-6">
                        <label for="Email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="Email" name="Email" 
                               value="{{ old('Email', $item->Email) }}">
                    </div>
                    
                    <div class="col-md-12">
                        <label for="Direccion" class="form-label">Dirección</label>
                        <textarea class="form-control" id="Direccion" name="Direccion" 
                                  rows="2">{{ old('Direccion', $item->Direccion) }}</textarea>
                    </div>
                    
                    <div class="col-md-12">
                        <label for="Observaciones" class="form-label">Observaciones</label>
                        <textarea class="form-control" id="Observaciones" name="Observaciones" 
                                  rows="3">{{ old('Observaciones', $item->Observaciones) }}</textarea>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="Activo" name="Activo" 
                                   value="1" {{ old('Activo', $item->Activo) ? 'checked' : '' }}>
                            <label class="form-check-label" for="Activo">
                                Activo
                            </label>
                        </div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                    <a href="{{ route('datos-personal-cubano.index') }}" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection