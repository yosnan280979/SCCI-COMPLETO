<!DOCTYPE html>
<html>
<head>
    <title>Personal Cubano - Impresión</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; }
        .title { font-size: 18px; font-weight: bold; }
        .subtitle { font-size: 14px; color: #666; }
        .filters { margin-bottom: 15px; padding: 10px; background: #f5f5f5; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background-color: #f2f2f2; font-weight: bold; text-align: left; padding: 8px; border: 1px solid #ddd; }
        td { padding: 8px; border: 1px solid #ddd; font-size: 11px; }
        .footer { margin-top: 30px; text-align: right; font-size: 10px; color: #666; }
        .text-end { text-align: right; }
        .text-center { text-align: center; }
        .badge { padding: 3px 8px; border-radius: 3px; font-size: 11px; display: inline-block; }
        .badge-success { background-color: #d4edda; color: #155724; }
        .badge-danger { background-color: #f8d7da; color: #721c24; }
        .badge-secondary { background-color: #e2e3e5; color: #383d41; }
        .badge-warning { background-color: #fff3cd; color: #856404; }
        .badge-info { background-color: #d1ecf1; color: #0c5460; }
        @media print {
            .no-print { display: none; }
            .page-break { page-break-before: always; }
            body { font-size: 11px; }
            table { font-size: 10px; }
        }
        .page-break { page-break-after: always; }
        .employee-container { margin-bottom: 20px; page-break-inside: avoid; padding-bottom: 15px; }
        .employee-header { background-color: #e9ecef; padding: 10px; font-weight: bold; border-radius: 5px 5px 0 0; }
        .observation { background-color: #f8f9fa; padding: 8px; margin-top: 5px; border-radius: 3px; }
        .section-title { background-color: #f0f0f0; padding: 6px 10px; margin: 10px 0 5px 0; font-weight: bold; border-left: 4px solid #007bff; }
        .status-active { color: #155724; font-weight: bold; }
        .status-inactive { color: #721c24; font-weight: bold; }
        .compact-row { margin-bottom: 2px; }
        .contact-info { 
            display: flex; 
            justify-content: space-between; 
            margin-top: 5px; 
            padding: 5px;
            background-color: #f8f9fa;
            border-radius: 3px;
        }
        .contact-item { flex: 1; padding: 0 10px; }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">
            🖨️ Imprimir
        </button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #6c757d; color: white; border: none; border-radius: 5px; cursor: pointer;">
            ✖️ Cerrar
        </button>
    </div>
    
    <div class="header">
        <div class="title">Listado de Personal Cubano</div>
        <div class="subtitle">Fecha de generación: {{ now()->format('d/m/Y H:i:s') }}</div>
        <div class="subtitle">Total de registros: {{ $items->count() }}</div>
    </div>
    
    @if(!empty($filtros))
    <div class="filters">
        <strong>Filtros aplicados:</strong><br>
        @foreach($filtros as $filtro)
        • {{ $filtro }}<br>
        @endforeach
    </div>
    @endif
    
    @foreach($items as $item)
    <div class="employee-container">
        <div class="employee-header">
            Personal #{{ $item->Id }} - {{ $item->Funcionario_cubano }}
            <span style="float: right;">
                @if($item->Activo)
                    <span class="badge badge-success">Activo</span>
                @else
                    <span class="badge badge-danger">Inactivo</span>
                @endif
                @if($item->Carnet_Acorec)
                    <span class="badge badge-info" style="margin-left: 5px;">Carnet: {{ $item->Carnet_Acorec }}</span>
                @endif
            </span>
        </div>
        
        <!-- Información Básica -->
        <div class="section-title">Información Básica</div>
        <table>
            <tbody>
                <tr>
                    <td width="20%"><strong>ID Personal:</strong></td>
                    <td width="30%">{{ $item->Id }}</td>
                    <td width="20%"><strong>Nombre Completo:</strong></td>
                    <td width="30%">{{ $item->Funcionario_cubano }}</td>
                </tr>
                <tr>
                    <td><strong>Proveedor Asociado:</strong></td>
                    <td>
                        @if($item->provider)
                            {{ $item->provider->Proveedor }}
                            @if($item->Id_Proveedor)
                                <small>(ID: {{ $item->Id_Proveedor }})</small>
                            @endif
                        @elseif($item->Id_Proveedor)
                            ID: {{ $item->Id_Proveedor }}
                        @else
                            N/A
                        @endif
                    </td>
                    <td><strong>Cargo:</strong></td>
                    <td>{{ $item->Cargo ?? 'N/A' }}</td>
                </tr>
            </tbody>
        </table>
        
        <!-- Información de Contrato -->
        <div class="section-title">Información de Contrato</div>
        <table>
            <tbody>
                <tr>
                    <td width="20%"><strong>Tipo de Contrato:</strong></td>
                    <td width="30%">
                        @if($item->tipoCtto)
                            {{ $item->tipoCtto->{'Tipo Ctto'} }}
                        @elseif($item->Id_Tipo_Ctto)
                            ID: {{ $item->Id_Tipo_Ctto }}
                        @else
                            N/A
                        @endif
                    </td>
                    <td width="20%"><strong>Vigencia:</strong></td>
                    <td width="30%">
                        @if($item->Vigencia)
                            {{ \Carbon\Carbon::parse($item->Vigencia)->format('d/m/Y') }}
                            @php
                                $vigenciaDate = \Carbon\Carbon::parse($item->Vigencia);
                                $today = \Carbon\Carbon::today();
                                $daysDiff = $today->diffInDays($vigenciaDate, false);
                            @endphp
                            @if($daysDiff < 0)
                                <span class="badge badge-danger" style="margin-left: 5px;">Vencido</span>
                            @elseif($daysDiff <= 30)
                                <span class="badge badge-warning" style="margin-left: 5px;">Próximo a vencer</span>
                            @endif
                        @else
                            N/A
                        @endif
                    </td>
                </tr>
            </tbody>
        </table>
        
        <!-- Información de Contacto -->
        <div class="section-title">Información de Contacto</div>
        <table>
            <tbody>
                <tr>
                    <td width="20%"><strong>Teléfono:</strong></td>
                    <td width="30%">{{ $item->telef ?? 'N/A' }}</td>
                    <td width="20%"><strong>Email:</strong></td>
                    <td width="30%">{{ $item->Email ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td><strong>Dirección:</strong></td>
                    <td colspan="3">{{ $item->Direccion ?? 'N/A' }}</td>
                </tr>
            </tbody>
        </table>
        
        <!-- Información de Identificación -->
        <div class="section-title">Información de Identificación</div>
        <table>
            <tbody>
                <tr>
                    <td width="20%"><strong>Carnet ACOREC:</strong></td>
                    <td width="80%">{{ $item->Carnet_Acorec ?? 'N/A' }}</td>
                </tr>
            </tbody>
        </table>
        
        <!-- Observaciones -->
        @if($item->Observaciones)
        <div class="observation">
            <strong>Observaciones:</strong><br>
            {{ $item->Observaciones }}
        </div>
        @endif
        
        @if(!$loop->last)
            <hr style="border-top: 1px dashed #ddd; margin: 20px 0;">
        @endif
    </div>
    @endforeach
    
    <!-- Totales generales -->
    <div style="margin-top: 30px; padding: 15px; background-color: #f8f9fa; border-radius: 5px;">
        <strong>Resumen General:</strong><br>
        • Total Personal: {{ $items->count() }}<br>
        • Personal Activo: {{ $items->where('Activo', 1)->count() }}<br>
        • Personal Inactivo: {{ $items->where('Activo', 0)->count() }}<br>
        @php
            $hoy = \Carbon\Carbon::today();
            $proximosVencer = $items->filter(function($item) use ($hoy) {
                if (!$item->Vigencia) return false;
                $vigencia = \Carbon\Carbon::parse($item->Vigencia);
                $dias = $hoy->diffInDays($vigencia, false);
                return $dias <= 30 && $dias >= 0;
            })->count();
            
            $vencidos = $items->filter(function($item) use ($hoy) {
                if (!$item->Vigencia) return false;
                $vigencia = \Carbon\Carbon::parse($item->Vigencia);
                return $hoy->greaterThan($vigencia);
            })->count();
        @endphp
        • Contratos Próximos a Vencer (30 días): {{ $proximosVencer }}<br>
        • Contratos Vencidos: {{ $vencidos }}
    </div>
    
    <div class="footer">
        <p>Total de registros: {{ $items->count() }}</p>
        <p>Generado por: {{ auth()->user()->{'Usuario'} ?? auth()->user()->name ?? 'Sistema' }}</p>
        <p>SCCI - Sistema de Control de Contratación e Importaciones</p>
    </div>
    
    <script>
        // Auto-print opcional (descomentar si se necesita)
        // window.onload = function() { window.print(); }
    </script>
</body>
</html>