<?php

namespace App\Exports;

use App\Models\EmpresaImportadora;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class EmpresasImportadorasExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $empresas;

    public function __construct($empresas)
    {
        $this->empresas = $empresas;
    }

    public function collection()
    {
        return $this->empresas;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Empresa Importadora',
            'Siglas',
            'Ministerio ID',
            'Ministerio',
        ];
    }

    public function map($empresa): array
    {
        return [
            $empresa->{'Id Emp Imp'},
            $empresa->{'Empresa Importadora'},
            $empresa->Siglas,
            $empresa->{'Id Ministerio'},
            $empresa->ministerio ? $empresa->ministerio->Ministerio : '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            // Estilo para la fila de encabezado
            1    => ['font' => ['bold' => true]],
        ];
    }
}