{{-- Componente reutilizable para acciones de tabla --}}
@props([
    'routePrefix',
    'itemId',
    'itemName' => 'registro',
    'showView' => true,
    'showEdit' => true,
    'showDelete' => true,
    'showPrint' => false,
    'printRoute' => null,
])

<div class="btn-group" role="group">
    @if($showView)
    <a href="{{ route($routePrefix . '.show', $itemId) }}" class="btn btn-sm btn-primary" title="Ver">
        <i class="fas fa-eye"></i>
    </a>
    @endif
    
    @if($showEdit)
    <a href="{{ route($routePrefix . '.edit', $itemId) }}" class="btn btn-sm btn-secondary" title="Editar">
        <i class="fas fa-edit"></i>
    </a>
    @endif
    
    @if($showDelete)
    <form action="{{ route($routePrefix . '.destroy', $itemId) }}" method="POST" style="display:inline;">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-sm btn-danger" 
                onclick="return confirm('¿Está seguro de eliminar este {{ $itemName }}?')" title="Eliminar">
            <i class="fas fa-trash"></i>
        </button>
    </form>
    @endif
    
    @if($showPrint && $printRoute)
    <a href="{{ route($printRoute, $itemId) }}" class="btn btn-sm btn-info" target="_blank" title="Imprimir">
        <i class="fas fa-print"></i>
    </a>
    @endif
</div>