<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('permissions', function (Blueprint $table) {
            // Agregar las nuevas columnas si no existen
            if (!Schema::hasColumn('permissions', 'create_p')) {
                $table->boolean('create_p')->default(false);
            }
            if (!Schema::hasColumn('permissions', 'delete_p')) {
                $table->boolean('delete_p')->default(false);
            }
            // Eliminar las columnas antiguas si existen
            if (Schema::hasColumn('permissions', 'create')) {
                $table->dropColumn('create');
            }
            if (Schema::hasColumn('permissions', 'delete')) {
                $table->dropColumn('delete');
            }
        });
    }

    public function down()
    {
        Schema::table('permissions', function (Blueprint $table) {
            // Revertir: eliminar las nuevas y restaurar las antiguas
            if (Schema::hasColumn('permissions', 'create_p')) {
                $table->dropColumn('create_p');
            }
            if (Schema::hasColumn('permissions', 'delete_p')) {
                $table->dropColumn('delete_p');
            }
            // Opcional: si quieres restaurar las columnas antiguas en el rollback
            if (!Schema::hasColumn('permissions', 'create')) {
                $table->boolean('create')->default(false);
            }
            if (!Schema::hasColumn('permissions', 'delete')) {
                $table->boolean('delete')->default(false);
            }
        });
    }
};