<?php

namespace App\Exports;

use App\Models\ContratoDescription;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class ContratoDescriptionExport implements FromCollection, WithHeadings, WithMapping
{
    protected $data;
    protected $columns;

    public function __construct($data, $columns = [])
    {
        $this->data = $data;
        $this->columns = $columns;
    }

    public function collection()
    {
        return $this->data;
    }

    public function headings(): array
    {
        $headings = [];

        foreach ($this->columns as $column) {
            switch ($column) {
                case 'id':
                    $headings[] = 'ID';
                    break;
                case 'solicitud_id':
                    $headings[] = 'Solicitud ID';
                    break;
                case 'contrato_id':
                    $headings[] = 'Contrato ID';
                    break;
                case 'producto':
                    $headings[] = 'Producto';
                    break;
                case 'unidad_medida':
                    $headings[] = 'Unidad Medida';
                    break;
                case 'cantidad':
                    $headings[] = 'Cantidad';
                    break;
                case 'precio_cuc':
                    $headings[] = 'Precio CUC';
                    break;
                case 'precio_moneda_prov':
                    $headings[] = 'Precio Moneda Proveedor';
                    break;
                case 'moneda_id':
                    $headings[] = 'Moneda ID';
                    break;
            }
        }

        return $headings;
    }

    public function map($row): array
    {
        $mappedRow = [];

        foreach ($this->columns as $column) {
            switch ($column) {
                case 'id':
                    $mappedRow[] = $row->id;
                    break;
                case 'solicitud_id':
                    $mappedRow[] = $row->solicitud_id;
                    break;
                case 'contrato_id':
                    $mappedRow[] = $row->contrato_id;
                    break;
                case 'producto':
                    $mappedRow[] = $row->producto;
                    break;
                case 'unidad_medida':
                    $mappedRow[] = $row->unidad_medida;
                    break;
                case 'cantidad':
                    $mappedRow[] = $row->cantidad;
                    break;
                case 'precio_cuc':
                    $mappedRow[] = $row->precio_cuc;
                    break;
                case 'precio_moneda_prov':
                    $mappedRow[] = $row->precio_moneda_prov;
                    break;
                case 'moneda_id':
                    $mappedRow[] = $row->moneda_id;
                    break;
            }
        }

        return $mappedRow;
    }
}
