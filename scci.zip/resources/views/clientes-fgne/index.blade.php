@extends('layouts.app')

@section('title','Listado de Clientes FGNE')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <!-- ENCABEZADO COPIADO DE ASIGNACIONES (bg-gradient-primary) -->
        <div class="card-header bg-gradient-primary text-white d-flex justify-content-between align-items-center">
            <h3>Listado de Clientes FGNE</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('clientes-fgne.create') }}" class="btn btn-primary btn-sm">➕ Nuevo</a>

                <!-- Formularios de exportación separados (GET) -->
                <form method="GET" action="{{ route('clientes-fgne.export.excel') }}" style="display: inline" id="exportExcelForm">
                    <input type="hidden" name="selected" id="exportSelectedExcel" value="">
                    <input type="hidden" name="fgne_codigo" value="{{ request('fgne_codigo') }}">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                <form method="GET" action="{{ route('clientes-fgne.export.pdf') }}" style="display: inline" id="exportPdfForm">
                    <input type="hidden" name="selected" id="exportSelectedPdf" value="">
                    <input type="hidden" name="fgne_codigo" value="{{ request('fgne_codigo') }}">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                <form method="GET" action="{{ route('clientes-fgne.print') }}" style="display: inline" id="printForm" target="_blank">
                    <input type="hidden" name="selected" id="exportSelectedPrint" value="">
                    <input type="hidden" name="fgne_codigo" value="{{ request('fgne_codigo') }}">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Filtros -->
            <form method="GET" action="{{ route('clientes-fgne.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-4">
                        <input type="text" name="search" class="form-control" placeholder="Buscar (Centro, Línea, Fuente...)" 
                               value="{{ request('search') }}">
                    </div>
                    <div class="col-md-3">
                        <select name="fgne_codigo" class="form-select">
                            <option value="">Código FGNE</option>
                            @foreach($codigos as $cod)
                                <option value="{{ $cod }}" {{ request('fgne_codigo') == $cod ? 'selected' : '' }}>
                                    {{ $cod }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('clientes-fgne.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
                <!-- Campos ocultos para ordenación -->
                <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
            </form>

            @if($items->isEmpty())
                <div class="alert alert-info">No hay asignaciones registradas.</div>
            @else
                <!-- Formulario para eliminación múltiple (DELETE) envuelve la TABLA COMPLETA -->
                <form id="deleteForm" method="POST" action="{{ route('clientes-fgne.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <!-- Tabla con scroll horizontal -->
                    <div class="table-responsive" style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
                        <table class="table table-bordered table-hover table-sm align-middle" style="min-width: 1200px;">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="selectAll">
                                    </th>
                                    <th width="200">
                                        <!-- Enlace de ordenación Nombre -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'nombre';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'nombre' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('clientes-fgne.index', $queryParams) }}">
                                            Nombre
                                            @if(request('sort_by') == 'nombre')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="200">Código FGNE</th>
                                    <th width="200">NIT</th>
                                    <th width="200">Representación</th>
                                    <th width="200">Banco / Sucursal</th>
                                    <th width="200">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($items as $item)
                                <tr>
                                    <td>
                                        <input type="checkbox" name="selected[]" value="{{ $item->id }}" class="select-item">
                                    </td>
                                    <td><strong>{{ $item->nombre }}</strong></td>
                                    <td>{{ $item->fgne_codigo ?? '---' }}</td>
                                    <td>{{ $item->codigo_nit ?? '---' }}</td>
                                    <td>{{ $item->representacion ?? '---' }}</td>
                                    <td>{{ $item->sucursal_banco ?? '---' }}</td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="{{ route('clientes-fgne.show', $item->id) }}" class="btn btn-info btn-sm">Ver</a>
                                            <a href="{{ route('clientes-fgne.edit', $item->id) }}" class="btn btn-warning btn-sm">Editar</a>
                                            <form action="{{ route('clientes-fgne.destroy', $item->id) }}" method="POST" style="display:inline-block;">
                                                @csrf @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar este registro?')">Eliminar</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar las asignaciones seleccionadas?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación corregida -->
                @if($items->hasPages())
                    @php 
                        // Preservar todos los parámetros de búsqueda en la paginación
                        $queryParams = request()->all();
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $items->firstItem() }}–{{ $items->lastItem() }} de {{ $items->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <!-- Primera página -->
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('clientes-fgne.index', $queryParams) }}">« Primera</a>
                                </li>
                                
                                <!-- Página anterior -->
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = $items->currentPage() - 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('clientes-fgne.index', $queryParams) }}">‹</a>
                                </li>
                                
                                <!-- Página actual -->
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $items->currentPage() }} de {{ $items->lastPage() }}</span>
                                </li>
                                
                                <!-- Página siguiente -->
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $items->currentPage() + 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('clientes-fgne.index', $queryParams) }}">›</a>
                                </li>
                                
                                <!-- Última página -->
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $items->lastPage();
                                    @endphp
                                    <a class="page-link" href="{{ route('clientes-fgne.index', $queryParams) }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<style>
/* Estilos para la tabla con scroll horizontal (COPIADOS DEL ADJUNTO) */
.table-responsive {
    border: 1px solid #dee2e6;
    border-radius: 4px;
    margin-bottom: 1rem;
}

/* Asegurar que las celdas mantengan su tamaño */
.table th, .table td {
    white-space: nowrap;
    vertical-align: middle;
    padding: 0.5rem;
}

/* Estilo para columnas numéricas */
.text-end {
    font-family: 'Courier New', monospace;
    font-weight: 500;
}

/* Mejorar visualización de botones */
.btn-group .btn-sm {
    padding: 0.25rem 0.5rem;
}

/* Scroll suave en móviles */
@media (max-width: 768px) {
    .table-responsive {
        -webkit-overflow-scrolling: touch;
    }
    
    .card-body {
        padding: 0.75rem;
    }
}

/* Hover para filas */
.table-hover tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.075);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar exportSelected cuando cambian las selecciones
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportSelectedExcel').value = selectedString;
        document.getElementById('exportSelectedPdf').value = selectedString;
        document.getElementById('exportSelectedPrint').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
});
</script>
@endsection