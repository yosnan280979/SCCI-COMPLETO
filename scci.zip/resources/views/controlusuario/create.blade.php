@extends('layouts.app')

@section('title', 'Crear ControlUsuario')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Crear Nuevo ControlUsuario</h3>
                    <div class="card-tools">
                        <a href="{{ route('controlusuario.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    </div>
                </div>
                <form action="{{ route('controlusuario.store') }}" method="POST">
                    @csrf
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                                        <div class="form-group">
                            <label for="usuario_id">Usuario ID</label>
                            <input type="text" class="form-control @error('usuario_id') is-invalid @enderror" 
                                   id="usuario_id" name="usuario_id" value="{{ old('usuario_id') }}" >
                            @error('usuario_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>                        <div class="form-group">
                            <label for="entrada">Entrada</label>
                            <input type="datetime-local" class="form-control @error('entrada') is-invalid @enderror" 
                                   id="entrada" name="entrada" value="{{ old('entrada') }}" >
                            @error('entrada')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>                        <div class="form-group">
                            <label for="salida">Salida</label>
                            <input type="datetime-local" class="form-control @error('salida') is-invalid @enderror" 
                                   id="salida" name="salida" value="{{ old('salida') }}" >
                            @error('salida')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Guardar
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <i class="fas fa-redo"></i> Limpiar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection