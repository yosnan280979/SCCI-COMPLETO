<!DOCTYPE html>
<html>
<head>
    <title>Contratos Suministro - PDF</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; }
        .title { font-size: 18px; font-weight: bold; }
        .subtitle { font-size: 14px; color: #666; }
        .filters { margin-bottom: 15px; padding: 10px; background: #f5f5f5; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background-color: #f2f2f2; font-weight: bold; text-align: left; padding: 8px; border: 1px solid #ddd; }
        td { padding: 8px; border: 1px solid #ddd; }
        .footer { margin-top: 30px; text-align: right; font-size: 10px; color: #666; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">Listado de Contratos Suministro</div>
        <div class="subtitle">Fecha de generación: {{ now()->format('d/m/Y H:i:s') }}</div>
    </div>
    
    @if(!empty($filtros))
    <div class="filters">
        <strong>Filtros aplicados:</strong><br>
        @foreach($filtros as $filtro)
        • {{ $filtro }}<br>
        @endforeach
    </div>
    @endif
    
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>No. Contrato Suministro</th>
                <th>Cliente</th>
                <th>Descripción</th>
                <th>Observaciones</th>
            </tr>
        </thead>
        <tbody>
            @forelse($items as $item)
            <tr>
                <td>{{ $item->{'Id Cttosuministro'} }}</td>
                <td>{{ $item->{'No Ctto Suministro'} }}</td>
                <td>{{ $item->cliente?->{'Cliente'} }}</td>
                <td>{{ $item->{'Descripcion'} }}</td>
                <td>{{ $item->{'Observaciones Ctto Sum'} }}</td>
            </tr>
            @empty
            <tr>
                <td colspan="5" style="text-align: center;">No hay datos para mostrar</td>
            </tr>
            @endforelse
        </tbody>
    </table>
    
    <div class="footer">
        Total de registros: {{ $items->count() }}<br>
        Generado por: {{ auth()->user()->{'Usuario'} ?? 'Sistema' }}
    </div>
</body>
</html>