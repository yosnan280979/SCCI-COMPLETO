<?php

return [
    'search' => [
        'smart' => true,
        'case_insensitive' => true,
        'use_wildcards' => false,
    ],
    'fractal' => [
        'serializer' => 'League\Fractal\Serializer\DataArraySerializer',
    ],
    'script_template' => 'datatables::script',
    'index_column' => 'DT_RowIndex',
    'engines' => [
        'eloquent' => Yajra\DataTables\EloquentDataTable::class,
        'query' => Yajra\DataTables\QueryDataTable::class,
        'collection' => Yajra\DataTables\CollectionDataTable::class,
    ],
    'builders' => [],
    'nulls_last_sql' => ':column :direction NULLS LAST',
    'error' => env('DATATABLES_ERROR', null),
    'columns' => [
        'excess' => ['rn', 'row_num'],
        'escape' => '*',
        'raw' => ['action'],
        'blacklist' => ['password', 'remember_token'],
        'whitelist' => '*',
    ],
    'json' => [
        'header' => [],
        'options' => 0,
    ],
];