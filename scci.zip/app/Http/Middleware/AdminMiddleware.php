<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check()) {
            return redirect()->route('login');
        }

        $user = auth()->user();
        
        // VERIFICACIÓN EXTRA: Asegurarnos que la relación se carga
        if (!$user->relationLoaded('userType')) {
            $user->load('userType');
        }

        // DEBUG: Agrega esto temporalmente para ver qué está pasando
        // dd([
        //     'usuario' => $user->Usuario,
        //     'userType' => $user->userType,
        //     'Id Tipo Usuario' => $user->userType ? $user->userType->{'Id Tipo Usuario'} : null
        // ]);

        if ($user->userType && $user->userType->{'Id Tipo Usuario'} == 1) {
            return $next($request);
        }

        return redirect()->route('dashboard')
            ->with('error', 'No tienes permisos de administrador para acceder a esta sección.');
    }
}