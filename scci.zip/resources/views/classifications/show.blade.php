@extends('layouts.app')

@section('title', 'Ver Classification')
@section('header', 'Ver Classification')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Ver Classification</div>

                <div class="card-body">
                    <table class="table table-bordered">
                        <tr>
                            <th>ID</th>
                            <td>{{ $classification->{'Id Clasificacion'} }}</td>
                        </tr>
                        <tr>
                            <th>Clasificacion</th>
                            <td>{{ $classification->{'Clasificacion'} ?? '' }}</td>
                        </tr>
                        <tr>
                            <th>Con Valor Ctto</th>
                            <td>{{ $classification->{'Con Valor Ctto'} ? 'Sí' : 'No' }}</td>
                        </tr>
                        <tr>
                            <th>Orden</th>
                            <td>{{ $classification->{'Orden'} ?? '' }}</td>
                        </tr>
                    </table>
                    
                    <div class="mt-4">
                        <a href="{{ route('nomencladores.classifications.index') }}" class="btn btn-secondary">Volver</a>
                        
                        @if(auth()->user()->userType->{'Id Tipo Usuario'} != 3)
                        <a href="{{ route('nomencladores.classifications.edit', $classification->{'Id Clasificacion'}) }}" class="btn btn-primary">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection