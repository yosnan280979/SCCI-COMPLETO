<?php

namespace App\Exports;

use App\Models\Embarque;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class EmbarquesExport implements FromCollection, WithHeadings, WithMapping
{
    public function collection()
    {
        return Embarque::all();
    }

    public function headings(): array
    {
        return [
            'ID',
            'SOE',
            'ETA',
            'Fecha Real Arribo',
            'Fecha Entrega Cliente',
            'Tipo Embarque',
        ];
    }

    public function map($item): array
    {
        return [
            $item->Id_Embarque ?? $item->id,
            $item->Id_SOE,
            $item->ETA ? \Carbon\Carbon::parse($item->ETA)->format('d/m/Y') : '',
            $item->Fecha_real_arribo ? \Carbon\Carbon::parse($item->Fecha_real_arribo)->format('d/m/Y') : '',
            $item->Fecha_ent_cliente ? \Carbon\Carbon::parse($item->Fecha_ent_cliente)->format('d/m/Y') : '',
            $item->Tipo_Embarque,
        ];
    }
}
