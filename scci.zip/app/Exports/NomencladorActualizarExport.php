<?php

namespace App\Exports;

use App\Models\NomencladorActualizar;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class NomencladorActualizarExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $actualizaciones;

    public function __construct($actualizaciones)
    {
        $this->actualizaciones = $actualizaciones;
    }

    public function collection()
    {
        return $this->actualizaciones;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Tipo Actualizado',
        ];
    }

    public function map($actualizacion): array
    {
        return [
            $actualizacion->{'Id Actualizado'},
            $actualizacion->{'Actualizado'},
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}