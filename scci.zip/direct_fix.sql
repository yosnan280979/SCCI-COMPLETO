-- Solución directa en MySQL
USE scci_db;

-- 1. Verificar tablas
SHOW TABLES;

-- 2. Eliminar tablas problemáticas si existen
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS permissions;
DROP TABLE IF EXISTS modules;
SET FOREIGN_KEY_CHECKS = 1;

-- 3. Crear tabla modules (sin restricciones problemáticas)
CREATE TABLE modules (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL,
    `order` INT DEFAULT 0,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Crear tabla permissions (sin restricciones problemáticas)
CREATE TABLE permissions (
    id INT NOT NULL AUTO_INCREMENT,
    id_area INT NOT NULL,
    id_module INT NOT NULL,
    view TINYINT DEFAULT 0,
    create_p TINYINT DEFAULT 0,
    edit TINYINT DEFAULT 0,
    delete_p TINYINT DEFAULT 0,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Agregar índices únicos después de crear las tablas
ALTER TABLE modules ADD UNIQUE INDEX idx_slug (slug);
ALTER TABLE permissions ADD UNIQUE INDEX idx_area_module (id_area, id_module);

-- 6. Insertar módulos
INSERT IGNORE INTO modules (name, slug, `order`) VALUES
('Dashboard', 'dashboard', 1),
('Solicitudes', 'solicitudes', 2),
('Contratos', 'contratos', 3),
('Asignaciones', 'asignaciones', 4),
('Logística', 'logistica', 5),
('Proveedores', 'proveedores', 6),
('DITEC', 'ditec', 7),
('Finanzas', 'finanzas', 8),
('Operaciones', 'operaciones', 9),
('Organización', 'organizacion', 10),
('Usuarios', 'usuarios', 11);

-- 7. Insertar permisos
DELETE FROM permissions;

INSERT INTO permissions (id_area, id_module, view, create_p, edit, delete_p)
SELECT 
    a.`Id Area`,
    m.id,
    CASE 
        WHEN a.Area = 'Informatica' THEN 1
        WHEN m.slug = 'dashboard' THEN 1
        ELSE 0
    END as view,
    CASE WHEN a.Area = 'Informatica' THEN 1 ELSE 0 END as create_p,
    CASE WHEN a.Area = 'Informatica' THEN 1 ELSE 0 END as edit,
    CASE WHEN a.Area = 'Informatica' THEN 1 ELSE 0 END as delete_p
FROM `Nomenclador Areas` a
CROSS JOIN modules m;

-- 8. Verificar
SELECT 
    a.Area,
    COUNT(p.id) as total_permisos,
    SUM(p.view) as puede_ver,
    SUM(p.create_p) as puede_crear
FROM `Nomenclador Areas` a
LEFT JOIN permissions p ON a.`Id Area` = p.id_area
GROUP BY a.Area
ORDER BY a.Area;

-- 9. Mostrar ejemplo
SELECT 
    a.Area,
    m.name as Modulo,
    p.view as Ver,
    p.create_p as Crear
FROM permissions p
JOIN `Nomenclador Areas` a ON p.id_area = a.`Id Area`
JOIN modules m ON p.id_module = m.id
WHERE a.Area = 'Informatica' OR m.slug = 'dashboard'
ORDER BY a.Area, m.order;