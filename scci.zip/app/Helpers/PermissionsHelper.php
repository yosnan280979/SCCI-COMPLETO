<?php

use App\Models\User;

if (!function_exists('getCurrentUser')) {
    /**
     * Obtiene el usuario actual con sus relaciones cargadas.
     *
     * @return \App\Models\User|null
     */
    function getCurrentUser()
    {
        return auth()->user();
    }
}

if (!function_exists('isInformatica')) {
    /**
     * Verifica si el usuario actual pertenece al área de Informática.
     *
     * @return bool
     */
    function isInformatica()
    {
        $user = getCurrentUser();
        return $user && $user->area && $user->area->Area === 'Informatica';
    }
}

if (!function_exists('canView')) {
    /**
     * Verifica si el usuario actual puede ver un módulo.
     *
     * @param string $moduleSlug
     * @return bool
     */
    function canView($moduleSlug)
    {
        $user = getCurrentUser();
        
        if (!$user) {
            return false;
        }
        
        // Informática tiene acceso completo
        if (isInformatica()) {
            return true;
        }
        
        // Verificar permisos en la base de datos
        return $user->hasPermission($moduleSlug, 'view');
    }
}

if (!function_exists('canCreate')) {
    /**
     * Verifica si el usuario actual puede crear en un módulo.
     *
     * @param string $moduleSlug
     * @return bool
     */
    function canCreate($moduleSlug)
    {
        $user = getCurrentUser();
        
        if (!$user) {
            return false;
        }
        
        if (isInformatica()) {
            return true;
        }
        
        return $user->hasPermission($moduleSlug, 'create');
    }
}

if (!function_exists('canEdit')) {
    /**
     * Verifica si el usuario actual puede editar en un módulo.
     *
     * @param string $moduleSlug
     * @return bool
     */
    function canEdit($moduleSlug)
    {
        $user = getCurrentUser();
        
        if (!$user) {
            return false;
        }
        
        if (isInformatica()) {
            return true;
        }
        
        return $user->hasPermission($moduleSlug, 'edit');
    }
}

if (!function_exists('canDelete')) {
    /**
     * Verifica si el usuario actual puede eliminar en un módulo.
     *
     * @param string $moduleSlug
     * @return bool
     */
    function canDelete($moduleSlug)
    {
        $user = getCurrentUser();
        
        if (!$user) {
            return false;
        }
        
        if (isInformatica()) {
            return true;
        }
        
        return $user->hasPermission($moduleSlug, 'delete');
    }
}

if (!function_exists('getUserAreaName')) {
    /**
     * Obtiene el área del usuario actual.
     *
     * @return string|null
     */
    function getUserAreaName()
    {
        $user = getCurrentUser();
        return $user->area->Area ?? null;
    }
}

if (!function_exists('getUserPermissions')) {
    /**
     * Obtiene todos los permisos del usuario actual.
     *
     * @return array
     */
    function getUserPermissions()
    {
        $user = getCurrentUser();
        
        if (!$user) {
            return [];
        }
        
        return $user->getAllPermissions()->toArray();
    }
}

if (!function_exists('checkPermission')) {
    /**
     * Verifica un permiso específico.
     *
     * @param string $moduleSlug
     * @param string $action
     * @return bool
     */
    function checkPermission($moduleSlug, $action = 'view')
    {
        switch ($action) {
            case 'create':
                return canCreate($moduleSlug);
            case 'edit':
                return canEdit($moduleSlug);
            case 'delete':
                return canDelete($moduleSlug);
            default:
                return canView($moduleSlug);
        }
    }
}