@extends('layouts.app')

@section('title', 'Clasificaciones')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Clasificaciones</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('nomencladores.classifications.create') }}" class="btn btn-primary btn-sm">➕ Nuevo</a>
                
                <!-- Formularios de exportación separados (GET) -->
                <form id="exportExcelForm" method="GET" action="{{ route('nomencladores.classifications.export.excel') }}" style="display: inline">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="con_valor_ctto" value="{{ request('con_valor_ctto') }}">
                    <input type="hidden" name="orden" value="{{ request('orden') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="exportSelectedIds" value="">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                
                <form id="exportPdfForm" method="GET" action="{{ route('nomencladores.classifications.export.pdf') }}" style="display: inline">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="con_valor_ctto" value="{{ request('con_valor_ctto') }}">
                    <input type="hidden" name="orden" value="{{ request('orden') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="pdfSelectedIds" value="">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                
                <form id="printForm" method="GET" action="{{ route('nomencladores.classifications.print') }}" style="display: inline" target="_blank">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="con_valor_ctto" value="{{ request('con_valor_ctto') }}">
                    <input type="hidden" name="orden" value="{{ request('orden') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="printSelectedIds" value="">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Filtros -->
            <form method="GET" action="{{ route('nomencladores.classifications.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" name="search" class="form-control" placeholder="Buscar por ID o Clasificación..."
                               value="{{ request('search') }}">
                    </div>
                    <div class="col-md-3">
                        <select name="con_valor_ctto" class="form-select">
                            <option value="">Con Valor Contrato</option>
                            <option value="1" {{ request('con_valor_ctto') == '1' ? 'selected' : '' }}>Sí</option>
                            <option value="0" {{ request('con_valor_ctto') == '0' ? 'selected' : '' }}>No</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="orden" class="form-control" placeholder="Orden"
                               value="{{ request('orden') }}">
                    </div>
                    <div class="col-md-3">
                        <select name="sort_by" class="form-select">
                            <option value="">Ordenar por</option>
                            <option value="Id Clasificacion" {{ request('sort_by') == 'Id Clasificacion' ? 'selected' : '' }}>ID Clasificación</option>
                            <option value="Clasificacion" {{ request('sort_by') == 'Clasificacion' ? 'selected' : '' }}>Clasificación</option>
                            <option value="Con Valor Ctto" {{ request('sort_by') == 'Con Valor Ctto' ? 'selected' : '' }}>Con Valor Contrato</option>
                            <option value="Orden" {{ request('sort_by') == 'Orden' ? 'selected' : '' }}>Orden</option>
                        </select>
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <select name="sort_dir" class="form-select">
                            <option value="desc" {{ request('sort_dir', 'desc') == 'desc' ? 'selected' : '' }}>
                                Descendente
                            </option>
                            <option value="asc" {{ request('sort_dir') == 'asc' ? 'selected' : '' }}>
                                Ascendente
                            </option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('nomencladores.classifications.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
            </form>

            @if($classifications->isEmpty())
                <div class="alert alert-info">No hay clasificaciones registradas.</div>
            @else
                <!-- Formulario para eliminación múltiple (DELETE) -->
                <form id="deleteForm" method="POST" action="{{ route('nomencladores.classifications.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-sm" style="font-size: 0.9rem;">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="select-all-checkbox">
                                    </th>
                                    <th>ID Clasificación</th>
                                    <th>Clasificación</th>
                                    <th>Con Valor Contrato</th>
                                    <th>Orden</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($classifications as $classification)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="selected_ids[]" value="{{ $classification->{'Id Clasificacion'} }}" class="select-item">
                                        </td>
                                        <td>{{ $classification->{'Id Clasificacion'} }}</td>
                                        <td>{{ $classification->Clasificacion }}</td>
                                        <td>
                                            <span class="badge bg-{{ $classification->{'Con Valor Ctto'} ? 'warning' : 'secondary' }}">
                                                {{ $classification->{'Con Valor Ctto'} ? 'Sí' : 'No' }}
                                            </span>
                                        </td>
                                        <td>{{ $classification->Orden }}</td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('nomencladores.classifications.show', $classification->{'Id Clasificacion'}) }}" class="btn btn-info btn-sm">Ver</a>
                                                <a href="{{ route('nomencladores.classifications.edit', $classification->{'Id Clasificacion'}) }}" class="btn btn-warning btn-sm">Editar</a>
                                                <form action="{{ route('nomencladores.classifications.destroy', $classification->{'Id Clasificacion'}) }}" method="POST" style="display:inline-block">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar esta clasificación?')">Eliminar</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar las clasificaciones seleccionadas?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación corregida -->
                @if($classifications->hasPages())
                    @php 
                        // Preservar todos los parámetros de búsqueda en la paginación
                        $queryParams = request()->all();
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $classifications->firstItem() }}–{{ $classifications->lastItem() }} de {{ $classifications->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <!-- Primera página -->
                                <li class="page-item {{ $classifications->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('nomencladores.classifications.index', $queryParams) }}">« Primera</a>
                                </li>
                                
                                <!-- Página anterior -->
                                <li class="page-item {{ $classifications->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = $classifications->currentPage() - 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('nomencladores.classifications.index', $queryParams) }}">‹</a>
                                </li>
                                
                                <!-- Página actual -->
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $classifications->currentPage() }} de {{ $classifications->lastPage() }}</span>
                                </li>
                                
                                <!-- Página siguiente -->
                                <li class="page-item {{ $classifications->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $classifications->currentPage() + 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('nomencladores.classifications.index', $queryParams) }}">›</a>
                                </li>
                                
                                <!-- Última página -->
                                <li class="page-item {{ $classifications->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $classifications->lastPage();
                                    @endphp
                                    <a class="page-link" href="{{ route('nomencladores.classifications.index', $queryParams) }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('select-all-checkbox');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar selecciones cuando cambian los checkboxes individuales
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportSelectedIds').value = selectedString;
        document.getElementById('pdfSelectedIds').value = selectedString;
        document.getElementById('printSelectedIds').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
});
</script>
@endsection