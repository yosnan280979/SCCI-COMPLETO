<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Auth;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        //
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        $this->registerPolicies();

        // Definir Gates para permisos
        Gate::define('view', function ($user) {
            return $user->hasPermission('view');
        });

        Gate::define('create', function ($user) {
            return $user->hasPermission('create');
        });

        Gate::define('edit', function ($user) {
            return $user->hasPermission('edit');
        });

        Gate::define('delete', function ($user) {
            return $user->hasPermission('delete');
        });

        // Gate adicional para Informática
        Gate::define('is_informatica', function ($user) {
            return $user->isInformatica();
        });
    }
}