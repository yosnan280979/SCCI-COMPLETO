<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Permission;
use App\Models\Area;

class PermissionsSeeder extends Seeder
{
    public function run()
    {
        // Crear áreas si no existen
        $areas = [
            'Informatica',
            'Contratación',
            'Logística',
            'Finanzas',
            'Operaciones',
            'Compras',
            'Ventas',
            'Almacén',
            'Calidad',
            'Dirección',
            'Administración',
            'Recursos Humanos',
            'Legal',
            'Comunicación',
            'Proyectos'
        ];

        foreach ($areas as $areaName) {
            Area::firstOrCreate(['Area' => $areaName]);
        }

        $areas = Area::all();
        
        // Permisos por defecto
        $defaultPermissions = [
            'Informatica' => [
                'dashboard' => ['view', 'create', 'edit', 'delete'],
                'solicitudes' => ['view', 'create', 'edit', 'delete'],
                'contratos' => ['view', 'create', 'edit', 'delete'],
                'asignaciones' => ['view', 'create', 'edit', 'delete'],
                'logistica' => ['view', 'create', 'edit', 'delete'],
                'proveedores' => ['view', 'create', 'edit', 'delete'],
                'ditec' => ['view', 'create', 'edit', 'delete'],
                'finanzas' => ['view', 'create', 'edit', 'delete'],
                'operaciones' => ['view', 'create', 'edit', 'delete'],
                'organizacion' => ['view', 'create', 'edit', 'delete'],
                'usuarios' => ['view', 'create', 'edit', 'delete'],
                'permissions' => ['view', 'create', 'edit', 'delete'],
            ],
            'Contratación' => [
                'dashboard' => ['view'],
                'solicitudes' => ['view', 'create', 'edit'],
                'contratos' => ['view', 'create', 'edit'],
                'asignaciones' => ['view'],
                'proveedores' => ['view'],
                'organizacion' => ['view'],
            ],
            'Logística' => [
                'dashboard' => ['view'],
                'logistica' => ['view', 'create', 'edit'],
                'proveedores' => ['view'],
                'contratos' => ['view'],
            ],
            'Finanzas' => [
                'dashboard' => ['view'],
                'finanzas' => ['view', 'create', 'edit'],
                'asignaciones' => ['view', 'create', 'edit'],
                'solicitudes' => ['view'],
                'contratos' => ['view'],
            ],
            'Operaciones' => [
                'dashboard' => ['view'],
                'operaciones' => ['view', 'create', 'edit'],
                'solicitudes' => ['view'],
                'contratos' => ['view'],
            ],
            'Compras' => [
                'dashboard' => ['view'],
                'solicitudes' => ['view', 'create', 'edit'],
                'proveedores' => ['view', 'create', 'edit'],
                'contratos' => ['view'],
            ],
            'Dirección' => [
                'dashboard' => ['view', 'create', 'edit'],
                'solicitudes' => ['view', 'create', 'edit'],
                'contratos' => ['view', 'create', 'edit'],
                'finanzas' => ['view'],
                'operaciones' => ['view'],
            ],
            'Administración' => [
                'dashboard' => ['view'],
                'finanzas' => ['view'],
                'organizacion' => ['view'],
            ],
            'Recursos Humanos' => [
                'dashboard' => ['view'],
                'organizacion' => ['view'],
            ],
            'Legal' => [
                'dashboard' => ['view'],
                'contratos' => ['view', 'create', 'edit'],
                'solicitudes' => ['view'],
            ],
        ];
        
        foreach ($areas as $area) {
            if (isset($defaultPermissions[$area->Area])) {
                foreach ($defaultPermissions[$area->Area] as $module => $actions) {
                    foreach ($actions as $action) {
                        Permission::firstOrCreate([
                            'module' => $module,
                            'action' => $action,
                            'area_id' => $area->id,
                        ]);
                    }
                }
            } else {
                // Permisos mínimos para áreas no especificadas
                Permission::firstOrCreate([
                    'module' => 'dashboard',
                    'action' => 'view',
                    'area_id' => $area->id,
                ]);
            }
        }
        
        $this->command->info('Permisos creados para ' . $areas->count() . ' áreas.');
    }
}