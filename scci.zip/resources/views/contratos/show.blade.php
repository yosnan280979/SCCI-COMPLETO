@extends('layouts.app')

@section('title', 'Detalle de Contrato')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Detalle de Contrato #{{ $contrato->{'Id Ctto'} }}</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>No. Contrato:</strong> {{ $contrato->{'No Ctto'} ?? 'N/A' }}</p>
                    <p><strong>Proveedor:</strong> {{ $contrato->provider->Proveedor ?? 'N/A' }}</p>
                    <p><strong>Valor (Mon. Prov.):</strong> {{ $contrato->{'Valor Ctto Mon Prov'} ? number_format($contrato->{'Valor Ctto Mon Prov'}, 2) : '0.00' }}</p>
                    <p><strong>Moneda:</strong> {{ $contrato->currency->Moneda ?? 'N/A' }}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Valor (CUC):</strong> {{ $contrato->{'Valor Ctto CUC'} ? number_format($contrato->{'Valor Ctto CUC'}, 2) : '0.00' }}</p>
                    <p><strong>Forma de Pago:</strong> {{ $contrato->{'Forma de Pago'} ?? 'N/A' }}</p>
                    <p><strong>Estado:</strong> 
                        @if($contrato->Concluido)
                            <span class="badge bg-success">Concluido</span>
                        @else
                            <span class="badge bg-warning">En Proceso</span>
                        @endif
                        @if($contrato->Cancelado)
                            <span class="badge bg-danger">Cancelado</span>
                        @endif
                    </p>
                    <p><strong>Observaciones:</strong> {{ $contrato->{'Observaciones Esp'} ?? 'N/A' }}</p>
                </div>
            </div>
            
            <div class="mt-3">
                <a href="{{ route('contratos.index') }}" class="btn btn-secondary">Volver</a>
                <a href="{{ route('contratos.edit', $contrato->{'Id Ctto'}) }}" class="btn btn-warning">Editar</a>
                <form action="{{ route('contratos.destroy', $contrato->{'Id Ctto'}) }}" method="POST" style="display:inline-block">
                    @csrf @method('DELETE')
                    <button type="submit" class="btn btn-danger" onclick="return confirm('¿Eliminar este contrato?')">Eliminar</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection