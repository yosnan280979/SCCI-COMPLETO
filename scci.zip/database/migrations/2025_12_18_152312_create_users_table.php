<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Verificar si la tabla ya existe antes de crearla
        if (!Schema::hasTable('Nomenclador Usuarios')) {
            Schema::create('Nomenclador Usuarios', function (Blueprint $table) {
                $table->string('PWD')->primary();
                $table->string('Usuario')->unique();
                $table->unsignedInteger('Id Tipo Usuario');
                $table->unsignedInteger('Id Area')->nullable();
                $table->unsignedInteger('Id Especialista')->nullable();
                $table->string('Nombre completo')->nullable();
                $table->string('remember_token')->nullable();
                $table->timestamps();

                $table->foreign('Id Tipo Usuario')->references('Id Tipo Usuario')->on('Nomenclador Tipos Usuarios');
                $table->foreign('Id Area')->references('Id Area')->on('Nomenclador Areas');
                $table->foreign('Id Especialista')->references('Id especialista')->on('Nomenclador Especialistas');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Nomenclador Usuarios');
    }
};