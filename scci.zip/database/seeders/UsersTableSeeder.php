// database/seeders/UsersTableSeeder.php
<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    public function run()
    {
        // Administrador
        User::create([
            'PWD' => Hash::make('password'),
            'Usuario' => 'admin',
            'Id Tipo Usuario' => 1,
            'Id Area' => 1,
            'Id Especialista' => 1,
            'Nombre completo' => 'Administrador del Sistema',
        ]);
        
        // Editor
        User::create([
            'PWD' => Hash::make('password'),
            'Usuario' => 'editor',
            'Id Tipo Usuario' => 2,
            'Id Area' => 1,
            'Id Especialista' => 2,
            'Nombre completo' => 'Editor del Sistema',
        ]);
        
        // Visualizador
        User::create([
            'PWD' => Hash::make('password'),
            'Usuario' => 'viewer',
            'Id Tipo Usuario' => 3,
            'Id Area' => 1,
            'Id Especialista' => 3,
            'Nombre completo' => 'Visualizador del Sistema',
        ]);
    }
}