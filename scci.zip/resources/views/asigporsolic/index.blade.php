@extends('layouts.app')

@section('title', 'Asignaciones por Solicitud')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Asignaciones por Solicitud</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('asigporsolic.create') }}" class="btn btn-primary btn-sm">➕ Crear Asignación</a>
                
                <!-- Formularios de exportación separados (GET) -->
                <form id="exportExcelForm" method="GET" action="{{ route('asigporsolic.export.excel') }}" style="display: inline">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="id_solicitud" value="{{ request('id_solicitud') }}">
                    <input type="hidden" name="ano_desde" value="{{ request('ano_desde') }}">
                    <input type="hidden" name="ano_hasta" value="{{ request('ano_hasta') }}">
                    <input type="hidden" name="mcuc_desde" value="{{ request('mcuc_desde') }}">
                    <input type="hidden" name="mcuc_hasta" value="{{ request('mcuc_hasta') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="exportSelectedIds" value="">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                
                <form id="exportPdfForm" method="GET" action="{{ route('asigporsolic.export.pdf') }}" style="display: inline">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="id_solicitud" value="{{ request('id_solicitud') }}">
                    <input type="hidden" name="ano_desde" value="{{ request('ano_desde') }}">
                    <input type="hidden" name="ano_hasta" value="{{ request('ano_hasta') }}">
                    <input type="hidden" name="mcuc_desde" value="{{ request('mcuc_desde') }}">
                    <input type="hidden" name="mcuc_hasta" value="{{ request('mcuc_hasta') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="pdfSelectedIds" value="">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                
                <form id="printForm" method="GET" action="{{ route('asigporsolic.print') }}" style="display: inline" target="_blank">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="id_solicitud" value="{{ request('id_solicitud') }}">
                    <input type="hidden" name="ano_desde" value="{{ request('ano_desde') }}">
                    <input type="hidden" name="ano_hasta" value="{{ request('ano_hasta') }}">
                    <input type="hidden" name="mcuc_desde" value="{{ request('mcuc_desde') }}">
                    <input type="hidden" name="mcuc_hasta" value="{{ request('mcuc_hasta') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="printSelectedIds" value="">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Filtros -->
            <form method="GET" action="{{ route('asigporsolic.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" name="search" class="form-control" placeholder="Buscar (ID Solicitud...)" 
                               value="{{ request('search') }}">
                    </div>
                    <div class="col-md-3">
                        <select name="id_solicitud" class="form-select">
                            <option value="">Solicitud</option>
                            @foreach($solicitudes as $solicitud)
                                <option value="{{ $solicitud->{'Id Solicitud'} }}" 
                                    {{ request('id_solicitud') == $solicitud->{'Id Solicitud'} ? 'selected' : '' }}>
                                    {{ $solicitud->{'No Solicitud'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2">
                        <input type="number" name="ano_desde" class="form-control" 
                               placeholder="Año desde" value="{{ request('ano_desde') }}" min="2000" max="2100">
                    </div>
                    <div class="col-md-2">
                        <input type="number" name="ano_hasta" class="form-control" 
                               placeholder="Año hasta" value="{{ request('ano_hasta') }}" min="2000" max="2100">
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('asigporsolic.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="mcuc_desde" class="form-control" 
                               placeholder="MCUC mínimo" value="{{ request('mcuc_desde') }}" min="0">
                    </div>
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="mcuc_hasta" class="form-control" 
                               placeholder="MCUC máximo" value="{{ request('mcuc_hasta') }}" min="0">
                    </div>
                    <div class="col-md-3">
                        <select name="sort_by" class="form-select">
                            <option value="">Ordenar por</option>
                            <option value="Id Solicitud" {{ request('sort_by') == 'Id Solicitud' ? 'selected' : '' }}>
                                ID Solicitud
                            </option>
                            <option value="Año finan" {{ request('sort_by') == 'Año finan' ? 'selected' : '' }}>
                                Año financiero
                            </option>
                            <option value="Asig MCUC" {{ request('sort_by') == 'Asig MCUC' ? 'selected' : '' }}>
                                Asignación MCUC
                            </option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="sort_dir" class="form-select">
                            <option value="desc" {{ request('sort_dir', 'desc') == 'desc' ? 'selected' : '' }}>
                                Descendente
                            </option>
                            <option value="asc" {{ request('sort_dir') == 'asc' ? 'selected' : '' }}>
                                Ascendente
                            </option>
                        </select>
                    </div>
                </div>
            </form>

            @if($asigporsolic->isEmpty())
                <div class="alert alert-info">No hay asignaciones registradas.</div>
            @else
                <!-- Formulario para eliminación múltiple (DELETE) -->
                <form id="deleteForm" method="POST" action="{{ route('asigporsolic.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <div class="table-responsive" style="overflow-x: auto;">
                        <table class="table table-bordered table-hover table-sm" style="font-size: 0.9rem;">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="select-all-checkbox">
                                    </th>
                                    <th>ID Solicitud</th>
                                    <th>Año Finan</th>
                                    <th>Asig MCUC</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($asigporsolic as $asignacion)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="selected_ids[]" value="{{ $asignacion->{'Id Solicitud'} }}" class="select-item">
                                        </td>
                                        <td>{{ $asignacion->{'Id Solicitud'} }}</td>
                                        <td>{{ $asignacion->{'Año finan'} }}</td>
                                        <td>{{ number_format($asignacion->{'Asig MCUC'}, 2) }}</td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('asigporsolic.show', $asignacion->{'Id Solicitud'}) }}" class="btn btn-info btn-sm">Ver</a>
                                                <a href="{{ route('asigporsolic.edit', $asignacion->{'Id Solicitud'}) }}" class="btn btn-warning btn-sm">Editar</a>
                                                <form action="{{ route('asigporsolic.destroy', $asignacion->{'Id Solicitud'}) }}" method="POST" style="display:inline-block">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar esta asignación?')">Eliminar</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            @if($asigporsolic->isNotEmpty())
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="2" class="text-end"><strong>Totales:</strong></td>
                                    <td><strong>{{ $asigporsolic->count() }} registros</strong></td>
                                    <td>
                                        <strong>
                                            @php
                                                $totalMcuc = $asigporsolic->sum('Asig MCUC');
                                            @endphp
                                            {{ number_format($totalMcuc, 2) }}
                                        </strong>
                                    </td>
                                    <td></td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar las asignaciones seleccionadas?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación corregida -->
                @if($asigporsolic->hasPages())
                    @php 
                        // Preservar todos los parámetros de búsqueda en la paginación
                        $queryParams = request()->all();
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $asigporsolic->firstItem() }}–{{ $asigporsolic->lastItem() }} de {{ $asigporsolic->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <!-- Primera página -->
                                <li class="page-item {{ $asigporsolic->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('asigporsolic.index', $queryParams) }}">« Primera</a>
                                </li>
                                
                                <!-- Página anterior -->
                                <li class="page-item {{ $asigporsolic->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = $asigporsolic->currentPage() - 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('asigporsolic.index', $queryParams) }}">‹</a>
                                </li>
                                
                                <!-- Página actual -->
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $asigporsolic->currentPage() }} de {{ $asigporsolic->lastPage() }}</span>
                                </li>
                                
                                <!-- Página siguiente -->
                                <li class="page-item {{ $asigporsolic->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $asigporsolic->currentPage() + 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('asigporsolic.index', $queryParams) }}">›</a>
                                </li>
                                
                                <!-- Última página -->
                                <li class="page-item {{ $asigporsolic->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $asigporsolic->lastPage();
                                    @endphp
                                    <a class="page-link" href="{{ route('asigporsolic.index', $queryParams) }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('select-all-checkbox');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar selecciones cuando cambian los checkboxes individuales
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportSelectedIds').value = selectedString;
        document.getElementById('pdfSelectedIds').value = selectedString;
        document.getElementById('printSelectedIds').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
});
</script>
@endsection