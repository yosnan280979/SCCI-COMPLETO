@extends('layouts.app')

@section('title', 'Editar Descripción de Contrato')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Editar Descripción de Contrato #{{ $descripcionContrato->Id ?? $descripcionContrato->id }}</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('descripcion-contrato.update', $descripcionContrato->Id ?? $descripcionContrato->id) }}" method="POST">
                @csrf
                @method('PUT')
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Id Solicitud" class="form-label">Solicitud</label>
                        <select class="form-select" id="Id Solicitud" name="Id Solicitud">
                            <option value="">Seleccionar Solicitud</option>
                            @foreach($solicitudes as $solicitud)
                                <option value="{{ $solicitud->{'Id Solicitud'} }}" 
                                    {{ ($descripcionContrato->{'Id Solicitud'} == $solicitud->{'Id Solicitud'}) ? 'selected' : '' }}>
                                    {{ $solicitud->{'No Solicitud'} }} - {{ $solicitud->cliente?->{'Cliente'} ?? 'N/A' }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="Id Ctto" class="form-label">Contrato</label>
                        <select class="form-select" id="Id Ctto" name="Id Ctto">
                            <option value="">Seleccionar Contrato</option>
                            @foreach($contratos as $contrato)
                                <option value="{{ $contrato->{'Id Ctto'} }}" 
                                    {{ ($descripcionContrato->{'Id Ctto'} == $contrato->{'Id Ctto'}) ? 'selected' : '' }}>
                                    {{ $contrato->{'No Ctto'} }} - {{ $contrato->proveedor?->{'Proveedor'} ?? 'N/A' }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Producto" class="form-label">Producto *</label>
                        <input type="text" class="form-control" id="Producto" name="Producto" 
                               value="{{ $descripcionContrato->Producto }}" required>
                    </div>
                    <div class="col-md-6">
                        <label for="UM" class="form-label">Unidad de Medida *</label>
                        <input type="text" class="form-control" id="UM" name="UM" 
                               value="{{ $descripcionContrato->UM }}" required>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="Cantidad" class="form-label">Cantidad *</label>
                        <input type="number" step="0.01" class="form-control" id="Cantidad" name="Cantidad" 
                               value="{{ $descripcionContrato->Cantidad }}" required>
                    </div>
                    <div class="col-md-4">
                        <label for="Precio CUC" class="form-label">Precio CUC</label>
                        <input type="number" step="0.01" class="form-control" id="Precio CUC" name="Precio CUC" 
                               value="{{ $descripcionContrato->{'Precio CUC'} }}">
                    </div>
                    <div class="col-md-4">
                        <label for="Precio Mon Prov" class="form-label">Precio Moneda Proveedor</label>
                        <input type="number" step="0.01" class="form-control" id="Precio Mon Prov" name="Precio Mon Prov" 
                               value="{{ $descripcionContrato->{'Precio Mon Prov'} }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Id Moneda" class="form-label">Moneda</label>
                        <select class="form-select" id="Id Moneda" name="Id Moneda">
                            <option value="">Seleccionar Moneda</option>
                            @foreach($monedas as $moneda)
                                <option value="{{ $moneda->{'Id Moneda'} }}" 
                                    {{ ($descripcionContrato->{'Id Moneda'} == $moneda->{'Id Moneda'}) ? 'selected' : '' }}>
                                    {{ $moneda->Moneda }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="{{ route('descripcion-contrato.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Actualizar Descripción</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection