<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Personal Cubano - PDF</title>
    <style>
        body { 
            font-family: 'DejaVu Sans', Arial, sans-serif; 
            font-size: 9px; 
            line-height: 1.3;
            margin: 0;
            padding: 0;
        }
        .header { 
            text-align: center; 
            margin-bottom: 10px; 
            padding-bottom: 8px;
            border-bottom: 2px solid #333;
        }
        .title { 
            font-size: 14px; 
            font-weight: bold; 
            margin-bottom: 3px;
        }
        .subtitle { 
            font-size: 10px; 
            color: #666;
            margin-bottom: 3px;
        }
        .report-info {
            font-size: 8px;
            color: #666;
            text-align: center;
            margin-bottom: 10px;
        }
        .filters { 
            margin-bottom: 8px; 
            padding: 6px; 
            background: #f5f5f5; 
            border-radius: 3px;
            border: 1px solid #ddd;
            font-size: 8px;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 5px;
            font-size: 7px;
        }
        th { 
            background-color: #f2f2f2; 
            font-weight: bold; 
            text-align: left; 
            padding: 3px 4px; 
            border: 1px solid #ddd;
            font-size: 8px;
        }
        td { 
            padding: 3px 4px; 
            border: 1px solid #ddd;
            font-size: 7px;
            vertical-align: top;
        }
        .text-center { text-align: center; }
        .badge-active { 
            background-color: #28a745; 
            color: white; 
            padding: 1px 4px; 
            border-radius: 2px;
            font-size: 7px;
        }
        .badge-inactive { 
            background-color: #dc3545; 
            color: white; 
            padding: 1px 4px; 
            border-radius: 2px;
            font-size: 7px;
        }
        .footer { 
            margin-top: 15px; 
            text-align: right; 
            font-size: 8px; 
            color: #666;
            border-top: 1px solid #ddd;
            padding-top: 8px;
        }
        .summary {
            margin-top: 8px;
            padding: 6px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 3px;
            font-size: 8px;
            margin-bottom: 10px;
        }
        .nowrap { white-space: nowrap; }
        .wrap { white-space: normal; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">Listado de Personal Cubano</div>
        <div class="subtitle">Empresa: {{ config('app.name', 'Sistema') }}</div>
        <div class="report-info">
            Fecha de generación: {{ now()->format('d/m/Y H:i:s') }}
        </div>
    </div>
    
    @if(!empty($filtros))
    <div class="filters">
        <strong>Filtros aplicados:</strong><br>
        @foreach($filtros as $filtro)
        • {{ $filtro }}<br>
        @endforeach
    </div>
    @endif

    <div class="summary">
        <strong>Resumen:</strong> 
        Total registros: {{ $items->count() }} | 
        Activos: {{ $items->where('Activo', 1)->count() }} | 
        Inactivos: {{ $items->where('Activo', 0)->count() }}
    </div>
    
    <table>
        <thead>
            <tr>
                <th class="text-center">ID</th>
                <th>Funcionario Cubano</th>
                <th>Proveedor</th>
                <th>Teléfono</th>
                <th>Email</th>
                <th>Carnet Acorec</th>
                <th>Vigencia</th>
                <th>Tipo Contrato</th>
                <th class="text-center">Activo</th>
                <th>Cargo</th>
                <th>Dirección</th>
                <th>Observaciones</th>
            </tr>
        </thead>
        <tbody>
            @forelse($items as $item)
            <tr>
                <td class="text-center">{{ $item->Id }}</td>
                <td>{{ $item->Funcionario_cubano }}</td>
                <td>{{ $item->provider ? $item->provider->Proveedor : ($item->Id_Proveedor ?: 'N/A') }}</td>
                <td class="nowrap">{{ $item->telef }}</td>
                <td>{{ $item->Email }}</td>
                <td>{{ $item->Carnet_Acorec }}</td>
                <td class="nowrap">{{ $item->Vigencia ? \Carbon\Carbon::parse($item->Vigencia)->format('d/m/Y') : '' }}</td>
                <td>
                    @if($item->tipoCtto)
                        {{ $item->tipoCtto->{'Tipo Ctto'} }}
                    @elseif($item->Id_Tipo_Ctto)
                        ID: {{ $item->Id_Tipo_Ctto }}
                    @else
                        N/A
                    @endif
                </td>
                <td class="text-center">
                    @if($item->Activo)
                        <span class="badge-active">Sí</span>
                    @else
                        <span class="badge-inactive">No</span>
                    @endif
                </td>
                <td>{{ $item->Cargo ?? 'N/A' }}</td>
                <td class="wrap">{{ $item->Direccion ?? 'N/A' }}</td>
                <td class="wrap">{{ $item->Observaciones ?? 'N/A' }}</td>
            </tr>
            @empty
            <tr>
                <td colspan="12" style="text-align: center; padding: 10px;">
                    No hay datos para mostrar
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
    
    <div class="footer">
        Total de registros: {{ $items->count() }}<br>
        Generado por: {{ auth()->user()->{'Usuario'} ?? auth()->user()->name ?? 'Sistema' }}<br>
        Sistema: {{ config('app.name', 'Gestión de Personal') }}
    </div>
</body>
</html>