@extends('layouts.app')

@section('title', 'Datos SOE')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Datos SOE</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('datos-soe.create') }}" class="btn btn-primary btn-sm">➕ Nuevo</a>
                <!-- Formularios independientes para exportación (GET) - ELIMINADO @csrf -->
                <form method="GET" action="{{ route('datos-soe.export.excel') }}" style="display: inline">
                    <input type="hidden" name="selected" id="exportSelectedExcel" value="">
                    <input type="hidden" name="no_soe" value="{{ request('no_soe') }}">
                    <input type="hidden" name="id_ctto" value="{{ request('id_ctto') }}">
                    <input type="hidden" name="no_suplemento" value="{{ request('no_suplemento') }}">
                    <input type="hidden" name="cancelado_soe" value="{{ request('cancelado_soe') }}">
                    <input type="hidden" name="fecha_desde" value="{{ request('fecha_desde') }}">
                    <input type="hidden" name="fecha_hasta" value="{{ request('fecha_hasta') }}">
                    <input type="hidden" name="valor_desde" value="{{ request('valor_desde') }}">
                    <input type="hidden" name="valor_hasta" value="{{ request('valor_hasta') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                <form method="GET" action="{{ route('datos-soe.export.pdf') }}" style="display: inline">
                    <input type="hidden" name="selected" id="exportSelectedPdf" value="">
                    <input type="hidden" name="no_soe" value="{{ request('no_soe') }}">
                    <input type="hidden" name="id_ctto" value="{{ request('id_ctto') }}">
                    <input type="hidden" name="no_suplemento" value="{{ request('no_suplemento') }}">
                    <input type="hidden" name="cancelado_soe" value="{{ request('cancelado_soe') }}">
                    <input type="hidden" name="fecha_desde" value="{{ request('fecha_desde') }}">
                    <input type="hidden" name="fecha_hasta" value="{{ request('fecha_hasta') }}">
                    <input type="hidden" name="valor_desde" value="{{ request('valor_desde') }}">
                    <input type="hidden" name="valor_hasta" value="{{ request('valor_hasta') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                <form method="GET" action="{{ route('datos-soe.print') }}" style="display: inline" target="_blank">
                    <input type="hidden" name="selected" id="exportSelectedPrint" value="">
                    <input type="hidden" name="no_soe" value="{{ request('no_soe') }}">
                    <input type="hidden" name="id_ctto" value="{{ request('id_ctto') }}">
                    <input type="hidden" name="no_suplemento" value="{{ request('no_suplemento') }}">
                    <input type="hidden" name="cancelado_soe" value="{{ request('cancelado_soe') }}">
                    <input type="hidden" name="fecha_desde" value="{{ request('fecha_desde') }}">
                    <input type="hidden" name="fecha_hasta" value="{{ request('fecha_hasta') }}">
                    <input type="hidden" name="valor_desde" value="{{ request('valor_desde') }}">
                    <input type="hidden" name="valor_hasta" value="{{ request('valor_hasta') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Buscador con filtros -->
            <form method="GET" action="{{ route('datos-soe.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" name="no_soe" value="{{ request('no_soe') }}" class="form-control" placeholder="No. SOE">
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="id_ctto" value="{{ request('id_ctto') }}" class="form-control" placeholder="ID Contrato">
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="no_suplemento" value="{{ request('no_suplemento') }}" class="form-control" placeholder="No. Suplemento">
                    </div>
                    <div class="col-md-3">
                        <select name="cancelado_soe" class="form-select">
                            <option value="">Estado</option>
                            <option value="0" {{ request('cancelado_soe') === '0' ? 'selected' : '' }}>Activo</option>
                            <option value="1" {{ request('cancelado_soe') === '1' ? 'selected' : '' }}>Cancelado</option>
                        </select>
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <input type="date" name="fecha_desde" value="{{ request('fecha_desde') }}" class="form-control" placeholder="Fecha Desde">
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="fecha_hasta" value="{{ request('fecha_hasta') }}" class="form-control" placeholder="Fecha Hasta">
                    </div>
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="valor_desde" value="{{ request('valor_desde') }}" class="form-control" placeholder="Valor CUC Desde">
                    </div>
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="valor_hasta" value="{{ request('valor_hasta') }}" class="form-control" placeholder="Valor CUC Hasta">
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <select name="sort_by" class="form-select">
                            <option value="">Ordenar por</option>
                            <option value="Id SOE" {{ request('sort_by') == 'Id SOE' ? 'selected' : '' }}>ID SOE</option>
                            <option value="No Suplemento" {{ request('sort_by') == 'No Suplemento' ? 'selected' : '' }}>No. Suplemento</option>
                            <option value="Valor Ctto CUC" {{ request('sort_by') == 'Valor Ctto CUC' ? 'selected' : '' }}>Valor CUC</option>
                            <option value="Fecha Comite" {{ request('sort_by') == 'Fecha Comite' ? 'selected' : '' }}>Fecha Comité</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="sort_dir" class="form-select">
                            <option value="desc" {{ request('sort_dir', 'desc') == 'desc' ? 'selected' : '' }}>Descendente</option>
                            <option value="asc" {{ request('sort_dir') == 'asc' ? 'selected' : '' }}>Ascendente</option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Filtrar</button>
                        <a href="{{ route('datos-soe.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
            </form>

            @if($datosSOE->isEmpty())
                <div class="alert alert-info">No hay datos SOE registrados.</div>
            @else
                <!-- Formulario para eliminación múltiple (DELETE) -->
                <form id="deleteForm" method="POST" action="{{ route('datos-soe.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <!-- Tabla con scroll horizontal -->
                    <div class="table-responsive" style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
                        <table class="table table-bordered table-hover table-sm align-middle" style="min-width: 2000px;">
                            <thead class="table-light">
                                <tr>
                                    <th width="50"><input type="checkbox" id="selectAll"></th>
                                    <th width="80">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Id SOE';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Id SOE' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-soe.index', $queryParams) }}">
                                            ID SOE
                                            @if(request('sort_by') == 'Id SOE')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="100">Contrato</th>
                                    <th width="120">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'No Suplemento';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'No Suplemento' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-soe.index', $queryParams) }}">
                                            Suplemento
                                            @if(request('sort_by') == 'No Suplemento')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="120">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Fecha Comite';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Fecha Comite' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-soe.index', $queryParams) }}">
                                            Fecha Comité
                                            @if(request('sort_by') == 'Fecha Comite')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="90">No Acta</th>
                                    <th width="90">No Acuerdo</th>
                                    <th width="120">Valor Mercancía</th>
                                    <th width="120">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Valor Ctto CUC';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Valor Ctto CUC' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-soe.index', $queryParams) }}">
                                            Valor CUC
                                            @if(request('sort_by') == 'Valor Ctto CUC')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="90">Moneda</th>
                                    <th width="120">Valor Moneda</th>
                                    <th width="100">No Referencia</th>
                                    <th width="120">CAD Gescons</th>
                                    <th width="120">CAD MICONS</th>
                                    <th width="120">Acta MICONS</th>
                                    <th width="120">Firma Ctto</th>
                                    <th width="120">Emisión Cert.</th>
                                    <th width="120">Pendiente CUC</th>
                                    <th width="120">Pendiente CUP</th>
                                    <th width="90">Total Emb.</th>
                                    <th width="180">Obs. Jurídico</th>
                                    <th width="180">Obs. SOE</th>
                                    <th width="180">Obs. Especialista</th>
                                    <th width="180">Observaciones</th>
                                    <th width="90">
                                        Cancelado
                                    </th>
                                    <th width="120">Forma Pago</th>
                                    <th width="90">Anular Val.</th>
                                    <th width="120">Momento SOE</th>
                                    <th width="90">Año Finan.</th>
                                    <th width="120">Línea Crédito</th>
                                    <th width="180">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($datosSOE as $item)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="ids[]" value="{{ $item->{'Id SOE'} }}" class="select-item">
                                        </td>
                                        <td>{{ $item->{'Id SOE'} }}</td>
                                        <td>{{ $item->contrato?->{'No Ctto'} ?? 'N/A' }}</td>
                                        <td>{{ $item->{'No Suplemento'} ?: '-' }}</td>
                                        <td>{{ $item->{'Fecha Comite'} ? \Carbon\Carbon::parse($item->{'Fecha Comite'})->format('d/m/Y') : '' }}</td>
                                        <td>{{ $item->{'No Acta'} ?: '-' }}</td>
                                        <td>{{ $item->{'No Acuerdo'} ?: '-' }}</td>
                                        <td class="text-end">
                                            @if($item->{'Valor Mercancia'})
                                                ${{ number_format($item->{'Valor Mercancia'}, 2) }}
                                            @else
                                                -
                                            @endif
                                        </td>
                                        <td class="text-end">
                                            @if($item->{'Valor Ctto CUC'})
                                                ${{ number_format($item->{'Valor Ctto CUC'}, 2) }}
                                            @else
                                                -
                                            @endif
                                        </td>
                                        <td>
                                            {{ $item->moneda->Moneda ?? 'N/A' }}
                                        </td>
                                        <td class="text-end">
                                            @if($item->{'Valor Mon Prov'})
                                                ${{ number_format($item->{'Valor Mon Prov'}, 2) }}
                                            @else
                                                -
                                            @endif
                                        </td>
                                        <td>{{ $item->{'No Referencia'} ?: '-' }}</td>
                                        <td>{{ $item->{'Fecha CAD Gescons'} ? \Carbon\Carbon::parse($item->{'Fecha CAD Gescons'})->format('d/m/Y') : '' }}</td>
                                        <td>{{ $item->{'Fecha CAD MICONS'} ? \Carbon\Carbon::parse($item->{'Fecha CAD MICONS'})->format('d/m/Y') : '' }}</td>
                                        <td>{{ $item->{'No Acta MICONS'} ?: '-' }}</td>
                                        <td>{{ $item->{'Fecha firma Ctto'} ? \Carbon\Carbon::parse($item->{'Fecha firma Ctto'})->format('d/m/Y') : '' }}</td>
                                        <td>{{ $item->{'Fecha emision certif'} ? \Carbon\Carbon::parse($item->{'Fecha emision certif'})->format('d/m/Y') : '' }}</td>
                                        <td class="text-end">
                                            @if($item->{'Pendiente finan CUC'})
                                                ${{ number_format($item->{'Pendiente finan CUC'}, 2) }}
                                            @else
                                                -
                                            @endif
                                        </td>
                                        <td class="text-end">
                                            @if($item->{'Pendiente finan CUP'})
                                                ${{ number_format($item->{'Pendiente finan CUP'}, 2) }}
                                            @else
                                                -
                                            @endif
                                        </td>
                                        <td class="text-center">{{ $item->{'Total embarques'} ?: '-' }}</td>
                                        <td title="{{ $item->{'Observaciones Juridico'} }}">
                                            {{ Str::limit($item->{'Observaciones Juridico'} ?? '', 30) }}
                                        </td>
                                        <td title="{{ $item->{'Observaciones SOE'} }}">
                                            {{ Str::limit($item->{'Observaciones SOE'} ?? '', 30) }}
                                        </td>
                                        <td title="{{ $item->{'Observaciones Especialista'} }}">
                                            {{ Str::limit($item->{'Observaciones Especialista'} ?? '', 30) }}
                                        </td>
                                        <td title="{{ $item->{'Observaciones'} }}">
                                            {{ Str::limit($item->{'Observaciones'} ?? '', 30) }}
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-{{ $item->{'Cancelado SOE'} ? 'danger' : 'success' }}">
                                                {{ $item->{'Cancelado SOE'} ? 'Sí' : 'No' }}
                                            </span>
                                        </td>
                                        <td>{{ Str::limit($item->{'Forma de Pago'} ?? '', 20) }}</td>
                                        <td class="text-center">
                                            <span class="badge bg-{{ $item->{'Anular Valores'} ? 'warning' : 'secondary' }}">
                                                {{ $item->{'Anular Valores'} ? 'Sí' : 'No' }}
                                            </span>
                                        </td>
                                        <td>{{ $item->momentosoe->MomentoSOE ?? 'N/A' }}</td>
                                        <td class="text-center">{{ $item->{'Año finan'} ?: '-' }}</td>
                                        <td>{{ $item->lineacredito->Lineacredito ?? 'N/A' }}</td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('datos-soe.show', $item->{'Id SOE'}) }}" class="btn btn-info btn-sm">Ver</a>
                                                <a href="{{ route('datos-soe.edit', $item->{'Id SOE'}) }}" class="btn btn-warning btn-sm">Editar</a>
                                                <form action="{{ route('datos-soe.destroy', $item->{'Id SOE'}) }}" method="POST" style="display:inline-block;">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Está seguro?')">Eliminar</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            @if($datosSOE->isNotEmpty())
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="7" class="text-end"><strong>Totales:</strong></td>
                                    <td class="text-end">
                                        <strong>
                                            @php
                                                $totalMercancia = $datosSOE->sum('Valor Mercancia');
                                            @endphp
                                            @if($totalMercancia)
                                                ${{ number_format($totalMercancia, 2) }}
                                            @else
                                                -
                                            @endif
                                        </strong>
                                    </td>
                                    <td class="text-end">
                                        <strong>
                                            @php
                                                $totalCuc = $datosSOE->sum('Valor Ctto CUC');
                                            @endphp
                                            @if($totalCuc)
                                                ${{ number_format($totalCuc, 2) }}
                                            @else
                                                -
                                            @endif
                                        </strong>
                                    </td>
                                    <td></td>
                                    <td class="text-end">
                                        <strong>
                                            @php
                                                $totalMon = $datosSOE->sum('Valor Mon Prov');
                                            @endphp
                                            @if($totalMon)
                                                ${{ number_format($totalMon, 2) }}
                                            @else
                                                -
                                            @endif
                                        </strong>
                                    </td>
                                    <td colspan="21"></td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar los registros seleccionados?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación corregida -->
                @if($datosSOE->hasPages())
                    @php 
                        // Preservar todos los parámetros de búsqueda en la paginación
                        $queryParams = request()->all();
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $datosSOE->firstItem() }}–{{ $datosSOE->lastItem() }} de {{ $datosSOE->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <!-- Primera página -->
                                <li class="page-item {{ $datosSOE->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-soe.index', $queryParams) }}">« Primera</a>
                                </li>
                                
                                <!-- Página anterior -->
                                <li class="page-item {{ $datosSOE->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = $datosSOE->currentPage() - 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-soe.index', $queryParams) }}">‹</a>
                                </li>
                                
                                <!-- Página actual -->
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $datosSOE->currentPage() }} de {{ $datosSOE->lastPage() }}</span>
                                </li>
                                
                                <!-- Página siguiente -->
                                <li class="page-item {{ $datosSOE->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $datosSOE->currentPage() + 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-soe.index', $queryParams) }}">›</a>
                                </li>
                                
                                <!-- Última página -->
                                <li class="page-item {{ $datosSOE->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $datosSOE->lastPage();
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-soe.index', $queryParams) }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<style>
/* Estilos para la tabla con scroll horizontal */
.table-responsive {
    border: 1px solid #dee2e6;
    border-radius: 4px;
    margin-bottom: 1rem;
}

/* Asegurar que las celdas mantengan su tamaño */
.table th, .table td {
    white-space: nowrap;
    vertical-align: middle;
    padding: 0.5rem;
}

/* Tooltips para texto largo */
[title] {
    cursor: help;
    position: relative;
}

/* Estilo para columnas numéricas */
.text-end {
    font-family: 'Courier New', monospace;
    font-weight: 500;
}

/* Mejorar visualización de botones */
.btn-group .btn-sm {
    padding: 0.25rem 0.5rem;
}

/* Scroll suave en móviles */
@media (max-width: 768px) {
    .table-responsive {
        -webkit-overflow-scrolling: touch;
    }
    
    .card-body {
        padding: 0.75rem;
    }
}

/* Ajustar tamaño de letra para que sea consistente con otras vistas */
.table-sm {
    font-size: 0.875rem;
}

/* Títulos de columnas más compactos pero legibles */
.table th {
    font-weight: 600;
    background-color: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
}

/* Hover para filas */
.table-hover tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.075);
}

/* Badges con mejor espaciado */
.badge {
    padding: 0.35em 0.65em;
    font-size: 0.75em;
    font-weight: 600;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar exportSelected cuando cambian las selecciones
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportSelectedExcel').value = selectedString;
        document.getElementById('exportSelectedPdf').value = selectedString;
        document.getElementById('exportSelectedPrint').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
    
    // Tooltips de Bootstrap para las observaciones truncadas
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
});
</script>
@endsection