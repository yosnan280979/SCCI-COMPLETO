<?php

namespace App\Exports;

use App\Models\Cliente;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ClientesExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $clientes;

    public function __construct($clientes)
    {
        $this->clientes = $clientes;
    }

    public function collection()
    {
        return $this->clientes;
    }

    public function headings(): array
    {
        return [
            'ID Cliente',
            'Cliente',
            'ID OSDE',
            'OSDE',
            'Bases Presentadas',
            'Fecha Bases'
        ];
    }

    public function map($cliente): array
    {
        return [
            $cliente->{'Id Cliente'},
            $cliente->Cliente,
            $cliente->{'Id OSDE'},
            $cliente->osde ? $cliente->osde->OSDE : '',
            $cliente->{'Bases Presentadas'} ? 'Sí' : 'No',
            $cliente->{'Fecha Bases'} ? \Carbon\Carbon::parse($cliente->{'Fecha Bases'})->format('d/m/Y') : ''
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1    => ['font' => ['bold' => true]],
        ];
    }
}