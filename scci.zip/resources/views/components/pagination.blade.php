@props(['items'])

@if($items->hasPages())
    <div class="d-flex justify-content-between align-items-center mt-2">
        <div class="text-muted">
            Mostrando {{ $items->firstItem() }}–{{ $items->lastItem() }} de {{ $items->total() }} registros
        </div>
        <nav>
            <ul class="pagination mb-0">
                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                    <a class="page-link" href="{{ $items->withQueryString()->url(1) }}">« Primera</a>
                </li>
                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                    <a class="page-link" href="{{ $items->previousPageUrl() }}">‹</a>
                </li>
                <li class="page-item disabled">
                    <span class="page-link">Página {{ $items->currentPage() }} de {{ $items->lastPage() }}</span>
                </li>
                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                    <a class="page-link" href="{{ $items->nextPageUrl() }}">›</a>
                </li>
                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                    <a class="page-link" href="{{ $items->withQueryString()->url($items->lastPage()) }}">Última »</a>
                </li>
            </ul>
        </nav>
    </div>
@endif
