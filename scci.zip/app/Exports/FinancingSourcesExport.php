<?php

namespace App\Exports;

use App\Models\FinancingSource;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class FinancingSourcesExport implements FromCollection, WithHeadings, WithMapping, WithStyles
{
    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function collection()
    {
        return $this->items;
    }

    public function headings(): array
    {
        return [
            'ID Fuente de Financiamiento',
            'Fuente de Financiamiento',
            'Fecha Creación',
            'Fecha Actualización'
        ];
    }

    public function map($item): array
    {
        return [
            $item->{'Id Fuentefinan'},
            $item->{'Fuente Financiamiento'},
            $item->created_at ? $item->created_at->format('d/m/Y H:i:s') : '',
            $item->updated_at ? $item->updated_at->format('d/m/Y H:i:s') : ''
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            // Estilo para la primera fila (encabezados)
            1 => [
                'font' => [
                    'bold' => true,
                    'color' => ['rgb' => 'FFFFFF']
                ],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['rgb' => '4F81BD']
                ]
            ],
            // Ajustar ancho de columnas
            'A' => ['width' => 25],
            'B' => ['width' => 40],
            'C' => ['width' => 25],
            'D' => ['width' => 25],
        ];
    }
}