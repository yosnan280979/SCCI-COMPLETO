@extends('layouts.app')

@section('title', 'CacheLock')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="card-title">CacheLock</h3>
                        <div>
                            <a href="{{ route('cachelock.create') }}" class="btn btn-primary">
                                <i class="fas fa-plus"></i> Nuevo CacheLock
                            </a>
                            <a href="{{ route('cachelock.export') }}" class="btn btn-success">
                                <i class="fas fa-file-export"></i> Exportar
                            </a>
                            <a href="{{ route('cachelock.pdf') }}" class="btn btn-danger" target="_blank">
                                <i class="fas fa-file-pdf"></i> PDF
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="cachelock-table" class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>Key</th>
                                    <th>Owner</th>
                                    <th>Expiration</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    $(document).ready(function() {
        $('#cachelock-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('cachelock.index') }}",
            columns: [
                { data: 'key', name: 'key' },
                { data: 'owner', name: 'owner' },
                { data: 'expiration', name: 'expiration' },
                { 
                    data: 'actions', 
                    name: 'actions', 
                    orderable: false, 
                    searchable: false,
                    className: 'text-center'
                }
            ],
            language: {
                url: "//cdn.datatables.net/plug-ins/1.10.25/i18n/Spanish.json"
            },
            order: [[0, 'desc']],
            pageLength: 25,
            responsive: true
        });
    });
</script>
@endpush