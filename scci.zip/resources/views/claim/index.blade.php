@extends('layouts.app')

@section('title', 'Claim')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="card-title">Claim</h3>
                        <div>
                            <a href="{{ route('claim.create') }}" class="btn btn-primary">
                                <i class="fas fa-plus"></i> Nuevo Claim
                            </a>
                            <a href="{{ route('claim.export') }}" class="btn btn-success">
                                <i class="fas fa-file-export"></i> Exportar
                            </a>
                            <a href="{{ route('claim.pdf') }}" class="btn btn-danger" target="_blank">
                                <i class="fas fa-file-pdf"></i> PDF
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="claim-table" class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Embarque ID</th>
                                    <th>Descripción</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    $(document).ready(function() {
        $('#claim-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('claim.index') }}",
            columns: [
                { data: 'id', name: 'id' },
                { data: 'embarque_id', name: 'embarque_id' },
                { data: 'descripcion', name: 'descripcion' },
                { 
                    data: 'actions', 
                    name: 'actions', 
                    orderable: false, 
                    searchable: false,
                    className: 'text-center'
                }
            ],
            language: {
                url: "//cdn.datatables.net/plug-ins/1.10.25/i18n/Spanish.json"
            },
            order: [[0, 'desc']],
            pageLength: 25,
            responsive: true
        });
    });
</script>
@endpush