@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3>Cache</h3>
                    <a href="{{ route('caches.create') }}" class="btn btn-primary float-right">Nuevo Cache</a>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Key</th>
                                <th>Value</th>
                                <th>Expiration</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($caches as $cache)
                            <tr>
                                <td>{{ $cache->key }}</td>
                                <td>{{ Str::limit($cache->value, 50) }}</td>
                                <td>{{ $cache->expiration }}</td>
                                <td>
                                    <a href="{{ route('caches.show', $cache->key) }}" class="btn btn-info btn-sm">Ver</a>
                                    <a href="{{ route('caches.edit', $cache->key) }}" class="btn btn-warning btn-sm">Editar</a>
                                    <form action="{{ route('caches.destroy', $cache->key) }}" method="POST" style="display:inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection