@extends('layouts.app')

@section('title', 'Crear Contrato')

@section('content')
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3>Crear Nuevo Contrato</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('contratos.store') }}" method="POST">
                @csrf
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="No Ctto" class="form-label">No. Contrato *</label>
                        <input type="text" class="form-control" id="No Ctto" name="No Ctto" required>
                    </div>
                    <div class="col-md-6">
                        <label for="Id Proveedor" class="form-label">Proveedor *</label>
                        <select class="form-select" id="Id Proveedor" name="Id Proveedor" required>
                            <option value="">Seleccionar Proveedor</option>
                            @foreach($providers as $provider)
                                <option value="{{ $provider->{'Id Proveedor'} }}">{{ $provider->Proveedor }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Valor Ctto Mon Prov" class="form-label">Valor (Mon. Prov.)</label>
                        <input type="number" step="0.01" class="form-control" id="Valor Ctto Mon Prov" name="Valor Ctto Mon Prov">
                    </div>
                    <div class="col-md-6">
                        <label for="Id Moneda" class="form-label">Moneda</label>
                        <select class="form-select" id="Id Moneda" name="Id Moneda">
                            <option value="">Seleccionar Moneda</option>
                            @foreach($currencies as $currency)
                                <option value="{{ $currency->{'Id Moneda'} }}">{{ $currency->Moneda }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Valor Ctto CUC" class="form-label">Valor (CUC)</label>
                        <input type="number" step="0.01" class="form-control" id="Valor Ctto CUC" name="Valor Ctto CUC">
                    </div>
                    <div class="col-md-6">
                        <label for="Forma de Pago" class="form-label">Forma de Pago</label>
                        <input type="text" class="form-control" id="Forma de Pago" name="Forma de Pago">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="Concluido" name="Concluido" value="1">
                            <label class="form-check-label" for="Concluido">Concluido</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="Cancelado" name="Cancelado" value="1">
                            <label class="form-check-label" for="Cancelado">Cancelado</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="Observaciones Esp" class="form-label">Observaciones</label>
                        <textarea class="form-control" id="Observaciones Esp" name="Observaciones Esp" rows="3"></textarea>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="{{ route('contratos.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar Contrato</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection