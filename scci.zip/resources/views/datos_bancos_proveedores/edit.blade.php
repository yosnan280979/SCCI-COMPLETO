@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">Editar Registro Bancario</h3>
                    <a href="{{ route('datos-bancos-proveedores.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Volver
                    </a>
                </div>
                <div class="card-body">
                    <form action="{{ route('datos-bancos-proveedores.update', $datosBanco->Id) }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="form-group">
                            <label for="Id_proveedor">Proveedor</label>
                            <select name="Id proveedor" id="Id_proveedor" class="form-control" required>
                                @foreach($proveedores as $prov)
                                    <option value="{{ $prov->{'Id Proveedor'} }}"
                                        {{ $datosBanco->{'Id proveedor'} == $prov->{'Id Proveedor'} ? 'selected' : '' }}>
                                        {{ $prov->{'Proveedor'} }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="Id_Banco">Banco</label>
                            <select name="Id Banco" id="Id_Banco" class="form-control" required>
                                @foreach($bancos as $banco)
                                    <option value="{{ $banco->{'Id Banco'} }}"
                                        {{ $datosBanco->{'Id Banco'} == $banco->{'Id Banco'} ? 'selected' : '' }}>
                                        {{ $banco->{'Banco'} }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="Id_Moneda">Moneda</label>
                            <select name="Id Moneda" id="Id_Moneda" class="form-control" required>
                                @foreach($monedas as $moneda)
                                    <option value="{{ $moneda->{'Id Moneda'} }}"
                                        {{ $datosBanco->{'Id Moneda'} == $moneda->{'Id Moneda'} ? 'selected' : '' }}>
                                        {{ $moneda->{'Moneda'} }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="Numero_Cuenta">Número de Cuenta</label>
                            <input type="text" name="Numero Cuenta" id="Numero_Cuenta" class="form-control"
                                   value="{{ old('Numero Cuenta', $datosBanco->{'Numero Cuenta'}) }}" required maxlength="50">
                        </div>

                        <div class="form-group">
                            <label for="Titular">Titular</label>
                            <input type="text" name="Titular" id="Titular" class="form-control"
                                   value="{{ old('Titular', $datosBanco->Titular) }}" maxlength="255">
                        </div>

                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-success mr-2">
                                <i class="fas fa-save"></i> Guardar Cambios
                            </button>
                            <a href="{{ route('datos-bancos-proveedores.show', $datosBanco->Id) }}" class="btn btn-info">
                                <i class="fas fa-eye"></i> Ver detalle
                            </a>
                        </div>
                    </form>
                </div>
                <div class="card-footer d-flex justify-content-between">
                    <form action="{{ route('datos-bancos-proveedores.destroy', $datosBanco->Id) }}" method="POST" onsubmit="return confirm('¿Seguro que deseas eliminar este registro?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Eliminar
                        </button>
                    </form>
                    <a href="{{ route('datos-bancos-proveedores.index') }}" class="btn btn-secondary">
                        <i class="fas fa-list"></i> Volver al listado
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
