<style>
    .min-vh-100 {
        min-height: 100vh;
    }
    
    .card {
        border: none;
        border-radius: 10px;
    }
    
    .card-body {
        padding: 2rem;
    }
    
    .btn-primary {
        background-color: #ef1c25;
        border-color: #ef1c25;
    }
    
    .btn-primary:hover {
        background-color: #d11921;
        border-color: #d11921;
    }
    
    .input-group-text {
        background-color: #33358a;
        color: white;
        border: 1px solid #33358a;
    }
    
    .form-control:focus {
        border-color: #07acfb;
        box-shadow: 0 0 0 0.25rem rgba(7, 172, 251, 0.25);
    }
    
    .invalid-feedback {
        color: #ef1c25;
    }
    
    .text-muted {
        color: #6c757d !important;
    }
</style>