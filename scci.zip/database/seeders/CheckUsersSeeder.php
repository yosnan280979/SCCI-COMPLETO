<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class CheckUsersSeeder extends Seeder
{
    public function run()
    {
        // Verificar usuarios existentes
        $users = User::all();
        
        foreach ($users as $user) {
            echo "Usuario: " . $user->Usuario . "\n";
            echo "ID Tipo Usuario: " . $user->{'Id Tipo Usuario'} . "\n";
            echo "Nombre completo: " . $user->{'Nombre completo'} . "\n";
            echo "Hash de contraseña: " . substr($user->PWD, 0, 20) . "...\n";
            echo "------------------------\n";
        }
    }
}