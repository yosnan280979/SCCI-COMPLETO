<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

class GenerateModule extends Command
{
    protected $signature = 'make:module {model} {--table=} {--fields=}';
    protected $description = 'Generate complete CRUD module with views, controller, and routes';

    public function handle()
    {
        $modelName = $this->argument('model');
        $tableName = $this->option('table') ?: $this->getTableName($modelName);
        $fields = $this->parseFields($this->option('fields'));

        $this->info("Generating module for: {$modelName}");
        $this->info("Table: {$tableName}");
        
        // 1. Generate Model (if doesn't exist)
        $this->generateModel($modelName, $tableName, $fields);
        
        // 2. Generate Controller
        $this->generateController($modelName, $tableName, $fields);
        
        // 3. Generate Views
        $this->generateViews($modelName, $fields);
        
        // 4. Generate Export Class
        $this->generateExportClass($modelName);
        
        // 5. Add Routes
        $this->addRoutes($modelName);
        
        $this->info("Module {$modelName} generated successfully!");
    }

    protected function getTableName($modelName)
    {
        // Convert ModelName to snake_case plural
        return Str::plural(Str::snake($modelName));
    }

    protected function parseFields($fieldsString)
    {
        if (empty($fieldsString)) {
            return [];
        }

        $fields = [];
        $parts = explode(',', $fieldsString);
        
        foreach ($parts as $part) {
            $fieldParts = explode(':', $part);
            $name = trim($fieldParts[0]);
            $type = isset($fieldParts[1]) ? trim($fieldParts[1]) : 'string';
            $rules = isset($fieldParts[2]) ? trim($fieldParts[2]) : 'nullable';
            
            $fields[] = [
                'name' => $name,
                'type' => $type,
                'rules' => $rules
            ];
        }
        
        return $fields;
    }

    protected function generateModel($modelName, $tableName, $fields)
    {
        $modelPath = app_path("Models/{$modelName}.php");
        
        if (File::exists($modelPath)) {
            $this->warn("Model {$modelName} already exists. Skipping...");
            return;
        }

        $fillable = array_map(fn($field) => "'{$field['name']}'", $fields);
        $fillableStr = implode(",\n        ", $fillable);
        
        $content = <<<PHP
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class {$modelName} extends Model
{
    protected \$table = '{$tableName}';
    protected \$primaryKey = 'Id';
    
    protected \$fillable = [
        {$fillableStr}
    ];
    
    public \$timestamps = false;
    
    // Add relationships here if needed
}

PHP;

        File::put($modelPath, $content);
        $this->info("Model created: {$modelName}.php");
    }

    protected function generateController($modelName, $tableName, $fields)
    {
        $controllerName = "{$modelName}Controller";
        $controllerPath = app_path("Http/Controllers/{$controllerName}.php");
        
        if (File::exists($controllerPath)) {
            $this->warn("Controller {$controllerName} already exists. Skipping...");
            return;
        }

        $viewName = Str::plural(Str::snake($modelName));
        $routeName = Str::plural(Str::kebab($modelName));
        $variableName = Str::camel($modelName);
        $variableNamePlural = Str::plural($variableName);
        
        // Generate validation rules
        $validationRules = [];
        foreach ($fields as $field) {
            $rule = $field['rules'];
            if ($field['type'] === 'string') {
                $rule .= '|string|max:255';
            } elseif ($field['type'] === 'integer') {
                $rule .= '|integer';
            } elseif ($field['type'] === 'float') {
                $rule .= '|numeric';
            } elseif ($field['type'] === 'date') {
                $rule .= '|date';
            } elseif ($field['type'] === 'boolean') {
                $rule .= '|boolean';
            }
            $validationRules[] = "'{$field['name']}' => '{$rule}'";
        }
        $validationStr = implode(",\n            ", $validationRules);
        
        $content = <<<PHP
<?php

namespace App\Http\Controllers;

use App\Models\\{$modelName};
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\\{$modelName}Export;
use PDF;

class {$controllerName} extends Controller
{
    public function index(Request \$request)
    {
        \$query = {$modelName}::query();
        
        // Búsqueda
        if (\$request->has('search') && !empty(\$request->search)) {
            \$search = \$request->search;
            \$query->where(function(\$q) use (\$search) {
                \$q->where('Id', 'like', "%{\$search}%");
PHP;

        // Add search for each string field
        foreach ($fields as $field) {
            if ($field['type'] === 'string') {
                $content .= "\n                  ->orWhere('{$field['name']}', 'like', \"%{\$search}%\")";
            }
        }
        
        $content .= <<<PHP
;
            });
        }
        
        // Ordenación
        \$orderBy = \$request->get('order_by', 'Id');
        \$orderDirection = \$request->get('order_direction', 'asc');
        \$query->orderBy(\$orderBy, \$orderDirection);
        
        \${$variableNamePlural} = \$query->paginate(25)->withQueryString();
        
        return view('{$viewName}.index', compact('{$variableNamePlural}'));
    }

    public function create()
    {
        return view('{$viewName}.create');
    }

    public function store(Request \$request)
    {
        \$request->validate([
            {$validationStr}
        ]);

        {$modelName}::create(\$request->all());
        return redirect()->route('{$routeName}.index')
            ->with('success', 'Registro creado correctamente');
    }

    public function show(\$id)
    {
        \${$variableName} = {$modelName}::findOrFail(\$id);
        return view('{$viewName}.show', compact('{$variableName}'));
    }

    public function edit(\$id)
    {
        \${$variableName} = {$modelName}::findOrFail(\$id);
        return view('{$viewName}.edit', compact('{$variableName}'));
    }

    public function update(Request \$request, \$id)
    {
        \$request->validate([
            {$validationStr}
        ]);

        \${$variableName} = {$modelName}::findOrFail(\$id);
        \${$variableName}->update(\$request->all());

        return redirect()->route('{$routeName}.index')
            ->with('success', 'Registro actualizado correctamente');
    }

    public function destroy(\$id)
    {
        \${$variableName} = {$modelName}::findOrFail(\$id);
        \${$variableName}->delete();

        return redirect()->route('{$routeName}.index')
            ->with('success', 'Registro eliminado correctamente');
    }
    
    public function destroyMultiple(Request \$request)
    {
        \$request->validate([
            'selected_ids' => 'required|array',
            'selected_ids.*' => 'exists:{$tableName},Id'
        ]);
        
        \$count = {$modelName}::whereIn('Id', \$request->selected_ids)->delete();
        
        return redirect()->route('{$routeName}.index')
            ->with('success', "{\$count} registros eliminados correctamente");
    }
    
    public function exportExcel(Request \$request)
    {
        \$query = {$modelName}::query();
        
        if (\$request->has('search') && !empty(\$request->search)) {
            \$search = \$request->search;
            \$query->where('Id', 'like', "%{\$search}%");
        }
        
        if (\$request->has('ids') && !empty(\$request->ids)) {
            \$ids = explode(',', \$request->ids);
            \$query->whereIn('Id', \$ids);
        }
        
        \${$variableNamePlural} = \$query->orderBy('Id')->get();
        
        return Excel::download(new {$modelName}Export(\${$variableNamePlural}), '{$routeName}_' . date('Y-m-d') . '.xlsx');
    }
    
    public function exportPdf(Request \$request)
    {
        \$query = {$modelName}::query();
        
        if (\$request->has('search') && !empty(\$request->search)) {
            \$search = \$request->search;
            \$query->where('Id', 'like', "%{\$search}%");
        }
        
        if (\$request->has('ids') && !empty(\$request->ids)) {
            \$ids = explode(',', \$request->ids);
            \$query->whereIn('Id', \$ids);
        }
        
        \${$variableNamePlural} = \$query->orderBy('Id')->get();
        
        \$pdf = PDF::loadView('{$viewName}.pdf', ['{$variableNamePlural}' => \${$variableNamePlural}]);
        return \$pdf->download('{$routeName}_' . date('Y-m-d') . '.pdf');
    }
    
    public function print(Request \$request)
    {
        \$query = {$modelName}::query();
        
        if (\$request->has('search') && !empty(\$request->search)) {
            \$search = \$request->search;
            \$query->where('Id', 'like', "%{\$search}%");
        }
        
        if (\$request->has('ids') && !empty(\$request->ids)) {
            \$ids = explode(',', \$request->ids);
            \$query->whereIn('Id', \$ids);
        }
        
        \${$variableNamePlural} = \$query->orderBy('Id')->get();
        
        return view('{$viewName}.print', compact('{$variableNamePlural}'));
    }
}

PHP;

        File::put($controllerPath, $content);
        $this->info("Controller created: {$controllerName}.php");
    }

    protected function generateViews($modelName, $fields)
    {
        $viewName = Str::plural(Str::snake($modelName));
        $viewPath = resource_path("views/{$viewName}");
        $variableName = Str::camel($modelName);
        $variableNamePlural = Str::plural($variableName);
        $routeName = Str::plural(Str::kebab($modelName));
        
        // Create view directory
        if (!File::exists($viewPath)) {
            File::makeDirectory($viewPath, 0755, true);
        }
        
        // Generate index.blade.php
        $this->generateIndexView($viewPath, $modelName, $viewName, $variableName, $variableNamePlural, $routeName, $fields);
        
        // Generate create.blade.php
        $this->generateCreateView($viewPath, $modelName, $viewName, $routeName, $fields);
        
        // Generate edit.blade.php
        $this->generateEditView($viewPath, $modelName, $viewName, $variableName, $routeName, $fields);
        
        // Generate show.blade.php
        $this->generateShowView($viewPath, $modelName, $viewName, $variableName, $routeName, $fields);
        
        // Generate print.blade.php
        $this->generatePrintView($viewPath, $modelName, $viewName, $variableName, $variableNamePlural, $fields);
        
        // Generate pdf.blade.php
        $this->generatePdfView($viewPath, $modelName, $viewName, $variableName, $variableNamePlural, $fields);
        
        $this->info("Views created in: resources/views/{$viewName}/");
    }

    protected function generateIndexView($path, $modelName, $viewName, $variableName, $variableNamePlural, $routeName, $fields)
    {
        $tableHeaders = '';
        $tableCells = '';
        
        $tableHeaders .= "<th>ID</th>\n";
        $tableCells .= "<td>{{ \${$variableName}->Id }}</td>\n";
        
        foreach ($fields as $field) {
            $label = $this->getFieldLabel($field['name']);
            $tableHeaders .= "                                    <th>{$label}</th>\n";
            $tableCells .= "                                        <td>{{ \${$variableName}->{$field['name']} }}</td>\n";
        }
        
        $content = <<<BLADE
@extends('layouts.app')

@section('title', '{$modelName}')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="mb-0">{$modelName}</h3>
                    @if(auth()->user()->userType->{'Id Tipo Usuario'} != 3)
                    <a href="{{ route('{$routeName}.create') }}" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Nuevo
                    </a>
                    @endif
                </div>
                <div class="card-body">
                    @include('partials.messages')
                    
                    <!-- Filtros y Búsqueda -->
                    <form method="GET" action="{{ route('{$routeName}.index') }}" class="mb-4">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="search" 
                                           value="{{ request('search') }}" 
                                           placeholder="Buscar...">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-primary" type="submit">
                                            <i class="fas fa-search"></i> Buscar
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <select class="form-control" name="order_by">
                                    <option value="Id" {{ request('order_by') == 'Id' ? 'selected' : '' }}>Ordenar por ID</option>
                                    @foreach(['nombre', 'descripcion'] as \$field)
                                        @if(in_array(\$field, [{$this->getFieldNames($fields)}]))
                                        <option value="{\$field}" {{ request('order_by') == \$field ? 'selected' : '' }}>Ordenar por {\$field}</option>
                                        @endif
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-control" name="order_direction">
                                    <option value="asc" {{ request('order_direction') == 'asc' ? 'selected' : '' }}>Ascendente</option>
                                    <option value="desc" {{ request('order_direction') == 'desc' ? 'selected' : '' }}>Descendente</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <div class="btn-group">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-filter"></i> Aplicar Filtros
                                    </button>
                                    <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">
                                        <i class="fas fa-times"></i> Limpiar Filtros
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
                    
                    <!-- Botones de Acciones Masivas -->
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-outline-primary" onclick="selectAll()">
                                    <i class="fas fa-check-square"></i> Seleccionar Todos
                                </button>
                                <button type="button" class="btn btn-outline-secondary" onclick="deselectAll()">
                                    <i class="fas fa-square"></i> Deseleccionar Todos
                                </button>
                                <button type="button" class="btn btn-danger" onclick="deleteSelected()">
                                    <i class="fas fa-trash"></i> Eliminar Seleccionados
                                </button>
                                <a href="{{ route('{$routeName}.export.excel', request()->query()) }}" 
                                   class="btn btn-success" id="export-excel-btn">
                                    <i class="fas fa-file-excel"></i> Exportar a Excel
                                </a>
                                <a href="{{ route('{$routeName}.export.pdf', request()->query()) }}" 
                                   class="btn btn-danger" id="export-pdf-btn">
                                    <i class="fas fa-file-pdf"></i> Exportar a PDF
                                </a>
                                <a href="{{ route('{$routeName}.print', request()->query()) }}" 
                                   class="btn btn-info" id="print-btn" target="_blank">
                                    <i class="fas fa-print"></i> Imprimir
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Tabla -->
                    <div class="table-responsive">
                        <form id="mass-action-form" action="{{ route('{$routeName}.destroy.multiple') }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <table class="table table-striped data-table">
                                <thead>
                                    <tr>
                                        <th width="50">
                                            <input type="checkbox" id="select-all-checkbox" onchange="toggleAllCheckboxes(this)">
                                        </th>
{$tableHeaders}
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse (\${$variableNamePlural} as \${$variableName})
                                    <tr>
                                        <td>
                                            <input type="checkbox" class="item-checkbox" name="selected_ids[]" value="{{ \${$variableName}->Id }}">
                                        </td>
{$tableCells}
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('{$routeName}.show', \${$variableName}->Id) }}" 
                                                   class="btn btn-sm btn-info" title="Ver">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                @if(auth()->user()->userType->{'Id Tipo Usuario'} != 3)
                                                <a href="{{ route('{$routeName}.edit', \${$variableName}->Id) }}" 
                                                   class="btn btn-sm btn-warning" title="Editar">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form action="{{ route('{$routeName}.destroy', \${$variableName}->Id) }}" 
                                                      method="POST" 
                                                      style="display: inline-block;" 
                                                      id="form-{{ \${$variableName}->Id }}">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="button" class="btn btn-sm btn-danger delete-btn" 
                                                            data-bs-toggle="tooltip" 
                                                            title="Eliminar" 
                                                            onclick="confirmDelete('form-{{ \${$variableName}->Id }}')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                    @empty
                                    <tr>
                                        <td colspan="{{ count($fields) + 3 }}" class="text-center">No hay registros</td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </form>
                    </div>
                    
                    <!-- Paginación -->
                    @if(\${$variableNamePlural}->hasPages())
                        <div class="d-flex justify-content-center mt-3">
                            <nav aria-label="Page navigation">
                                <ul class="pagination">
                                    {{-- Previous Page Link --}}
                                    @if(\${$variableNamePlural}->onFirstPage())
                                        <li class="page-item disabled">
                                            <span class="page-link">&laquo;</span>
                                        </li>
                                    @else
                                        <li class="page-item">
                                            <a class="page-link" href="{{ \${$variableNamePlural}->previousPageUrl() }}" rel="prev">&laquo;</a>
                                        </li>
                                    @endif

                                    {{-- Pagination Elements --}}
                                    @for(\$page = 1; \$page <= \${$variableNamePlural}->lastPage(); \$page++)
                                        @if(\$page == \${$variableNamePlural}->currentPage())
                                            <li class="page-item active">
                                                <span class="page-link">{{ \$page }}</span>
                                            </li>
                                        @else
                                            <li class="page-item">
                                                <a class="page-link" href="{{ \${$variableNamePlural}->url(\$page) }}">{{ \$page }}</a>
                                            </li>
                                        @endif
                                    @endfor

                                    {{-- Next Page Link --}}
                                    @if(\${$variableNamePlural}->hasMorePages())
                                        <li class="page-item">
                                            <a class="page-link" href="{{ \${$variableNamePlural}->nextPageUrl() }}" rel="next">&raquo;</a>
                                        </li>
                                    @else
                                        <li class="page-item disabled">
                                            <span class="page-link">&raquo;</span>
                                        </li>
                                    @endif
                                </ul>
                            </nav>
                        </div>
                        <div class="text-center text-muted">
                            Mostrando {{ \${$variableNamePlural}->firstItem() }} a {{ \${$variableNamePlural}->lastItem() }} de {{ \${$variableNamePlural}->total() }} registros
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
function confirmDelete(formId) {
    if (confirm('¿Está seguro de que desea eliminar este registro?')) {
        document.getElementById(formId).submit();
    }
}

// Funciones para selección múltiple
function selectAll() {
    document.querySelectorAll('.item-checkbox').forEach(checkbox => {
        checkbox.checked = true;
    });
    document.getElementById('select-all-checkbox').checked = true;
}

function deselectAll() {
    document.querySelectorAll('.item-checkbox').forEach(checkbox => {
        checkbox.checked = false;
    });
    document.getElementById('select-all-checkbox').checked = false;
}

function toggleAllCheckboxes(source) {
    document.querySelectorAll('.item-checkbox').forEach(checkbox => {
        checkbox.checked = source.checked;
    });
}

// Verificar cuando se cambian checkboxes individuales
document.addEventListener('DOMContentLoaded', function() {
    const checkboxes = document.querySelectorAll('.item-checkbox');
    const selectAllCheckbox = document.getElementById('select-all-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            if (!this.checked) {
                selectAllCheckbox.checked = false;
            } else {
                // Verificar si todos están seleccionados
                const allChecked = Array.from(checkboxes).every(cb => cb.checked);
                selectAllCheckbox.checked = allChecked;
            }
        });
    });
});

// Eliminar elementos seleccionados
function deleteSelected() {
    const selectedCheckboxes = document.querySelectorAll('.item-checkbox:checked');
    
    if (selectedCheckboxes.length === 0) {
        alert('Por favor, seleccione al menos un registro para eliminar.');
        return;
    }
    
    if (confirm(`¿Está seguro de que desea eliminar los \${selectedCheckboxes.length} registros seleccionados?`)) {
        document.getElementById('mass-action-form').submit();
    }
}

// Actualizar enlaces de exportación cuando se seleccionan elementos
document.addEventListener('DOMContentLoaded', function() {
    const checkboxes = document.querySelectorAll('.item-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateExportLinks);
    });
    
    function updateExportLinks() {
        const selectedCheckboxes = document.querySelectorAll('.item-checkbox:checked');
        const selectedIds = Array.from(selectedCheckboxes).map(cb => cb.value).join(',');
        
        // Obtener parámetros actuales de búsqueda
        const urlParams = new URLSearchParams(window.location.search);
        
        // Actualizar botones de exportación
        const excelBtn = document.getElementById('export-excel-btn');
        const pdfBtn = document.getElementById('export-pdf-btn');
        const printBtn = document.getElementById('print-btn');
        
        // Construir nueva URL
        const baseExcelUrl = excelBtn.href.split('?')[0];
        const basePdfUrl = pdfBtn.href.split('?')[0];
        const basePrintUrl = printBtn.href.split('?')[0];
        
        // Si hay seleccionados, agregar parámetro ids
        if (selectedIds) {
            excelBtn.href = baseExcelUrl + '?ids=' + selectedIds;
            pdfBtn.href = basePdfUrl + '?ids=' + selectedIds;
            printBtn.href = basePrintUrl + '?ids=' + selectedIds;
            
            // Agregar otros parámetros de búsqueda (excepto page)
            urlParams.forEach((value, key) => {
                if (key !== 'page' && key !== 'ids') {
                    excelBtn.href += '&' + key + '=' + value;
                    pdfBtn.href += '&' + key + '=' + value;
                    printBtn.href += '&' + key + '=' + value;
                }
            });
        } else {
            // Sin seleccionados, usar solo filtros
            let params = '';
            urlParams.forEach((value, key) => {
                if (key !== 'ids') {
                    if (params) params += '&';
                    params += key + '=' + value;
                }
            });
            
            if (params) {
                excelBtn.href = baseExcelUrl + '?' + params;
                pdfBtn.href = basePdfUrl + '?' + params;
                printBtn.href = basePrintUrl + '?' + params;
            } else {
                excelBtn.href = baseExcelUrl;
                pdfBtn.href = basePdfUrl;
                printBtn.href = basePrintUrl;
            }
        }
    }
    
    // Inicializar enlaces
    updateExportLinks();
});
</script>
@endpush
BLADE;

        File::put("{$path}/index.blade.php", $content);
    }

    protected function generateCreateView($path, $modelName, $viewName, $routeName, $fields)
    {
        $formFields = '';
        foreach ($fields as $field) {
            $label = $this->getFieldLabel($field['name']);
            $inputType = $this->getInputType($field['type']);
            
            $formFields .= <<<HTML
                        <div class="form-group row">
                            <label for="{$field['name']}" class="col-md-4 col-form-label text-md-right">{$label}</label>

                            <div class="col-md-6">
                                <input id="{$field['name']}" type="{$inputType}" class="form-control @error('{$field['name']}') is-invalid @enderror" 
                                       name="{$field['name']}" value="{{ old('{$field['name']}') }}" 
                                       required autocomplete="{$field['name']}" autofocus>

                                @error('{$field['name']}')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ \$message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
HTML;
        }

        $content = <<<BLADE
@extends('layouts.app')

@section('title', 'Crear {$modelName}')
@section('header', 'Crear {$modelName}')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Crear {$modelName}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('{$routeName}.store') }}">
                        @csrf

{$formFields}

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Crear
                                </button>
                                <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">Cancelar</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
BLADE;

        File::put("{$path}/create.blade.php", $content);
    }

    protected function generateEditView($path, $modelName, $viewName, $variableName, $routeName, $fields)
    {
        $formFields = '';
        foreach ($fields as $field) {
            $label = $this->getFieldLabel($field['name']);
            $inputType = $this->getInputType($field['type']);
            
            $formFields .= <<<HTML
                        <div class="form-group row">
                            <label for="{$field['name']}" class="col-md-4 col-form-label text-md-right">{$label}</label>

                            <div class="col-md-6">
                                <input id="{$field['name']}" type="{$inputType}" class="form-control @error('{$field['name']}') is-invalid @enderror" 
                                       name="{$field['name']}" value="{{ old('{$field['name']}', \${$variableName}->{$field['name']}) }}" 
                                       required autocomplete="{$field['name']}" autofocus>

                                @error('{$field['name']}')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ \$message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
HTML;
        }

        $content = <<<BLADE
@extends('layouts.app')

@section('title', 'Editar {$modelName}')
@section('header', 'Editar {$modelName}')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Editar {$modelName}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('{$routeName}.update', \${$variableName}->Id) }}">
                        @csrf
                        @method('PUT')

{$formFields}

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Actualizar
                                </button>
                                <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">Cancelar</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
BLADE;

        File::put("{$path}/edit.blade.php", $content);
    }

    protected function generateShowView($path, $modelName, $viewName, $variableName, $routeName, $fields)
    {
        $tableRows = '';
        foreach ($fields as $field) {
            $label = $this->getFieldLabel($field['name']);
            $tableRows .= <<<HTML
            <tr>
                <th>{$label}</th>
                <td>{{ \${$variableName}->{$field['name']} }}</td>
            </tr>
HTML;
        }

        $content = <<<BLADE
@extends('layouts.app')

@section('title', 'Ver {$modelName}')
@section('header', 'Ver {$modelName}')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Detalles de {$modelName}</div>

                <div class="card-body">
                    <table class="table table-bordered">
                        <tr>
                            <th>ID</th>
                            <td>{{ \${$variableName}->Id }}</td>
                        </tr>
{$tableRows}
                    </table>
                    
                    <div class="mt-4">
                        <a href="{{ route('{$routeName}.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                        @if(auth()->user()->userType->{'Id Tipo Usuario'} != 3)
                        <a href="{{ route('{$routeName}.edit', \${$variableName}->Id) }}" class="btn btn-primary">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
BLADE;

        File::put("{$path}/show.blade.php", $content);
    }

    protected function generatePrintView($path, $modelName, $viewName, $variableName, $variableNamePlural, $fields)
    {
        $tableHeaders = '';
        $tableCells = '';
        
        $tableHeaders .= "<th>ID</th>\n";
        $tableCells .= "<td>{{ \${$variableName}->Id }}</td>\n";
        
        foreach ($fields as $field) {
            $label = $this->getFieldLabel($field['name']);
            $tableHeaders .= "                <th>{$label}</th>\n";
            $tableCells .= "                    <td>{{ \${$variableName}->{$field['name']} }}</td>\n";
        }

        $content = <<<BLADE
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$modelName} - Impresión</title>
    <style>
        @media print {
            body { font-family: Arial, sans-serif; font-size: 12px; }
            .no-print { display: none !important; }
            .page-break { page-break-after: always; }
        }
        
        body { font-family: Arial, sans-serif; font-size: 14px; padding: 20px; }
        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 10px; }
        .header h1 { margin: 0; font-size: 24px; color: #333; }
        .header p { margin: 5px 0; color: #666; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .footer { margin-top: 30px; text-align: center; font-size: 12px; color: #666; }
        .print-info { margin-bottom: 20px; padding: 10px; background-color: #f8f9fa; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Listado de {$modelName}</h1>
        <p>Sistema de Control de Contratos e Importaciones</p>
        <p>Fecha de impresión: {{ date('d/m/Y H:i:s') }}</p>
    </div>
    
    <div class="print-info">
        <p><strong>Total de registros:</strong> {{ \${$variableNamePlural}->count() }}</p>
        @if(request()->has('search') && request('search'))
            <p><strong>Búsqueda:</strong> "{{ request('search') }}"</p>
        @endif
    </div>
    
    <table>
        <thead>
            <tr>
{$tableHeaders}
            </tr>
        </thead>
        <tbody>
            @foreach(\${$variableNamePlural} as \${$variableName})
            <tr>
{$tableCells}
            </tr>
            @endforeach
        </tbody>
    </table>
    
    <div class="footer">
        <p>Documento generado automáticamente por el Sistema SCCI</p>
    </div>
    
    <div class="no-print" style="text-align: center; margin-top: 20px;">
        <button onclick="window.print()" class="btn btn-primary">
            <i class="fas fa-print"></i> Imprimir
        </button>
        <button onclick="window.close()" class="btn btn-secondary">
            <i class="fas fa-times"></i> Cerrar
        </button>
    </div>
    
    <script>
        // Auto-print al cargar la página
        window.onload = function() {
            setTimeout(function() {
                window.print();
            }, 1000);
        };
    </script>
</body>
</html>
BLADE;

        File::put("{$path}/print.blade.php", $content);
    }

    protected function generatePdfView($path, $modelName, $viewName, $variableName, $variableNamePlural, $fields)
    {
        $tableHeaders = '';
        $tableCells = '';
        
        $tableHeaders .= "<th>ID</th>\n";
        $tableCells .= "<td>{{ \${$variableName}->Id }}</td>\n";
        
        foreach ($fields as $field) {
            $label = $this->getFieldLabel($field['name']);
            $tableHeaders .= "                <th>{$label}</th>\n";
            $tableCells .= "                    <td>{{ \${$variableName}->{$field['name']} }}</td>\n";
        }

        $content = <<<BLADE
<!DOCTYPE html>
<html>
<head>
    <title>{$modelName} - {{ date('Y-m-d') }}</title>
    <style>
        body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 30px; }
        .header h1 { margin: 0; font-size: 20px; color: #333; }
        .header p { margin: 5px 0; color: #666; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 6px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .footer { margin-top: 30px; text-align: center; font-size: 10px; color: #666; }
        .info-box { margin-bottom: 20px; padding: 10px; background-color: #f8f9fa; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Reporte de {$modelName}</h1>
        <p>Sistema de Control de Contratos e Importaciones</p>
        <p>Fecha de generación: {{ date('d/m/Y H:i:s') }}</p>
    </div>
    
    <div class="info-box">
        <p><strong>Total de registros:</strong> {{ \${$variableNamePlural}->count() }}</p>
        @if(request()->has('search') && request('search'))
            <p><strong>Búsqueda aplicada:</strong> "{{ request('search') }}"</p>
        @endif
    </div>
    
    <table>
        <thead>
            <tr>
{$tableHeaders}
            </tr>
        </thead>
        <tbody>
            @foreach(\${$variableNamePlural} as \${$variableName})
            <tr>
{$tableCells}
            </tr>
            @endforeach
        </tbody>
    </table>
    
    <div class="footer">
        <p>Documento generado automáticamente por el Sistema SCCI</p>
    </div>
</body>
</html>
BLADE;

        File::put("{$path}/pdf.blade.php", $content);
    }

    protected function generateExportClass($modelName)
    {
        $exportPath = app_path("Exports/{$modelName}Export.php");
        
        if (File::exists($exportPath)) {
            $this->warn("Export class {$modelName}Export already exists. Skipping...");
            return;
        }

        $content = <<<PHP
<?php

namespace App\Exports;

use App\Models\\{$modelName};
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class {$modelName}Export implements FromCollection, WithHeadings, WithMapping
{
    protected \${$modelName};

    public function __construct(\${$modelName})
    {
        \$this->{$modelName} = \${$modelName};
    }

    public function collection()
    {
        return \$this->{$modelName};
    }

    public function map(\${$modelName}): array
    {
        return [
            \${$modelName}->Id,
            // Add other fields here
        ];
    }

    public function headings(): array
    {
        return [
            'ID',
            // Add other headings here
        ];
    }
}

PHP;

        File::put($exportPath, $content);
        $this->info("Export class created: {$modelName}Export.php");
    }

    protected function addRoutes($modelName)
    {
        $routeFile = base_path('routes/web.php');
        $routeName = Str::plural(Str::kebab($modelName));
        $controllerName = "{$modelName}Controller";
        
        $routeTemplate = <<<PHP

// Routes for {$modelName}
Route::prefix('{$routeName}')->name('{$routeName}.')->group(function () {
    Route::get('/', [{$controllerName}::class, 'index'])->name('index');
    Route::get('/create', [{$controllerName}::class, 'create'])->name('create');
    Route::post('/', [{$controllerName}::class, 'store'])->name('store');
    Route::get('/{{$modelName}}', [{$controllerName}::class, 'show'])->name('show');
    Route::get('/{{$modelName}}/edit', [{$controllerName}::class, 'edit'])->name('edit');
    Route::put('/{{$modelName}}', [{$controllerName}::class, 'update'])->name('update');
    Route::delete('/{{$modelName}}', [{$controllerName}::class, 'destroy'])->name('destroy');
    Route::delete('/destroy-multiple', [{$controllerName}::class, 'destroyMultiple'])->name('destroy.multiple');
    Route::get('/export/excel', [{$controllerName}::class, 'exportExcel'])->name('export.excel');
    Route::get('/export/pdf', [{$controllerName}::class, 'exportPdf'])->name('export.pdf');
    Route::get('/print', [{$controllerName}::class, 'print'])->name('print');
});

PHP;

        // Append routes to web.php
        File::append($routeFile, $routeTemplate);
        $this->info("Routes added for: {$routeName}");
    }

    protected function getFieldLabel($fieldName)
    {
        // Convert field name to readable label
        return ucwords(str_replace(['_', '-'], ' ', $fieldName));
    }

    protected function getInputType($fieldType)
    {
        return match($fieldType) {
            'integer' => 'number',
            'float' => 'number',
            'date' => 'date',
            'boolean' => 'checkbox',
            default => 'text',
        };
    }

    protected function getFieldNames($fields)
    {
        $names = array_map(fn($field) => "'{$field['name']}'", $fields);
        return implode(', ', $names);
    }
}