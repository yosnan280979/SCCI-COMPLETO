<?php

namespace App\Exports;

use App\Models\ControlUsuario;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class ControlUsuarioExport implements FromCollection, WithHeadings, WithMapping
{
    protected $data;
    protected $columns;

    public function __construct($data, $columns = [])
    {
        $this->data = $data;
        $this->columns = $columns;
    }

    public function collection()
    {
        return $this->data;
    }

    public function headings(): array
    {
        $headings = [];

        foreach ($this->columns as $column) {
            switch ($column) {
                case 'id':
                    $headings[] = 'ID';
                    break;
                case 'usuario_id':
                    $headings[] = 'Usuario ID';
                    break;
                case 'entrada':
                    $headings[] = 'Entrada';
                    break;
                case 'salida':
                    $headings[] = 'Salida';
                    break;
            }
        }

        return $headings;
    }

    public function map($row): array
    {
        $mappedRow = [];

        foreach ($this->columns as $column) {
            switch ($column) {
                case 'id':
                    $mappedRow[] = $row->id;
                    break;
                case 'usuario_id':
                    $mappedRow[] = $row->usuario_id;
                    break;
                case 'entrada':
                    $mappedRow[] = $row->entrada ? $row->entrada->format('d/m/Y H:i') : '';
                    break;
                case 'salida':
                    $mappedRow[] = $row->salida ? $row->salida->format('d/m/Y H:i') : '';
                    break;
            }
        }

        return $mappedRow;
    }
}
