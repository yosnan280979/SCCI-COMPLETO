<?php

namespace App\Exports;

use App\Models\Asignacion;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class AsignacionesExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $asignaciones;

    public function __construct($asignaciones)
    {
        $this->asignaciones = $asignaciones;
    }

    public function collection()
    {
        return $this->asignaciones;
    }

    public function headings(): array
    {
        return [
            'Centro de Balance',
            'Línea de Crédito',
            'Fuente de Financiamiento',
            'Año',
            'Valor',
        ];
    }

    public function map($asignacion): array
    {
        return [
            $asignacion->centroBalance?->{'Centro Balance'} ?? '',
            $asignacion->lineaCredito?->{'Linea de Crédito'} ?? '',
            $asignacion->fuenteFinanciamiento?->{'Fuente Financiamiento'} ?? '',
            $asignacion->{'Año Asignacion'},
            $asignacion->Valor,
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}