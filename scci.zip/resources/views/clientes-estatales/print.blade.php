<!DOCTYPE html>
<html>
<head>
    <title>Clientes Estatales - Impresión</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #333; padding-bottom: 10px; }
        .title { font-size: 18px; font-weight: bold; text-transform: uppercase; }
        .subtitle { font-size: 12px; color: #555; }
        .filters { margin-bottom: 15px; padding: 10px; background: #f5f5f5; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: left; vertical-align: top; }
        th { background-color: #f0f0f0; font-weight: bold; text-transform: uppercase; font-size: 10px; }
        .footer { margin-top: 30px; text-align: right; font-size: 10px; color: #666; }
        @media print {
            .no-print { display: none; }
            .page-break { page-break-before: always; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="text-align:center; margin-bottom:20px;">
        <button onclick="window.print()" style="padding:10px 20px; background:#007bff; color:white; border:none; border-radius:5px; cursor:pointer;">🖨️ Imprimir</button>
        <button onclick="window.close()" style="padding:10px 20px; background:#6c757d; color:white; border:none; border-radius:5px; cursor:pointer;">✖️ Cerrar</button>
    </div>

    <div class="header">
        <div class="title">Listado de Clientes Estatales</div>
        <div class="subtitle">Fecha de impresión: {{ now()->format('d/m/Y H:i:s') }}</div>
        <div class="subtitle">Usuario: {{ auth()->user()->{'Nombre completo'} ?? 'Sistema' }}</div>
    </div>

    @if(!empty($filtros))
    <div class="filters">
        <strong>Filtros aplicados:</strong><br>
        @foreach($filtros as $filtro)
        • {{ $filtro }}<br>
        @endforeach
    </div>
    @endif

    <table>
        <thead>
            <tr>
                <th style="width:30%;">Empresa</th>
                <th style="width:15%;">Ministerio</th>
                <th style="width:15%;">NIT / REEUP</th>
                <th style="width:20%;">Director</th>
                <th style="width:20%;">Contacto / Email</th>
            </tr>
        </thead>
        <tbody>
            @forelse($items as $item)
            <tr>
                <td><strong>{{ $item->nombre_empresa }}</strong></td>
                <td>{{ $item->ministerio ?? '-' }}</td>
                <td>{{ $item->codigo_nit ?? '-' }}</td>
                <td>{{ $item->nombre_director ?? '-' }}</td>
                <td>
                    Telf: {{ $item->telefono ?? '-' }}<br>
                    Email: {{ $item->email ?? '-' }}
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="5" style="text-align:center; padding:20px;">No hay datos para mostrar</td>
            </tr>
            @endforelse
        </tbody>
        <tfoot>
            <tr>
                <td colspan="5" style="text-align:right; font-size:10px;">
                    Total de registros: {{ $items->count() }}
                </td>
            </tr>
        </tfoot>
    </table>
</body>
</html>
