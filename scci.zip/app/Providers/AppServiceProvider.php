<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Auth;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        //
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        $this->registerPolicies();

        // Definir Gates basados en tu sistema de permisos
        Gate::define('view', function ($user) {
            return $this->checkPermission($user, 'view');
        });

        Gate::define('create', function ($user) {
            return $this->checkPermission($user, 'create');
        });

        Gate::define('edit', function ($user) {
            return $this->checkPermission($user, 'edit');
        });

        Gate::define('delete', function ($user) {
            return $this->checkPermission($user, 'delete');
        });

        // Gate adicional para Informática
        Gate::define('is_informatica', function ($user) {
            return $user->area && ($user->area->Area ?? null) === 'Informatica';
        });
    }

    /**
     * Verifica si un usuario tiene un permiso específico.
     */
    private function checkPermission($user, string $permission): bool
    {
        // Informática tiene acceso a todo
        if ($user->area && ($user->area->Area ?? null) === 'Informatica') {
            return true;
        }

        $userType = $user->userType ? ($user->userType->{'Id Tipo Usuario'} ?? 3) : 3;
        $userArea = $user->area ? ($user->area->Area ?? null) : null;

        $permissions = $this->getPermissionsMatrix();

        return isset($permissions[$userArea][$userType]) &&
               in_array($permission, $permissions[$userArea][$userType], true);
    }

    /**
     * Matriz de permisos por área y tipo de usuario.
     */
    private function getPermissionsMatrix(): array
    {
        return [
            'Dirección' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Comerciales' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Dir. UEB Importaciones' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Política Comercial' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'SOE' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Control Financiamientos' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Juridico' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Marketing' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Otras Areas' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Economia' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Calidad' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Exportaciones' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Informatica' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit', 'delete'],
                3 => ['view', 'create', 'edit', 'delete'],
            ],
        ];
    }
}