#!/bin/bash

echo "Iniciando corrección de métodos en formularios de exportación..."

# 1. Cambiar POST a GET en formularios de exportación Excel
echo "Corrigiendo formularios de exportación Excel..."
find resources/views -name "*.blade.php" -exec sed -i 's/method="POST" action="{{ route(\([^)]*\.export\.excel[^)]*\)"/method="GET" action="{{ route(\1"/g' {} \;

# 2. Cambiar POST a GET en formularios de exportación PDF
echo "Corrigiendo formularios de exportación PDF..."
find resources/views -name "*.blade.php" -exec sed -i 's/method="POST" action="{{ route(\([^)]*\.export\.pdf[^)]*\)"/method="GET" action="{{ route(\1"/g' {} \;

# 3. Cambiar POST a GET en formularios de impresión (print)
echo "Corrigiendo formularios de impresión..."
find resources/views -name "*.blade.php" -exec sed -i 's/method="POST" action="{{ route(\([^)]*\.print[^)]*\)"/method="GET" action="{{ route(\1"/g' {} \;

echo "¡Corrección completada!"
echo ""
echo "Resumen de cambios realizados:"
echo "1. Todos los formularios de exportación Excel cambiados de POST a GET"
echo "2. Todos los formularios de exportación PDF cambiados de POST a GET"
echo "3. Todos los formularios de impresión cambiados de POST a GET"
