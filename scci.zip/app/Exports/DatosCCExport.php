<?php

namespace App\Exports;

use App\Models\DatosCC;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class DatosCCExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function collection()
    {
        return $this->items;
    }

    public function headings(): array
    {
        return [
            'ID',
            'No. CC',
            'SOE',
            'Valor CC',
            'Moneda',
            'Capacidad',
            'Fecha Pedido Cap',
            'Fecha Asignada Cap',
            'Fecha Presentada CC',
            'Fecha Apertura CC',
            'Momento CC',
            'Año finan',
            'Observaciones',
        ];
    }

    public function map($item): array
    {
        return [
            $item->{'Id CC'},
            $item->{'No CC'},
            $item->{'Id SOE'},
            $item->{'Valor CC'} ?? 0,
            $item->moneda?->Moneda ?? '',
            $item->capacidad?->Capacidad ?? '',
            $item->{'Fecha Pedido Cap'} ? \Carbon\Carbon::parse($item->{'Fecha Pedido Cap'})->format('d/m/Y') : '',
            $item->{'Fecha Asignada Cap'} ? \Carbon\Carbon::parse($item->{'Fecha Asignada Cap'})->format('d/m/Y') : '',
            $item->{'Fecha Presentada CC'} ? \Carbon\Carbon::parse($item->{'Fecha Presentada CC'})->format('d/m/Y') : '',
            $item->{'Fecha Apertura CC'} ? \Carbon\Carbon::parse($item->{'Fecha Apertura CC'})->format('d/m/Y') : '',
            $item->momentoCC?->{'Momento CC'} ?? '',
            $item->{'Año finan'} ?? '',
            $item->{'Observaciones CC'} ?? '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}