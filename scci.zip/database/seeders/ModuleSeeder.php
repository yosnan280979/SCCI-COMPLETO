<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class ModuleSeeder extends Seeder
{
    public function run()
    {
        $this->command->info('Iniciando seeder de módulos y permisos...');

        // Verificar si las tablas existen
        if (!Schema::hasTable('modules')) {
            $this->command->error('La tabla modules no existe. Crealá primero con la migración.');
            return;
        }

        if (!Schema::hasTable('Nomenclador Areas')) {
            $this->command->error('La tabla Nomenclador Areas no existe.');
            return;
        }

        // Insertar módulos del sistema
        $modules = [
            ['name' => 'Dashboard', 'slug' => 'dashboard', 'order' => 1],
            ['name' => 'Solicitudes', 'slug' => 'solicitudes', 'order' => 2],
            ['name' => 'Contratos', 'slug' => 'contratos', 'order' => 3],
            ['name' => 'Asignaciones', 'slug' => 'asignaciones', 'order' => 4],
            ['name' => 'Logística', 'slug' => 'logistica', 'order' => 5],
            ['name' => 'Proveedores', 'slug' => 'proveedores', 'order' => 6],
            ['name' => 'DITEC', 'slug' => 'ditec', 'order' => 7],
            ['name' => 'Finanzas', 'slug' => 'finanzas', 'order' => 8],
            ['name' => 'Operaciones', 'slug' => 'operaciones', 'order' => 9],
            ['name' => 'Organización', 'slug' => 'organizacion', 'order' => 10],
            ['name' => 'Usuarios', 'slug' => 'usuarios', 'order' => 11],
        ];

        foreach ($modules as $module) {
            DB::table('modules')->updateOrInsert(
                ['slug' => $module['slug']],
                $module
            );
            $this->command->info("Módulo {$module['name']} insertado.");
        }

        // Obtener todas las áreas y módulos
        $areas = DB::table('Nomenclador Areas')->get();
        $modules = DB::table('modules')->get();

        $this->command->info('Asignando permisos por área...');

        // Asignar permisos por defecto
        foreach ($areas as $area) {
            foreach ($modules as $module) {
                $permissions = $this->getDefaultPermissions($area->Area, $module->slug);

                DB::table('permissions')->updateOrInsert(
                    ['id_area' => $area->{'Id Area'}, 'id_module' => $module->id],
                    [
                        'id_area'  => $area->{'Id Area'},
                        'id_module' => $module->id,
                        'view'     => $permissions['view'] ?? false,
                        'create_p' => $permissions['create'] ?? false,  // ← columna corregida
                        'edit'     => $permissions['edit'] ?? false,
                        'delete_p' => $permissions['delete'] ?? false,  // ← columna corregida
                    ]
                );
            }
            $this->command->info("Permisos asignados para área: {$area->Area}");
        }

        $this->command->info('¡Seeder completado exitosamente!');
    }

    private function getDefaultPermissions($areaName, $moduleSlug)
    {
        // Informática tiene acceso completo a todo
        if ($areaName === 'Informatica') {
            return [
                'view'   => true,
                'create' => true,
                'edit'   => true,
                'delete' => true,
            ];
        }

        // Permisos por defecto para otras áreas
        $defaultPermissions = [
            'view'   => false,
            'create' => false,
            'edit'   => false,
            'delete' => false,
        ];

        // Mapeo de permisos por área (basado en tu lista de áreas)
        $permissionsByArea = [
            'Dirección' => [
                'dashboard'    => ['view' => true],
                'solicitudes'  => ['view' => true, 'create' => true, 'edit' => true],
                'contratos'    => ['view' => true, 'create' => true, 'edit' => true],
                'asignaciones' => ['view' => true],
                'logistica'    => ['view' => true],
                'proveedores'  => ['view' => true],
                'ditec'        => ['view' => true],
                'finanzas'     => ['view' => true],
                'operaciones'  => ['view' => true],
                'organizacion' => ['view' => true],
            ],
            'Comerciales' => [
                'dashboard'   => ['view' => true],
                'solicitudes' => ['view' => true, 'create' => true],
                'contratos'   => ['view' => true, 'create' => true],
                'proveedores' => ['view' => true],
                'logistica'   => ['view' => true],
                'ditec'       => ['view' => true],
            ],
            'Dir. UEB Importaciones' => [
                'dashboard'   => ['view' => true],
                'solicitudes' => ['view' => true, 'create' => true],
                'contratos'   => ['view' => true, 'create' => true],
                'logistica'   => ['view' => true, 'create' => true, 'edit' => true],
                'proveedores' => ['view' => true, 'create' => true],
                'ditec'       => ['view' => true],
            ],
            'Política Comercial' => [
                'dashboard'   => ['view' => true],
                'solicitudes' => ['view' => true],
                'contratos'   => ['view' => true],
                'proveedores' => ['view' => true],
            ],
            'SOE' => [
                'dashboard'   => ['view' => true],
                'solicitudes' => ['view' => true, 'create' => true],
                'contratos'   => ['view' => true, 'create' => true],
                'logistica'   => ['view' => true],
            ],
            'Control Financiamientos' => [
                'dashboard'    => ['view' => true],
                'solicitudes'  => ['view' => true],
                'contratos'    => ['view' => true],
                'asignaciones' => ['view' => true, 'create' => true, 'edit' => true],
                'finanzas'     => ['view' => true, 'create' => true, 'edit' => true],
            ],
            'Juridico' => [
                'dashboard'   => ['view' => true],
                'solicitudes' => ['view' => true],
                'contratos'   => ['view' => true, 'edit' => true],
                'proveedores' => ['view' => true],
            ],
            'Marketing' => [
                'dashboard'   => ['view' => true],
                'solicitudes' => ['view' => true],
                'contratos'   => ['view' => true],
                'proveedores' => ['view' => true],
                'operaciones' => ['view' => true],
            ],
            'Otras Areas' => [
                'dashboard' => ['view' => true],
            ],
            'Economia' => [
                'dashboard'    => ['view' => true],
                'solicitudes'  => ['view' => true],
                'contratos'    => ['view' => true],
                'asignaciones' => ['view' => true],
                'finanzas'     => ['view' => true, 'create' => true, 'edit' => true],
            ],
            'Calidad' => [
                'dashboard'   => ['view' => true],
                'solicitudes' => ['view' => true],
                'contratos'   => ['view' => true],
                'logistica'   => ['view' => true],
                'proveedores' => ['view' => true],
            ],
            'Exportaciones' => [
                'dashboard'   => ['view' => true],
                'solicitudes' => ['view' => true],
                'contratos'   => ['view' => true],
                'logistica'   => ['view' => true],
                'proveedores' => ['view' => true],
                'operaciones' => ['view' => true],
            ],
        ];

        if (isset($permissionsByArea[$areaName][$moduleSlug])) {
            return array_merge($defaultPermissions, $permissionsByArea[$areaName][$moduleSlug]);
        }

        return $defaultPermissions;
    }
}