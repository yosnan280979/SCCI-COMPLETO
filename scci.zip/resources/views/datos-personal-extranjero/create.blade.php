@extends('layouts.app')

@section('header', 'Personal Extranjero - Crear')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Nuevo Personal Extranjero</h5>
        <div>
            <a href="{{ route('datos-personal-extranjero.index') }}" class="btn btn-secondary btn-sm">
                <i class="fas fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>
    <div class="card-body">
        <form action="{{ route('datos-personal-extranjero.store') }}" method="POST" id="createForm">
            @csrf

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Id_proveedor" class="form-label required">Proveedor</label>
                        <select class="form-control select2" id="Id_proveedor" name="Id_proveedor" required>
                            <option value="">Seleccione un proveedor</option>
                            @foreach($proveedores as $proveedor)
                                <option value="{{ $proveedor->Id_Proveedor }}" {{ old('Id_proveedor') == $proveedor->Id_Proveedor ? 'selected' : '' }}>
                                    {{ $proveedor->Proveedor }}
                                </option>
                            @endforeach
                        </select>
                        @error('Id_proveedor')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Funcionario_extranjero" class="form-label required">Funcionario Extranjero</label>
                        <input type="text" class="form-control" id="Funcionario_extranjero" name="Funcionario_extranjero" value="{{ old('Funcionario_extranjero') }}" maxlength="50" required>
                        @error('Funcionario_extranjero')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Telef" class="form-label">Teléfono</label>
                        <input type="text" class="form-control" id="Telef" name="Telef" value="{{ old('Telef') }}" maxlength="50">
                        @error('Telef')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="Email" name="Email" value="{{ old('Email') }}" maxlength="50">
                        @error('Email')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Cargo" class="form-label">Cargo</label>
                        <input type="text" class="form-control" id="Cargo" name="Cargo" value="{{ old('Cargo') }}" maxlength="50">
                        @error('Cargo')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Permiso_de_Trabajo" class="form-label">Permiso de Trabajo</label>
                        <input type="text" class="form-control" id="Permiso_de_Trabajo" name="Permiso_de_Trabajo" value="{{ old('Permiso_de_Trabajo') }}" maxlength="50">
                        @error('Permiso_de_Trabajo')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Id_pais" class="form-label">ID País</label>
                        <input type="number" class="form-control" id="Id_pais" name="Id_pais" value="{{ old('Id_pais') }}">
                        @error('Id_pais')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Fecha_Vencimiento" class="form-label">Fecha Vencimiento</label>
                        <input type="date" class="form-control" id="Fecha_Vencimiento" name="Fecha_Vencimiento" value="{{ old('Fecha_Vencimiento') }}">
                        @error('Fecha_Vencimiento')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Escnot" class="form-label">Escnot</label>
                        <input type="text" class="form-control" id="Escnot" name="Escnot" value="{{ old('Escnot') }}" maxlength="50">
                        @error('Escnot')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Aprot" class="form-label">Aprot</label>
                        <input type="number" class="form-control" id="Aprot" name="Aprot" value="{{ old('Aprot') }}">
                        @error('Aprot')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Fechavenpod" class="form-label">Fecha Venpod</label>
                        <input type="date" class="form-control" id="Fechavenpod" name="Fechavenpod" value="{{ old('Fechavenpod') }}">
                        @error('Fechavenpod')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="Activo" class="form-label required">Activo</label>
                        <select class="form-control" id="Activo" name="Activo" required>
                            <option value="1" {{ old('Activo', 1) == '1' ? 'selected' : '' }}>Sí</option>
                            <option value="0" {{ old('Activo') == '0' ? 'selected' : '' }}>No</option>
                        </select>
                        @error('Activo')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="Firmante" class="form-label required">Firmante</label>
                        <select class="form-control" id="Firmante" name="Firmante" required>
                            <option value="1" {{ old('Firmante', 0) == '1' ? 'selected' : '' }}>Sí</option>
                            <option value="0" {{ old('Firmante') == '0' ? 'selected' : '' }}>No</option>
                        </select>
                        @error('Firmante')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <div class="mt-4 border-top pt-3">
                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Guardar
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> Limpiar
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection

@section('scripts')
<script>
$(document).ready(function() {
    $('.select2').select2({
        theme: 'bootstrap-5'
    });

    // Validación del formulario
    $('#createForm').validate({
        rules: {
            Id_proveedor: 'required',
            Funcionario_extranjero: 'required',
            Activo: 'required',
            Firmante: 'required'
        },
        messages: {
            Id_proveedor: 'Este campo es requerido',
            Funcionario_extranjero: 'Este campo es requerido',
            Activo: 'Este campo es requerido',
            Firmante: 'Este campo es requerido'
        },
        errorElement: 'span',
        errorPlacement: function (error, element) {
            error.addClass('invalid-feedback');
            element.closest('.mb-3').append(error);
        },
        highlight: function (element, errorClass, validClass) {
            $(element).addClass('is-invalid');
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).removeClass('is-invalid');
        }
    });
});
</script>
@endsection