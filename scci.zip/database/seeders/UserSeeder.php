<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;

class UserSeeder extends Seeder
{
    public function run()
    {
        $usuarios = [
            ['Usuario' => 'Idania',               'PWD' => '***Idania2021*',   'Id_Tipo_Usuario' => 2, 'Id_Area' => 9,  'Id_Especialista' => 24, 'Nombre_Completo' => 'Idania Cansino'],
            ['Usuario' => 'Osdanys',              'PWD' => '****ofr/',         'Id_Tipo_Usuario' => 2, 'Id_Area' => 9,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Osdanys Falcon Rivero'],
            ['Usuario' => 'Betty',                'PWD' => '***betty**',       'Id_Tipo_Usuario' => 2, 'Id_Area' => 6,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Beatriz Pérez'],
            ['Usuario' => 'Madelaine',            'PWD' => '***mvp8604',       'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Madelaine Villegas Pozo'],
            ['Usuario' => 'Natalia',              'PWD' => '***Naty.30978*',   'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Natalia Rojas de la Osa'],
            ['Usuario' => 'Daniela',              'PWD' => '***Imeco2020',     'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Daniela Valdéz Ramírez'],
            ['Usuario' => 'Wendy',                'PWD' => '***1958',          'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 13, 'Nombre_Completo' => 'Wendy Vázquez'],
            ['Usuario' => 'Dayron',               'PWD' => '***DPH**',         'Id_Tipo_Usuario' => 2, 'Id_Area' => 4,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Dayron Pereira Hurtado'],
            ['Usuario' => 'Denise',               'PWD' => '***tita2503',      'Id_Tipo_Usuario' => 2, 'Id_Area' => 9,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Denise Muzaurieta Ladron de Guevara'],
            ['Usuario' => 'Alejandro',            'PWD' => 'AlexC',            'Id_Tipo_Usuario' => 1, 'Id_Area' => 8,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Alejandro Castillo Reyes'],
            ['Usuario' => 'Achong',               'PWD' => '***achong**',      'Id_Tipo_Usuario' => 5, 'Id_Area' => 1,  'Id_Especialista' => null, 'Nombre_Completo' => 'Pedro Hernández Achong'],
            ['Usuario' => 'Orestes',              'PWD' => '**Orestes2020*',   'Id_Tipo_Usuario' => 3, 'Id_Area' => 13, 'Id_Especialista' => 0,  'Nombre_Completo' => 'Orestes Rodriguez Fundora'],
            ['Usuario' => 'Sonia',                'PWD' => 'Sonia2020*',       'Id_Tipo_Usuario' => 3, 'Id_Area' => 1,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Sonia Elena Perez Fernandez'],
            ['Usuario' => 'Alexis',               'PWD' => '***Alexis2020*',   'Id_Tipo_Usuario' => 3, 'Id_Area' => 3,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Alexis Gallardo'],
            ['Usuario' => 'Lourdes',              'PWD' => 'lourdes**',        'Id_Tipo_Usuario' => 2, 'Id_Area' => 4,  'Id_Especialista' => 37, 'Nombre_Completo' => 'Lourdes Quijada'],
            ['Usuario' => 'Leandro Marketing',    'PWD' => 'Mercado',          'Id_Tipo_Usuario' => 2, 'Id_Area' => 9,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Leandro Fernández Pico'],
            ['Usuario' => 'Carlos Javier',        'PWD' => 'carlosj*21',       'Id_Tipo_Usuario' => 2, 'Id_Area' => 9,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Carlos Javier Crespo Capote'],
            ['Usuario' => 'Amelia',               'PWD' => '***AW*24',         'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 12, 'Nombre_Completo' => 'Amelia Wilson'],
            ['Usuario' => 'Haymee',               'PWD' => 'HSV2025',          'Id_Tipo_Usuario' => 2, 'Id_Area' => 4,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Haymee Santos Valdes'],
            ['Usuario' => 'Nora',                 'PWD' => '***Erika2025',     'Id_Tipo_Usuario' => 2, 'Id_Area' => 4,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Nora Lucas Moreno'],
            ['Usuario' => 'Meybel',               'PWD' => '***meybel**',      'Id_Tipo_Usuario' => 2, 'Id_Area' => 4,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Meybel Muñoz Garcia'],
            ['Usuario' => 'Aixa',                 'PWD' => 'aixa2024*',        'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 8,  'Nombre_Completo' => 'Aixa'],
            ['Usuario' => 'Yaime',                'PWD' => '***ym*00',         'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 14, 'Nombre_Completo' => 'Yaimeé Monedo'],
            ['Usuario' => 'Yuniet',               'PWD' => 'yuniet2024',       'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Yuniet Gonzalez Maurisset'],
            ['Usuario' => 'Cores',                'PWD' => 'cores71',          'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 12, 'Nombre_Completo' => 'Manuel Cores'],
            ['Usuario' => 'Oydanis',              'PWD' => 'nani***',          'Id_Tipo_Usuario' => 2, 'Id_Area' => 4,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Oydanis de la Torre'],
            ['Usuario' => 'Alejandra',            'PWD' => 'Imeco2025',        'Id_Tipo_Usuario' => 2, 'Id_Area' => 9,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Alejandra Sotolongo'],
            ['Usuario' => 'Alejandra Calidad',    'PWD' => 'Imeco2025*',       'Id_Tipo_Usuario' => 2, 'Id_Area' => 12, 'Id_Especialista' => 0,  'Nombre_Completo' => 'Tahimi Mesa'],
            ['Usuario' => 'Larrinaga',            'PWD' => 'larrinaga**',      'Id_Tipo_Usuario' => 3, 'Id_Area' => 1,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Mario F. Larrinaga Careaga'],
            ['Usuario' => 'Leslie',               'PWD' => 'Victorres21',      'Id_Tipo_Usuario' => 2, 'Id_Area' => 9,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Leslie'],
            ['Usuario' => 'Lidice',               'PWD' => 'ahg2002',          'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 8,  'Nombre_Completo' => 'Lidice Gil'],
            ['Usuario' => 'Gladys',               'PWD' => 'Maikel',           'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 16, 'Nombre_Completo' => 'Gladys Portal'],
            ['Usuario' => 'Miguelina',            'PWD' => '***miguelina**',   'Id_Tipo_Usuario' => 2, 'Id_Area' => 4,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Miguelina'],
            ['Usuario' => 'Pavel',                'PWD' => 'prr2607',          'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 21, 'Nombre_Completo' => 'Pavel'],
            ['Usuario' => 'Sahily',               'PWD' => 'sahily**',         'Id_Tipo_Usuario' => 3, 'Id_Area' => 1,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Sahily'],
            ['Usuario' => 'Arelys',               'PWD' => 'JKS01',            'Id_Tipo_Usuario' => 3, 'Id_Area' => 2,  'Id_Especialista' => 17, 'Nombre_Completo' => 'Arelys Nuñez'],
            ['Usuario' => 'Maritza',              'PWD' => '***Mary**',        'Id_Tipo_Usuario' => 2, 'Id_Area' => 4,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Cecilia Casas'],
            ['Usuario' => 'Maydol',               'PWD' => '***mca1993',       'Id_Tipo_Usuario' => 2, 'Id_Area' => 4,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Maydol'],
            ['Usuario' => 'Leandro Calidad',      'PWD' => 'Calidad',          'Id_Tipo_Usuario' => 2, 'Id_Area' => 12, 'Id_Especialista' => 0,  'Nombre_Completo' => 'Leandro Fernández Pico'],
            ['Usuario' => 'Davila',               'PWD' => '***adg631213',     'Id_Tipo_Usuario' => 2, 'Id_Area' => 9,  'Id_Especialista' => 0,  'Nombre_Completo' => 'Davila'],
        ];

        foreach ($usuarios as $u) {
            User::create([
                'Usuario'           => $u['Usuario'],
                'PWD'               => bcrypt($u['PWD']),
                'Id Tipo Usuario'   => $u['Id_Tipo_Usuario'],
                'Id Area'           => $u['Id_Area'],
                'Id Especialista'   => $u['Id_Especialista'],
                'Nombre completo'   => $u['Nombre_Completo'],
            ]);
        }
    }
}