<div class="btn-group" role="group">
    <a href="{{ route('claim.show', $claim->id) }}" class="btn btn-info btn-sm">
        <i class="fas fa-eye"></i>
    </a>
    <a href="{{ route('claim.edit', $claim->id) }}" class="btn btn-warning btn-sm">
        <i class="fas fa-edit"></i>
    </a>
    <form action="{{ route('claim.destroy', $claim->id) }}" method="POST" class="d-inline delete-form">
        @csrf
        @method('DELETE')
        <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="{{ $claim->id }}">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>