<?php
require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

echo "=== FIX PERMISSIONS SYSTEM ===\n";

// 1. Crear tablas si no existen
if (!Schema::hasTable('modules')) {
    echo "Creando tabla modules...\n";
    DB::statement("
        CREATE TABLE `modules` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `name` VARCHAR(255) NOT NULL,
            `slug` VARCHAR(255) NOT NULL UNIQUE,
            `description` TEXT NULL,
            `order` INT(11) DEFAULT 0,
            `active` TINYINT(1) DEFAULT 1,
            `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
}

if (!Schema::hasTable('permissions')) {
    echo "Creando tabla permissions...\n";
    DB::statement("
        CREATE TABLE `permissions` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `id_area` INT(11) NOT NULL,
            `id_module` INT(11) NOT NULL,
            `view` TINYINT(1) DEFAULT 0,
            `create` TINYINT(1) DEFAULT 0,
            `edit` TINYINT(1) DEFAULT 0,
            `delete` TINYINT(1) DEFAULT 0,
            `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `unique_area_module` (`id_area`, `id_module`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
}

// 2. Insertar módulos básicos
$modules = [
    ['name' => 'Dashboard', 'slug' => 'dashboard', 'order' => 1],
    ['name' => 'Solicitudes', 'slug' => 'solicitudes', 'order' => 2],
    ['name' => 'Contratos', 'slug' => 'contratos', 'order' => 3],
    ['name' => 'Asignaciones', 'slug' => 'asignaciones', 'order' => 4],
    ['name' => 'Logística', 'slug' => 'logistica', 'order' => 5],
    ['name' => 'Proveedores', 'slug' => 'proveedores', 'order' => 6],
    ['name' => 'DITEC', 'slug' => 'ditec', 'order' => 7],
    ['name' => 'Finanzas', 'slug' => 'finanzas', 'order' => 8],
    ['name' => 'Operaciones', 'slug' => 'operaciones', 'order' => 9],
    ['name' => 'Organización', 'slug' => 'organizacion', 'order' => 10],
    ['name' => 'Usuarios', 'slug' => 'usuarios', 'order' => 11],
];

foreach ($modules as $module) {
    $exists = DB::table('modules')->where('slug', $module['slug'])->exists();
    if (!$exists) {
        DB::table('modules')->insert($module);
        echo "Módulo creado: {$module['name']}\n";
    }
}

// 3. Obtener áreas
$areas = DB::table('Nomenclador Areas')->get();
echo "Áreas encontradas: " . count($areas) . "\n";

// 4. Asignar permisos básicos
foreach ($areas as $area) {
    $modules = DB::table('modules')->get();
    
    foreach ($modules as $module) {
        // Verificar si ya existe
        $exists = DB::table('permissions')
            ->where('id_area', $area->{'Id Area'})
            ->where('id_module', $module->id)
            ->exists();
        
        if (!$exists) {
            $view = $create = $edit = $delete = 0;
            
            // Informática tiene todo
            if ($area->Area === 'Informatica') {
                $view = $create = $edit = $delete = 1;
            }
            // Dashboard para todos
            else if ($module->slug === 'dashboard') {
                $view = 1;
            }
            
            DB::table('permissions')->insert([
                'id_area' => $area->{'Id Area'},
                'id_module' => $module->id,
                'view' => $view,
                'create' => $create,
                'edit' => $edit,
                'delete' => $delete,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
        }
    }
    echo "Permisos asignados para: {$area->Area}\n";
}

echo "=== PROCESO COMPLETADO ===\n";

// 5. Mostrar resumen
$summary = DB::table('permissions')
    ->join('Nomenclador Areas', 'permissions.id_area', '=', 'Nomenclador Areas.Id Area')
    ->join('modules', 'permissions.id_module', '=', 'modules.id')
    ->select('Nomenclador Areas.Area', 'modules.name', 'permissions.view')
    ->where('permissions.view', 1)
    ->orderBy('Nomenclador Areas.Area')
    ->orderBy('modules.order')
    ->get();

echo "\nRESUMEN DE PERMISOS:\n";
$currentArea = '';
foreach ($summary as $row) {
    if ($currentArea !== $row->Area) {
        $currentArea = $row->Area;
        echo "\n{$row->Area}:\n";
    }
    echo "  - {$row->name}\n";
}
