<?php
// Ejecutar: php create_controllers.php

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$controllers = [
    'ClienteController',
    'DestinoController',
    'TipoProductoGeneralController',
    'SolicitudDescripcionController',
    'SolicitudProveedorController',
    'DatosSOEController',
    'ContratoSuministroController',
    'DatosCttoSuministroController',
    'EmbarqueController',
    'CargaController',
    'FacturacionController',
    'ReclamacionController',
    'AsignacionController',
    'AsigPorSolicController',
    'DatosCCController',
    'DatosBancosProveedorController',
    'DatosPersonalExtranjeroController',
    'DatosPersonalCubanoController',
    'DocPorProveedorController',
    'DITECController',
    'ProveedorDITECController',
    'PaisesProveedorController',
    'ProveedorEmpImpController',
    'ProveedorMarcaController',
    'TipoProductoProveedorController',
    'SalidaMercadoController',
    'ProveedorSalirMercadoController',
    'ControlUsuarioController',
    'CttoCVICttoSumController',
    'PagoClienteController',
    'SolCttoController',
    'NomencladorActualizarController',
    'BancoController',
    'EmpresaImportadoraController',
    'MinisterioController',
    'MomentoSOEController',
    'TipoRespuestaController',
    'DocumentoController',
    'CapacidadController',
    'MomentoCCController',
    'PaisController',
    'TipoProveedorController',
    'TipoProductoController',
    'TipoCttoCubanoController',
];

foreach ($controllers as $controller) {
    $command = "php artisan make:controller {$controller} --resource --model=" . str_replace('Controller', '', $controller);
    echo "Ejecutando: {$command}\n";
    exec($command, $output, $returnVar);
    
    if ($returnVar === 0) {
        echo "✓ {$controller} creado exitosamente\n";
    } else {
        echo "✗ Error al crear {$controller}\n";
    }
}

echo "\n¡Todos los controladores han sido generados!\n";