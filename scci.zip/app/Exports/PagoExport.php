<?php

namespace App\Exports;

use App\Models\Pago;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class PagoExport implements FromCollection, WithHeadings, WithMapping
{
    protected $items;

    public function __construct($items = null)
    {
        $this->items = $items;
    }

    /**
     * Colección de datos a exportar
     */
    public function collection()
    {
        return $this->items ?? Pago::with('contratoSuministro')->get();
    }

    /**
     * Encabezados de columnas
     */
    public function headings(): array
    {
        return [
            'ID',
            'Contrato Suministro',
            'No. Elemento Pago',
            'Valor MN',
            'Valor CUC',
            'Observaciones',
        ];
    }

    /**
     * Mapeo de cada fila
     */
    public function map($item): array
    {
        return [
            $item->Id ?? $item->id,
            $item->contratoSuministro?->Descripcion ?? 'N/A',
            $item->No_Elemento_Pago,
            number_format($item->Valor_MN, 2),
            number_format($item->Valor_CUC, 2),
            $item->Observaciones,
        ];
    }
}
