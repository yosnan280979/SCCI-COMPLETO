<?php

namespace App\Exports;

use App\Models\Capacidad;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class CapacidadesExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $capacidades;

    public function __construct($capacidades)
    {
        $this->capacidades = $capacidades;
    }

    public function collection()
    {
        return $this->capacidades;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Capacidad',
            'Descripción',
        ];
    }

    public function map($capacidad): array
    {
        return [
            $capacidad->{'Id Capacidad'},
            $capacidad->Capacidad,
            $capacidad->Descripcion,
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}