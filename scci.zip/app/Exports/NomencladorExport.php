// app/Exports/NomencladorExport.php
<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class NomencladorExport implements FromCollection, WithHeadings, WithTitle, ShouldAutoSize, WithStyles
{
    protected $type;
    
    public function __construct($type)
    {
        $this->type = $type;
    }
    
    public function collection()
    {
        switch ($this->type) {
            case 'areas':
                return \App\Models\Area::all();
            case 'specialists':
                return \App\Models\Specialist::all();
            case 'balance_centers':
                return \App\Models\BalanceCenter::with('osde')->get();
            case 'osdes':
                return \App\Models\OSDE::all();
            case 'classifications':
                return \App\Models\Classification::orderBy('Orden')->get();
            case 'operation_types':
                return \App\Models\OperationType::all();
            case 'credit_lines':
                return \App\Models\CreditLine::all();
            case 'financing_sources':
                return \App\Models\FinancingSource::all();
            case 'providers':
                return \App\Models\Provider::all();
            case 'currencies':
                return \App\Models\Currency::all();
            case 'load_types':
                return \App\Models\LoadType::all();
            case 'user_types':
                return \App\Models\UserType::all();
            default:
                return collect([]);
        }
    }
    
    public function headings(): array
    {
        switch ($this->type) {
            case 'areas':
                return ['ID', 'Área'];
            case 'specialists':
                return ['ID', 'Especialista', 'Activo', 'ID Tutor'];
            case 'balance_centers':
                return ['ID', 'Centro de Balance', 'Activo', 'ID OSDE', 'OSDE'];
            case 'osdes':
                return ['ID', 'OSDE', 'MICONS'];
            case 'classifications':
                return ['ID', 'Clasificación', 'Con Valor Contrato', 'Orden'];
            case 'operation_types':
                return ['ID', 'Tipo de Operación'];
            case 'credit_lines':
                return ['ID', 'Línea de Crédito'];
            case 'financing_sources':
                return ['ID', 'Fuente de Financiamiento', 'CT'];
            case 'providers':
                return ['ID', 'No. Exp', 'Proveedor', 'País', 'Activo', 'Correo', 'Código MINCEX', 'Fecha CC', 'ID Tipo Proveedor', 'Oficina Cuba', 'Correo Cuba', 'Dirección Cuba', 'Dirección Matriz', 'Correo Matriz', 'Teléfono Cuba', 'Teléfono Matriz', 'Fax Cuba', 'Fax Matriz', 'Productos', 'Vigencia CC', 'No. Registro CC', 'Siglas', 'Sitio Web', 'Fecha Fundación', 'Capital Social', 'ID Moneda', 'Código Postal Matriz', 'Código Postal Cuba', 'Registro Mercantil', 'Fecha RM', 'Fecha V RM', 'Región Matriz', 'Ciudad Matriz', 'No. Escritura Consular', 'Fecha Escritura Consular', 'Notario', 'Fecha Confianza 1', 'Fecha Aval Banco Cuba', 'Fecha Aval Banco Exterior', 'Año Último Balance', 'Fecha Alta Comité', 'Acta Alta Comité', 'Acuerdo Alta Comité', 'Fecha Alta Consejo', 'Acta Alta Consejo', 'Acuerdo Alta Consejo', 'Fecha Baja Consejo', 'Acta Baja Consejo', 'Acuerdo Baja Consejo', 'Observación Temporal'];
            case 'currencies':
                return ['ID', 'Moneda'];
            case 'load_types':
                return ['ID', 'Tipo de Carga'];
            case 'user_types':
                return ['ID', 'Tipo de Usuario'];
            default:
                return [];
        }
    }
    
    public function title(): string
    {
        switch ($this->type) {
            case 'areas':
                return 'Áreas';
            case 'specialists':
                return 'Especialistas';
            case 'balance_centers':
                return 'Centros de Balance';
            case 'osdes':
                return 'OSDEs';
            case 'classifications':
                return 'Clasificaciones';
            case 'operation_types':
                return 'Tipos de Operación';
            case 'credit_lines':
                return 'Líneas de Crédito';
            case 'financing_sources':
                return 'Fuentes de Financiamiento';
            case 'providers':
                return 'Proveedores';
            case 'currencies':
                return 'Monedas';
            case 'load_types':
                return 'Tipos de Carga';
            case 'user_types':
                return 'Tipos de Usuario';
            default:
                return 'Datos';
        }
    }
    
    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }
}