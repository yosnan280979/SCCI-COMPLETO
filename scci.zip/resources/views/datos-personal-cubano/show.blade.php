@extends('layouts.app')

@section('title', 'Detalles del Personal Cubano')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Detalles del Personal Cubano</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('datos-personal-cubano.edit', $item->Id) }}" class="btn btn-warning btn-sm">Editar</a>
                <form action="{{ route('datos-personal-cubano.destroy', $item->Id) }}" method="POST" style="display:inline-block;">
                    @csrf @method('DELETE')
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar este registro?')">Eliminar</button>
                </form>
                <a href="{{ route('datos-personal-cubano.index') }}" class="btn btn-secondary btn-sm">Volver</a>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered">
                        <tr>
                            <th width="40%">ID:</th>
                            <td>{{ $item->Id }}</td>
                        </tr>
                        <tr>
                            <th>Funcionario Cubano:</th>
                            <td>{{ $item->Funcionario_cubano }}</td>
                        </tr>
                        <tr>
                            <th>Cargo:</th>
                            <td>{{ $item->Cargo ?? 'N/A' }}</td>
                        </tr>
                        <tr>
                            <th>Proveedor:</th>
                            <td>
                                @if($item->provider)
                                    {{ $item->provider->Proveedor }} (ID: {{ $item->Id_Proveedor }})
                                @else
                                    N/A
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Tipo de Contrato:</th>
                            <td>
                                @if($item->tipoCtto)
                                    {{ $item->tipoCtto->{'Tipo Ctto'} }} (ID: {{ $item->Id_Tipo_Ctto }})
                                @else
                                    N/A
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Carnet Acorec:</th>
                            <td>{{ $item->Carnet_Acorec ?? 'N/A' }}</td>
                        </tr>
                        <tr>
                            <th>Vigencia:</th>
                            <td>{{ $item->Vigencia ? \Carbon\Carbon::parse($item->Vigencia)->format('d/m/Y') : 'N/A' }}</td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered">
                        <tr>
                            <th width="40%">Teléfono:</th>
                            <td>{{ $item->telef ?? 'N/A' }}</td>
                        </tr>
                        <tr>
                            <th>Email:</th>
                            <td>{{ $item->Email ?? 'N/A' }}</td>
                        </tr>
                        <tr>
                            <th>Estado:</th>
                            <td>
                                <span class="badge bg-{{ $item->Activo ? 'success' : 'danger' }}">
                                    {{ $item->Activo ? 'Activo' : 'Inactivo' }}
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <th>Dirección:</th>
                            <td>{{ $item->Direccion ?? 'N/A' }}</td>
                        </tr>
                        <tr>
                            <th>Observaciones:</th>
                            <td>{{ $item->Observaciones ?? 'N/A' }}</td>
                        </tr>
                        <tr>
                            <th>Fecha de creación:</th>
                            <td>{{ $item->created_at ? \Carbon\Carbon::parse($item->created_at)->format('d/m/Y H:i') : 'N/A' }}</td>
                        </tr>
                        <tr>
                            <th>Última actualización:</th>
                            <td>{{ $item->updated_at ? \Carbon\Carbon::parse($item->updated_at)->format('d/m/Y H:i') : 'N/A' }}</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection