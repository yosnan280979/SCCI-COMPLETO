@extends('layouts.app')

@section('title', 'Crear Datos Contrato Suministro')

@section('content')
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3>Crear Nuevos Datos de Contrato Suministro</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('datos-ctto-suministro.store') }}" method="POST">
                @csrf
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Id Cttosuministro" class="form-label">Contrato Suministro *</label>
                        <select class="form-select" id="Id Cttosuministro" name="Id Cttosuministro" required>
                            <option value="">Seleccionar Contrato</option>
                            @foreach($contratosSuministro as $contrato)
                                <option value="{{ $contrato->{'Id Cttosuministro'} }}">
                                    {{ $contrato->{'No Ctto Suministro'} }} - {{ $contrato->Descripcion }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="No Suplemento" class="form-label">No. Suplemento *</label>
                        <input type="number" class="form-control" id="No Suplemento" name="No Suplemento" required>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Fecha firma Ctto" class="form-label">Fecha Firma Contrato *</label>
                        <input type="date" class="form-control" id="Fecha firma Ctto" name="Fecha firma Ctto" required>
                    </div>
                    <div class="col-md-6">
                        <label for="Forma de Pago" class="form-label">Forma de Pago</label>
                        <input type="text" class="form-control" id="Forma de Pago" name="Forma de Pago">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-3">
                        <label for="Importe CUC" class="form-label">Importe CUC</label>
                        <input type="number" step="0.01" class="form-control" id="Importe CUC" name="Importe CUC">
                    </div>
                    <div class="col-md-3">
                        <label for="Importe CUP" class="form-label">Importe CUP</label>
                        <input type="number" step="0.01" class="form-control" id="Importe CUP" name="Importe CUP">
                    </div>
                    <div class="col-md-3">
                        <label for="Pendiente Finan CUC" class="form-label">Pendiente Financiar CUC</label>
                        <input type="number" step="0.01" class="form-control" id="Pendiente Finan CUC" name="Pendiente Finan CUC">
                    </div>
                    <div class="col-md-3">
                        <label for="Pendiente CUP" class="form-label">Pendiente CUP</label>
                        <input type="number" step="0.01" class="form-control" id="Pendiente CUP" name="Pendiente CUP">
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="{{ route('datos-ctto-suministro.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar Datos</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection