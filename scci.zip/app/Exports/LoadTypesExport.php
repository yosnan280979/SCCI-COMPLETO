<?php

namespace App\Exports;

use App\Models\LoadType;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class LoadTypesExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $loadTypes;

    public function __construct($loadTypes)
    {
        $this->loadTypes = $loadTypes;
    }

    public function collection()
    {
        return $this->loadTypes;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Tipo de Carga',
        ];
    }

    public function map($loadType): array
    {
        return [
            $loadType->{'Id Tipo Carga'},
            $loadType->{'Tipo Carga'},
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}