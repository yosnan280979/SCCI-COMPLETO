<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class QuickPermissionsSeeder extends Seeder
{
    public function run()
    {
        // Solo crear tablas si no existen
        $this->createTablesIfNotExist();
        
        // Insertar módulos mínimos
        $this->insertBasicModules();
        
        // Asignar permisos básicos
        $this->assignBasicPermissions();
    }
    
    private function createTablesIfNotExist()
    {
        // Crear tabla modules
        if (!DB::select("SHOW TABLES LIKE 'modules'")) {
            DB::statement("
                CREATE TABLE `modules` (
                    `id` INT(11) NOT NULL AUTO_INCREMENT,
                    `name` VARCHAR(255) NOT NULL,
                    `slug` VARCHAR(255) NOT NULL,
                    `order` INT(11) DEFAULT 0,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `slug_unique` (`slug`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");
        }
        
        // Crear tabla permissions
        if (!DB::select("SHOW TABLES LIKE 'permissions'")) {
            DB::statement("
                CREATE TABLE `permissions` (
                    `id` INT(11) NOT NULL AUTO_INCREMENT,
                    `id_area` INT(11) NOT NULL,
                    `id_module` INT(11) NOT NULL,
                    `view` TINYINT(1) DEFAULT 0,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `area_module` (`id_area`, `id_module`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");
        }
    }
    
    private function insertBasicModules()
    {
        $modules = [
            ['slug' => 'dashboard', 'name' => 'Dashboard'],
            ['slug' => 'solicitudes', 'name' => 'Solicitudes'],
            ['slug' => 'contratos', 'name' => 'Contratos'],
            ['slug' => 'usuarios', 'name' => 'Usuarios'],
        ];
        
        foreach ($modules as $module) {
            DB::table('modules')->updateOrInsert(
                ['slug' => $module['slug']],
                $module
            );
        }
    }
    
    private function assignBasicPermissions()
    {
        // Obtener áreas
        $areas = DB::table('Nomenclador Areas')->get();
        $modules = DB::table('modules')->get();
        
        foreach ($areas as $area) {
            foreach ($modules as $module) {
                $view = false;
                
                // Todos pueden ver dashboard
                if ($module->slug === 'dashboard') {
                    $view = true;
                }
                
                // Informática puede ver todo
                if ($area->Area === 'Informatica') {
                    $view = true;
                }
                
                DB::table('permissions')->updateOrInsert(
                    ['id_area' => $area->{'Id Area'}, 'id_module' => $module->id],
                    ['view' => $view]
                );
            }
        }
    }
}