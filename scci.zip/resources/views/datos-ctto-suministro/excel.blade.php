<table border="1">
    <thead>
        <tr>
            <th>ID</th>
            <th>Contrato Suministro</th>
            <th>No. Suplemento</th>
            <th>Importe CUC</th>
            <th>Importe CUP</th>
            <th>Fecha Firma</th>
        </tr>
    </thead>
    <tbody>
        @if(request()->filled('selected'))
            @php
                $selectedIds = explode(',', request('selected'));
                $itemsToExport = $items->whereIn('Id_Supsum', $selectedIds);
            @endphp
            @foreach($itemsToExport as $item)
                <tr>
                    <td>{{ $item->Id_Supsum ?? $item->id }}</td>
                    <td>{{ $item->contratoSuministro->Descripcion ?? 'N/A' }}</td>
                    <td>{{ $item->No_Suplemento }}</td>
                    <td>{{ number_format($item->Importe_CUC, 2) }}</td>
                    <td>{{ number_format($item->Importe_CUP, 2) }}</td>
                    <td>{{ $item->Fecha_firma_Ctto ? \Carbon\Carbon::parse($item->Fecha_firma_Ctto)->format('d/m/Y') : '' }}</td>
                </tr>
            @endforeach
        @else
            @foreach($items as $item)
                <tr>
                    <td>{{ $item->Id_Supsum ?? $item->id }}</td>
                    <td>{{ $item->contratoSuministro->Descripcion ?? 'N/A' }}</td>
                    <td>{{ $item->No_Suplemento }}</td>
                    <td>{{ number_format($item->Importe_CUC, 2) }}</td>
                    <td>{{ number_format($item->Importe_CUP, 2) }}</td>
                    <td>{{ $item->Fecha_firma_Ctto ? \Carbon\Carbon::parse($item->Fecha_firma_Ctto)->format('d/m/Y') : '' }}</td>
                </tr>
            @endforeach
        @endif
    </tbody>
</table>