@extends('layouts.app')

@section('title', 'Editar ControlUsuario')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Editar ControlUsuario</h3>
                    <div class="card-tools">
                        <a href="{{ route('controlusuario.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    </div>
                </div>
                <form action="{{ route('controlusuario.update', $control_usuario->id) }}" method="POST">
                    @csrf
                    @method('PUT')
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                                        <div class="form-group">
                            <label for="usuario_id">Usuario ID</label>
                            <input type="text" class="form-control @error('usuario_id') is-invalid @enderror" 
                                   id="usuario_id" name="usuario_id" value="{{ old('usuario_id', $control_usuario->usuario_id) }}" >
                            @error('usuario_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>                        <div class="form-group">
                            <label for="entrada">Entrada</label>
                            <input type="datetime-local" class="form-control @error('entrada') is-invalid @enderror" 
                                   id="entrada" name="entrada" value="{{$control_usuario->entrada ? $control_usuario->entrada->format('Y-m-d\\TH:i') : ''}}" >
                            @error('entrada')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>                        <div class="form-group">
                            <label for="salida">Salida</label>
                            <input type="datetime-local" class="form-control @error('salida') is-invalid @enderror" 
                                   id="salida" name="salida" value="{{$control_usuario->salida ? $control_usuario->salida->format('Y-m-d\\TH:i') : ''}}" >
                            @error('salida')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Actualizar
                        </button>
                        <a href="{{ route('controlusuario.index') }}" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancelar
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection