<?php

namespace App\Exports;

use App\Models\DatosPersonalCubano;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class DatosPersonalCubanoExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function collection()
    {
        return $this->items;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Funcionario Cubano',
            'Proveedor ID',
            'Proveedor',
            'Teléfono',
            'Email',
            'Carnet Acorec',
            'Vigencia',
            'Tipo Contrato ID',
            'Tipo Contrato',
            'Activo',
            'Cargo',
            'Dirección',
            'Observaciones'
        ];
    }

    public function map($item): array
    {
        return [
            $item->Id,
            $item->Funcionario_cubano,
            $item->Id_Proveedor,
            $item->provider ? $item->provider->Proveedor : '',
            $item->telef,
            $item->Email,
            $item->Carnet_Acorec,
            $item->Vigencia ? \Carbon\Carbon::parse($item->Vigencia)->format('d/m/Y') : '',
            $item->Id_Tipo_Ctto,
            $item->tipoCtto ? $item->tipoCtto->{'Tipo Ctto'} : '',
            $item->Activo ? 'Sí' : 'No',
            $item->Cargo ?? '',
            $item->Direccion ?? '',
            $item->Observaciones ?? ''
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            // Estilo para la fila de encabezado
            1    => ['font' => ['bold' => true]],
        ];
    }
}