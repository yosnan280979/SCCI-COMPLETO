<?php

namespace App\Exports;

use App\Models\CttoCVICttoSum;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class CttoCVICttoSumExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function collection()
    {
        return $this->items;
    }

    public function headings(): array
    {
        return [
            'ID',
            'ID SOE',
            'No Suplemento SOE',
            'ID Contrato Suministro',
            'No Ctto Suministro',
            'Descripción Ctto Suministro',
        ];
    }

    public function map($item): array
    {
        return [
            $item->Id,
            $item->Id_SOE,
            $item->datosSOE?->{'No Suplemento'} ?? '',
            $item->Id_Ctto_Sum,
            $item->contratoSuministro?->{'No Ctto Suministro'} ?? '',
            $item->contratoSuministro?->{'Descripcion'} ?? '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}