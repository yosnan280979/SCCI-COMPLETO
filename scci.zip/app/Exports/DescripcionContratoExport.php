<?php

namespace App\Exports;

use App\Models\DescripcionContrato;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Carbon\Carbon;

class DescripcionContratoExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $descripcionContratos;

    public function __construct($descripcionContratos)
    {
        $this->descripcionContratos = $descripcionContratos;
    }

    public function collection()
    {
        return $this->descripcionContratos;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Solicitud',
            'Contrato',
            'Producto',
            'UM',
            'Cantidad',
            'Precio CUC',
            'Precio Moneda Proveedor',
            'Moneda',
        ];
    }

    public function map($item): array
    {
        return [
            $item->Id,
            $item->solicitud?->{'No Solicitud'} ?? 'N/A',
            $item->contrato?->{'No Ctto'} ?? 'N/A',
            $item->Producto,
            $item->UM,
            $item->Cantidad ? number_format($item->Cantidad, 2) : '0.00',
            $item->{'Precio CUC'} ? number_format($item->{'Precio CUC'}, 2) : '0.00',
            $item->{'Precio Mon Prov'} ? number_format($item->{'Precio Mon Prov'}, 2) : '0.00',
            $item->moneda?->Moneda ?? 'N/A',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}