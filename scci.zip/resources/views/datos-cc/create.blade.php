@extends('layouts.app')

@section('header', 'Crear Certificado de Compra')

@section('content')
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Nuevo Certificado de Compra</h5>
    </div>
    <div class="card-body">
        <form action="{{ route('datos-cc.store') }}" method="POST">
            @csrf
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Id_SOE" class="form-label">SOE *</label>
                        <select class="form-control select2" id="Id_SOE" name="Id_SOE" required>
                            <option value="">Seleccione un SOE</option>
                            @foreach($soes as $soe)
                                <option value="{{ $soe->{'Id SOE'} }}" {{ old('Id_SOE') == $soe->{'Id SOE'} ? 'selected' : '' }}>
                                    {{ $soe->{'Id SOE'} }} - {{ $soe->{'No Referencia'} ?? 'Sin referencia' }}
                                </option>
                            @endforeach
                        </select>
                        @error('Id_SOE')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="No_CC" class="form-label">No. CC</label>
                        <input type="text" class="form-control" id="No_CC" name="No_CC" 
                               value="{{ old('No_CC') }}" placeholder="Ej: CC-2023-001">
                        @error('No_CC')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Id_Moneda" class="form-label">Moneda</label>
                        <select class="form-control select2" id="Id_Moneda" name="Id_Moneda">
                            <option value="">Seleccione moneda</option>
                            @foreach($monedas as $moneda)
                                <option value="{{ $moneda->{'Id Moneda'} }}" {{ old('Id_Moneda') == $moneda->{'Id Moneda'} ? 'selected' : '' }}>
                                    {{ $moneda->Moneda }}
                                </option>
                            @endforeach
                        </select>
                        @error('Id_Moneda')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Valor_CC" class="form-label">Valor CC</label>
                        <input type="number" step="0.01" class="form-control" id="Valor_CC" name="Valor_CC" 
                               value="{{ old('Valor_CC') }}" placeholder="0.00">
                        @error('Valor_CC')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Id_Capacidad" class="form-label">Capacidad</label>
                        <select class="form-control select2" id="Id_Capacidad" name="Id_Capacidad">
                            <option value="">Seleccione capacidad</option>
                            @foreach($capacidades as $capacidad)
                                <option value="{{ $capacidad->{'Id Capacidad'} }}" {{ old('Id_Capacidad') == $capacidad->{'Id Capacidad'} ? 'selected' : '' }}>
                                    {{ $capacidad->Capacidad }} - {{ $capacidad->Descripcion }}
                                </option>
                            @endforeach
                        </select>
                        @error('Id_Capacidad')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Id_Linea_credito" class="form-label">Línea de Crédito</label>
                        <select class="form-control select2" id="Id_Linea_credito" name="Id_Linea_credito">
                            <option value="">Seleccione línea</option>
                            @foreach($lineasCredito as $linea)
                                <option value="{{ $linea->{'Id Lineacredito'} }}" {{ old('Id_Linea_credito') == $linea->{'Id Lineacredito'} ? 'selected' : '' }}>
                                    {{ $linea->{'Linea de Crédito'} }}
                                </option>
                            @endforeach
                        </select>
                        @error('Id_Linea_credito')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Fecha_Pedido_Cap" class="form-label">Fecha Pedido Capacidad</label>
                        <input type="date" class="form-control" id="Fecha_Pedido_Cap" name="Fecha_Pedido_Cap" 
                               value="{{ old('Fecha_Pedido_Cap') }}">
                        @error('Fecha_Pedido_Cap')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Fecha_Asignada_Cap" class="form-label">Fecha Asignada Capacidad</label>
                        <input type="date" class="form-control" id="Fecha_Asignada_Cap" name="Fecha_Asignada_Cap" 
                               value="{{ old('Fecha_Asignada_Cap') }}">
                        @error('Fecha_Asignada_Cap')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Fecha_Presentada_CC" class="form-label">Fecha Presentada CC</label>
                        <input type="date" class="form-control" id="Fecha_Presentada_CC" name="Fecha_Presentada_CC" 
                               value="{{ old('Fecha_Presentada_CC') }}">
                        @error('Fecha_Presentada_CC')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Fecha_Apertura_CC" class="form-label">Fecha Apertura CC</label>
                        <input type="date" class="form-control" id="Fecha_Apertura_CC" name="Fecha_Apertura_CC" 
                               value="{{ old('Fecha_Apertura_CC') }}">
                        @error('Fecha_Apertura_CC')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Id_MomentoCC" class="form-label">Momento CC</label>
                        <select class="form-control select2" id="Id_MomentoCC" name="Id_MomentoCC">
                            <option value="">Seleccione momento</option>
                            @foreach($momentosCC as $momento)
                                <option value="{{ $momento->{'Id MomentoCC'} }}" {{ old('Id_MomentoCC') == $momento->{'Id MomentoCC'} ? 'selected' : '' }}>
                                    {{ $momento->{'Momento CC'} }}
                                </option>
                            @endforeach
                        </select>
                        @error('Id_MomentoCC')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="Año_finan" class="form-label">Año Financiero</label>
                        <input type="number" class="form-control" id="Año_finan" name="Año_finan" 
                               value="{{ old('Año_finan', date('Y')) }}" placeholder="Ej: 2023">
                        @error('Año_finan')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    <div class="mb-3">
                        <label for="Observaciones_CC" class="form-label">Observaciones</label>
                        <textarea class="form-control" id="Observaciones_CC" name="Observaciones_CC" rows="3">{{ old('Observaciones_CC') }}</textarea>
                        @error('Observaciones_CC')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>
            
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Guardar
                </button>
                <a href="{{ route('datos-cc.index') }}" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancelar
                </a>
            </div>
        </form>
    </div>
</div>
@endsection

@section('scripts')
<script>
$(document).ready(function() {
    $('.select2').select2({
        theme: 'bootstrap-5'
    });
});
</script>
@endsection