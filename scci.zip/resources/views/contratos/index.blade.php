@extends('layouts.app')

@section('title', 'Contratos')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Contratos</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('contratos.create') }}" class="btn btn-primary btn-sm">➕ Crear Contrato</a>
                
                <!-- Formularios de exportación separados (GET) -->
                <form id="exportExcelForm" method="GET" action="{{ route('contratos.export.excel') }}" style="display: inline">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="no_ctto" value="{{ request('no_ctto') }}">
                    <input type="hidden" name="id_proveedor" value="{{ request('id_proveedor') }}">
                    <input type="hidden" name="id_moneda" value="{{ request('id_moneda') }}">
                    <input type="hidden" name="forma_pago" value="{{ request('forma_pago') }}">
                    <input type="hidden" name="concluido" value="{{ request('concluido') }}">
                    <input type="hidden" name="cancelado" value="{{ request('cancelado') }}">
                    <input type="hidden" name="fecha_desde" value="{{ request('fecha_desde') }}">
                    <input type="hidden" name="fecha_hasta" value="{{ request('fecha_hasta') }}">
                    <input type="hidden" name="valor_min_cuc" value="{{ request('valor_min_cuc') }}">
                    <input type="hidden" name="valor_max_cuc" value="{{ request('valor_max_cuc') }}">
                    <input type="hidden" name="valor_min_mon_prov" value="{{ request('valor_min_mon_prov') }}">
                    <input type="hidden" name="valor_max_mon_prov" value="{{ request('valor_max_mon_prov') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="exportSelectedIds" value="">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                
                <form id="exportPdfForm" method="GET" action="{{ route('contratos.export.pdf') }}" style="display: inline">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="no_ctto" value="{{ request('no_ctto') }}">
                    <input type="hidden" name="id_proveedor" value="{{ request('id_proveedor') }}">
                    <input type="hidden" name="id_moneda" value="{{ request('id_moneda') }}">
                    <input type="hidden" name="forma_pago" value="{{ request('forma_pago') }}">
                    <input type="hidden" name="concluido" value="{{ request('concluido') }}">
                    <input type="hidden" name="cancelado" value="{{ request('cancelado') }}">
                    <input type="hidden" name="fecha_desde" value="{{ request('fecha_desde') }}">
                    <input type="hidden" name="fecha_hasta" value="{{ request('fecha_hasta') }}">
                    <input type="hidden" name="valor_min_cuc" value="{{ request('valor_min_cuc') }}">
                    <input type="hidden" name="valor_max_cuc" value="{{ request('valor_max_cuc') }}">
                    <input type="hidden" name="valor_min_mon_prov" value="{{ request('valor_min_mon_prov') }}">
                    <input type="hidden" name="valor_max_mon_prov" value="{{ request('valor_max_mon_prov') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="pdfSelectedIds" value="">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                
                <form id="printForm" method="GET" action="{{ route('contratos.print') }}" style="display: inline" target="_blank">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="no_ctto" value="{{ request('no_ctto') }}">
                    <input type="hidden" name="id_proveedor" value="{{ request('id_proveedor') }}">
                    <input type="hidden" name="id_moneda" value="{{ request('id_moneda') }}">
                    <input type="hidden" name="forma_pago" value="{{ request('forma_pago') }}">
                    <input type="hidden" name="concluido" value="{{ request('concluido') }}">
                    <input type="hidden" name="cancelado" value="{{ request('cancelado') }}">
                    <input type="hidden" name="fecha_desde" value="{{ request('fecha_desde') }}">
                    <input type="hidden" name="fecha_hasta" value="{{ request('fecha_hasta') }}">
                    <input type="hidden" name="valor_min_cuc" value="{{ request('valor_min_cuc') }}">
                    <input type="hidden" name="valor_max_cuc" value="{{ request('valor_max_cuc') }}">
                    <input type="hidden" name="valor_min_mon_prov" value="{{ request('valor_min_mon_prov') }}">
                    <input type="hidden" name="valor_max_mon_prov" value="{{ request('valor_max_mon_prov') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="printSelectedIds" value="">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Filtros -->
            <form method="GET" action="{{ route('contratos.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" name="search" class="form-control" placeholder="Búsqueda general..."
                               value="{{ request('search') }}">
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="no_ctto" class="form-control" placeholder="No. Contrato"
                               value="{{ request('no_ctto') }}">
                    </div>
                    <div class="col-md-3">
                        <select name="id_proveedor" class="form-select">
                            <option value="">Proveedor</option>
                            @foreach($providers as $provider)
                                <option value="{{ $provider->{'Id Proveedor'} }}" {{ request('id_proveedor') == $provider->{'Id Proveedor'} ? 'selected' : '' }}>
                                    {{ $provider->Proveedor }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="id_moneda" class="form-select">
                            <option value="">Moneda</option>
                            @foreach($currencies as $currency)
                                <option value="{{ $currency->{'Id Moneda'} }}" {{ request('id_moneda') == $currency->{'Id Moneda'} ? 'selected' : '' }}>
                                    {{ $currency->Moneda }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <input type="text" name="forma_pago" class="form-control" placeholder="Forma de Pago"
                               value="{{ request('forma_pago') }}">
                    </div>
                    <div class="col-md-3">
                        <select name="concluido" class="form-select">
                            <option value="">Concluido</option>
                            <option value="1" {{ request('concluido') == '1' ? 'selected' : '' }}>Sí</option>
                            <option value="0" {{ request('concluido') == '0' ? 'selected' : '' }}>No</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="cancelado" class="form-select">
                            <option value="">Cancelado</option>
                            <option value="1" {{ request('cancelado') == '1' ? 'selected' : '' }}>Sí</option>
                            <option value="0" {{ request('cancelado') == '0' ? 'selected' : '' }}>No</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="fecha_desde" class="form-control" placeholder="Fecha desde"
                               value="{{ request('fecha_desde') }}">
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <input type="date" name="fecha_hasta" class="form-control" placeholder="Fecha hasta"
                               value="{{ request('fecha_hasta') }}">
                    </div>
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="valor_min_cuc" class="form-control" placeholder="Valor CUC mínimo"
                               value="{{ request('valor_min_cuc') }}">
                    </div>
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="valor_max_cuc" class="form-control" placeholder="Valor CUC máximo"
                               value="{{ request('valor_max_cuc') }}">
                    </div>
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="valor_min_mon_prov" class="form-control" placeholder="Valor Mon. Prov. mínimo"
                               value="{{ request('valor_min_mon_prov') }}">
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="valor_max_mon_prov" class="form-control" placeholder="Valor Mon. Prov. máximo"
                               value="{{ request('valor_max_mon_prov') }}">
                    </div>
                    <div class="col-md-3">
                        <select name="sort_by" class="form-select">
                            <option value="">Ordenar por</option>
                            <option value="Id Ctto" {{ request('sort_by') == 'Id Ctto' ? 'selected' : '' }}>ID</option>
                            <option value="No Ctto" {{ request('sort_by') == 'No Ctto' ? 'selected' : '' }}>No. Contrato</option>
                            <option value="Valor Ctto CUC" {{ request('sort_by') == 'Valor Ctto CUC' ? 'selected' : '' }}>Valor CUC</option>
                            <option value="Valor Ctto Mon Prov" {{ request('sort_by') == 'Valor Ctto Mon Prov' ? 'selected' : '' }}>Valor Mon. Prov.</option>
                            <option value="Fecha Ctto" {{ request('sort_by') == 'Fecha Ctto' ? 'selected' : '' }}>Fecha</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="sort_dir" class="form-select">
                            <option value="desc" {{ request('sort_dir', 'desc') == 'desc' ? 'selected' : '' }}>Descendente</option>
                            <option value="asc" {{ request('sort_dir') == 'asc' ? 'selected' : '' }}>Ascendente</option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('contratos.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
            </form>

            @if($contratos->isEmpty())
                <div class="alert alert-info">No hay contratos registrados.</div>
            @else
                <!-- Formulario para eliminación múltiple (DELETE) -->
                <form id="deleteForm" method="POST" action="{{ route('contratos.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <div class="table-responsive" style="overflow-x: auto;">
                        <table class="table table-bordered table-hover table-sm" style="font-size: 0.9rem;">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="select-all-checkbox">
                                    </th>
                                    <th>ID</th>
                                    <th>No. Contrato</th>
                                    <th>Proveedor</th>
                                    <th>Valor Mon. Prov.</th>
                                    <th>Moneda</th>
                                    <th>Forma de Pago</th>
                                    <th>Valor CUC</th>
                                    <th>Concluido</th>
                                    <th>Observaciones</th>
                                    <th>Cancelado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($contratos as $contrato)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="selected_ids[]" value="{{ $contrato->{'Id Ctto'} }}" class="select-item">
                                        </td>
                                        <td>{{ $contrato->{'Id Ctto'} }}</td>
                                        <td>{{ $contrato->{'No Ctto'} ?? 'N/A' }}</td>
                                        <td>
                                            {{ $contrato->{'Id Proveedor'} }}
                                            @php
                                                $provider = $contrato->provider;
                                            @endphp
                                            @if($provider)
                                                <br><small class="text-muted">{{ $provider->Proveedor }}</small>
                                            @endif
                                        </td>
                                        <td class="text-end">{{ $contrato->{'Valor Ctto Mon Prov'} ? number_format($contrato->{'Valor Ctto Mon Prov'}, 2) : '0.00' }}</td>
                                        <td>
                                            {{ $contrato->{'Id Moneda'} }}
                                            @php
                                                $currency = $contrato->currency;
                                            @endphp
                                            @if($currency)
                                                <br><small class="text-muted">{{ $currency->Moneda }}</small>
                                            @endif
                                        </td>
                                        <td>{{ $contrato->{'Forma de Pago'} ?? 'N/A' }}</td>
                                        <td class="text-end">{{ $contrato->{'Valor Ctto CUC'} ? number_format($contrato->{'Valor Ctto CUC'}, 2) : '0.00' }}</td>
                                        <td>
                                            <span class="badge bg-{{ $contrato->Concluido ? 'success' : 'secondary' }}">
                                                {{ $contrato->Concluido ? 'Sí' : 'No' }}
                                            </span>
                                        </td>
                                        <td>{{ Str::limit($contrato->{'Observaciones Esp'}, 30) }}</td>
                                        <td>
                                            <span class="badge bg-{{ $contrato->Cancelado ? 'danger' : 'secondary' }}">
                                                {{ $contrato->Cancelado ? 'Sí' : 'No' }}
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('contratos.show', $contrato->{'Id Ctto'}) }}" class="btn btn-info btn-sm">Ver</a>
                                                <a href="{{ route('contratos.edit', $contrato->{'Id Ctto'}) }}" class="btn btn-warning btn-sm">Editar</a>
                                                <form action="{{ route('contratos.destroy', $contrato->{'Id Ctto'}) }}" method="POST" style="display:inline-block;">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Está seguro de eliminar este contrato?')">Eliminar</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            @if($contratos->isNotEmpty())
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="4" class="text-end"><strong>Totales:</strong></td>
                                    <td class="text-end">
                                        <strong>{{ number_format($contratos->sum('Valor Ctto Mon Prov'), 2) }}</strong>
                                    </td>
                                    <td></td>
                                    <td></td>
                                    <td class="text-end">
                                        <strong>{{ number_format($contratos->sum('Valor Ctto CUC'), 2) }}</strong>
                                    </td>
                                    <td>
                                        <strong>
                                            @php
                                                $concluidos = $contratos->where('Concluido', 1)->count();
                                                $noConcluidos = $contratos->where('Concluido', 0)->count();
                                            @endphp
                                            Concluidos: {{ $concluidos }}<br>
                                            No concluidos: {{ $noConcluidos }}
                                        </strong>
                                    </td>
                                    <td></td>
                                    <td>
                                        <strong>
                                            @php
                                                $cancelados = $contratos->where('Cancelado', 1)->count();
                                                $noCancelados = $contratos->where('Cancelado', 0)->count();
                                            @endphp
                                            Cancelados: {{ $cancelados }}<br>
                                            No cancelados: {{ $noCancelados }}
                                        </strong>
                                    </td>
                                    <td></td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar los contratos seleccionados?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación corregida -->
                @if($contratos->hasPages())
                    @php 
                        // Preservar todos los parámetros de búsqueda en la paginación
                        $queryParams = request()->all();
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $contratos->firstItem() }}–{{ $contratos->lastItem() }} de {{ $contratos->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <!-- Primera página -->
                                <li class="page-item {{ $contratos->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('contratos.index', $queryParams) }}">« Primera</a>
                                </li>
                                
                                <!-- Página anterior -->
                                <li class="page-item {{ $contratos->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = $contratos->currentPage() - 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('contratos.index', $queryParams) }}">‹</a>
                                </li>
                                
                                <!-- Página actual -->
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $contratos->currentPage() }} de {{ $contratos->lastPage() }}</span>
                                </li>
                                
                                <!-- Página siguiente -->
                                <li class="page-item {{ $contratos->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $contratos->currentPage() + 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('contratos.index', $queryParams) }}">›</a>
                                </li>
                                
                                <!-- Última página -->
                                <li class="page-item {{ $contratos->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $contratos->lastPage();
                                    @endphp
                                    <a class="page-link" href="{{ route('contratos.index', $queryParams) }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('select-all-checkbox');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar selecciones cuando cambian los checkboxes individuales
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportSelectedIds').value = selectedString;
        document.getElementById('pdfSelectedIds').value = selectedString;
        document.getElementById('printSelectedIds').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
});
</script>
@endsection