<!DOCTYPE html>
<html>
<head>
    <title>Asignaciones - PDF</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; }
        .title { font-size: 18px; font-weight: bold; }
        .subtitle { font-size: 14px; color: #666; }
        .filters { margin-bottom: 15px; padding: 10px; background: #f5f5f5; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background-color: #f2f2f2; font-weight: bold; text-align: left; padding: 8px; border: 1px solid #ddd; }
        td { padding: 8px; border: 1px solid #ddd; }
        .text-right { text-align: right; }
        .footer { margin-top: 30px; text-align: right; font-size: 10px; color: #666; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">Listado de Asignaciones</div>
        <div class="subtitle">Fecha de generación: {{ now()->format('d/m/Y H:i:s') }}</div>
    </div>
    
    @if(!empty($filtros))
    <div class="filters">
        <strong>Filtros aplicados:</strong><br>
        @foreach($filtros as $filtro)
        • {{ $filtro }}<br>
        @endforeach
    </div>
    @endif
    
    <table>
        <thead>
            <tr>
                <th>Centro de Balance</th>
                <th>Línea de Crédito</th>
                <th>Fuente de Financiamiento</th>
                <th>Año</th>
                <th class="text-right">Valor</th>
            </tr>
        </thead>
        <tbody>
            @forelse($asignaciones as $asignacion)
            <tr>
                <td>{{ $asignacion->centroBalance?->{'Centro Balance'} ?? '---' }}</td>
                <td>{{ $asignacion->lineaCredito?->{'Linea de Crédito'} ?? '---' }}</td>
                <td>{{ $asignacion->fuenteFinanciamiento?->{'Fuente Financiamiento'} ?? '---' }}</td>
                <td>{{ $asignacion->{'Año Asignacion'} }}</td>
                <td class="text-right">{{ number_format($asignacion->Valor, 2) }}</td>
            </tr>
            @empty
            <tr>
                <td colspan="5" style="text-align: center;">No hay datos para mostrar</td>
            </tr>
            @endforelse
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4" style="text-align: right; font-weight: bold;">Total:</td>
                <td style="text-align: right; font-weight: bold;">
                    {{ number_format($asignaciones->sum('Valor'), 2) }}
                </td>
            </tr>
        </tfoot>
    </table>
    
    <div class="footer">
        Total de registros: {{ $asignaciones->count() }}<br>
        Generado por: {{ auth()->user()->{'Usuario'} ?? 'Sistema' }}
    </div>
</body>
</html>