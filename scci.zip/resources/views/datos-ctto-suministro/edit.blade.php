@extends('layouts.app')

@section('title', 'Editar Contrato Suministro')

@section('content')
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3>Editar Dato de Contrato Suministro</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('datos-ctto-suministro.update', $dato->Id_Supsum) }}">
                @csrf
                @method('PUT')
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="Id_Cto_Suministro" class="form-label">Contrato Suministro</label>
                        <select name="Id_Cto_Suministro" id="Id_Cto_Suministro" class="form-select @error('Id_Cto_Suministro') is-invalid @enderror" required>
                            <option value="">Seleccione un contrato</option>
                            @foreach($contratosSuministro as $contrato)
                                <option value="{{ $contrato->Id_Cto_Suministro }}" {{ $dato->Id_Cto_Suministro == $contrato->Id_Cto_Suministro ? 'selected' : '' }}>{{ $contrato->Descripcion }}</option>
                            @endforeach
                        </select>
                        @error('Id_Cto_Suministro')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-6">
                        <label for="No_Suplemento" class="form-label">No. Suplemento</label>
                        <input type="text" name="No_Suplemento" id="No_Suplemento" class="form-control @error('No_Suplemento') is-invalid @enderror" value="{{ $dato->No_Suplemento }}" required>
                        @error('No_Suplemento')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-6">
                        <label for="Importe_CUC" class="form-label">Importe CUC</label>
                        <input type="number" step="0.01" name="Importe_CUC" id="Importe_CUC" class="form-control @error('Importe_CUC') is-invalid @enderror" value="{{ $dato->Importe_CUC }}" required>
                        @error('Importe_CUC')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-6">
                        <label for="Importe_CUP" class="form-label">Importe CUP</label>
                        <input type="number" step="0.01" name="Importe_CUP" id="Importe_CUP" class="form-control @error('Importe_CUP') is-invalid @enderror" value="{{ $dato->Importe_CUP }}" required>
                        @error('Importe_CUP')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-6">
                        <label for="Fecha_firma_Ctto" class="form-label">Fecha Firma</label>
                        <input type="date" name="Fecha_firma_Ctto" id="Fecha_firma_Ctto" class="form-control @error('Fecha_firma_Ctto') is-invalid @enderror" value="{{ $dato->Fecha_firma_Ctto->format('Y-m-d') }}" required>
                        @error('Fecha_firma_Ctto')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                <div class="mt-4">
                    <a href="{{ route('datos-ctto-suministro.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection