<?php

$modules = [
    'AsigPorSolic' => [
        'table' => 'Asig por solic',
        'fields' => 'Id_Solicitud:integer:required,Año_finan:integer:required,Asig_MCUC:float:nullable'
    ],
    'Carga' => [
        'table' => 'Cargas',
        'fields' => 'Id_Tipo_Carga:integer:required,Id_Embarque:integer:required,Cantidad:float:nullable,Real:float:nullable'
    ],
    'Embarque' => [
        'table' => 'Embarques',
        'fields' => 'Id_SOE:integer:nullable,ETA:date:nullable,Fecha_Ent_s_Ctto:date:nullable,Fecha_real_arribo:date:nullable,Tipo_Embarque:string:nullable'
    ],
    'Facturacion' => [
        'table' => 'Facturacion',
        'fields' => 'Id_embarque:integer:nullable,No_Factura:string:nullable,Fecha_Factura:string:nullable,Valor_CUC:float:nullable,Valor_CUP:float:nullable'
    ],
    'DescripcionContrato' => [
        'table' => 'Descripcion Contrato',
        'fields' => 'Id_Solicitud:integer:nullable,Id_Ctto:integer:nullable,Producto:string:nullable,UM:string:nullable,Cantidad:float:nullable,Precio_CUC:float:nullable'
    ],
    'DescripcionSolicitud' => [
        'table' => 'Descripcion Solicitud',
        'fields' => 'Id_Solicitud:integer:nullable,Producto:string:nullable,UM:string:nullable,Cantidad:float:nullable,Precio_CUC:float:nullable'
    ],
    'DITEC' => [
        'table' => 'DITEC',
        'fields' => 'No_DITEC:string:nullable,Renueva:string:nullable,Fecha_Otorgamiento:date:nullable,Producto:string:nullable,Fabricante:string:nullable'
    ],
    'DatosSOE' => [
        'table' => 'Datos SOE',
        'fields' => 'Id_Ctto:integer:required,Id_Solicitud:integer:nullable,No_Suplemento:integer:nullable,Fecha_Comite:date:nullable,No_Acta:string:nullable'
    ],
    'DatosCC' => [
        'table' => 'Datos CC',
        'fields' => 'Id_SOE:integer:required,No_CC:string:nullable,Id_Moneda:integer:nullable,Valor_CC:float:nullable,Id_Capacidad:integer:nullable'
    ],
    'DatosCttoSuministro' => [
        'table' => 'Datos Ctto suministro',
        'fields' => 'Id_Cttosuministro:integer:nullable,No_Suplemento:integer:nullable,Fecha_firma_Ctto:date:nullable,Importe_CUC:float:nullable,Importe_CUP:float:nullable'
    ],
    'DatosPersonalExtranjero' => [
        'table' => 'Datos Personal Extranjero',
        'fields' => 'Id_proveedor:integer:nullable,Funcionario_extranjero:string:nullable,Telef:string:nullable,Email:string:nullable,Activo:boolean:nullable'
    ],
    'DatosPersonalCubano' => [
        'table' => 'Datos Personal Cubano',
        'fields' => 'Id_proveedor:integer:nullable,Funcionario_cubano:string:nullable,telef:string:nullable,Email:string:nullable,Carnet_Acorec:string:nullable'
    ],
    'CttoCVIvsCttoSum' => [
        'table' => 'CttoCVI vs CttoSum',
        'fields' => 'Id_SOE:integer:nullable,Id_Ctto_Sum:integer:nullable'
    ],
    'DatosBancosProveedores' => [
        'table' => 'Datos Bancos Proveedores',
        'fields' => 'Id_proveedor:integer:required,Id_Banco:integer:required,Numero_Cuenta:string:nullable,Id_Moneda:integer:nullable'
    ],
    'ProveedoresvsMarcas' => [
        'table' => 'Proveedores vs Marcas',
        'fields' => 'Id_proveedor:integer:required,Marca:string:nullable,Productos:string:nullable,Vencimiento:date:nullable'
    ],
    'ProveedoresvsEmpImp' => [
        'table' => 'Proveedores vs Emp Imp',
        'fields' => 'Id_proveedor:integer:required,Id_Emp_Imp:integer:required'
    ],
    'ProveedoresparaSalirAlMercado' => [
        'table' => 'Proveedores para Salir al Mercado',
        'fields' => 'Usuario:string:nullable,No_Solicitud:integer:nullable,añosol:integer:nullable,Tipo_Producto:string:nullable,Proveedor:string:nullable'
    ],
    'SalidasAlMercado' => [
        'table' => 'Salidas al Mercado',
        'fields' => 'No_Sal_Mer:integer:required,Id_Especialista:integer:required,Año_Sal_Mer:integer:required,Fecha_sal_Mer:date:nullable,Fecha_pri_oferta:date:nullable'
    ],
    'SolCtto' => [
        'table' => 'sol ctto',
        'fields' => 'Id_Solicitud:integer:nullable,Id_Ctto:integer:nullable,Id_SOE:integer:nullable,Observaciones:string:nullable,Id_Clasificacion:integer:nullable'
    ],
    'SolicitudesProveedores' => [
        'table' => 'Solicitudes Proveedores',
        'fields' => 'Id_Solicitud:integer:nullable,Id_Proveedor:integer:nullable,Respuesta:boolean:nullable,Fecha_Oferta:date:nullable,Selecionado:boolean:nullable'
    ],
    'TipoProductovsProveedor' => [
        'table' => 'Tipo Producto vs Proveedor',
        'fields' => 'Id_Tipo_Producto:integer:required,Id_Proveedor:integer:required,Datos:string:nullable'
    ],
    'PaisesvsProveedores' => [
        'table' => 'Paises vs Proveedores',
        'fields' => 'Id_proveedor:integer:required,Id_Pais:integer:required,Oficina:boolean:nullable'
    ],
    'ProveedorvsDITEC' => [
        'table' => 'Proveedor vs DITEC',
        'fields' => 'Id_DITEC:integer:required,Id_Proveedor:integer:required'
    ],
    'PagosPorElCliente' => [
        'table' => 'Pagos por el Cliente',
        'fields' => 'Id_Cttosuministro:integer:nullable,No_Elemento_Pago:string:nullable,Valor_MN:float:nullable,Valor_CUC:float:nullable,Observaciones:string:nullable'
    ],
    'Reclamaciones' => [
        'table' => 'Reclamaciones',
        'fields' => 'Id_embarque:integer:nullable,Descripcion:string:nullable'
    ],
    'ControlDeUsuarios' => [
        'table' => 'Control de Usuarios',
        'fields' => 'PDW:string:nullable,Entrada:datetime:nullable,Salida:datetime:nullable'
    ],
];

foreach ($modules as $modelName => $config) {
    $table = $config['table'];
    $fields = $config['fields'];
    
    $command = "php artisan make:module {$modelName} --table=\"{$table}\" --fields=\"{$fields}\"";
    
    echo "Generando: {$modelName}\n";
    echo "Comando: {$command}\n";
    
    // Execute the command
    exec($command, $output, $returnVar);
    
    if ($returnVar === 0) {
        echo "✓ {$modelName} generado correctamente\n";
    } else {
        echo "✗ Error generando {$modelName}\n";
        print_r($output);
    }
    
    echo "----------------------------------------\n";
}

echo "¡Generación completada!\n";