<?php

namespace App\Exports;

use App\Models\Contrato;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ContratosExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $contratos;

    public function __construct($contratos)
    {
        $this->contratos = $contratos;
    }

    public function collection()
    {
        return $this->contratos;
    }

    public function headings(): array
    {
        return [
            'ID',
            'No. Contrato',
            'Proveedor',
            'Valor (Mon. Prov.)',
            'Valor (CUC)',
            'Moneda',
            'Forma de Pago',
            'Concluido',
            'Cancelado',
            'Observaciones',
        ];
    }

    public function map($contrato): array
    {
        return [
            $contrato->{'Id Ctto'},
            $contrato->{'No Ctto'} ?? '',
            $contrato->provider->Proveedor ?? '',
            $contrato->{'Valor Ctto Mon Prov'} ?? 0,
            $contrato->{'Valor Ctto CUC'} ?? 0,
            $contrato->currency->Moneda ?? '',
            $contrato->{'Forma de Pago'} ?? '',
            $contrato->Concluido ? 'Sí' : 'No',
            $contrato->Cancelado ? 'Sí' : 'No',
            $contrato->{'Observaciones Esp'} ?? '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}