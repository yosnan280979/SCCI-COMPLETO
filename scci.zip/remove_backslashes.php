<?php
echo "=== Eliminando barras invertidas de rutas ===\n\n";

$viewsDir = 'resources/views/';
$filesFixed = 0;

$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($viewsDir),
    RecursiveIteratorIterator::SELF_FIRST
);

foreach ($iterator as $file) {
    if ($file->isFile() && $file->getExtension() === 'php') {
        $content = file_get_contents($file->getPathname());
        $originalContent = $content;
        
        // Eliminar barras invertidas antes de puntos en rutas
        $content = preg_replace('/nomencladores\\\\./', 'nomencladores.', $content);
        $content = preg_replace('/proveedores\\\\./', 'proveedores.', $content);
        $content = preg_replace('/tipo-proveedor\\\\./', 'tipo-proveedor.', $content);
        $content = preg_replace('/especialistas\\\\./', 'especialistas.', $content);
        $content = preg_replace('/tipos-usuario\\\\./', 'tipos-usuario.', $content);
        $content = preg_replace('/clientes\\\\./', 'clientes.', $content);
        
        // Eliminar barras invertidas en funciones route()
        $content = preg_replace("/route\('([^']*?)\\\\.([^']*?)'\)/", "route('$1.$2')", $content);
        $content = preg_replace('/route\("([^"]*?)\\\\.([^"]*?)"\)/', 'route("$1.$2")', $content);
        
        if ($content !== $originalContent) {
            file_put_contents($file->getPathname(), $content);
            echo "✓ Corregido: " . $file->getPathname() . "\n";
            $filesFixed++;
        }
    }
}

echo "\n=== Resumen ===\n";
echo "Archivos corregidos: $filesFixed\n";
echo "¡Barras invertidas eliminadas!\n";
