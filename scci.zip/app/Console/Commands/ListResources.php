<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;

class ListResources extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'list:resources';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Lista todos los modelos, controladores, middlewares, policies, jobs y vistas de la aplicación.';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info('=== Listando Modelos ===');
        $this->listPhpClasses(app_path('Models'), 'App\\Models');

        $this->newLine(2);
        $this->info('=== Listando Controladores ===');
        $this->listPhpClasses(app_path('Http/Controllers'), 'App\\Http\\Controllers');

        $this->newLine(2);
        $this->info('=== Listando Middlewares ===');
        $this->listPhpClasses(app_path('Http/Middleware'), 'App\\Http\\Middleware');

        $this->newLine(2);
        $this->info('=== Listando Policies ===');
        $this->listPhpClasses(app_path('Policies'), 'App\\Policies');

        $this->newLine(2);
        $this->info('=== Listando Jobs ===');
        $this->listPhpClasses(app_path('Jobs'), 'App\\Jobs');

        $this->newLine(2);
        $this->info('=== Listando Vistas (Blade) ===');
        $this->listBladeViews();

        $this->newLine();
        $this->info('Listado completado.');

        return Command::SUCCESS;
    }

    /**
     * Lista las clases PHP en un directorio específico y las convierte en namespaces.
     *
     * @param string $path
     * @param string $baseNamespace
     */
    protected function listPhpClasses(string $path, string $baseNamespace)
    {
        if (!File::exists($path)) {
            $this->error("El directorio {$path} no existe.");
            return;
        }

        $files = File::allFiles($path);

        if (empty($files)) {
            $this->line("No se encontraron archivos en {$path}.");
            return;
        }

        $classes = [];

        foreach ($files as $file) {
            $relativePath = $file->getRelativePathname();
            $class = str_replace(
                ['/', '.php'],
                ['\\', ''],
                $baseNamespace . '\\' . $relativePath
            );

            if (class_exists($class)) {
                $classes[] = [$class];
            }
        }

        if (!empty($classes)) {
            $this->table(['Clase'], $classes);
        }
    }

    /**
     * Lista todas las vistas Blade y su nombre de referencia.
     */
    protected function listBladeViews()
    {
        $viewsPath = resource_path('views');

        if (!File::exists($viewsPath)) {
            $this->error("El directorio de vistas {$viewsPath} no existe.");
            return;
        }

        $files = File::allFiles($viewsPath);

        if (empty($files)) {
            $this->line("No se encontraron vistas en {$viewsPath}.");
            return;
        }

        $views = [];

        foreach ($files as $file) {
            if (str_ends_with($file->getFilename(), '.blade.php')) {
                $relativePath = $file->getRelativePathname();
                $viewName = str_replace('/', '.', substr($relativePath, 0, -strlen('.blade.php')));
                $views[] = [$viewName];
            }
        }

        if (!empty($views)) {
            $this->table(['Vista'], $views);
        }
    }
}
