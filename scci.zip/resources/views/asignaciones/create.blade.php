@extends('layouts.app')

@section('title', 'Crear Asignación')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Crear Nueva Asignación</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('asignaciones.store') }}" method="POST">
                @csrf
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Id_Centro_Balance" class="form-label">Centro de Balance *</label>
                        <select class="form-select" id="Id_Centro_Balance" name="Id_Centro_Balance" required>
                            <option value="">Seleccionar Centro de Balance</option>
                            @foreach($centrosBalance as $centro)
                                <option value="{{ $centro->{'Id Centro Balnce'} }}" {{ old('Id_Centro_Balance') == $centro->{'Id Centro Balnce'} ? 'selected' : '' }}>
                                    {{ $centro->{'Centro Balance'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="Id_Lineacredito" class="form-label">Línea de Crédito *</label>
                        <select class="form-select" id="Id_Lineacredito" name="Id_Lineacredito" required>
                            <option value="">Seleccionar Línea de Crédito</option>
                            @foreach($lineasCredito as $linea)
                                <option value="{{ $linea->{'Id Lineacredito'} }}" {{ old('Id_Lineacredito') == $linea->{'Id Lineacredito'} ? 'selected' : '' }}>
                                    {{ $linea->{'Linea de Crédito'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Id_Fuentafinan" class="form-label">Fuente de Financiamiento *</label>
                        <select class="form-select" id="Id_Fuentafinan" name="Id_Fuentafinan" required>
                            <option value="">Seleccionar Fuente de Financiamiento</option>
                            @foreach($fuentesFinanciamiento as $fuente)
                                <option value="{{ $fuente->{'Id Fuentefinan'} }}" {{ old('Id_Fuentafinan') == $fuente->{'Id Fuentefinan'} ? 'selected' : '' }}>
                                    {{ $fuente->{'Fuente Financiamiento'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="Año_Asignacion" class="form-label">Año *</label>
                        <select class="form-select" id="Año_Asignacion" name="Año_Asignacion" required>
                            <option value="">Seleccionar Año</option>
                            @foreach($anios as $anio)
                                <option value="{{ $anio }}" {{ old('Año_Asignacion') == $anio ? 'selected' : '' }}>
                                    {{ $anio }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="Valor" class="form-label">Valor *</label>
                        <input type="number" step="0.01" class="form-control" id="Valor" name="Valor" 
                               value="{{ old('Valor') }}" required min="0">
                    </div>
                </div>
                
                <div class="d-flex justify-content-between mt-4">
                    <a href="{{ route('asignaciones.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar Asignación</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection