<?php

namespace App\Exports;

use App\Models\Banco;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class BancosExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $bancos;

    public function __construct($bancos)
    {
        $this->bancos = $bancos;
    }

    public function collection()
    {
        return $this->bancos;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Banco',
            'País',
        ];
    }

    public function map($banco): array
    {
        return [
            $banco->{'Id Banco'},
            $banco->Banco,
            $banco->pais ? $banco->pais->{'País'} : '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}