// app/Console/Kernel.php

protected $commands = [
    \App\Console\Commands\ListResources::class,
    \App\Console\Commands\GenerateModule::class,
    \App\Console\Commands\AssignDefaultPermissionsCommand::class,
];