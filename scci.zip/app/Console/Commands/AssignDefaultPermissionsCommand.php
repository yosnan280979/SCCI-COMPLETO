<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Area;
use App\Models\Module;
use App\Models\Permission;

class AssignDefaultPermissionsCommand extends Command
{
    protected $signature = 'permissions:assign-defaults';
    protected $description = 'Asigna permisos por defecto a todas las áreas';

    public function handle()
    {
        $areas = Area::all();
        $modules = Module::all();

        $permissionsByArea = [
            'Informatica' => [
                '*' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => true]
            ],
            'Dirección' => [
                'dashboard' => ['view' => true],
                'solicitudes' => ['view' => true, 'create' => true, 'edit' => true],
                'contratos' => ['view' => true, 'create' => true, 'edit' => true],
                'asignaciones' => ['view' => true],
                'logistica' => ['view' => true],
                'proveedores' => ['view' => true],
                'ditec' => ['view' => true],
                'finanzas' => ['view' => true],
                'operaciones' => ['view' => true],
                'organizacion' => ['view' => true],
            ],
            'Comerciales' => [
                'dashboard' => ['view' => true],
                'solicitudes' => ['view' => true, 'create' => true],
                'contratos' => ['view' => true, 'create' => true],
                'logistica' => ['view' => true],
                'proveedores' => ['view' => true],
                'ditec' => ['view' => true],
            ],
            'Dir. UEB Importaciones' => [
                'dashboard' => ['view' => true],
                'solicitudes' => ['view' => true, 'create' => true],
                'contratos' => ['view' => true, 'create' => true],
                'logistica' => ['view' => true, 'create' => true, 'edit' => true],
                'proveedores' => ['view' => true, 'create' => true],
                'ditec' => ['view' => true],
            ],
            'Política Comercial' => [
                'dashboard' => ['view' => true],
                'solicitudes' => ['view' => true],
                'contratos' => ['view' => true],
                'proveedores' => ['view' => true],
            ],
            'SOE' => [
                'dashboard' => ['view' => true],
                'solicitudes' => ['view' => true, 'create' => true],
                'contratos' => ['view' => true, 'create' => true],
                'logistica' => ['view' => true],
            ],
            'Control Financiamientos' => [
                'dashboard' => ['view' => true],
                'solicitudes' => ['view' => true],
                'contratos' => ['view' => true],
                'asignaciones' => ['view' => true, 'create' => true, 'edit' => true],
                'finanzas' => ['view' => true, 'create' => true, 'edit' => true],
            ],
            'Juridico' => [
                'dashboard' => ['view' => true],
                'solicitudes' => ['view' => true],
                'contratos' => ['view' => true, 'edit' => true],
                'proveedores' => ['view' => true],
            ],
            'Marketing' => [
                'dashboard' => ['view' => true],
                'solicitudes' => ['view' => true],
                'contratos' => ['view' => true],
                'proveedores' => ['view' => true],
                'operaciones' => ['view' => true],
            ],
            'Otras Areas' => [
                'dashboard' => ['view' => true],
            ],
            'Economia' => [
                'dashboard' => ['view' => true],
                'solicitudes' => ['view' => true],
                'contratos' => ['view' => true],
                'asignaciones' => ['view' => true],
                'finanzas' => ['view' => true, 'create' => true, 'edit' => true],
            ],
            'Calidad' => [
                'dashboard' => ['view' => true],
                'solicitudes' => ['view' => true],
                'contratos' => ['view' => true],
                'logistica' => ['view' => true],
                'proveedores' => ['view' => true],
            ],
            'Exportaciones' => [
                'dashboard' => ['view' => true],
                'solicitudes' => ['view' => true],
                'contratos' => ['view' => true],
                'logistica' => ['view' => true],
                'proveedores' => ['view' => true],
                'operaciones' => ['view' => true],
            ],
        ];

        $this->info('Asignando permisos por defecto...');

        foreach ($areas as $area) {
            $areaPermissions = $permissionsByArea[$area->Area] ?? [];

            foreach ($modules as $module) {
                $modulePermissions = $areaPermissions[$module->slug] ?? 
                                   (isset($areaPermissions['*']) ? $areaPermissions['*'] : 
                                   ['view' => false, 'create' => false, 'edit' => false, 'delete' => false]);

                Permission::updateOrCreate(
                    [
                        'area_id' => $area->id,
                        'module_id' => $module->id,
                    ],
                    $modulePermissions
                );
            }

            $this->info("Permisos asignados para {$area->Area}");
        }

        $this->info('¡Permisos asignados exitosamente!');
    }
}