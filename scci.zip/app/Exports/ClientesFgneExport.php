<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\WithTitle;
use Illuminate\Contracts\View\View;

class ClientesFgneExport implements FromView, WithTitle
{
    protected $items;

    /**
     * Constructor para recibir los datos filtrados desde el controlador
     */
    public function __construct($items)
    {
        $this->items = $items;
    }

    /**
     * @return View
     */
    public function view(): View
    {
        // Llama a la vista 'clientes-fgne.export' que creamos anteriormente
        return view('clientes-fgne.export', [
            'items' => $this->items
        ]);
    }

    /**
     * @return string
     */
    public function title(): string
    {
        return 'Listado Clientes FGNE';
    }
}