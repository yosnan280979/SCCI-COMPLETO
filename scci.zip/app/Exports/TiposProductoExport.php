<?php

namespace App\Exports;

use App\Models\TipoProducto;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class TiposProductoExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $tiposProducto;

    public function __construct($tiposProducto)
    {
        $this->tiposProducto = $tiposProducto;
    }

    public function collection()
    {
        return $this->tiposProducto;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Tipo de Producto',
            'Siglas',
            'Tipo Producto General',
        ];
    }

    public function map($tipoProducto): array
    {
        return [
            $tipoProducto->{'Id Tipo Producto'},
            $tipoProducto->{'Tipo Producto'},
            $tipoProducto->Siglas ?? 'N/A',
            $tipoProducto->tipoProductoGeneral?->{'Tipo Prod general'} ?? 'N/A',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}