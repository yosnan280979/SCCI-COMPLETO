<?php

namespace App\Exports;

use App\Models\ProveedorSalirMercado;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ProveedorSalirMercadoExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function collection()
    {
        return $this->items;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Usuario',
            'No Solicitud',
            'Año Solicitud',
            'Tipo Producto',
            'Proveedor',
            'Correo Cuba',
            'Teléfono Cuba',
            'Correo Cmatriz',
            'Teléfono Cmatriz',
            'Momento',
        ];
    }

    public function map($item): array
    {
        return [
            $item->Id ?? $item->id,
            $item->Usuario,
            $item->{'No Solicitud'} ?? $item->No_Solicitud,
            $item->añosol,
            $item->{'Tipo Producto'} ?? $item->Tipo_Producto,
            $item->Proveedor,
            $item->datosProveedor->{'Correo Cuba'} ?? 'N/A',
            $item->datosProveedor->{'Telef Cuba'} ?? 'N/A',
            $item->datosProveedor->{'Correo Cmatriz'} ?? 'N/A',
            $item->datosProveedor->{'Telef Cmatriz'} ?? 'N/A',
            $item->Momento ? \Carbon\Carbon::parse($item->Momento)->format('d/m/Y') : '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}