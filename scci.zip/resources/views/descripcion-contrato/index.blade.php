@extends('layouts.app')

@section('title', 'Descripción de Contratos')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Descripción de Contratos</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('descripcion-contrato.create') }}" class="btn btn-primary btn-sm">➕ Crear Descripción</a>
                
                <!-- Formularios independientes para exportación (GET) -->
                <form method="GET" action="{{ route('descripcion-contrato.export.excel') }}" style="display: inline">
                    <input type="hidden" name="selected" id="exportExcelSelected" value="">
                    <!-- Pasar filtros -->
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="Id_Solicitud" value="{{ request('Id_Solicitud') }}">
                    <input type="hidden" name="Id_Ctto" value="{{ request('Id_Ctto') }}">
                    <input type="hidden" name="UM" value="{{ request('UM') }}">
                    <input type="hidden" name="precio_min" value="{{ request('precio_min') }}">
                    <input type="hidden" name="precio_max" value="{{ request('precio_max') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                
                <form method="GET" action="{{ route('descripcion-contrato.export.pdf') }}" style="display: inline">
                    <input type="hidden" name="selected" id="exportPdfSelected" value="">
                    <!-- Pasar filtros -->
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="Id_Solicitud" value="{{ request('Id_Solicitud') }}">
                    <input type="hidden" name="Id_Ctto" value="{{ request('Id_Ctto') }}">
                    <input type="hidden" name="UM" value="{{ request('UM') }}">
                    <input type="hidden" name="precio_min" value="{{ request('precio_min') }}">
                    <input type="hidden" name="precio_max" value="{{ request('precio_max') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                
                <form method="GET" action="{{ route('descripcion-contrato.print') }}" style="display: inline" target="_blank">
                    <input type="hidden" name="selected" id="printSelected" value="">
                    <!-- Pasar filtros -->
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="Id_Solicitud" value="{{ request('Id_Solicitud') }}">
                    <input type="hidden" name="Id_Ctto" value="{{ request('Id_Ctto') }}">
                    <input type="hidden" name="UM" value="{{ request('UM') }}">
                    <input type="hidden" name="precio_min" value="{{ request('precio_min') }}">
                    <input type="hidden" name="precio_max" value="{{ request('precio_max') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Buscador con filtros -->
            <form method="GET" action="{{ route('descripcion-contrato.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" name="search" value="{{ request('search') }}" class="form-control" placeholder="Buscar (Producto, UM...)">
                    </div>
                    <div class="col-md-3">
                        <select name="Id_Solicitud" class="form-select">
                            <option value="">Solicitud</option>
                            @if(isset($solicitudes) && $solicitudes->count() > 0)
                                @foreach($solicitudes as $solicitud)
                                    <option value="{{ $solicitud->{'Id Solicitud'} }}" {{ request('Id_Solicitud') == $solicitud->{'Id Solicitud'} ? 'selected' : '' }}>
                                        {{ $solicitud->{'No Solicitud'} }} ({{ $solicitud->{'Id Solicitud'} }})
                                    </option>
                                @endforeach
                            @else
                                <option value="">No hay solicitudes disponibles</option>
                            @endif
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="Id_Ctto" class="form-select">
                            <option value="">Contrato</option>
                            @if(isset($contratos) && $contratos->count() > 0)
                                @foreach($contratos as $contrato)
                                    <option value="{{ $contrato->{'Id Ctto'} }}" {{ request('Id_Ctto') == $contrato->{'Id Ctto'} ? 'selected' : '' }}>
                                        {{ $contrato->{'No Ctto'} }} ({{ $contrato->{'Id Ctto'} }})
                                    </option>
                                @endforeach
                            @else
                                <option value="">No hay contratos disponibles</option>
                            @endif
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="UM" class="form-select">
                            <option value="">Unidad de Medida</option>
                            @if(isset($unidadesMedida) && $unidadesMedida->count() > 0)
                                @foreach($unidadesMedida as $um)
                                    <option value="{{ $um->UM }}" {{ request('UM') == $um->UM ? 'selected' : '' }}>
                                        {{ $um->UM }}
                                    </option>
                                @endforeach
                            @else
                                <option value="">No hay unidades disponibles</option>
                            @endif
                        </select>
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="precio_min" value="{{ request('precio_min') }}" class="form-control" placeholder="Precio mínimo">
                    </div>
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="precio_max" value="{{ request('precio_max') }}" class="form-control" placeholder="Precio máximo">
                    </div>
                    <div class="col-md-3">
                        <select name="sort_by" class="form-select">
                            <option value="">Ordenar por</option>
                            <option value="Id" {{ request('sort_by') == 'Id' ? 'selected' : '' }}>
                                ID
                            </option>
                            <option value="Id_Solicitud" {{ request('sort_by') == 'Id_Solicitud' ? 'selected' : '' }}>
                                Solicitud
                            </option>
                            <option value="Id_Ctto" {{ request('sort_by') == 'Id_Ctto' ? 'selected' : '' }}>
                                Contrato
                            </option>
                            <option value="Producto" {{ request('sort_by') == 'Producto' ? 'selected' : '' }}>
                                Producto
                            </option>
                            <option value="Cantidad" {{ request('sort_by') == 'Cantidad' ? 'selected' : '' }}>
                                Cantidad
                            </option>
                            <option value="Precio CUC" {{ request('sort_by') == 'Precio CUC' ? 'selected' : '' }}>
                                Precio CUC
                            </option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="sort_dir" class="form-select">
                            <option value="desc" {{ request('sort_dir', 'desc') == 'desc' ? 'selected' : '' }}>
                                Descendente
                            </option>
                            <option value="asc" {{ request('sort_dir') == 'asc' ? 'selected' : '' }}>
                                Ascendente
                            </option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('descripcion-contrato.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
            </form>

            @if($descripcionContratos->isEmpty())
                <div class="alert alert-info">No hay descripciones de contratos registradas.</div>
            @else
                <!-- Formulario para eliminación múltiple (DELETE) -->
                <form id="deleteForm" method="POST" action="{{ route('descripcion-contrato.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-sm">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="selectAll">
                                    </th>
                                    <th>
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Id';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Id' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('descripcion-contrato.index', $queryParams) }}">
                                            ID
                                            @if(request('sort_by') == 'Id')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Id_Solicitud';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Id_Solicitud' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('descripcion-contrato.index', $queryParams) }}">
                                            Solicitud
                                            @if(request('sort_by') == 'Id_Solicitud')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Id_Ctto';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Id_Ctto' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('descripcion-contrato.index', $queryParams) }}">
                                            Contrato
                                            @if(request('sort_by') == 'Id_Ctto')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Producto';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Producto' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('descripcion-contrato.index', $queryParams) }}">
                                            Producto
                                            @if(request('sort_by') == 'Producto')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Cantidad';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Cantidad' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('descripcion-contrato.index', $queryParams) }}">
                                            Cantidad
                                            @if(request('sort_by') == 'Cantidad')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>UM</th>
                                    <th>
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Precio CUC';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Precio CUC' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('descripcion-contrato.index', $queryParams) }}">
                                            Precio CUC
                                            @if(request('sort_by') == 'Precio CUC')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>Moneda</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($descripcionContratos as $item)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="ids[]" value="{{ $item->Id ?? $item->id }}" class="select-item">
                                        </td>
                                        <td>{{ $item->Id ?? $item->id }}</td>
                                        <td>
                                            @if($item->solicitud)
                                                {{ $item->solicitud->{'No Solicitud'} }} ({{ $item->{'Id Solicitud'} }})
                                            @else
                                                N/A
                                            @endif
                                        </td>
                                        <td>
                                            @if($item->contrato)
                                                {{ $item->contrato->{'No Ctto'} }} ({{ $item->{'Id Ctto'} }})
                                            @else
                                                N/A
                                            @endif
                                        </td>
                                        <td>{{ $item->Producto ?? 'N/A' }}</td>
                                        <td>{{ $item->Cantidad ? number_format($item->Cantidad, 2) : '0.00' }}</td>
                                        <td>{{ $item->UM ?? 'N/A' }}</td>
                                        <td>
                                            @if($item->{'Precio CUC'})
                                                ${{ number_format($item->{'Precio CUC'}, 2) }}
                                            @else
                                                $0.00
                                            @endif
                                        </td>
                                        <td>{{ $item->moneda->Moneda ?? 'N/A' }}</td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('descripcion-contrato.show', $item->Id ?? $item->id) }}" class="btn btn-info btn-sm">Ver</a>
                                                <a href="{{ route('descripcion-contrato.edit', $item->Id ?? $item->id) }}" class="btn btn-warning btn-sm">Editar</a>
                                                <form action="{{ route('descripcion-contrato.destroy', $item->Id ?? $item->id) }}" method="POST" style="display:inline-block;">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Está seguro?')">Eliminar</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            @if($descripcionContratos->isNotEmpty())
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="5" class="text-end"><strong>Totales:</strong></td>
                                    <td><strong>{{ $descripcionContratos->sum('Cantidad') }}</strong></td>
                                    <td></td>
                                    <td>
                                        <strong>
                                            ${{ number_format($descripcionContratos->sum('Precio CUC'), 2) }}
                                        </strong>
                                    </td>
                                    <td colspan="2"></td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar los registros seleccionados?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación -->
                @if($descripcionContratos->hasPages())
                    @php 
                        $queryParams = request()->all();
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $descripcionContratos->firstItem() }}–{{ $descripcionContratos->lastItem() }} de {{ $descripcionContratos->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <li class="page-item {{ $descripcionContratos->onFirstPage() ? 'disabled' : '' }}">
                                    @php $queryParams['page'] = 1; @endphp
                                    <a class="page-link" href="{{ route('descripcion-contrato.index', $queryParams) }}">« Primera</a>
                                </li>
                                <li class="page-item {{ $descripcionContratos->onFirstPage() ? 'disabled' : '' }}">
                                    @php $queryParams['page'] = $descripcionContratos->currentPage() - 1; @endphp
                                    <a class="page-link" href="{{ route('descripcion-contrato.index', $queryParams) }}">‹</a>
                                </li>
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $descripcionContratos->currentPage() }} de {{ $descripcionContratos->lastPage() }}</span>
                                </li>
                                <li class="page-item {{ $descripcionContratos->hasMorePages() ? '' : 'disabled' }}">
                                    @php $queryParams['page'] = $descripcionContratos->currentPage() + 1; @endphp
                                    <a class="page-link" href="{{ route('descripcion-contrato.index', $queryParams) }}">›</a>
                                </li>
                                <li class="page-item {{ $descripcionContratos->hasMorePages() ? '' : 'disabled' }}">
                                    @php $queryParams['page'] = $descripcionContratos->lastPage(); @endphp
                                    <a class="page-link" href="{{ route('descripcion-contrato.index', $queryParams) }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar exportSelected cuando cambian las selecciones
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportExcelSelected').value = selectedString;
        document.getElementById('exportPdfSelected').value = selectedString;
        document.getElementById('printSelected').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
});
</script>
@endsection