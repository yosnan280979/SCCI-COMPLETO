<!DOCTYPE html>
<html>
<head>
    <title>Contratos - Impresión</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; }
        .title { font-size: 18px; font-weight: bold; }
        .subtitle { font-size: 14px; color: #666; }
        .filters { margin-bottom: 15px; padding: 10px; background: #f5f5f5; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background-color: #f2f2f2; font-weight: bold; text-align: left; padding: 8px; border: 1px solid #ddd; }
        td { padding: 8px; border: 1px solid #ddd; font-size: 11px; }
        .footer { margin-top: 30px; text-align: right; font-size: 10px; color: #666; }
        .text-end { text-align: right; }
        .text-center { text-align: center; }
        .badge { padding: 3px 8px; border-radius: 3px; font-size: 11px; display: inline-block; }
        .badge-success { background-color: #d4edda; color: #155724; }
        .badge-warning { background-color: #fff3cd; color: #856404; }
        .badge-danger { background-color: #f8d7da; color: #721c24; }
        .badge-secondary { background-color: #e2e3e5; color: #383d41; }
        @media print {
            .no-print { display: none; }
            .page-break { page-break-before: always; }
            body { font-size: 11px; }
            table { font-size: 10px; }
        }
        .page-break { page-break-after: always; }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">
            🖨️ Imprimir
        </button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #6c757d; color: white; border: none; border-radius: 5px; cursor: pointer;">
            ✖️ Cerrar
        </button>
    </div>
    
    <div class="header">
        <div class="title">Listado de Contratos</div>
        <div class="subtitle">Fecha de generación: {{ now()->format('d/m/Y H:i:s') }}</div>
        <div class="subtitle">Total de registros: {{ $contratos->count() }}</div>
    </div>
    
    @if(!empty($filtros))
    <div class="filters">
        <strong>Filtros aplicados:</strong><br>
        @foreach($filtros as $filtro)
        • {{ $filtro }}<br>
        @endforeach
    </div>
    @endif
    
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>No. Contrato</th>
                <th>Proveedor</th>
                <th>Valor Mon. Prov.</th>
                <th>Moneda</th>
                <th>Forma de Pago</th>
                <th>Valor CUC</th>
                <th>Concluido</th>
                <th>Observaciones</th>
                <th>Cancelado</th>
            </tr>
        </thead>
        <tbody>
            @forelse($contratos as $contrato)
            <tr>
                <td>{{ $contrato->{'Id Ctto'} }}</td>
                <td>{{ $contrato->{'No Ctto'} ?? 'N/A' }}</td>
                <td>
                    {{ $contrato->{'Id Proveedor'} }}
                    @php
                        $provider = $contrato->provider;
                    @endphp
                    @if($provider)
                        <br><small style="font-size: 10px; color: #666;">{{ $provider->Proveedor }}</small>
                    @endif
                </td>
                <td class="text-end">{{ $contrato->{'Valor Ctto Mon Prov'} ? number_format($contrato->{'Valor Ctto Mon Prov'}, 2) : '0.00' }}</td>
                <td>
                    {{ $contrato->{'Id Moneda'} }}
                    @php
                        $currency = $contrato->currency;
                    @endphp
                    @if($currency)
                        <br><small style="font-size: 10px; color: #666;">{{ $currency->Moneda }}</small>
                    @endif
                </td>
                <td>{{ $contrato->{'Forma de Pago'} ?? 'N/A' }}</td>
                <td class="text-end">{{ $contrato->{'Valor Ctto CUC'} ? number_format($contrato->{'Valor Ctto CUC'}, 2) : '0.00' }}</td>
                <td class="text-center">
                    @if($contrato->Concluido)
                        <span class="badge badge-success">Sí</span>
                    @else
                        <span class="badge badge-secondary">No</span>
                    @endif
                </td>
                <td>{{ Str::limit($contrato->{'Observaciones Esp'}, 30) }}</td>
                <td class="text-center">
                    @if($contrato->Cancelado)
                        <span class="badge badge-danger">Sí</span>
                    @else
                        <span class="badge badge-secondary">No</span>
                    @endif
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="10" style="text-align: center;">No hay datos para mostrar</td>
            </tr>
            @endforelse
        </tbody>
        @if($contratos->count() > 0)
        <tfoot>
            <tr>
                <th colspan="3" class="text-end">Totales:</th>
                <th class="text-end">{{ number_format($contratos->sum('Valor Ctto Mon Prov'), 2) }}</th>
                <th colspan="2"></th>
                <th class="text-end">{{ number_format($contratos->sum('Valor Ctto CUC'), 2) }}</th>
                <th>
                    Concluidos: {{ $contratos->where('Concluido', 1)->count() }}<br>
                    No concluidos: {{ $contratos->where('Concluido', 0)->count() }}
                </th>
                <th></th>
                <th>
                    Cancelados: {{ $contratos->where('Cancelado', 1)->count() }}<br>
                    No cancelados: {{ $contratos->where('Cancelado', 0)->count() }}
                </th>
            </tr>
        </tfoot>
        @endif
    </table>
    
    <div class="footer">
        <p>Total de registros: {{ $contratos->count() }}</p>
        <p>Generado por: {{ auth()->user()->{'Usuario'} ?? 'Sistema' }}</p>
        <p>SCCI - Sistema de Control de Contratación e Importaciones</p>
    </div>
    
    <script>
        // Auto-print on load (optional)
        // window.onload = function() { window.print(); }
    </script>
</body>
</html>