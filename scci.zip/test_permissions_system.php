<?php
require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

echo "=== PRUEBA FINAL DEL SISTEMA DE PERMISOS ===\n\n";

// 1. Verificar tablas y datos
echo "1. Verificando estructura de la base de datos:\n";

$tables = [
    'modules' => DB::table('modules')->count(),
    'permissions' => DB::table('permissions')->count(),
    'Nomenclador Areas' => DB::table(DB::raw('`Nomenclador Areas`'))->count(),
    'Nomenclador Usuarios' => DB::table(DB::raw('`Nomenclador Usuarios`'))->count(),
];

foreach ($tables as $table => $count) {
    echo "   - {$table}: {$count} registros\n";
}

// 2. Verificar estructura de Nomenclador Usuarios
echo "\n2. Verificando columnas de Nomenclador Usuarios:\n";
$columns = DB::select("DESCRIBE `Nomenclador Usuarios`");
foreach ($columns as $column) {
    echo "   - {$column->Field} ({$column->Type})\n";
}

// 3. Encontrar un usuario de Informática
echo "\n3. Buscando usuario de Informática:\n";

$informaticaArea = DB::table(DB::raw('`Nomenclador Areas`'))
    ->where('Area', 'Informatica')
    ->first();

if ($informaticaArea) {
    echo "   ✓ Área Informática encontrada (ID: {$informaticaArea->{'Id Area'}})\n";

    $informaticaUser = DB::table(DB::raw('`Nomenclador Usuarios`'))
        ->where(DB::raw('`Id Area`'), $informaticaArea->{'Id Area'})
        ->first();

    if ($informaticaUser) {
        echo "   ✓ Usuario de Informática encontrado: {$informaticaUser->Usuario}\n";

        $userModel = User::find($informaticaUser->PWD);

        if ($userModel) {
            Auth::login($userModel);

            echo "   Probando permisos (debería tener todos):\n";
            $modules = ['dashboard', 'solicitudes', 'contratos', 'usuarios'];
            foreach ($modules as $module) {
                $canView = $userModel->hasPermission($module, 'view') ? '✅' : '❌';
                $canCreate = $userModel->hasPermission($module, 'create') ? '✅' : '❌';
                echo "   - {$module}: Ver={$canView}, Crear={$canCreate}\n";
            }

            echo "   Es Informática: " . ($userModel->isInformatica() ? '✅ Sí' : '❌ No') . "\n";
        } else {
            echo "   ✗ No se pudo crear modelo del usuario\n";
        }
    } else {
        echo "   ✗ No se encontró usuario en el área de Informática\n";
    }
} else {
    echo "   ✗ No se encontró el área de Informática\n";
}

// 4. Usuario de otra área
echo "\n4. Buscando usuario de otra área:\n";

$otherArea = DB::table(DB::raw('`Nomenclador Areas`'))
    ->where('Area', '!=', 'Informatica')
    ->first();

if ($otherArea) {
    echo "   ✓ Área encontrada: {$otherArea->Area} (ID: {$otherArea->{'Id Area'}})\n";

    $otherUser = DB::table(DB::raw('`Nomenclador Usuarios`'))
        ->where(DB::raw('`Id Area`'), $otherArea->{'Id Area'})
        ->first();

    if ($otherUser) {
        echo "   ✓ Usuario encontrado: {$otherUser->Usuario}\n";

        $userModel = User::find($otherUser->PWD);

        if ($userModel) {
            Auth::login($userModel);

            echo "   Probando permisos:\n";
            $modules = ['dashboard', 'solicitudes', 'contratos', 'usuarios'];
            foreach ($modules as $module) {
                $canView = $userModel->hasPermission($module, 'view') ? '✅' : '❌';
                echo "   - {$module}: Ver={$canView}\n";
            }

            echo "   Es Informática: " . ($userModel->isInformatica() ? '✅ Sí' : '❌ No') . "\n";
        } else {
            echo "   ✗ No se pudo crear modelo del usuario\n";
        }
    } else {
        echo "   ✗ No se encontró usuario en esta área\n";
    }
} else {
    echo "   ✗ No se encontraron otras áreas\n";
}

// 5. Resumen de permisos por área
echo "\n5. Resumen de permisos por área:\n";

$summary = DB::select("
    SELECT 
        a.Area,
        COUNT(p.id) as total_permisos,
        SUM(p.view) as puede_ver,
        SUM(p.create_p) as puede_crear
    FROM `Nomenclador Areas` a
    LEFT JOIN permissions p ON a.`Id Area` = p.id_area
    GROUP BY a.`Id Area`, a.Area
    ORDER BY a.Area
");

foreach ($summary as $row) {
    echo "   - {$row->Area}: {$row->total_permisos} permisos, ver {$row->puede_ver}, crear {$row->puede_crear}\n";
}

// 6. Usuarios de ejemplo
echo "\n6. Usuarios de ejemplo:\n";

$users = DB::table(DB::raw('`Nomenclador Usuarios` as u'))
    ->join(DB::raw('`Nomenclador Areas` as a'), DB::raw('u.`Id Area`'), '=', DB::raw('a.`Id Area`'))
    ->select([
        'u.Usuario',
        DB::raw('u.`Nombre completo` as nombre_completo'),
        'a.Area'
    ])
    ->limit(5)
    ->get();

foreach ($users as $user) {
    echo "   - {$user->Usuario} ({$user->nombre_completo}): {$user->Area}\n";
}

echo "\n=== PRUEBA COMPLETADA ===\n";
