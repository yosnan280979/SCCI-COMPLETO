<?php

namespace App\Exports;

use App\Models\Provider;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class ProvidersExport implements FromCollection, WithHeadings, WithMapping
{
    protected $providers;

    public function __construct($providers)
    {
        $this->providers = $providers;
    }

    public function collection()
    {
        return $this->providers;
    }

    public function headings(): array
    {
        return [
            'ID',
            'No. Exp',
            'Proveedor',
            'País',
            'Estado',
            'Correo',
            'Código MINCEX',
            'Tipo Proveedor',
            'Oficina Cuba',
            'Siglas',
            'Teléfono Cuba',
            'Dirección Cuba',
            'Sitio Web'
        ];
    }

    public function map($provider): array
    {
        return [
            $provider->{'Id Proveedor'},
            $provider->{'No Exp'},
            $provider->{'Proveedor'},
            $provider->pais?->{'País'} ?? '',
            $provider->{'Activo'} ? 'Activo' : 'Inactivo',
            $provider->{'Correo'},
            $provider->{'Codigo MINCEX'},
            $provider->tipoProveedor?->{'Tipo Proveedor'} ?? '',
            $provider->{'Oficina Cuba'} ? 'Sí' : 'No',
            $provider->{'Siglas'},
            $provider->{'Telef Cuba'},
            $provider->{'Direccion Cuba'},
            $provider->{'Sitio Web'}
        ];
    }
}