@extends('layouts.app')

@section('title', 'Editar Datos SOE')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Editar Datos SOE #{{ $datosSOE->{'Id SOE'} }}</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('datos-soe.update', $datosSOE->{'Id SOE'}) }}" method="POST">
                @csrf
                @method('PUT')
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Id Ctto" class="form-label">Contrato *</label>
                        <select class="form-select" id="Id Ctto" name="Id Ctto" required>
                            <option value="">Seleccionar Contrato</option>
                            @foreach($contratos as $contrato)
                                <option value="{{ $contrato->{'Id Ctto'} }}" 
                                    {{ $datosSOE->{'Id Ctto'} == $contrato->{'Id Ctto'} ? 'selected' : '' }}>
                                    {{ $contrato->{'No Ctto'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="No Suplemento" class="form-label">No. Suplemento</label>
                        <input type="number" class="form-control" id="No Suplemento" name="No Suplemento"
                               value="{{ $datosSOE->{'No Suplemento'} }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Fecha Comite" class="form-label">Fecha Comité</label>
                        <input type="date" class="form-control" id="Fecha Comite" name="Fecha Comite"
                               value="{{ $datosSOE->{'Fecha Comite'} }}">
                    </div>
                    <div class="col-md-6">
                        <label for="No Acta" class="form-label">No. Acta</label>
                        <input type="text" class="form-control" id="No Acta" name="No Acta"
                               value="{{ $datosSOE->{'No Acta'} }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="No Acuerdo" class="form-label">No. Acuerdo</label>
                        <input type="text" class="form-control" id="No Acuerdo" name="No Acuerdo"
                               value="{{ $datosSOE->{'No Acuerdo'} }}">
                    </div>
                    <div class="col-md-6">
                        <label for="Valor Mercancia" class="form-label">Valor Mercancía</label>
                        <input type="number" step="0.01" class="form-control" id="Valor Mercancia" name="Valor Mercancia"
                               value="{{ $datosSOE->{'Valor Mercancia'} }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Valor Ctto CUC" class="form-label">Valor Contrato (CUC)</label>
                        <input type="number" step="0.01" class="form-control" id="Valor Ctto CUC" name="Valor Ctto CUC"
                               value="{{ $datosSOE->{'Valor Ctto CUC'} }}">
                    </div>
                    <div class="col-md-6">
                        <label for="Valor Mon Prov" class="form-label">Valor Mon. Prov.</label>
                        <input type="number" step="0.01" class="form-control" id="Valor Mon Prov" name="Valor Mon Prov"
                               value="{{ $datosSOE->{'Valor Mon Prov'} }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="No Referencia" class="form-label">No. Referencia</label>
                        <input type="text" class="form-control" id="No Referencia" name="No Referencia"
                               value="{{ $datosSOE->{'No Referencia'} }}">
                    </div>
                    <div class="col-md-6">
                        <label for="Fecha CAD Gescons" class="form-label">Fecha CAD Gescons</label>
                        <input type="date" class="form-control" id="Fecha CAD Gescons" name="Fecha CAD Gescons"
                               value="{{ $datosSOE->{'Fecha CAD Gescons'} }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Fecha CAD MICONS" class="form-label">Fecha CAD MICONS</label>
                        <input type="date" class="form-control" id="Fecha CAD MICONS" name="Fecha CAD MICONS"
                               value="{{ $datosSOE->{'Fecha CAD MICONS'} }}">
                    </div>
                    <div class="col-md-6">
                        <label for="No Acta MICONS" class="form-label">No. Acta MICONS</label>
                        <input type="text" class="form-control" id="No Acta MICONS" name="No Acta MICONS"
                               value="{{ $datosSOE->{'No Acta MICONS'} }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Fecha firma Ctto" class="form-label">Fecha Firma Contrato</label>
                        <input type="date" class="form-control" id="Fecha firma Ctto" name="Fecha firma Ctto"
                               value="{{ $datosSOE->{'Fecha firma Ctto'} }}">
                    </div>
                    <div class="col-md-6">
                        <label for="Fecha emision certif" class="form-label">Fecha Emisión Certif.</label>
                        <input type="date" class="form-control" id="Fecha emision certif" name="Fecha emision certif"
                               value="{{ $datosSOE->{'Fecha emision certif'} }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Pendiente finan CUC" class="form-label">Pendiente Financiar (CUC)</label>
                        <input type="number" step="0.01" class="form-control" id="Pendiente finan CUC" name="Pendiente finan CUC"
                               value="{{ $datosSOE->{'Pendiente finan CUC'} }}">
                    </div>
                    <div class="col-md-6">
                        <label for="Pendiente finan CUP" class="form-label">Pendiente Financiar (CUP)</label>
                        <input type="number" step="0.01" class="form-control" id="Pendiente finan CUP" name="Pendiente finan CUP"
                               value="{{ $datosSOE->{'Pendiente finan CUP'} }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Total embarques" class="form-label">Total Embarques</label>
                        <input type="number" class="form-control" id="Total embarques" name="Total embarques"
                               value="{{ $datosSOE->{'Total embarques'} }}">
                    </div>
                    <div class="col-md-6">
                        <label for="Forma de Pago" class="form-label">Forma de Pago</label>
                        <input type="text" class="form-control" id="Forma de Pago" name="Forma de Pago"
                               value="{{ $datosSOE->{'Forma de Pago'} }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Año finan" class="form-label">Año Financiamiento</label>
                        <input type="number" class="form-control" id="Año finan" name="Año finan"
                               value="{{ $datosSOE->{'Año finan'} }}">
                    </div>
                    <div class="col-md-6">
                        <div class="form-check mt-4">
                            <input class="form-check-input" type="checkbox" id="Cancelado SOE" name="Cancelado SOE" value="1"
                                {{ $datosSOE->{'Cancelado SOE'} ? 'checked' : '' }}>
                            <label class="form-check-label" for="Cancelado SOE">Cancelado SOE</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="Anular Valores" name="Anular Valores" value="1"
                                {{ $datosSOE->{'Anular Valores'} ? 'checked' : '' }}>
                            <label class="form-check-label" for="Anular Valores">Anular Valores</label>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Observaciones Juridico" class="form-label">Observaciones Jurídico</label>
                        <textarea class="form-control" id="Observaciones Juridico" name="Observaciones Juridico" rows="3">{{ $datosSOE->{'Observaciones Juridico'} }}</textarea>
                    </div>
                    <div class="col-md-6">
                        <label for="Observaciones SOE" class="form-label">Observaciones SOE</label>
                        <textarea class="form-control" id="Observaciones SOE" name="Observaciones SOE" rows="3">{{ $datosSOE->{'Observaciones SOE'} }}</textarea>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Observaciones Especialista" class="form-label">Observaciones Especialista</label>
                        <textarea class="form-control" id="Observaciones Especialista" name="Observaciones Especialista" rows="3">{{ $datosSOE->{'Observaciones Especialista'} }}</textarea>
                    </div>
                    <div class="col-md-6">
                        <label for="Observaciones" class="form-label">Observaciones Generales</label>
                        <textarea class="form-control" id="Observaciones" name="Observaciones" rows="3">{{ $datosSOE->Observaciones }}</textarea>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="{{ route('datos-soe.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Actualizar Datos SOE</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection