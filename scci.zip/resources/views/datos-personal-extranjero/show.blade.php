@extends('layouts.app')

@section('header', 'Personal Extranjero - Detalles')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Detalles del Personal Extranjero</h5>
        <div>
            <a href="{{ route('datos-personal-extranjero.edit', $item->Id ?? $item->id) }}" class="btn btn-warning btn-sm">
                <i class="fas fa-edit"></i> Editar
            </a>
            <a href="{{ route('datos-personal-extranjero.index') }}" class="btn btn-secondary btn-sm">
                <i class="fas fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-3">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-id-card"></i> Información Personal</h6>
                    </div>
                    <div class="card-body">
                        <table class="table table-borderless">
                            <tr>
                                <th width="40%" class="text-muted">ID:</th>
                                <td>
                                    <span class="badge bg-primary">{{ $item->Id ?? $item->id }}</span>
                                </td>
                            </tr>
                            <tr>
                                <th class="text-muted">Proveedor:</th>
                                <td>
                                    <span class="badge bg-info">{{ $item->proveedor->Proveedor ?? 'N/A' }}</span>
                                </td>
                            </tr>
                            <tr>
                                <th class="text-muted">Funcionario:</th>
                                <td>
                                    <strong>{{ $item->Funcionario_extranjero }}</strong>
                                </td>
                            </tr>
                            <tr>
                                <th class="text-muted">Cargo:</th>
                                <td>{{ $item->Cargo ?? 'N/A' }}</td>
                            </tr>
                            <tr>
                                <th class="text-muted">Teléfono:</th>
                                <td>
                                    @if($item->Telef)
                                        <i class="fas fa-phone text-success"></i> {{ $item->Telef }}
                                    @else
                                        <span class="text-muted">N/A</span>
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th class="text-muted">Email:</th>
                                <td>
                                    @if($item->Email)
                                        <a href="mailto:{{ $item->Email }}">
                                            <i class="fas fa-envelope text-primary"></i> {{ $item->Email }}
                                        </a>
                                    @else
                                        <span class="text-muted">N/A</span>
                                    @endif
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card mb-3">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-file-contract"></i> Información Laboral</h6>
                    </div>
                    <div class="card-body">
                        <table class="table table-borderless">
                            <tr>
                                <th width="40%" class="text-muted">Permiso de Trabajo:</th>
                                <td>{{ $item->Permiso_de_Trabajo ?? 'N/A' }}</td>
                            </tr>
                            <tr>
                                <th class="text-muted">ID País:</th>
                                <td>{{ $item->Id_pais ?? 'N/A' }}</td>
                            </tr>
                            <tr>
                                <th class="text-muted">Fecha Vencimiento:</th>
                                <td>
                                    @if($item->Fecha_Vencimiento)
                                        <span class="badge bg-{{ \Carbon\Carbon::parse($item->Fecha_Vencimiento)->isFuture() ? 'success' : 'danger' }}">
                                            {{ \Carbon\Carbon::parse($item->Fecha_Vencimiento)->format('d/m/Y') }}
                                        </span>
                                    @else
                                        <span class="text-muted">N/A</span>
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th class="text-muted">Fecha Venpod:</th>
                                <td>
                                    @if($item->Fechavenpod)
                                        {{ \Carbon\Carbon::parse($item->Fechavenpod)->format('d/m/Y') }}
                                    @else
                                        <span class="text-muted">N/A</span>
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th class="text-muted">Escnot:</th>
                                <td>{{ $item->Escnot ?? 'N/A' }}</td>
                            </tr>
                            <tr>
                                <th class="text-muted">Aprot:</th>
                                <td>{{ $item->Aprot ?? 'N/A' }}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-toggle-on"></i> Estados</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 text-center">
                                <div class="p-3 border rounded">
                                    <h6 class="text-muted">Activo</h6>
                                    <div class="mt-2">
                                        <span class="badge bg-{{ $item->Activo ? 'success' : 'secondary' }} p-2 fs-6">
                                            <i class="fas fa-{{ $item->Activo ? 'check-circle' : 'times-circle' }}"></i>
                                            {{ $item->Activo ? 'ACTIVO' : 'INACTIVO' }}
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 text-center">
                                <div class="p-3 border rounded">
                                    <h6 class="text-muted">Firmante</h6>
                                    <div class="mt-2">
                                        <span class="badge bg-{{ $item->Firmante ? 'warning' : 'secondary' }} p-2 fs-6">
                                            {{ $item->Firmante ? 'AUTORIZADO' : 'NO AUTORIZADO' }}
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 text-center">
                                <div class="p-3 border rounded">
                                    <h6 class="text-muted">Estado Permiso</h6>
                                    <div class="mt-2">
                                        @if($item->Fecha_Vencimiento)
                                            @if(\Carbon\Carbon::parse($item->Fecha_Vencimiento)->isFuture())
                                                <span class="badge bg-success p-2 fs-6">VIGENTE</span>
                                            @else
                                                <span class="badge bg-danger p-2 fs-6">VENCIDO</span>
                                            @endif
                                        @else
                                            <span class="badge bg-secondary p-2 fs-6">NO ESPECIFICADO</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 text-center">
                                <div class="p-3 border rounded">
                                    <h6 class="text-muted">Acciones</h6>
                                    <div class="mt-2">
                                        <button type="button" class="btn btn-danger btn-sm" onclick="confirmDelete()">
                                            <i class="fas fa-trash"></i> Eliminar
                                        </button>
                                        <form id="deleteForm" action="{{ route('datos-personal-extranjero.destroy', $item->Id ?? $item->id) }}" method="POST" class="d-none">
                                            @csrf
                                            @method('DELETE')
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
function confirmDelete() {
    if (confirm('¿Está seguro de eliminar este registro? Esta acción no se puede deshacer.')) {
        document.getElementById('deleteForm').submit();
    }
}
</script>
@endsection