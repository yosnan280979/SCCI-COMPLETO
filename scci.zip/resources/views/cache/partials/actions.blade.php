<div class="btn-group" role="group">
    <a href="{{ route('cache.show', $cache->key) }}" class="btn btn-info btn-sm">
        <i class="fas fa-eye"></i>
    </a>
    <a href="{{ route('cache.edit', $cache->key) }}" class="btn btn-warning btn-sm">
        <i class="fas fa-edit"></i>
    </a>
    <form action="{{ route('cache.destroy', $cache->key) }}" method="POST" class="d-inline delete-form">
        @csrf
        @method('DELETE')
        <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="{{ $cache->key }}">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>