<!DOCTYPE html>
<html>
<head>
    <title>Contratos - Reporte PDF</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 6px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        h1 { text-align: center; color: #333; }
        .header { text-align: center; margin-bottom: 20px; }
        .footer { margin-top: 30px; padding-top: 10px; border-top: 1px solid #ddd; text-align: center; font-size: 10px; color: #666; }
        .text-end { text-align: right; }
        .text-center { text-align: center; }
        .badge { padding: 3px 8px; border-radius: 3px; font-size: 11px; }
        .badge-success { background-color: #d4edda; color: #155724; }
        .badge-warning { background-color: #fff3cd; color: #856404; }
        .badge-danger { background-color: #f8d7da; color: #721c24; }
        .badge-secondary { background-color: #e2e3e5; color: #383d41; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Reporte de Contratos</h1>
        <p>Fecha: {{ date('d/m/Y H:i:s') }}</p>
        <p>Total de registros: {{ $contratos->count() }}</p>
        
        @if(!empty($filtros))
            <div style="margin-top: 10px; text-align: left; font-size: 11px;">
                <strong>Filtros aplicados:</strong><br>
                @foreach($filtros as $filtro)
                    • {{ $filtro }}<br>
                @endforeach
            </div>
        @endif
    </div>
    
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>No. Contrato</th>
                <th>Proveedor</th>
                <th>Valor Mon. Prov.</th>
                <th>Moneda</th>
                <th>Forma de Pago</th>
                <th>Valor CUC</th>
                <th>Concluido</th>
                <th>Observaciones</th>
                <th>Cancelado</th>
            </tr>
        </thead>
        <tbody>
            @foreach($contratos as $contrato)
            <tr>
                <td>{{ $contrato->{'Id Ctto'} }}</td>
                <td>{{ $contrato->{'No Ctto'} ?? 'N/A' }}</td>
                <td>
                    {{ $contrato->{'Id Proveedor'} }}
                    @php
                        $provider = $contrato->provider;
                    @endphp
                    @if($provider)
                        <br><small>{{ $provider->Proveedor }}</small>
                    @endif
                </td>
                <td class="text-end">{{ $contrato->{'Valor Ctto Mon Prov'} ? number_format($contrato->{'Valor Ctto Mon Prov'}, 2) : '0.00' }}</td>
                <td>
                    {{ $contrato->{'Id Moneda'} }}
                    @php
                        $currency = $contrato->currency;
                    @endphp
                    @if($currency)
                        <br><small>{{ $currency->Moneda }}</small>
                    @endif
                </td>
                <td>{{ $contrato->{'Forma de Pago'} ?? 'N/A' }}</td>
                <td class="text-end">{{ $contrato->{'Valor Ctto CUC'} ? number_format($contrato->{'Valor Ctto CUC'}, 2) : '0.00' }}</td>
                <td class="text-center">
                    @if($contrato->Concluido)
                        <span class="badge badge-success">Sí</span>
                    @else
                        <span class="badge badge-secondary">No</span>
                    @endif
                </td>
                <td>{{ Str::limit($contrato->{'Observaciones Esp'}, 30) }}</td>
                <td class="text-center">
                    @if($contrato->Cancelado)
                        <span class="badge badge-danger">Sí</span>
                    @else
                        <span class="badge badge-secondary">No</span>
                    @endif
                </td>
            </tr>
            @endforeach
        </tbody>
        @if($contratos->count() > 0)
        <tfoot>
            <tr>
                <th colspan="3" class="text-end">Totales:</th>
                <th class="text-end">{{ number_format($contratos->sum('Valor Ctto Mon Prov'), 2) }}</th>
                <th colspan="2"></th>
                <th class="text-end">{{ number_format($contratos->sum('Valor Ctto CUC'), 2) }}</th>
                <th>
                    Concluidos: {{ $contratos->where('Concluido', 1)->count() }}<br>
                    No concluidos: {{ $contratos->where('Concluido', 0)->count() }}
                </th>
                <th></th>
                <th>
                    Cancelados: {{ $contratos->where('Cancelado', 1)->count() }}<br>
                    No cancelados: {{ $contratos->where('Cancelado', 0)->count() }}
                </th>
            </tr>
        </tfoot>
        @endif
    </table>
    
    <div class="footer">
        <p>Exportación generada por SCCI - Sistema de Control de Contratación e Importaciones</p>
        <p>© {{ date('Y') }} Exportadora e Importadora de la Construcción</p>
        <p>Página 1 de 1</p>
    </div>
</body>
</html>