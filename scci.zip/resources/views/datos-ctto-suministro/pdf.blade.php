<!DOCTYPE html>
<html>
<head>
    <title>Datos Contrato Suministro - PDF</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; }
        .title { font-size: 18px; font-weight: bold; }
        .subtitle { font-size: 14px; color: #666; }
        .filters { margin-bottom: 15px; padding: 10px; background: #f5f5f5; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background-color: #f2f2f2; font-weight: bold; text-align: left; padding: 8px; border: 1px solid #ddd; }
        td { padding: 8px; border: 1px solid #ddd; }
        .footer { margin-top: 30px; text-align: right; font-size: 10px; color: #666; }
        .text-right { text-align: right; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">Listado de Datos Contrato Suministro</div>
        <div class="subtitle">Fecha de generación: {{ now()->format('d/m/Y H:i:s') }}</div>
    </div>
    
    @if(!empty($filtros))
    <div class="filters">
        <strong>Filtros aplicados:</strong><br>
        @foreach($filtros as $filtro)
        • {{ $filtro }}<br>
        @endforeach
    </div>
    @endif
    
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Contrato Suministro</th>
                <th>No. Suplemento</th>
                <th>Fecha Firma</th>
                <th class="text-right">Importe CUC</th>
                <th class="text-right">Importe CUP</th>
                <th class="text-right">Pendiente CUC</th>
                <th class="text-right">Pendiente CUP</th>
                <th>Forma de Pago</th>
            </tr>
        </thead>
        <tbody>
            @php
                $totalCUC = 0;
                $totalCUP = 0;
                $totalPendienteCUC = 0;
                $totalPendienteCUP = 0;
            @endphp
            @forelse($items as $item)
            @php
                $totalCUC += $item->{'Importe CUC'} ?? 0;
                $totalCUP += $item->{'Importe CUP'} ?? 0;
                $totalPendienteCUC += $item->{'Pendiente Finan CUC'} ?? 0;
                $totalPendienteCUP += $item->{'Pendiente CUP'} ?? 0;
            @endphp
            <tr>
                <td>{{ $item->{'Id Supsum'} }}</td>
                <td>{{ $item->contratoSuministro ? $item->contratoSuministro->Descripcion : 'N/A' }}</td>
                <td>{{ $item->{'No Suplemento'} }}</td>
                <td>{{ $item->{'Fecha firma Ctto'} ? \Carbon\Carbon::parse($item->{'Fecha firma Ctto'})->format('d/m/Y') : '' }}</td>
                <td class="text-right">{{ number_format($item->{'Importe CUC'}, 2) }}</td>
                <td class="text-right">{{ number_format($item->{'Importe CUP'}, 2) }}</td>
                <td class="text-right">{{ number_format($item->{'Pendiente Finan CUC'}, 2) }}</td>
                <td class="text-right">{{ number_format($item->{'Pendiente CUP'}, 2) }}</td>
                <td>{{ $item->{'Forma de Pago'} }}</td>
            </tr>
            @empty
            <tr>
                <td colspan="9" style="text-align: center;">No hay datos para mostrar</td>
            </tr>
            @endforelse
        </tbody>
        @if($items->count() > 0)
        <tfoot>
            <tr>
                <td colspan="4" style="text-align: right; font-weight: bold;">Totales:</td>
                <td class="text-right" style="font-weight: bold;">{{ number_format($totalCUC, 2) }}</td>
                <td class="text-right" style="font-weight: bold;">{{ number_format($totalCUP, 2) }}</td>
                <td class="text-right" style="font-weight: bold;">{{ number_format($totalPendienteCUC, 2) }}</td>
                <td class="text-right" style="font-weight: bold;">{{ number_format($totalPendienteCUP, 2) }}</td>
                <td></td>
            </tr>
        </tfoot>
        @endif
    </table>
    
    <div class="footer">
        Total de registros: {{ $items->count() }}<br>
        Generado por: {{ auth()->user()->{'Usuario'} ?? 'Sistema' }}
    </div>
</body>
</html>