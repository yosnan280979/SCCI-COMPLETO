@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">Detalle del Registro Bancario</h3>
                    <a href="{{ route('datos-bancos-proveedores.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Volver
                    </a>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tr><th>ID</th><td>{{ $datosBanco->Id }}</td></tr>
                        <tr><th>Proveedor</th><td>{{ $datosBanco->proveedor?->{'Proveedor'} ?? '---' }}</td></tr>
                        <tr><th>Banco</th><td>{{ $datosBanco->banco?->{'Banco'} ?? '---' }}</td></tr>
                        <tr><th>Moneda</th><td>{{ $datosBanco->moneda?->{'Moneda'} ?? '---' }}</td></tr>
                        <tr><th>Número de Cuenta</th><td>{{ $datosBanco->{'Numero Cuenta'} }}</td></tr>
                        <tr><th>Titular</th><td>{{ $datosBanco->Titular ?? '---' }}</td></tr>
                    </table>
                </div>
                <div class="card-footer d-flex justify-content-end">
                    <a href="{{ route('datos-bancos-proveedores.edit', $datosBanco->Id) }}" class="btn btn-warning">
                        <i class="fas fa-edit"></i> Editar
                    </a>
                    <form action="{{ route('datos-bancos-proveedores.destroy', $datosBanco->Id) }}" method="POST" style="display:inline-block; margin-left:10px;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Eliminar
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
