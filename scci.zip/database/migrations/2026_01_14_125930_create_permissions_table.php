<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('permissions')) {
            Schema::create('permissions', function (Blueprint $table) {
                $table->id();
                $table->integer('id_area');
                $table->integer('id_module');
                $table->boolean('view')->default(false);
                $table->boolean('create')->default(false);
                $table->boolean('edit')->default(false);
                $table->boolean('delete')->default(false);
                $table->timestamps();
                
                $table->unique(['id_area', 'id_module']);
            });
        }
    }

    public function down()
    {
        Schema::dropIfExists('permissions');
    }
};