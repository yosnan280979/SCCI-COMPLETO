<!DOCTYPE html>
<html>
<head>
    <title>Datos SOE - Impresión</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; }
        .title { font-size: 18px; font-weight: bold; }
        .subtitle { font-size: 14px; color: #666; }
        .filters { margin-bottom: 15px; padding: 10px; background: #f5f5f5; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background-color: #f2f2f2; font-weight: bold; text-align: left; padding: 8px; border: 1px solid #ddd; }
        td { padding: 8px; border: 1px solid #ddd; font-size: 11px; }
        .footer { margin-top: 30px; text-align: right; font-size: 10px; color: #666; }
        .text-end { text-align: right; }
        .text-center { text-align: center; }
        .badge { padding: 3px 8px; border-radius: 3px; font-size: 11px; display: inline-block; }
        .badge-success { background-color: #d4edda; color: #155724; }
        .badge-danger { background-color: #f8d7da; color: #721c24; }
        .badge-secondary { background-color: #e2e3e5; color: #383d41; }
        @media print {
            .no-print { display: none; }
            .page-break { page-break-before: always; }
            body { font-size: 11px; }
            table { font-size: 10px; }
        }
        .page-break { page-break-after: always; }
        .soe-container { margin-bottom: 20px; page-break-inside: avoid; }
        .soe-header { background-color: #e9ecef; padding: 10px; font-weight: bold; }
        .observation { background-color: #f8f9fa; padding: 8px; margin-top: 5px; }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">
            🖨️ Imprimir
        </button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #6c757d; color: white; border: none; border-radius: 5px; cursor: pointer;">
            ✖️ Cerrar
        </button>
    </div>
    
    <div class="header">
        <div class="title">Listado de Datos SOE</div>
        <div class="subtitle">Fecha de generación: {{ now()->format('d/m/Y H:i:s') }}</div>
        <div class="subtitle">Total de registros: {{ $datosSOE->count() }}</div>
    </div>
    
    @if(!empty($filtros))
    <div class="filters">
        <strong>Filtros aplicados:</strong><br>
        @foreach($filtros as $filtro)
        • {{ $filtro }}<br>
        @endforeach
    </div>
    @endif
    
    @foreach($datosSOE as $soe)
    <div class="soe-container">
        <div class="soe-header">
            Datos SOE #{{ $soe->{'Id SOE'} }}
        </div>
        
        <table>
            <tbody>
                <!-- Primera fila -->
                <tr>
                    <td width="20%"><strong>ID SOE:</strong></td>
                    <td width="30%">{{ $soe->{'Id SOE'} }}</td>
                    <td width="20%"><strong>Contrato:</strong></td>
                    <td width="30%">
                        {{ $soe->{'Id Ctto'} }}
                        @if($soe->contrato)
                            - {{ $soe->contrato->{'No Ctto'} }}
                        @endif
                    </td>
                </tr>
                
                <!-- Segunda fila -->
                <tr>
                    <td><strong>Suplemento:</strong></td>
                    <td>{{ $soe->{'No Suplemento'} ?? 'N/A' }}</td>
                    <td><strong>Fecha Comité:</strong></td>
                    <td>{{ $soe->{'Fecha Comite'} ? \Carbon\Carbon::parse($soe->{'Fecha Comite'})->format('d/m/Y') : 'N/A' }}</td>
                </tr>
                
                <!-- Tercera fila -->
                <tr>
                    <td><strong>No. Acta:</strong></td>
                    <td>{{ $soe->{'No Acta'} ?? 'N/A' }}</td>
                    <td><strong>No. Acuerdo:</strong></td>
                    <td>{{ $soe->{'No Acuerdo'} ?? 'N/A' }}</td>
                </tr>
                
                <!-- Cuarta fila -->
                <tr>
                    <td><strong>Valor Mercancía:</strong></td>
                    <td class="text-end">{{ $soe->{'Valor Mercancia'} ? number_format($soe->{'Valor Mercancia'}, 2) : '0.00' }}</td>
                    <td><strong>Valor Ctto CUC:</strong></td>
                    <td class="text-end">{{ $soe->{'Valor Ctto CUC'} ? number_format($soe->{'Valor Ctto CUC'}, 2) : '0.00' }}</td>
                </tr>
                
                <!-- Quinta fila -->
                <tr>
                    <td><strong>ID Moneda:</strong></td>
                    <td>{{ $soe->{'Id Moneda'} ?? 'N/A' }}</td>
                    <td><strong>Valor Mon Prov:</strong></td>
                    <td class="text-end">{{ $soe->{'Valor Mon Prov'} ? number_format($soe->{'Valor Mon Prov'}, 2) : '0.00' }}</td>
                </tr>
                
                <!-- Sexta fila -->
                <tr>
                    <td><strong>No. Referencia:</strong></td>
                    <td>{{ $soe->{'No Referencia'} ?? 'N/A' }}</td>
                    <td><strong>Fecha CAD Gescons:</strong></td>
                    <td>{{ $soe->{'Fecha CAD Gescons'} ? \Carbon\Carbon::parse($soe->{'Fecha CAD Gescons'})->format('d/m/Y') : 'N/A' }}</td>
                </tr>
                
                <!-- Séptima fila -->
                <tr>
                    <td><strong>Fecha CAD MICONS:</strong></td>
                    <td>{{ $soe->{'Fecha CAD MICONS'} ? \Carbon\Carbon::parse($soe->{'Fecha CAD MICONS'})->format('d/m/Y') : 'N/A' }}</td>
                    <td><strong>No. Acta MICONS:</strong></td>
                    <td>{{ $soe->{'No Acta MICONS'} ?? 'N/A' }}</td>
                </tr>
                
                <!-- Octava fila -->
                <tr>
                    <td><strong>Fecha firma Ctto:</strong></td>
                    <td>{{ $soe->{'Fecha firma Ctto'} ? \Carbon\Carbon::parse($soe->{'Fecha firma Ctto'})->format('d/m/Y') : 'N/A' }}</td>
                    <td><strong>Fecha emisión certif:</strong></td>
                    <td>{{ $soe->{'Fecha emision certif'} ? \Carbon\Carbon::parse($soe->{'Fecha emision certif'})->format('d/m/Y') : 'N/A' }}</td>
                </tr>
                
                <!-- Novena fila -->
                <tr>
                    <td><strong>Pendiente finan CUC:</strong></td>
                    <td class="text-end">{{ $soe->{'Pendiente finan CUC'} ? number_format($soe->{'Pendiente finan CUC'}, 2) : '0.00' }}</td>
                    <td><strong>Pendiente finan CUP:</strong></td>
                    <td class="text-end">{{ $soe->{'Pendiente finan CUP'} ? number_format($soe->{'Pendiente finan CUP'}, 2) : '0.00' }}</td>
                </tr>
                
                <!-- Décima fila -->
                <tr>
                    <td><strong>Total embarques:</strong></td>
                    <td>{{ $soe->{'Total embarques'} ?? 'N/A' }}</td>
                    <td><strong>Cancelado SOE:</strong></td>
                    <td class="text-center">
                        @if($soe->{'Cancelado SOE'})
                            <span class="badge badge-danger">Sí</span>
                        @else
                            <span class="badge badge-success">No</span>
                        @endif
                    </td>
                </tr>
                
                <!-- Undécima fila -->
                <tr>
                    <td><strong>Forma de Pago:</strong></td>
                    <td>{{ $soe->{'Forma de Pago'} ?? 'N/A' }}</td>
                    <td><strong>Anular Valores:</strong></td>
                    <td class="text-center">
                        @if($soe->{'Anular Valores'})
                            <span class="badge badge-danger">Sí</span>
                        @else
                            <span class="badge badge-success">No</span>
                        @endif
                    </td>
                </tr>
                
                <!-- Duodécima fila -->
                <tr>
                    <td><strong>ID MomentoSOE:</strong></td>
                    <td>{{ $soe->{'Id MomentoSOE'} ?? 'N/A' }}</td>
                    <td><strong>Año finan:</strong></td>
                    <td>{{ $soe->{'Año finan'} ?? 'N/A' }}</td>
                </tr>
                
                <!-- Decimotercera fila -->
                <tr>
                    <td><strong>ID Línea Crédito:</strong></td>
                    <td>{{ $soe->{'Id Linea credito'} ?? 'N/A' }}</td>
                    <td></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
        
        <!-- Observaciones -->
        <div class="observation">
            <strong>Observaciones Jurídico:</strong><br>
            {{ $soe->{'Observaciones Juridico'} ?? 'N/A' }}
        </div>
        
        <div class="observation">
            <strong>Observaciones SOE:</strong><br>
            {{ $soe->{'Observaciones SOE'} ?? 'N/A' }}
        </div>
        
        <div class="observation">
            <strong>Observaciones Especialista:</strong><br>
            {{ $soe->{'Observaciones Especialista'} ?? 'N/A' }}
        </div>
        
        <div class="observation">
            <strong>Observaciones Generales:</strong><br>
            {{ $soe->Observaciones ?? 'N/A' }}
        </div>
        
        @if(!$loop->last)
            <hr style="border-top: 1px dashed #ddd; margin: 20px 0;">
        @endif
    </div>
    @endforeach
    
    <!-- Totales generales -->
    <div style="margin-top: 30px; padding: 15px; background-color: #f8f9fa; border-radius: 5px;">
        <strong>Totales Generales:</strong><br>
        • Total Registros: {{ $datosSOE->count() }}<br>
        • Valor Mercancía Total: {{ number_format($datosSOE->sum('Valor Mercancia'), 2) }}<br>
        • Valor Ctto CUC Total: {{ number_format($datosSOE->sum('Valor Ctto CUC'), 2) }}<br>
        • Registros Cancelados: {{ $datosSOE->where('Cancelado SOE', 1)->count() }}
    </div>
    
    <div class="footer">
        <p>Total de registros: {{ $datosSOE->count() }}</p>
        <p>Generado por: {{ auth()->user()->{'Usuario'} ?? 'Sistema' }}</p>
        <p>SCCI - Sistema de Control de Contratación e Importaciones</p>
    </div>
    
    <script>
        // Auto-print on load (optional)
        // window.onload = function() { window.print(); }
    </script>
</body>
</html>