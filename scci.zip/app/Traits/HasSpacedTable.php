<?php

namespace App\Traits;

trait HasSpacedTable
{
    /**
     * Get the table associated with the model.
     *
     * @return string
     */
    public function getTable()
    {
        if (isset($this->table)) {
            return $this->table;
        }

        // Para tablas con espacios, las envolvemos en backticks
        $table = str_replace('\\', '', snake_case(str_plural(class_basename($this))));
        
        return "`$table`";
    }
}