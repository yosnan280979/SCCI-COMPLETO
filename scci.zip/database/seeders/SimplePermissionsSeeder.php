<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SimplePermissionsSeeder extends Seeder
{
    public function run()
    {
        $this->command->info('Iniciando seeder simplificado...');
        
        // 1. Crear módulos básicos
        $modules = [
            ['name' => 'Dashboard', 'slug' => 'dashboard', 'order' => 1],
            ['name' => 'Solicitudes', 'slug' => 'solicitudes', 'order' => 2],
            ['name' => 'Contratos', 'slug' => 'contratos', 'order' => 3],
            ['name' => 'Asignaciones', 'slug' => 'asignaciones', 'order' => 4],
            ['name' => 'Logística', 'slug' => 'logistica', 'order' => 5],
            ['name' => 'Proveedores', 'slug' => 'proveedores', 'order' => 6],
            ['name' => 'DITEC', 'slug' => 'ditec', 'order' => 7],
            ['name' => 'Finanzas', 'slug' => 'finanzas', 'order' => 8],
            ['name' => 'Operaciones', 'slug' => 'operaciones', 'order' => 9],
            ['name' => 'Organización', 'slug' => 'organizacion', 'order' => 10],
            ['name' => 'Usuarios', 'slug' => 'usuarios', 'order' => 11],
        ];
        
        foreach ($modules as $module) {
            DB::table('modules')->insertOrIgnore($module);
        }
        
        $this->command->info('Módulos creados.');
        
        // 2. Obtener todas las áreas
        $areas = DB::table('Nomenclador Areas')->get();
        $modules = DB::table('modules')->get();
        
        $this->command->info('Asignando permisos...');
        
        // 3. Asignar permisos básicos
        foreach ($areas as $area) {
            foreach ($modules as $module) {
                $view = false;
                $create = false;
                $edit = false;
                $delete = false;
                
                // Informática tiene acceso completo
                if ($area->Area === 'Informatica') {
                    $view = true;
                    $create = true;
                    $edit = true;
                    $delete = true;
                }
                // Todos pueden ver el dashboard
                else if ($module->slug === 'dashboard') {
                    $view = true;
                }
                
                // Insertar permiso
                DB::table('permissions')->insertOrIgnore([
                    'id_area' => $area->{'Id Area'},
                    'id_module' => $module->id,
                    'view' => $view,
                    'create' => $create,
                    'edit' => $edit,
                    'delete' => $delete,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
            $this->command->info("Permisos asignados para: {$area->Area}");
        }
        
        $this->command->info('¡Seeder completado!');
    }
}