<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EditorMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check()) {
            return redirect()->route('login');
        }

        $user = auth()->user();
        
        if (!$user->relationLoaded('userType')) {
            $user->load('userType');
        }

        if ($user->userType && in_array($user->userType->{'Id Tipo Usuario'}, [1, 2])) {
            return $next($request);
        }

        return redirect()->route('dashboard')
            ->with('error', 'No tienes permisos de editor para acceder a esta sección.');
    }
}