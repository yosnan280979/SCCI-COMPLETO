<?php
require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\DB;

echo "=== SOLUCIÓN DEFINITIVA PARA PERMISOS ===\n\n";

// 1. Eliminar tablas si existen (en orden correcto)
echo "1. Eliminando tablas existentes...\n";

// Primero verificar si existen
$tables = DB::select("SHOW TABLES");
foreach ($tables as $table) {
    foreach ($table as $tableName) {
        if ($tableName === 'permissions' || $tableName === 'modules') {
            DB::statement("DROP TABLE IF EXISTS `$tableName`");
            echo "  ✓ Tabla '$tableName' eliminada\n";
        }
    }
}

// 2. Crear tabla modules con estructura simple
echo "\n2. Creando tabla 'modules'...\n";
DB::statement("
    CREATE TABLE modules (
        id INT NOT NULL AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        slug VARCHAR(255) NOT NULL,
        `order` INT DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY slug_unique (slug)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");
echo "  ✓ Tabla 'modules' creada\n";

// 3. Crear tabla permissions con estructura simple
echo "\n3. Creando tabla 'permissions'...\n";
DB::statement("
    CREATE TABLE permissions (
        id INT NOT NULL AUTO_INCREMENT,
        id_area INT NOT NULL,
        id_module INT NOT NULL,
        view TINYINT DEFAULT 0,
        create_p TINYINT DEFAULT 0,
        edit TINYINT DEFAULT 0,
        delete_p TINYINT DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY area_module_unique (id_area, id_module)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");
echo "  ✓ Tabla 'permissions' creada\n";

// 4. Insertar módulos básicos
echo "\n4. Insertando módulos...\n";
$modules = [
    ['name' => 'Dashboard', 'slug' => 'dashboard', 'order' => 1],
    ['name' => 'Solicitudes', 'slug' => 'solicitudes', 'order' => 2],
    ['name' => 'Contratos', 'slug' => 'contratos', 'order' => 3],
    ['name' => 'Asignaciones', 'slug' => 'asignaciones', 'order' => 4],
    ['name' => 'Logística', 'slug' => 'logistica', 'order' => 5],
    ['name' => 'Proveedores', 'slug' => 'proveedores', 'order' => 6],
    ['name' => 'DITEC', 'slug' => 'ditec', 'order' => 7],
    ['name' => 'Finanzas', 'slug' => 'finanzas', 'order' => 8],
    ['name' => 'Operaciones', 'slug' => 'operaciones', 'order' => 9],
    ['name' => 'Organización', 'slug' => 'organizacion', 'order' => 10],
    ['name' => 'Usuarios', 'slug' => 'usuarios', 'order' => 11],
];

foreach ($modules as $module) {
    // Usar insert ignore para evitar duplicados
    DB::statement("INSERT IGNORE INTO modules (name, slug, `order`) VALUES (?, ?, ?)", [
        $module['name'],
        $module['slug'],
        $module['order']
    ]);
    echo "  ✓ Módulo: {$module['name']}\n";
}

// 5. Obtener todas las áreas
echo "\n5. Obteniendo áreas...\n";
$areas = DB::table('Nomenclador Areas')->get();
echo "  Encontradas: " . count($areas) . " áreas\n";

// 6. Asignar permisos básicos
echo "\n6. Asignando permisos básicos...\n";

// Primero, limpiar permisos existentes
DB::table('permissions')->truncate();

foreach ($areas as $area) {
    $modules = DB::table('modules')->get();
    
    foreach ($modules as $module) {
        $view = 0;
        $create = 0;
        $edit = 0;
        $delete = 0;
        
        // Informática tiene acceso completo
        if ($area->Area === 'Informatica') {
            $view = 1;
            $create = 1;
            $edit = 1;
            $delete = 1;
        }
        // Todos pueden ver dashboard
        else if ($module->slug === 'dashboard') {
            $view = 1;
        }
        // Otros permisos según área
        else {
            switch ($area->Area) {
                case 'Dirección':
                    if (in_array($module->slug, ['solicitudes', 'contratos', 'asignaciones', 'logistica', 'proveedores', 'finanzas'])) {
                        $view = 1;
                        $create = 1;
                        $edit = 1;
                    }
                    break;
                case 'Comerciales':
                    if (in_array($module->slug, ['solicitudes', 'contratos', 'proveedores', 'logistica'])) {
                        $view = 1;
                        $create = 1;
                    }
                    break;
                case 'Dir. UEB Importaciones':
                    if (in_array($module->slug, ['solicitudes', 'contratos', 'logistica', 'proveedores'])) {
                        $view = 1;
                        $create = 1;
                        $edit = 1;
                    }
                    break;
                // Agrega más casos según necesites
            }
        }
        
        // Insertar permiso
        DB::table('permissions')->insert([
            'id_area' => $area->{'Id Area'},
            'id_module' => $module->id,
            'view' => $view,
            'create_p' => $create,
            'edit' => $edit,
            'delete_p' => $delete,
        ]);
    }
    
    echo "  ✓ Permisos asignados para: {$area->Area}\n";
}

// 7. Verificar resultados
echo "\n7. Verificando resultados...\n";
echo "  Total módulos: " . DB::table('modules')->count() . "\n";
echo "  Total permisos: " . DB::table('permissions')->count() . "\n";

// 8. Mostrar resumen
echo "\n8. Resumen por área:\n";
$areasWithPermissions = DB::select("
    SELECT 
        a.Area,
        COUNT(p.id) as total_permisos,
        SUM(p.view) as puede_ver,
        SUM(p.create_p) as puede_crear
    FROM `Nomenclador Areas` a
    LEFT JOIN permissions p ON a.`Id Area` = p.id_area
    GROUP BY a.`Id Area`, a.Area
    ORDER BY a.Area
");

foreach ($areasWithPermissions as $row) {
    echo "  - {$row->Area}:\n";
    echo "    Total permisos: {$row->total_permisos}\n";
    echo "    Puede ver: {$row->puede_ver} módulos\n";
    echo "    Puede crear: {$row->puede_crear} módulos\n";
}

echo "\n=== PROCESO COMPLETADO ===\n";

// 9. Mostrar ejemplo de usuario de Informática
echo "\n9. Ejemplo de usuario Informática:\n";
$userInformatica = DB::table('Nomenclador Usuarios as u')
    ->join('Nomenclador Areas as a', 'u.id_area', '=', 'a.`Id Area`')
    ->where('a.Area', 'Informatica')
    ->select('u.Usuario', 'u.`Nombre completo`', 'a.Area')
    ->first();

if ($userInformatica) {
    echo "  Usuario: {$userInformatica->Usuario}\n";
    echo "  Nombre: {$userInformatica->{'Nombre completo'}}\n";
    echo "  Área: {$userInformatica->Area}\n";
    echo "  Este usuario debería ver TODOS los módulos\n";
}

// 10. Instrucciones finales
echo "\n10. Para probar el sistema:\n";
echo "  a) Inicia sesión con un usuario de Informática\n";
echo "  b) Deberías ver todos los menús\n";
echo "  c) Inicia sesión con un usuario de otra área\n";
echo "  d) Solo deberías ver los módulos permitidos\n";