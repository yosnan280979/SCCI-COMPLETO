@extends('layouts.app')

@section('title', 'Contratos Suministro')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Contratos Suministro</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('contratos-suministro.create') }}" class="btn btn-primary btn-sm">➕ Crear Contrato</a>
                <!-- Formularios de exportación CORREGIDOS: method="GET" -->
                <form id="exportExcelForm" method="GET" action="{{ route('contratos-suministro.export.excel') }}" style="display: inline">
                    @csrf
                    <input type="hidden" name="selected" id="exportExcelSelected" value="">
                    <input type="hidden" name="No_Ctto" value="{{ request('No_Ctto') }}">
                    <input type="hidden" name="Cliente" value="{{ request('Cliente') }}">
                    <input type="hidden" name="Descripcion" value="{{ request('Descripcion') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                <form id="exportPdfForm" method="GET" action="{{ route('contratos-suministro.export.pdf') }}" style="display: inline">
                    @csrf
                    <input type="hidden" name="selected" id="exportPdfSelected" value="">
                    <input type="hidden" name="No_Ctto" value="{{ request('No_Ctto') }}">
                    <input type="hidden" name="Cliente" value="{{ request('Cliente') }}">
                    <input type="hidden" name="Descripcion" value="{{ request('Descripcion') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                <form id="printForm" method="GET" action="{{ route('contratos-suministro.print') }}" style="display: inline" target="_blank">
                    @csrf
                    <input type="hidden" name="selected" id="printSelected" value="">
                    <input type="hidden" name="No_Ctto" value="{{ request('No_Ctto') }}">
                    <input type="hidden" name="Cliente" value="{{ request('Cliente') }}">
                    <input type="hidden" name="Descripcion" value="{{ request('Descripcion') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif

            <!-- Buscador con filtros -->
            <form method="GET" action="{{ route('contratos-suministro.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" name="No_Ctto" value="{{ request('No_Ctto') }}" class="form-control" placeholder="No. Contrato">
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="Cliente" value="{{ request('Cliente') }}" class="form-control" placeholder="Cliente">
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="Descripcion" value="{{ request('Descripcion') }}" class="form-control" placeholder="Descripción">
                    </div>
                    <div class="col-md-3">
                        <select name="sort_by" class="form-select">
                            <option value="">Ordenar por</option>
                            <option value="Id Cttosuministro" {{ request('sort_by') == 'Id Cttosuministro' ? 'selected' : '' }}>
                                ID
                            </option>
                            <option value="No Ctto Suministro" {{ request('sort_by') == 'No Ctto Suministro' ? 'selected' : '' }}>
                                No. Contrato
                            </option>
                            <option value="Cliente" {{ request('sort_by') == 'Cliente' ? 'selected' : '' }}>
                                Cliente
                            </option>
                            <option value="Descripcion" {{ request('sort_by') == 'Descripcion' ? 'selected' : '' }}>
                                Descripción
                            </option>
                        </select>
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <select name="sort_dir" class="form-select">
                            <option value="desc" {{ request('sort_dir', 'desc') == 'desc' ? 'selected' : '' }}>
                                Descendente
                            </option>
                            <option value="asc" {{ request('sort_dir') == 'asc' ? 'selected' : '' }}>
                                Ascendente
                            </option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('contratos-suministro.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
            </form>

            @if($items->isEmpty())
                <div class="alert alert-info">No hay contratos registrados.</div>
            @else
                <!-- Formulario para eliminación múltiple (DELETE) -->
                <form id="deleteMultipleForm" method="POST" action="{{ route('contratos-suministro.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-sm align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="selectAll">
                                    </th>
                                    <th>
                                        <a href="{{ route('contratos-suministro.index', array_merge(request()->except(['sort_by', 'sort_dir']), ['sort_by' => 'Id Cttosuministro', 'sort_dir' => request('sort_by') == 'Id Cttosuministro' && request('sort_dir', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            ID
                                            @if(request('sort_by') == 'Id Cttosuministro')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>
                                        <a href="{{ route('contratos-suministro.index', array_merge(request()->except(['sort_by', 'sort_dir']), ['sort_by' => 'No Ctto Suministro', 'sort_dir' => request('sort_by') == 'No Ctto Suministro' && request('sort_dir', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            No. Ctto Suministro
                                            @if(request('sort_by') == 'No Ctto Suministro')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>
                                        <a href="{{ route('contratos-suministro.index', array_merge(request()->except(['sort_by', 'sort_dir']), ['sort_by' => 'Cliente', 'sort_dir' => request('sort_by') == 'Cliente' && request('sort_dir', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            Cliente
                                            @if(request('sort_by') == 'Cliente')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>
                                        <a href="{{ route('contratos-suministro.index', array_merge(request()->except(['sort_by', 'sort_dir']), ['sort_by' => 'Descripcion', 'sort_dir' => request('sort_by') == 'Descripcion' && request('sort_dir', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            Descripción
                                            @if(request('sort_by') == 'Descripcion')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>Observaciones</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($items as $item)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="ids[]" value="{{ $item->{'Id Cttosuministro'} }}" class="select-item">
                                        </td>
                                        <td>{{ $item->{'Id Cttosuministro'} }}</td>
                                        <td>{{ $item->{'No Ctto Suministro'} }}</td>
                                        <td>{{ $item->cliente->Cliente ?? 'N/A' }}</td>
                                        <td>{{ Str::limit($item->Descripcion, 30) }}</td>
                                        <td>{{ Str::limit($item->{'Observaciones Ctto Sum'}, 20) }}</td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('contratos-suministro.show', $item->{'Id Cttosuministro'}) }}" class="btn btn-info btn-sm">Ver</a>
                                                <a href="{{ route('contratos-suministro.edit', $item->{'Id Cttosuministro'}) }}" class="btn btn-warning btn-sm">Editar</a>
                                                <form action="{{ route('contratos-suministro.destroy', $item->{'Id Cttosuministro'}) }}" method="POST" style="display:inline-block;">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Está seguro?')">Eliminar</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            @if($items->isNotEmpty())
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="4" class="text-end"><strong>Totales:</strong></td>
                                    <td colspan="3"><strong>{{ $items->count() }} registros</strong></td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar los contratos seleccionados?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación -->
                @if($items->hasPages())
                    @php 
                        $queryParams = request()->except('page');
                        $queryString = http_build_query($queryParams);
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $items->firstItem() }}–{{ $items->lastItem() }} de {{ $items->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    <a class="page-link" href="{{ $items->url(1) }}?{{ $queryString }}">« Primera</a>
                                </li>
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    <a class="page-link" href="{{ $items->previousPageUrl() }}?{{ $queryString }}">‹</a>
                                </li>
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $items->currentPage() }} de {{ $items->lastPage() }}</span>
                                </li>
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    <a class="page-link" href="{{ $items->nextPageUrl() }}?{{ $queryString }}">›</a>
                                </li>
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    <a class="page-link" href="{{ $items->url($items->lastPage()) }}?{{ $queryString }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar exportSelected cuando cambian las selecciones
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportExcelSelected').value = selectedString;
        document.getElementById('exportPdfSelected').value = selectedString;
        document.getElementById('printSelected').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
});
</script>
@endsection