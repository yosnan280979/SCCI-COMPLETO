@extends('layouts.app')

@section('title', 'Crear Classification')
@section('header', 'Crear Classification')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Crear Classification</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('nomencladores.classifications.store') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="Clasificacion" class="col-md-4 col-form-label text-md-right">Clasificacion</label>

                            <div class="col-md-6">
                                <input id="Clasificacion" type="text" class="form-control @error('Clasificacion') is-invalid @enderror" name="Clasificacion" value="{{ old('Clasificacion') }}" required autocomplete="Clasificacion" autofocus>

                                @error('Clasificacion')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="Con Valor Ctto" class="col-md-4 col-form-label text-md-right">Con Valor Ctto</label>

                            <div class="col-md-6">
                                <select id="Con Valor Ctto" class="form-control @error('Con Valor Ctto') is-invalid @enderror" name="Con Valor Ctto" >
                                    <option value="1" {{ old('Con Valor Ctto') == 1 ? 'selected' : '' }}>Sí</option>
                                    <option value="0" {{ old('Con Valor Ctto') == 0 ? 'selected' : '' }}>No</option>
                                </select>

                                @error('Con Valor Ctto')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="Orden" class="col-md-4 col-form-label text-md-right">Orden</label>

                            <div class="col-md-6">
                                <input id="Orden" type="number" step="0.01" class="form-control @error('Orden') is-invalid @enderror" name="Orden" value="{{ old('Orden') }}" >

                                @error('Orden')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Crear classification
                                </button>
                                <a href="{{ route('nomencladores.classifications.index') }}" class="btn btn-secondary">Cancelar</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection