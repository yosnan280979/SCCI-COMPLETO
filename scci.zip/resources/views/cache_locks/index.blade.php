@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="card-title">Cache Locks</h3>
                        <div>
                            <a href="{{ route('cache_locks.create') }}" class="btn btn-primary">
                                <i class="fas fa-plus"></i> Nuevo Cache_lock
                            </a>
                            <a href="{{ route('cache_locks.export.excel') }}" class="btn btn-success">
                                <i class="fas fa-file-export"></i> Exportar Excel
                            </a>
                            <a href="{{ route('cache_locks.export.pdf') }}" class="btn btn-danger" target="_blank">
                                <i class="fas fa-file-pdf"></i> PDF
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="cache_locks-table" class="table table-bordered table-hover">
                            <!-- Contenido de la tabla -->
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection