@extends('layouts.app')

@section('title', 'Editar Certificado de Compra')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Editar Certificado de Compra #{{ $item->{'Id CC'} }}</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('datos-cc.update', $item->{'Id CC'}) }}" method="POST">
                @csrf
                @method('PUT')
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="No_CC" class="form-label">No. CC</label>
                            <input type="text" class="form-control" id="No_CC" name="No_CC" 
                                   value="{{ old('No_CC', $item->{'No CC'}) }}">
                        </div>
                        
                        <div class="mb-3">
                            <label for="Id_SOE" class="form-label">SOE</label>
                            <select class="form-control" id="Id_SOE" name="Id_SOE">
                                <option value="">Seleccionar SOE</option>
                                @foreach($soes as $soe)
                                    <option value="{{ $soe->{'Id SOE'} }}" 
                                        {{ old('Id_SOE', $item->{'Id SOE'}) == $soe->{'Id SOE'} ? 'selected' : '' }}>
                                        {{ $soe->{'Id SOE'} }} - {{ $soe->{'No Referencia'} ?? 'Sin referencia' }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="Id_Moneda" class="form-label">Moneda</label>
                            <select class="form-control" id="Id_Moneda" name="Id_Moneda">
                                <option value="">Seleccionar Moneda</option>
                                @foreach($monedas as $moneda)
                                    <option value="{{ $moneda->{'Id Moneda'} }}" 
                                        {{ old('Id_Moneda', $item->{'Id Moneda'}) == $moneda->{'Id Moneda'} ? 'selected' : '' }}>
                                        {{ $moneda->Moneda }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="Valor_CC" class="form-label">Valor CC</label>
                            <input type="number" step="0.01" class="form-control" id="Valor_CC" name="Valor_CC" 
                                   value="{{ old('Valor_CC', $item->{'Valor CC'}) }}">
                        </div>
                        
                        <div class="mb-3">
                            <label for="Id_Capacidad" class="form-label">Capacidad</label>
                            <select class="form-control" id="Id_Capacidad" name="Id_Capacidad">
                                <option value="">Seleccionar Capacidad</option>
                                @foreach($capacidades as $capacidad)
                                    <option value="{{ $capacidad->{'Id Capacidad'} }}" 
                                        {{ old('Id_Capacidad', $item->{'Id Capacidad'}) == $capacidad->{'Id Capacidad'} ? 'selected' : '' }}>
                                        {{ $capacidad->Capacidad }} - {{ $capacidad->Descripcion }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="Fecha_Pedido_Cap" class="form-label">Fecha Pedido Capacidad</label>
                            <input type="date" class="form-control" id="Fecha_Pedido_Cap" name="Fecha_Pedido_Cap" 
                                   value="{{ old('Fecha_Pedido_Cap', $item->{'Fecha Pedido Cap'} ? \Carbon\Carbon::parse($item->{'Fecha Pedido Cap'})->format('Y-m-d') : '') }}">
                        </div>
                        
                        <div class="mb-3">
                            <label for="Fecha_Asignada_Cap" class="form-label">Fecha Asignada Capacidad</label>
                            <input type="date" class="form-control" id="Fecha_Asignada_Cap" name="Fecha_Asignada_Cap" 
                                   value="{{ old('Fecha_Asignada_Cap', $item->{'Fecha Asignada Cap'} ? \Carbon\Carbon::parse($item->{'Fecha Asignada Cap'})->format('Y-m-d') : '') }}">
                        </div>
                        
                        <div class="mb-3">
                            <label for="Fecha_Presentada_CC" class="form-label">Fecha Presentada CC</label>
                            <input type="date" class="form-control" id="Fecha_Presentada_CC" name="Fecha_Presentada_CC" 
                                   value="{{ old('Fecha_Presentada_CC', $item->{'Fecha Presentada CC'} ? \Carbon\Carbon::parse($item->{'Fecha Presentada CC'})->format('Y-m-d') : '') }}">
                        </div>
                        
                        <div class="mb-3">
                            <label for="Fecha_Apertura_CC" class="form-label">Fecha Apertura CC</label>
                            <input type="date" class="form-control" id="Fecha_Apertura_CC" name="Fecha_Apertura_CC" 
                                   value="{{ old('Fecha_Apertura_CC', $item->{'Fecha Apertura CC'} ? \Carbon\Carbon::parse($item->{'Fecha Apertura CC'})->format('Y-m-d') : '') }}">
                        </div>
                        
                        <div class="mb-3">
                            <label for="Id_MomentoCC" class="form-label">Momento CC</label>
                            <select class="form-control" id="Id_MomentoCC" name="Id_MomentoCC">
                                <option value="">Seleccionar Momento CC</option>
                                @foreach($momentosCC as $momento)
                                    <option value="{{ $momento->{'Id MomentoCC'} }}" 
                                        {{ old('Id_MomentoCC', $item->{'Id MomentoCC'}) == $momento->{'Id MomentoCC'} ? 'selected' : '' }}>
                                        {{ $momento->{'Momento CC'} }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="Año_finan" class="form-label">Año Financiero</label>
                            <input type="number" class="form-control" id="Año_finan" name="Año_finan" 
                                   value="{{ old('Año_finan', $item->{'Año finan'}) }}">
                        </div>
                        
                        <div class="mb-3">
                            <label for="Id_Linea_credito" class="form-label">Línea de Crédito</label>
                            <select class="form-control" id="Id_Linea_credito" name="Id_Linea_credito">
                                <option value="">Seleccionar Línea de Crédito</option>
                                @foreach($lineasCredito as $linea)
                                    <option value="{{ $linea->{'Id Lineacredito'} }}" 
                                        {{ old('Id_Linea_credito', $item->{'Id Linea credito'}) == $linea->{'Id Lineacredito'} ? 'selected' : '' }}>
                                        {{ $linea->{'Linea de Crédito'} }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="Observaciones_CC" class="form-label">Observaciones</label>
                    <textarea class="form-control" id="Observaciones_CC" name="Observaciones_CC" rows="3">{{ old('Observaciones_CC', $item->{'Observaciones CC'}) }}</textarea>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="{{ route('datos-cc.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Actualizar Certificado</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection