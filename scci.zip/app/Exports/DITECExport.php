<?php

namespace App\Exports;

use App\Models\DITEC;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class DITECExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $ditecs;

    public function __construct($ditecs)
    {
        $this->ditecs = $ditecs;
    }

    public function collection()
    {
        return $this->ditecs;
    }

    public function headings(): array
    {
        return [
            'ID',
            'No DITEC',
            'Renueva',
            'Fecha Otorgamiento',
            'Producto',
            'Fabricante',
            'Id País',
            'Vencido',
            'En renovacion',
            'Suministrador',
        ];
    }

    public function map($ditec): array
    {
        return [
            $ditec->{'Id Ditec'},
            $ditec->{'No DITEC'},
            $ditec->Renueva,
            $ditec->{'Fecha Otorgamiento'} ? \Carbon\Carbon::parse($ditec->{'Fecha Otorgamiento'})->format('d/m/Y') : '',
            $ditec->{'Producto'},
            $ditec->{'Fabricante'},
            $ditec->{'Id País'},
            $ditec->Vencido ? 'Sí' : 'No',
            $ditec->{'En renovacion'} ? 'Sí' : 'No',
            $ditec->{'Suministrador'},
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}