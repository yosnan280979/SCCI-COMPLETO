<?php

namespace App\Exports;

use App\Models\Solicitud;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class SolicitudesExport implements FromCollection, WithHeadings, WithMapping
{
    protected $solicitudes;
    
    public function __construct($solicitudes)
    {
        $this->solicitudes = $solicitudes;
    }
    
    public function collection()
    {
        return $this->solicitudes;
    }
    
    public function headings(): array
    {
        return [
            'ID',
            'No. Solicitud',
            'Fecha Solicitud',
            'Cliente',
            'Especialista',
            'Centro de Balance',
            'Observaciones'
        ];
    }
    
    public function map($solicitud): array
    {
        return [
            $solicitud->{'Id Solicitud'},
            $solicitud->{'No Solicitud'},
            $solicitud->{'Fecha Solicitud'} ? \Carbon\Carbon::parse($solicitud->{'Fecha Solicitud'})->format('d/m/Y') : '',
            $solicitud->cliente?->{'Cliente'} ?? '---',
            $solicitud->especialista?->{'Especialista'} ?? '---',
            $solicitud->balanceCenter?->{'Centro Balance'} ?? '---',
            $solicitud->{'Observaciones'} ?? ''
        ];
    }
}