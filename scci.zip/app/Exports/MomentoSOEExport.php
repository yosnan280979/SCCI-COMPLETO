<?php

namespace App\Exports;

use App\Models\MomentoSOE;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class MomentoSOEExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $momentosSOE;

    public function __construct($momentosSOE)
    {
        $this->momentosSOE = $momentosSOE;
    }

    public function collection()
    {
        return $this->momentosSOE;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Momento SOE',
        ];
    }

    public function map($momentoSOE): array
    {
        return [
            $momentoSOE->{'Id MomentoSOE'},
            $momentoSOE->{'Momento SOE'},
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}