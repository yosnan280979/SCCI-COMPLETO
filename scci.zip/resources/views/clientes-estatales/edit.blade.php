@extends('layouts.app')

@section('title', 'Editar Cliente Estatal')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Editar Cliente Estatal</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('clientes-estatales.update', $item->id) }}" method="POST">
                @csrf
                @method('PUT')
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="ministerio" class="form-label">Ministerio</label>
                        <select class="form-select" id="ministerio" name="ministerio">
                            <option value="">Seleccionar Ministerio</option>
                            <option value="MICONS" {{ old('ministerio', $item->ministerio) == 'MICONS' ? 'selected' : '' }}>MICONS</option>
                            <option value="MINAG" {{ old('ministerio', $item->ministerio) == 'MINAG' ? 'selected' : '' }}>MINAG</option>
                            <option value="MES" {{ old('ministerio', $item->ministerio) == 'MES' ? 'selected' : '' }}>MES</option>
                            <option value="MINSAP" {{ old('ministerio', $item->ministerio) == 'MINSAP' ? 'selected' : '' }}>MINSAP</option>
                            <option value="OTROS" {{ old('ministerio', $item->ministerio) == 'OTROS' ? 'selected' : '' }}>OTROS</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="nombre_empresa" class="form-label">Nombre de la Empresa *</label>
                        <input type="text" name="nombre_empresa" class="form-control" required value="{{ old('nombre_empresa', $item->nombre_empresa) }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="codigo_nit" class="form-label">Código NIT / REEUP</label>
                        <input type="text" name="codigo_nit" class="form-control" value="{{ old('codigo_nit', $item->codigo_nit) }}">
                    </div>
                    <div class="col-md-6">
                        <label for="red_creacion" class="form-label">Resolución Creación</label>
                        <input type="text" name="resolucion_creacion" class="form-control" value="{{ old('resolucion_creacion', $item->resolucion_creacion) }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-12">
                        <label for="direccion" class="form-label">Dirección</label>
                        <input type="text" name="direccion" class="form-control" value="{{ old('direccion', $item->direccion) }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="telefono" class="form-label">Teléfonos</label>
                        <input type="text" name="telefono" class="form-control" cantidad texto" value="{{ old('telefono', $item->telefono) }}">
                    </div>
                    <div class="col-md-6">
                        <label for="nombre_director" class="form-label">Nombre Director(a)</label>
                        <input type="text" name="nombre_director" class="form-control" value="{{ old('nombre_director', $item->nombre_director) }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" value="{{ old('email', $item->email) }}">
                    </div>
                    
                    <div class="col-md-6">
                        <label for="resolucion_director" class="form-label">Resolución Director(a)</label>
                        <input type="text" name="resolucion_director" class="form-control" value="{{ old('resolucion_director', $item->resolucion_director) }}">
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-12">
                        <label for="cuentas_bancarias" class="form-label">Cuentas Bancarias</label>
                        <textarea name="cuentas_bancarias" class="form-control" rows="2">{{ old('cuentas_bancarias', $item->cuentas_bancarias) }}</textarea>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-12">
                        <label for="convenios_firmados" class="form-label">Convenios Firmados</label>
                        <textarea name="convenios_firmados" class="form-control" rows="2">{{ old('convenios_firmados', $item->convenios_firmados) }}</textarea>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-12">
                        <h6>Historial por Año</h6>
                        <hr>
                    </div>
                    <div class="row">
                        @for($i = 2020; $i <= 2026; $i++)
                        <div class="col-md-3">
                            <label class="form-label">Año {{ $i }}</label>
                            <input type="text" name="anno_{{ $i }}" class="form-control" placeholder="Activo / Inactivo" value="{{ old("anno_$i", $item->{"anno_$i"}) }}">
                        </div>
                        @endfor
                    </div>
                </div>
                
                <div class="d-flex justify-content-end mt-4">
                    <a href="{{ route('clientes-estatales.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Actualizar Cliente</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection