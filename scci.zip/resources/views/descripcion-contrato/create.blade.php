@extends('layouts.app')

@section('title', 'Crear ContratoDescription')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Crear Nuevo ContratoDescription</h3>
                    <div class="card-tools">
                        <a href="{{ route('descripcion-contrato.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    </div>
                </div>
                <form action="{{ route('descripcion-contrato.store') }}" method="POST">
                    @csrf
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                                        <div class="form-group">
                            <label for="solicitud_id">Solicitud ID</label>
                            <input type="number" class="form-control @error('solicitud_id') is-invalid @enderror" 
                                   id="solicitud_id" name="solicitud_id" value="{{ old('solicitud_id') }}" >
                            @error('solicitud_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>                        <div class="form-group">
                            <label for="contrato_id">Contrato ID</label>
                            <input type="number" class="form-control @error('contrato_id') is-invalid @enderror" 
                                   id="contrato_id" name="contrato_id" value="{{ old('contrato_id') }}" >
                            @error('contrato_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>                        <div class="form-group">
                            <label for="producto">Producto</label>
                            <input type="text" class="form-control @error('producto') is-invalid @enderror" 
                                   id="producto" name="producto" value="{{ old('producto') }}" >
                            @error('producto')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>                        <div class="form-group">
                            <label for="unidad_medida">Unidad Medida</label>
                            <input type="text" class="form-control @error('unidad_medida') is-invalid @enderror" 
                                   id="unidad_medida" name="unidad_medida" value="{{ old('unidad_medida') }}" >
                            @error('unidad_medida')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>                        <div class="form-group">
                            <label for="cantidad">Cantidad</label>
                            <input type="number" class="form-control @error('cantidad') is-invalid @enderror" 
                                   id="cantidad" name="cantidad" value="{{ old('cantidad') }}" >
                            @error('cantidad')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>                        <div class="form-group">
                            <label for="precio_cuc">Precio CUC</label>
                            <input type="number" class="form-control @error('precio_cuc') is-invalid @enderror" 
                                   id="precio_cuc" name="precio_cuc" value="{{ old('precio_cuc') }}" >
                            @error('precio_cuc')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>                        <div class="form-group">
                            <label for="precio_moneda_prov">Precio Moneda Proveedor</label>
                            <input type="number" class="form-control @error('precio_moneda_prov') is-invalid @enderror" 
                                   id="precio_moneda_prov" name="precio_moneda_prov" value="{{ old('precio_moneda_prov') }}" >
                            @error('precio_moneda_prov')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>                        <div class="form-group">
                            <label for="moneda_id">Moneda ID</label>
                            <input type="number" class="form-control @error('moneda_id') is-invalid @enderror" 
                                   id="moneda_id" name="moneda_id" value="{{ old('moneda_id') }}" >
                            @error('moneda_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Guardar
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <i class="fas fa-redo"></i> Limpiar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection