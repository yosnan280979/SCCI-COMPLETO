<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ProveedorEmpImpExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $relaciones;

    public function __construct($relaciones)
    {
        $this->relaciones = $relaciones;
    }

    public function collection()
    {
        return $this->relaciones;
    }

    public function headings(): array
    {
        return [
            'ID',
            'ID Proveedor',
            'Proveedor',
            'ID Empresa Importadora',
            'Empresa Importadora'
        ];
    }

    public function map($relacion): array
    {
        return [
            $relacion->Id,
            $relacion->Id_Proveedor,
            $relacion->proveedor ? $relacion->proveedor->Proveedor : '',
            $relacion->Id_EmpresaImportadora,
            $relacion->empresaImportadora ? $relacion->empresaImportadora->{'Empresa Importadora'} : ''
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1    => ['font' => ['bold' => true]],
        ];
    }
}