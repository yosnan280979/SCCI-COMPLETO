<?php

namespace App\Exports;

use App\Models\Reclamacion;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class ReclamacionesExport implements FromCollection, WithHeadings, WithMapping
{
    public function collection()
    {
        return Reclamacion::all();
    }

    public function headings(): array
    {
        return [
            'ID',
            'Embarque',
            'Descripción',
        ];
    }

    public function map($item): array
    {
        return [
            $item->Id_Reclamacion ?? $item->id,
            $item->Id_embarque,
            $item->Descripcion,
        ];
    }
}
