<?php

namespace App\Exports;

use App\Models\DatosSOE;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class DatosSOEExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $datosSOE;

    public function __construct($datosSOE)
    {
        $this->datosSOE = $datosSOE;
    }

    public function collection()
    {
        return $this->datosSOE;
    }

    public function headings(): array
    {
        return [
            'ID SOE',
            'ID Contrato',
            'No. Contrato',
            'No. Suplemento',
            'Fecha Comité',
            'No. Acta',
            'No. Acuerdo',
            'Valor Mercancía',
            'Valor Contrato CUC',
            'Valor Moneda Proveedor',
            'No. Referencia',
            'Fecha CAD Gescons',
            'Fecha CAD MICONS',
            'No. Acta MICONS',
            'Fecha Firma Contrato',
            'Fecha Emisión Certificado',
            'Pendiente CUC',
            'Pendiente CUP',
            'Total Embarques',
            'Cancelado SOE',
            'Forma de Pago',
            'Anular Valores',
            'Año Financiero',
            'Observaciones',
        ];
    }

    public function map($datosSOE): array
    {
        return [
            $datosSOE->{'Id SOE'},
            $datosSOE->{'Id Ctto'},
            $datosSOE->contrato?->{'No Ctto'} ?? 'N/A',
            $datosSOE->{'No Suplemento'},
            $datosSOE->{'Fecha Comite'} ? \Carbon\Carbon::parse($datosSOE->{'Fecha Comite'})->format('d/m/Y') : '',
            $datosSOE->{'No Acta'},
            $datosSOE->{'No Acuerdo'},
            $datosSOE->{'Valor Mercancia'},
            $datosSOE->{'Valor Ctto CUC'},
            $datosSOE->{'Valor Mon Prov'},
            $datosSOE->{'No Referencia'},
            $datosSOE->{'Fecha CAD Gescons'} ? \Carbon\Carbon::parse($datosSOE->{'Fecha CAD Gescons'})->format('d/m/Y') : '',
            $datosSOE->{'Fecha CAD MICONS'} ? \Carbon\Carbon::parse($datosSOE->{'Fecha CAD MICONS'})->format('d/m/Y') : '',
            $datosSOE->{'No Acta MICONS'},
            $datosSOE->{'Fecha firma Ctto'} ? \Carbon\Carbon::parse($datosSOE->{'Fecha firma Ctto'})->format('d/m/Y') : '',
            $datosSOE->{'Fecha emision certif'} ? \Carbon\Carbon::parse($datosSOE->{'Fecha emision certif'})->format('d/m/Y') : '',
            $datosSOE->{'Pendiente finan CUC'},
            $datosSOE->{'Pendiente finan CUP'},
            $datosSOE->{'Total embarques'},
            $datosSOE->{'Cancelado SOE'} ? 'Sí' : 'No',
            $datosSOE->{'Forma de Pago'},
            $datosSOE->{'Anular Valores'} ? 'Sí' : 'No',
            $datosSOE->{'Año finan'},
            $datosSOE->{'Observaciones'},
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}