<div class="btn-group" role="group">
    <a href="{{ route('asigporsolic.show', $asig_por_solic->id) }}" class="btn btn-info btn-sm">
        <i class="fas fa-eye"></i>
    </a>
    <a href="{{ route('asigporsolic.edit', $asig_por_solic->id) }}" class="btn btn-warning btn-sm">
        <i class="fas fa-edit"></i>
    </a>
    <form action="{{ route('asigporsolic.destroy', $asig_por_solic->id) }}" method="POST" class="d-inline delete-form">
        @csrf
        @method('DELETE')
        <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="{{ $asig_por_solic->id }}">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>