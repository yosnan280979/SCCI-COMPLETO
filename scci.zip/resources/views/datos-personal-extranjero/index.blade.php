@extends('layouts.app')

@section('title', 'Personal Extranjero')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Personal Extranjero</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('datos-personal-extranjero.create') }}" class="btn btn-primary btn-sm">➕ Nuevo</a>
                <!-- Formularios de exportación separados (GET) - ELIMINADO @csrf -->
                <form id="exportExcelForm" method="GET" action="{{ route('datos-personal-extranjero.export.excel') }}" style="display: inline">
                    <input type="hidden" name="selected" id="exportExcelSelected" value="">
                    <!-- Campos de filtros como hidden -->
                    <input type="hidden" name="Funcionario_extranjero" value="{{ request('Funcionario_extranjero') }}">
                    <input type="hidden" name="Cargo" value="{{ request('Cargo') }}">
                    <input type="hidden" name="Email" value="{{ request('Email') }}">
                    <input type="hidden" name="Telef" value="{{ request('Telef') }}">
                    <input type="hidden" name="Activo" value="{{ request('Activo') }}">
                    <input type="hidden" name="Firmante" value="{{ request('Firmante') }}">
                    <input type="hidden" name="Id_proveedor" value="{{ request('Id_proveedor') }}">
                    <input type="hidden" name="Permiso_de_Trabajo" value="{{ request('Permiso_de_Trabajo') }}">
                    <input type="hidden" name="Id_pais" value="{{ request('Id_pais') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                <form id="exportPdfForm" method="GET" action="{{ route('datos-personal-extranjero.export.pdf') }}" style="display: inline">
                    <input type="hidden" name="selected" id="exportPdfSelected" value="">
                    <!-- Campos de filtros como hidden -->
                    <input type="hidden" name="Funcionario_extranjero" value="{{ request('Funcionario_extranjero') }}">
                    <input type="hidden" name="Cargo" value="{{ request('Cargo') }}">
                    <input type="hidden" name="Email" value="{{ request('Email') }}">
                    <input type="hidden" name="Telef" value="{{ request('Telef') }}">
                    <input type="hidden" name="Activo" value="{{ request('Activo') }}">
                    <input type="hidden" name="Firmante" value="{{ request('Firmante') }}">
                    <input type="hidden" name="Id_proveedor" value="{{ request('Id_proveedor') }}">
                    <input type="hidden" name="Permiso_de_Trabajo" value="{{ request('Permiso_de_Trabajo') }}">
                    <input type="hidden" name="Id_pais" value="{{ request('Id_pais') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                <form id="printForm" method="GET" action="{{ route('datos-personal-extranjero.print') }}" style="display: inline" target="_blank">
                    <input type="hidden" name="selected" id="printSelected" value="">
                    <!-- Campos de filtros como hidden -->
                    <input type="hidden" name="Funcionario_extranjero" value="{{ request('Funcionario_extranjero') }}">
                    <input type="hidden" name="Cargo" value="{{ request('Cargo') }}">
                    <input type="hidden" name="Email" value="{{ request('Email') }}">
                    <input type="hidden" name="Telef" value="{{ request('Telef') }}">
                    <input type="hidden" name="Activo" value="{{ request('Activo') }}">
                    <input type="hidden" name="Firmante" value="{{ request('Firmante') }}">
                    <input type="hidden" name="Id_proveedor" value="{{ request('Id_proveedor') }}">
                    <input type="hidden" name="Permiso_de_Trabajo" value="{{ request('Permiso_de_Trabajo') }}">
                    <input type="hidden" name="Id_pais" value="{{ request('Id_pais') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Filtros -->
            <form method="GET" action="{{ route('datos-personal-extranjero.index') }}" class="mb-3" id="filterForm">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" name="Funcionario_extranjero" value="{{ request('Funcionario_extranjero') }}" class="form-control" placeholder="Funcionario">
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="Cargo" value="{{ request('Cargo') }}" class="form-control" placeholder="Cargo">
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="Email" value="{{ request('Email') }}" class="form-control" placeholder="Email">
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="Telef" value="{{ request('Telef') }}" class="form-control" placeholder="Teléfono">
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <select name="Activo" class="form-select">
                            <option value="">Activo</option>
                            <option value="1" {{ request('Activo') == '1' ? 'selected' : '' }}>Sí</option>
                            <option value="0" {{ request('Activo') == '0' ? 'selected' : '' }}>No</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="Firmante" class="form-select">
                            <option value="">Firmante</option>
                            <option value="1" {{ request('Firmante') == '1' ? 'selected' : '' }}>Sí</option>
                            <option value="0" {{ request('Firmante') == '0' ? 'selected' : '' }}>No</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="Permiso_de_Trabajo" value="{{ request('Permiso_de_Trabajo') }}" class="form-control" placeholder="Permiso de Trabajo">
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="Id_pais" value="{{ request('Id_pais') }}" class="form-control" placeholder="ID País">
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    @if(isset($proveedores) && $proveedores->count() > 0)
                    <div class="col-md-4">
                        <select name="Id_proveedor" class="form-select">
                            <option value="">Proveedor</option>
                            @foreach($proveedores as $prov)
                                <option value="{{ $prov->{'Id Proveedor'} }}" {{ request('Id_proveedor') == $prov->{'Id Proveedor'} ? 'selected' : '' }}>
                                    {{ $prov->Proveedor }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    @endif
                    <div class="col-md-3">
                        <select name="sort_by" class="form-select">
                            <option value="">Ordenar por</option>
                            <option value="Id" {{ request('sort_by') == 'Id' ? 'selected' : '' }}>ID</option>
                            <option value="Funcionario_extranjero" {{ request('sort_by') == 'Funcionario_extranjero' ? 'selected' : '' }}>Funcionario</option>
                            <option value="Cargo" {{ request('sort_by') == 'Cargo' ? 'selected' : '' }}>Cargo</option>
                            <option value="Email" {{ request('sort_by') == 'Email' ? 'selected' : '' }}>Email</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="sort_dir" class="form-select">
                            <option value="desc" {{ request('sort_dir', 'desc') == 'desc' ? 'selected' : '' }}>Descendente</option>
                            <option value="asc" {{ request('sort_dir') == 'asc' ? 'selected' : '' }}>Ascendente</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('datos-personal-extranjero.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
            </form>

            @if($items->isEmpty())
                <div class="alert alert-info">No hay registros de personal extranjero.</div>
            @else
                <!-- Formulario principal para eliminación múltiple (DELETE) -->
                <form id="bulkForm" method="POST" action="{{ route('datos-personal-extranjero.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <!-- Tabla con scroll horizontal -->
                    <div class="table-responsive" style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
                        <table class="table table-bordered table-hover table-sm align-middle" style="min-width: 1800px;">
                            <thead class="table-light">
                                <tr>
                                    <th width="50"><input type="checkbox" id="selectAll"></th>
                                    <th width="80">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Id';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Id' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-personal-extranjero.index', $queryParams) }}">
                                            ID
                                            @if(request('sort_by') == 'Id')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="150">Proveedor</th>
                                    <th width="150">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Funcionario_extranjero';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Funcionario_extranjero' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-personal-extranjero.index', $queryParams) }}">
                                            Funcionario
                                            @if(request('sort_by') == 'Funcionario_extranjero')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="150">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Cargo';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Cargo' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-personal-extranjero.index', $queryParams) }}">
                                            Cargo
                                            @if(request('sort_by') == 'Cargo')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="150">Email</th>
                                    <th width="120">Teléfono</th>
                                    <th width="100">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Activo';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Activo' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-personal-extranjero.index', $queryParams) }}">
                                            Activo
                                            @if(request('sort_by') == 'Activo')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="120">Permiso de Trabajo</th>
                                    <th width="100">ID País</th>
                                    <th width="120">Fecha Vencimiento</th>
                                    <th width="100">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Firmante';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Firmante' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-personal-extranjero.index', $queryParams) }}">
                                            Firmante
                                            @if(request('sort_by') == 'Firmante')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="100">Escnot</th>
                                    <th width="100">Aprot</th>
                                    <th width="120">Fechavenpod</th>
                                    <th width="180">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($items as $item)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="ids[]" value="{{ $item->Id }}" class="select-item">
                                        </td>
                                        <td>{{ $item->Id }}</td>
                                        <td>{{ $item->proveedor->Proveedor ?? 'N/A' }}</td>
                                        <td>{{ $item->Funcionario_extranjero }}</td>
                                        <td>{{ $item->Cargo }}</td>
                                        <td>{{ $item->Email ?? 'N/A' }}</td>
                                        <td>{{ $item->Telef ?? 'N/A' }}</td>
                                        <td class="text-center">
                                            <span class="badge bg-{{ $item->Activo ? 'success' : 'danger' }}">
                                                {{ $item->Activo ? 'Sí' : 'No' }}
                                            </span>
                                        </td>
                                        <td>{{ $item->Permiso_de_Trabajo ?? 'N/A' }}</td>
                                        <td class="text-center">{{ $item->Id_pais ?? 'N/A' }}</td>
                                        <td>{{ $item->Fecha_Vencimiento ? \Carbon\Carbon::parse($item->Fecha_Vencimiento)->format('d/m/Y') : 'N/A' }}</td>
                                        <td class="text-center">
                                            <span class="badge bg-{{ $item->Firmante ? 'success' : 'secondary' }}">
                                                {{ $item->Firmante ? 'Sí' : 'No' }}
                                            </span>
                                        </td>
                                        <td>{{ $item->Escnot ?? 'N/A' }}</td>
                                        <td class="text-center">{{ $item->Aprot ?? 'N/A' }}</td>
                                        <td>{{ $item->Fechavenpod ? \Carbon\Carbon::parse($item->Fechavenpod)->format('d/m/Y') : 'N/A' }}</td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('datos-personal-extranjero.show', $item->Id) }}" class="btn btn-info btn-sm">Ver</a>
                                                <a href="{{ route('datos-personal-extranjero.edit', $item->Id) }}" class="btn btn-warning btn-sm">Editar</a>
                                                <form action="{{ route('datos-personal-extranjero.destroy', $item->Id) }}" method="POST" style="display:inline-block;">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Está seguro?')">Eliminar</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            @if($items->isNotEmpty())
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="4" class="text-end"><strong>Totales:</strong></td>
                                    <td colspan="4"><strong>{{ $items->count() }} registros</strong></td>
                                    <td class="text-center">
                                        <strong>
                                            @php
                                                $activos = $items->where('Activo', 1)->count();
                                                $inactivos = $items->where('Activo', 0)->count();
                                            @endphp
                                            Activos: {{ $activos }}<br>
                                            Inactivos: {{ $inactivos }}
                                        </strong>
                                    </td>
                                    <td colspan="3"></td>
                                    <td class="text-center">
                                        <strong>
                                            @php
                                                $firmantes = $items->where('Firmante', 1)->count();
                                                $noFirmantes = $items->where('Firmante', 0)->count();
                                            @endphp
                                            Firmantes: {{ $firmantes }}<br>
                                            No firmantes: {{ $noFirmantes }}
                                        </strong>
                                    </td>
                                    <td colspan="3"></td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar los registros seleccionados?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación corregida -->
                @if($items->hasPages())
                    @php 
                        // Preservar todos los parámetros de búsqueda en la paginación
                        $queryParams = request()->all();
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $items->firstItem() }}–{{ $items->lastItem() }} de {{ $items->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <!-- Primera página -->
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-personal-extranjero.index', $queryParams) }}">« Primera</a>
                                </li>
                                
                                <!-- Página anterior -->
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = $items->currentPage() - 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-personal-extranjero.index', $queryParams) }}">‹</a>
                                </li>
                                
                                <!-- Página actual -->
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $items->currentPage() }} de {{ $items->lastPage() }}</span>
                                </li>
                                
                                <!-- Página siguiente -->
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $items->currentPage() + 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-personal-extranjero.index', $queryParams) }}">›</a>
                                </li>
                                
                                <!-- Última página -->
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $items->lastPage();
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-personal-extranjero.index', $queryParams) }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<style>
/* Estilos para la tabla con scroll horizontal */
.table-responsive {
    border: 1px solid #dee2e6;
    border-radius: 4px;
    margin-bottom: 1rem;
}

/* Asegurar que las celdas mantengan su tamaño */
.table th, .table td {
    white-space: nowrap;
    vertical-align: middle;
    padding: 0.5rem;
}

/* Tooltips para texto largo */
[title] {
    cursor: help;
    position: relative;
}

/* Badges con mejor espaciado */
.badge {
    padding: 0.35em 0.65em;
    font-size: 0.75em;
    font-weight: 600;
}

/* Scroll suave en móviles */
@media (max-width: 768px) {
    .table-responsive {
        -webkit-overflow-scrolling: touch;
    }
    
    .card-body {
        padding: 0.75rem;
    }
}

/* Hover para filas */
.table-hover tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.075);
}

/* Títulos de columnas */
.table th {
    font-weight: 600;
    background-color: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar exportSelected cuando cambian las selecciones
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportExcelSelected').value = selectedString;
        document.getElementById('exportPdfSelected').value = selectedString;
        document.getElementById('printSelected').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
});
</script>
@endsection