<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RoleMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string  $role
     * @return mixed
     */
    public function handle(Request $request, Closure $next, string $role): Response
    {
        // Verificar si el usuario está autenticado
        if (!auth()->check()) {
            return redirect()->route('login');
        }

        $user = auth()->user();
        
        // Asegurarse de cargar la relación userType
        if (!$user->relationLoaded('userType')) {
            $user->load('userType');
        }

        // Verificar que userType existe
        if (!$user->userType) {
            return redirect()->route('login')
                ->with('error', 'Tu tipo de usuario no está configurado.');
        }

        // Obtener el ID del tipo de usuario
        $userRoleId = $user->userType->{'Id Tipo Usuario'};

        // Verificar permisos según el rol requerido
        $allowed = false;
        $errorMessage = 'No tienes permisos para acceder a esta sección.';

        switch ($role) {
            case 'admin':
                $allowed = ($userRoleId == 1);
                $errorMessage = 'Se requieren permisos de administrador.';
                break;
                
            case 'editor':
                $allowed = in_array($userRoleId, [1, 2]);
                $errorMessage = 'Se requieren permisos de editor o administrador.';
                break;
                
            case 'lector':
                $allowed = in_array($userRoleId, [1, 2, 3]);
                $errorMessage = 'Debes estar autenticado para acceder a esta sección.';
                break;
        }

        if ($allowed) {
            return $next($request);
        }

        return redirect()->route('dashboard')
            ->with('error', $errorMessage);
    }
}