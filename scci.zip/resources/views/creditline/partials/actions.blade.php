<div class="btn-group" role="group">
    <a href="{{ route('creditline.show', $credit_line->id) }}" class="btn btn-info btn-sm">
        <i class="fas fa-eye"></i>
    </a>
    <a href="{{ route('creditline.edit', $credit_line->id) }}" class="btn btn-warning btn-sm">
        <i class="fas fa-edit"></i>
    </a>
    <form action="{{ route('creditline.destroy', $credit_line->id) }}" method="POST" class="d-inline delete-form">
        @csrf
        @method('DELETE')
        <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="{{ $credit_line->id }}">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>