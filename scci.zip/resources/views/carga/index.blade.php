@extends('layouts.app')

@section('title', 'Cargas')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Cargas</h3>
            <div class="d-flex gap-2">
                @if(auth()->user()->userType->{'Id Tipo Usuario'} != 3)
                    <a href="{{ route('cargas.create') }}" class="btn btn-primary btn-sm">➕ Nueva Carga</a>
                @endif
                <!-- Formulario para exportaciones (GET) -->
                <form id="exportForm" method="GET" action="{{ route('cargas.export.excel') }}" style="display: inline">
                    @csrf
                    <input type="hidden" name="selected" id="exportSelected" value="">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="id_tipo_carga" value="{{ request('id_tipo_carga') }}">
                    <input type="hidden" name="id_embarque" value="{{ request('id_embarque') }}">
                    <input type="hidden" name="order_by" value="{{ request('order_by') }}">
                    <input type="hidden" name="order_direction" value="{{ request('order_direction') }}">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                <form id="exportPdfForm" method="GET" action="{{ route('cargas.export.pdf') }}" style="display: inline">
                    @csrf
                    <input type="hidden" name="selected" id="exportPdfSelected" value="">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="id_tipo_carga" value="{{ request('id_tipo_carga') }}">
                    <input type="hidden" name="id_embarque" value="{{ request('id_embarque') }}">
                    <input type="hidden" name="order_by" value="{{ request('order_by') }}">
                    <input type="hidden" name="order_direction" value="{{ request('order_direction') }}">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                <form id="printForm" method="GET" action="{{ route('cargas.print') }}" style="display: inline" target="_blank">
                    @csrf
                    <input type="hidden" name="selected" id="printSelected" value="">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="id_tipo_carga" value="{{ request('id_tipo_carga') }}">
                    <input type="hidden" name="id_embarque" value="{{ request('id_embarque') }}">
                    <input type="hidden" name="order_by" value="{{ request('order_by') }}">
                    <input type="hidden" name="order_direction" value="{{ request('order_direction') }}">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Filtros -->
            <form method="GET" action="{{ route('cargas.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" name="search" value="{{ request('search') }}" class="form-control"
                               placeholder="Buscar por ID, Cantidad, Real...">
                    </div>
                    <div class="col-md-3">
                        <select name="id_tipo_carga" class="form-select">
                            <option value="">Tipo de Carga</option>
                            @foreach($tiposCarga as $tipo)
                                <option value="{{ $tipo->{'Id Tipo Carga'} }}" {{ request('id_tipo_carga') == $tipo->{'Id Tipo Carga'} ? 'selected' : '' }}>
                                    {{ $tipo->{'Tipo Carga'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="id_embarque" value="{{ request('id_embarque') }}" class="form-control"
                               placeholder="ID Embarque">
                    </div>
                    <div class="col-md-3">
                        <select name="order_by" class="form-select">
                            <option value="">Ordenar por</option>
                            <option value="Id Carga" {{ request('order_by') == 'Id Carga' ? 'selected' : '' }}>ID</option>
                            <option value="Cantidad" {{ request('order_by') == 'Cantidad' ? 'selected' : '' }}>Cantidad</option>
                            <option value="Real" {{ request('order_by') == 'Real' ? 'selected' : '' }}>Real</option>
                        </select>
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <select name="order_direction" class="form-select">
                            <option value="desc" {{ request('order_direction', 'desc') == 'desc' ? 'selected' : '' }}>Descendente</option>
                            <option value="asc" {{ request('order_direction') == 'asc' ? 'selected' : '' }}>Ascendente</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('cargas.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
            </form>

            @if($cargas->isEmpty())
                <div class="alert alert-info">No hay cargas registradas.</div>
            @else
                <!-- Formulario para eliminación múltiple (DELETE) -->
                <form id="deleteForm" method="POST" action="{{ route('cargas.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-sm align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="selectAll">
                                    </th>
                                    <th>
                                        <a href="{{ route('cargas.index', array_merge(request()->except(['order_by', 'order_direction']), ['order_by' => 'Id Carga', 'order_direction' => request('order_by') == 'Id Carga' && request('order_direction', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            ID
                                            @if(request('order_by') == 'Id Carga')
                                                @if(request('order_direction', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>Tipo Carga</th>
                                    <th>Embarque</th>
                                    <th class="text-end">
                                        <a href="{{ route('cargas.index', array_merge(request()->except(['order_by', 'order_direction']), ['order_by' => 'Cantidad', 'order_direction' => request('order_by') == 'Cantidad' && request('order_direction', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            Cantidad
                                            @if(request('order_by') == 'Cantidad')
                                                @if(request('order_direction', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th class="text-end">
                                        <a href="{{ route('cargas.index', array_merge(request()->except(['order_by', 'order_direction']), ['order_by' => 'Real', 'order_direction' => request('order_by') == 'Real' && request('order_direction', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            Real
                                            @if(request('order_by') == 'Real')
                                                @if(request('order_direction', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($cargas as $carga)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="ids[]" value="{{ $carga->{'Id Carga'} }}" class="select-item">
                                        </td>
                                        <td>{{ $carga->{'Id Carga'} }}</td>
                                        <td>{{ $carga->tipoCarga?->{'Tipo Carga'} ?? 'N/A' }}</td>
                                        <td>{{ $carga->embarque?->{'Id Embarque'} ?? 'N/A' }}</td>
                                        <td class="text-end">{{ $carga->Cantidad }}</td>
                                        <td class="text-end">{{ $carga->Real }}</td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('cargas.show', $carga->{'Id Carga'}) }}" class="btn btn-info btn-sm">Ver</a>
                                                @if(auth()->user()->userType->{'Id Tipo Usuario'} != 3)
                                                    <a href="{{ route('cargas.edit', $carga->{'Id Carga'}) }}" class="btn btn-warning btn-sm">Editar</a>
                                                    <form action="{{ route('cargas.destroy', $carga->{'Id Carga'}) }}" method="POST" style="display:inline-block;">
                                                        @csrf @method('DELETE')
                                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Está seguro de eliminar esta carga?')">Eliminar</button>
                                                    </form>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            @if($cargas->isNotEmpty())
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="4" class="text-end"><strong>Totales:</strong></td>
                                    <td class="text-end">
                                        <strong>
                                            @php
                                                $totalCantidad = $cargas->sum('Cantidad');
                                            @endphp
                                            {{ number_format($totalCantidad, 2) }}
                                        </strong>
                                    </td>
                                    <td class="text-end">
                                        <strong>
                                            @php
                                                $totalReal = $cargas->sum('Real');
                                            @endphp
                                            {{ number_format($totalReal, 2) }}
                                        </strong>
                                    </td>
                                    <td></td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    @if(auth()->user()->userType->{'Id Tipo Usuario'} != 3)
                        <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar las cargas seleccionadas?')">
                            🗑️ Eliminar Seleccionados
                        </button>
                    @endif
                </form>

                <!-- Paginación -->
                @if($cargas->hasPages())
                    @php 
                        $queryParams = request()->except('page');
                        $queryString = http_build_query($queryParams);
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $cargas->firstItem() }}–{{ $cargas->lastItem() }} de {{ $cargas->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <li class="page-item {{ $cargas->onFirstPage() ? 'disabled' : '' }}">
                                    <a class="page-link" href="{{ $cargas->url(1) }}?{{ $queryString }}">« Primera</a>
                                </li>
                                <li class="page-item {{ $cargas->onFirstPage() ? 'disabled' : '' }}">
                                    <a class="page-link" href="{{ $cargas->previousPageUrl() }}?{{ $queryString }}">‹</a>
                                </li>
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $cargas->currentPage() }} de {{ $cargas->lastPage() }}</span>
                                </li>
                                <li class="page-item {{ $cargas->hasMorePages() ? '' : 'disabled' }}">
                                    <a class="page-link" href="{{ $cargas->nextPageUrl() }}?{{ $queryString }}">›</a>
                                </li>
                                <li class="page-item {{ $cargas->hasMorePages() ? '' : 'disabled' }}">
                                    <a class="page-link" href="{{ $cargas->url($cargas->lastPage()) }}?{{ $queryString }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar exportSelected cuando cambian las selecciones
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportSelected').value = selectedString;
        document.getElementById('exportPdfSelected').value = selectedString;
        document.getElementById('printSelected').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
});
</script>
@endsection