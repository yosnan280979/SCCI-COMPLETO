<?php

use Illuminate\Support\Facades\Auth;

if (!function_exists('hasPermission')) {
    /**
     * Verifica si el usuario actual tiene un permiso específico.
     *
     * @param string $permission Permiso: 'view' | 'create' | 'edit' | 'delete'
     * @return bool
     */
    function hasPermission(string $permission): bool
    {
        $user = Auth::user();

        // Si no hay usuario autenticado
        if (!$user) {
            return false;
        }

        // El área de Informática tiene acceso total
        if ($user->area && ($user->area->Area ?? null) === 'Informatica') {
            return true;
        }

        // Tipo de usuario (1=Admin, 2=Editor, 3=Lector por defecto)
        $userType = $user->userType ? ($user->userType->{'Id Tipo Usuario'} ?? 3) : 3;
        $userArea = $user->area ? ($user->area->Area ?? null) : null;

        // Matriz de permisos por área y tipo de usuario
        $permissions = [
            'Dirección' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Comerciales' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Dir. UEB Importaciones' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Política Comercial' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'SOE' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Control Financiamientos' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Juridico' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Marketing' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Otras Areas' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Economia' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Calidad' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Exportaciones' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit'],
                3 => ['view'],
            ],
            'Informatica' => [
                1 => ['view', 'create', 'edit', 'delete'],
                2 => ['view', 'create', 'edit', 'delete'],
                3 => ['view', 'create', 'edit', 'delete'],
            ],
        ];

        return isset($permissions[$userArea][$userType]) &&
               in_array($permission, $permissions[$userArea][$userType], true);
    }
}

if (!function_exists('canView')) {
    /** Verifica si el usuario puede ver */
    function canView(): bool
    {
        return hasPermission('view');
    }
}

if (!function_exists('canEdit')) {
    /** Verifica si el usuario puede editar */
    function canEdit(): bool
    {
        return hasPermission('edit');
    }
}

if (!function_exists('canCreate')) {
    /** Verifica si el usuario puede crear */
    function canCreate(): bool
    {
        return hasPermission('create');
    }
}

if (!function_exists('canDelete')) {
    /** Verifica si el usuario puede eliminar */
    function canDelete(): bool
    {
        return hasPermission('delete');
    }
}
