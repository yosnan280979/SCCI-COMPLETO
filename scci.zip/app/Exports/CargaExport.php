<?php

namespace App\Exports;

use App\Models\Carga;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class CargaExport implements FromCollection, WithHeadings, WithMapping
{
    protected $data;
    protected $columns;

    public function __construct($data, $columns = [])
    {
        $this->data = $data;
        $this->columns = $columns;
    }

    public function collection()
    {
        return $this->data;
    }

    public function headings(): array
    {
        $headings = [];

        foreach ($this->columns as $column) {
            switch ($column) {
                case 'id':
                    $headings[] = 'ID';
                    break;
                case 'tipo_carga_id':
                    $headings[] = 'Tipo Carga ID';
                    break;
                case 'embarque_id':
                    $headings[] = 'Embarque ID';
                    break;
                case 'cantidad':
                    $headings[] = 'Cantidad';
                    break;
                case 'real':
                    $headings[] = 'Real';
                    break;
            }
        }

        return $headings;
    }

    public function map($row): array
    {
        $mappedRow = [];

        foreach ($this->columns as $column) {
            switch ($column) {
                case 'id':
                    $mappedRow[] = $row->id;
                    break;
                case 'tipo_carga_id':
                    $mappedRow[] = $row->tipo_carga_id;
                    break;
                case 'embarque_id':
                    $mappedRow[] = $row->embarque_id;
                    break;
                case 'cantidad':
                    $mappedRow[] = $row->cantidad;
                    break;
                case 'real':
                    $mappedRow[] = $row->real;
                    break;
            }
        }

        return $mappedRow;
    }
}
