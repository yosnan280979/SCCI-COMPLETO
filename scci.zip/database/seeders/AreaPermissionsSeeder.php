<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AreaPermissionsSeeder extends Seeder
{
    public function run()
    {
        $this->command->info('Asignando permisos específicos por área...');
        
        // Definir permisos específicos por área
        $permissionsByArea = [
            'Dirección' => [
                'dashboard' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'solicitudes' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'contratos' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'asignaciones' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'logistica' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'proveedores' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'ditec' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'finanzas' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'operaciones' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'organizacion' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'usuarios' => ['view' => false, 'create' => false, 'edit' => false, 'delete' => false],
            ],
            'Comerciales' => [
                'solicitudes' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'contratos' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'proveedores' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'logistica' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
            ],
            'Dir. UEB Importaciones' => [
                'solicitudes' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'contratos' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'logistica' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'proveedores' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
            ],
            'Política Comercial' => [
                'solicitudes' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'contratos' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'proveedores' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
            ],
            'SOE' => [
                'solicitudes' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'contratos' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'logistica' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
            ],
            'Control Financiamientos' => [
                'asignaciones' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
                'finanzas' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
            ],
            'Juridico' => [
                'contratos' => ['view' => true, 'create' => false, 'edit' => true, 'delete' => false],
                'proveedores' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
            ],
            'Marketing' => [
                'proveedores' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'operaciones' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
            ],
            'Economia' => [
                'asignaciones' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'finanzas' => ['view' => true, 'create' => true, 'edit' => true, 'delete' => false],
            ],
            'Calidad' => [
                'logistica' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'proveedores' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
            ],
            'Exportaciones' => [
                'logistica' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'proveedores' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
                'operaciones' => ['view' => true, 'create' => false, 'edit' => false, 'delete' => false],
            ],
        ];
        
        // Obtener todas las áreas
        $areas = DB::table('Nomenclador Areas')->get();
        $modules = DB::table('modules')->get();
        
        // Para cada área, actualizar los permisos según el mapeo
        foreach ($areas as $area) {
            $this->command->info("Procesando área: {$area->Area}");
            
            // Si el área no está en el mapeo, saltar
            if (!isset($permissionsByArea[$area->Area])) {
                continue;
            }
            
            $areaPermissions = $permissionsByArea[$area->Area];
            
            foreach ($modules as $module) {
                // Si el módulo está en los permisos del área
                if (isset($areaPermissions[$module->slug])) {
                    $perms = $areaPermissions[$module->slug];
                    
                    DB::table('permissions')
                        ->where('id_area', $area->{'Id Area'})
                        ->where('id_module', $module->id)
                        ->update([
                            'view' => $perms['view'] ?? false,
                            'create_p' => $perms['create'] ?? false,
                            'edit' => $perms['edit'] ?? false,
                            'delete_p' => $perms['delete'] ?? false,
                        ]);
                }
            }
        }
        
        $this->command->info('Permisos específicos asignados correctamente.');
    }
}