<?php

namespace App\Exports;

use App\Models\SolicitudesProveedores;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class SolicitudesProveedoresExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $solicitudes;

    public function __construct($solicitudes)
    {
        $this->solicitudes = $solicitudes;
    }

    public function collection()
    {
        return $this->solicitudes;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Id Solicitud',
            'Id Proveedor',
            'Respuesta',
            'Fecha Oferta',
            'Seleccionado',
            'Id Ctto',
            'Observaciones',
            'Id Tipo Producto',
            'Id Tipo Respuesta',
            'Fecha Dictec',
        ];
    }

    public function map($solicitud): array
    {
        return [
            $solicitud->Id,
            $solicitud->{'Id Solicitud'},
            $solicitud->{'Id Proveedor'},
            $solicitud->Respuesta ? 'Sí' : 'No',
            $solicitud->{'Fecha Oferta'} ? \Carbon\Carbon::parse($solicitud->{'Fecha Oferta'})->format('d/m/Y') : '',
            $solicitud->Selecionado ? 'Sí' : 'No',
            $solicitud->{'Id Ctto'} ?? '',
            $solicitud->Observaciones ?? '',
            $solicitud->{'Id Tipo Producto'} ?? '',
            $solicitud->{'Id Tipo Respuesta'} ?? '',
            $solicitud->{'Fecha Dictec'} ? \Carbon\Carbon::parse($solicitud->{'Fecha Dictec'})->format('d/m/Y') : '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}