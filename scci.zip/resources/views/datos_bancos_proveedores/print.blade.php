<!DOCTYPE html>
<html>
<head>
    <title>Datos Bancarios de Proveedores - Impresión</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; }
        .title { font-size: 18px; font-weight: bold; }
        .subtitle { font-size: 14px; color: #666; }
        .filters { margin-bottom: 15px; padding: 10px; background: #f5f5f5; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background-color: #f2f2f2; font-weight: bold; text-align: left; padding: 8px; border: 1px solid #ddd; }
        td { padding: 8px; border: 1px solid #ddd; font-size: 11px; }
        .footer { margin-top: 30px; text-align: right; font-size: 10px; color: #666; }
        .text-end { text-align: right; }
        .text-center { text-align: center; }
        .badge { padding: 3px 8px; border-radius: 3px; font-size: 11px; display: inline-block; }
        .badge-success { background-color: #d4edda; color: #155724; }
        .badge-danger { background-color: #f8d7da; color: #721c24; }
        .badge-info { background-color: #d1ecf1; color: #0c5460; }
        .badge-secondary { background-color: #e2e3e5; color: #383d41; }
        @media print {
            .no-print { display: none; }
            .page-break { page-break-before: always; }
            body { font-size: 11px; }
            table { font-size: 10px; }
        }
        .page-break { page-break-after: always; }
        .bank-container { margin-bottom: 20px; page-break-inside: avoid; padding-bottom: 15px; }
        .bank-header { background-color: #e9ecef; padding: 10px; font-weight: bold; border-radius: 5px 5px 0 0; }
        .observation { background-color: #f8f9fa; padding: 8px; margin-top: 5px; border-radius: 3px; }
        .section-title { background-color: #f0f0f0; padding: 6px 10px; margin: 10px 0 5px 0; font-weight: bold; border-left: 4px solid #007bff; }
        .account-number { font-family: 'Courier New', monospace; font-weight: bold; letter-spacing: 1px; }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">
            🖨️ Imprimir
        </button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #6c757d; color: white; border: none; border-radius: 5px; cursor: pointer;">
            ✖️ Cerrar
        </button>
    </div>
    
    <div class="header">
        <div class="title">Datos Bancarios de Proveedores</div>
        <div class="subtitle">Fecha de generación: {{ now()->format('d/m/Y H:i:s') }}</div>
        <div class="subtitle">Total de registros: {{ $datosBancos->count() }}</div>
    </div>
    
    @if(!empty($filtros))
    <div class="filters">
        <strong>Filtros aplicados:</strong><br>
        @foreach($filtros as $filtro)
        • {{ $filtro }}<br>
        @endforeach
    </div>
    @endif
    
    @foreach($datosBancos as $dato)
    <div class="bank-container">
        <div class="bank-header">
            Datos Bancarios #{{ $dato->Id }}
            <span style="float: right;">
                @if($dato->Activo)
                    <span class="badge badge-success">Activo</span>
                @else
                    <span class="badge badge-danger">Inactivo</span>
                @endif
            </span>
        </div>
        
        <!-- Información del Proveedor y Banco -->
        <div class="section-title">Información General</div>
        <table>
            <tbody>
                <tr>
                    <td width="20%"><strong>ID Registro:</strong></td>
                    <td width="30%">{{ $dato->Id }}</td>
                    <td width="20%"><strong>Estado:</strong></td>
                    <td width="30%" class="text-center">
                        @if($dato->Activo)
                            <span class="badge badge-success">Activo</span>
                        @else
                            <span class="badge badge-danger">Inactivo</span>
                        @endif
                    </td>
                </tr>
                <tr>
                    <td><strong>Proveedor:</strong></td>
                    <td colspan="3">{{ $dato->proveedor?->{'Proveedor'} ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td><strong>Banco:</strong></td>
                    <td colspan="3">{{ $dato->banco?->{'Banco'} ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td><strong>Moneda:</strong></td>
                    <td>{{ $dato->moneda?->{'Moneda'} ?? 'N/A' }}</td>
                    <td><strong>Tipo de Cuenta:</strong></td>
                    <td>{{ $dato->{'Tipo Cuenta'} ?? 'N/A' }}</td>
                </tr>
            </tbody>
        </table>
        
        <!-- Información de la Cuenta -->
        <div class="section-title">Información de la Cuenta</div>
        <table>
            <tbody>
                <tr>
                    <td width="20%"><strong>Número de Cuenta:</strong></td>
                    <td width="80%" class="account-number">{{ $dato->{'Numero Cuenta'} ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td><strong>Titular de la Cuenta:</strong></td>
                    <td>{{ $dato->Titular ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td><strong>Código SWIFT/BIC:</strong></td>
                    <td>{{ $dato->{'SWIFT_BIC'} ?? 'N/A' }}</td>
                </tr>
            </tbody>
        </table>
        
        <!-- Información de Contacto del Banco -->
        <div class="section-title">Información de Contacto del Banco</div>
        <table>
            <tbody>
                <tr>
                    <td width="20%"><strong>Dirección del Banco:</strong></td>
                    <td width="80%">{{ $dato->{'Direccion Banco'} ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td><strong>Teléfono del Banco:</strong></td>
                    <td>{{ $dato->{'Telefono Banco'} ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td><strong>Email del Banco:</strong></td>
                    <td>{{ $dato->{'Email Banco'} ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td><strong>Contacto del Banco:</strong></td>
                    <td>{{ $dato->{'Contacto Banco'} ?? 'N/A' }}</td>
                </tr>
            </tbody>
        </table>
        
        <!-- Observaciones -->
        <div class="observation">
            <strong>Observaciones:</strong><br>
            {{ $dato->Observaciones ?? 'N/A' }}
        </div>
        
        @if(!$loop->last)
            <hr style="border-top: 1px dashed #ddd; margin: 20px 0;">
        @endif
    </div>
    @endforeach
    
    <!-- Totales generales -->
    <div style="margin-top: 30px; padding: 15px; background-color: #f8f9fa; border-radius: 5px;">
        <strong>Resumen General:</strong><br>
        • Total Registros: {{ $datosBancos->count() }}<br>
        • Cuentas Activas: {{ $datosBancos->where('Activo', 1)->count() }}<br>
        • Cuentas Inactivas: {{ $datosBancos->where('Activo', 0)->count() }}<br>
        • Proveedores con Datos Bancarios: {{ $datosBancos->unique('Id Proveedor')->count() }}
    </div>
    
    <div class="footer">
        <p>Total de registros: {{ $datosBancos->count() }}</p>
        <p>Generado por: {{ auth()->user()->{'Usuario'} ?? 'Sistema' }}</p>
        <p>SCCI - Sistema de Control de Contratación e Importaciones</p>
    </div>
    
    <script>
        // Auto-print opcional (descomentar si se necesita)
        // window.onload = function() { window.print(); }
    </script>
</body>
</html>