<?php

namespace App\Exports;

use App\Models\CreditLine;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class CreditLinesExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $creditLines;

    public function __construct($creditLines)
    {
        $this->creditLines = $creditLines;
    }

    public function collection()
    {
        return $this->creditLines;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Línea de Crédito',
        ];
    }

    public function map($linea): array
    {
        return [
            $linea->{'Id Lineacredito'},
            $linea->{'Linea de Crédito'},
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}