<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // Agregar la columna solo si no existe
        if (!Schema::hasColumn('Nomenclador Proveedores', 'Id Tipo Producto')) {
            Schema::table('Nomenclador Proveedores', function (Blueprint $table) {
                $table->integer('Id Tipo Producto')->nullable()->after('Productos');
            });
        }
    }

    public function down()
    {
        Schema::table('Nomenclador Proveedores', function (Blueprint $table) {
            if (Schema::hasColumn('Nomenclador Proveedores', 'Id Tipo Producto')) {
                $table->dropColumn('Id Tipo Producto');
            }
        });
    }
};