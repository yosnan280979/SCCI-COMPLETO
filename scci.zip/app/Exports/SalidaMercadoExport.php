<?php

namespace App\Exports;

use App\Models\SalidaMercado;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class SalidaMercadoExport implements FromCollection, WithHeadings, WithMapping
{
    protected $items;

    public function __construct($items = null)
    {
        $this->items = $items;
    }

    public function collection()
    {
        return $this->items ?? SalidaMercado::all();
    }

    public function headings(): array
    {
        return ['ID','No. Salida','ID Especialista','Año','Fecha Salida','Fecha Primera Oferta'];
    }

    public function map($item): array
    {
        return [
            $item->Id_Salida_Mercado ?? $item->id,
            $item->No_Sal_Mer,
            $item->Id_Especialista,
            $item->Año_Sal_Mer,
            $item->Fecha_sal_Mer ? \Carbon\Carbon::parse($item->Fecha_sal_Mer)->format('d/m/Y') : '',
            $item->Fecha_pri_oferta ? \Carbon\Carbon::parse($item->Fecha_pri_oferta)->format('d/m/Y') : '',
        ];
    }
}
