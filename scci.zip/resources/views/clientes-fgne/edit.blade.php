@extends('layouts.app')

@section('title', 'Editar Cliente FGNE')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Editar Cliente FGNE</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('clientes-fgne.update', $item->id) }}" method="POST">
                @csrf
                @method('PUT')
                
                <div class="row mb-3">
                    <div class="col-md-3">
                        <label for="no_registro" class="form-label">No. Registro</label>
                        <input type="number" class="form-control" id="no_registro" name="no_registro" value="{{ old('no_registro', $item->no_registro) }}">
                    </div>
                    <div class="col-md-3">
                        <label for="fgne_codigo" class="form-label">FGNE (TCP/CNA/MIPYME)</label>
                        <input type="text" class="form-control" id="fgne_codigo" name="fgne_codigo" value="{{ old('fgne_codigo', $item->fgne_codigo) }}">
                    </div>
                    <div class="col-md-6">
                        <label for="nombre" class="form-label">Nombre *</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" required value="{{ old('nombre', $item->nombre) }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="codigo_nit" class="form-label">Código NIT</label>
                        <input type="text" class="form-control" id="codigo_nit" name="codigo_nit" value="{{ old('codigo_nit', $item->codigo_nit) }}">
                    </div>
                    <div class="col-md-8">
                        <label for="objeto_social" class="form-label">Objeto Social</label>
                        <textarea name="objeto_social" class="form-control" rows="2">{{ old('objeto_social', $item->objeto_social) }}</textarea>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-12">
                        <label for="direccion" class="form-label">Dirección</label>
                        <input type="text" class="form-control" id="direccion" name="direccion" value="{{ old('direccion', $item->direccion) }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="telefonos" class="form-label">Teléfonos</label>
                        <input type="text" class="form-control" id="telefonos" name="telefonos" value="{{ old('telefonos', $item->telefonos) }}">
                    </div>
                    <div class="col-md-4">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="{{ old('email', $item->email) }}">
                    </div>
                    <div class="col-md-4">
                        <label for="representacion" class="form-label">Representación</label>
                        <input type="text" class="form-control" id="representacion" value="{{ old('representacion', $item->representacion) }}">
                    </div>
                </div>

                <div class="mt-4 mb-3">
                    <h6>Cuentas Bancarias</h6>
                    <hr>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="cuenta_mn" class="form-label">Cta. MN</label>
                        <input type="text" class="form-control" id="cuenta_mn" name="cuenta_mn" value="{{ old('cuenta_mn', $item->cuenta_mn) }}">
                    </div>
                    <div class="col-md-4">
                        <label for="cuenta_usd" class="form-label">Cta. USD</label>
                        <input type="text" class="form-control" id="cuenta_usd" name="cuenta_usd" value="{{ old('cuenta_usd', $item->cuenta_usd) }}">
                    </div>
                    <div class="col-md-4">
                        <label for="cuenta_mlc" class="form-label">Cta. MLC</label>
                        <input type="text" class="form-control" id="cuenta_mlc" name="cuenta_mlc" value="{{ old('cuenta_mlc', $item->cuenta_mlc) }}">
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-12">
                        <label for="sucursal_banco" class="form-label">Sucursal Banco</label>
                        <input type="text" class="form-control" id="sucursal_banco" name="sucursal_banco" value="{{ old('sucursal_banco', $item->sucursal_banco) }}">
                    </div>
                </div>

                <div class="mt-4 mb-3">
                    <h6>Ficha y Actualizaciones</h6>
                    <hr>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <label for="ficha" class="form-label">Ficha</label>
                        <input type="text" class="form-control" id="ficha" name="ficha" value="{{ old('ficha', $item->ficha) }}">
                    </div>
                    <div class="col-md-3">
                        <label for="actualiz" class="form-label">Actualiz</label>
                        <input type="text" class="form-control" id="actualiz" name="actualiz" value="{{ old('actualiz', $item->actualiz) }}">
                    </div>
                    <div class="col-md-3">
                        <label for="bases_generales" class="form-label">Bases Generales</label>
                        <input type="text" class="form-control" id="bases_generales" value="{{ old('bases_generales', $item->bases_generales) }}">
                    </div>
                    <div class="col-md-3">
                        <label for="fecha_actualizacion" class="form-label">Fecha Actualización</label>
                        <input type="date" class="form-control" id="fecha_actualizacion" name="fecha_actualizacion" value="{{ old('fecha_actualizacion', $item->fecha_actualizacion) }}">
                    </div>
                </div>

                <div class="mt-4 mb-3">
                    <h6>Contratos</h6>
                    <hr>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <label for="ctto_consignacion" class="form-label">Ctto. Consignación</label>
                        <input type="text" class="form-control" id="ctto_consignacion" value="{{ old('ctto_consignacion', $item->ctto_consignacion) }}">
                    </div>
                    <div class="col-md-4">
                        <label for="fecha_ctto_consignacion" class="form-label">Fecha Ctto. Consignación</label>
                        <input type="date" class="form-control" id="fecha_ctto_consignacion" value="{{ old('fecha_ctto_consignacion', $item->fecha_ctto_consignacion) }}">
                    </div>
                    <div class="col-md-4">
                        <label for="ctto_in_bond" class="form-label">Ctto. In Bond</label>
                        <input type="text" class="form-control" id="ctto_in_bond" value="{{ old('ctto_in_bond', $item->ctto_in_bond) }}">
                    </div>
                    <div class="col-md-4">
                        <label for="fecha_ctto_in_bond" class="form-label">Fecha Ctto. In Bond</label>
                        <input type="date" class="form-control" id="fecha_ctto_in_bond" value="{{ old('fecha_ctto_in_bond', $item->fecha_ctto_in_bond) }}">
                    </div>
                </div>
                
                <div class="d-flex justify-content-end mt-4">
                    <a href="{{ route('clientes-fgne.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Actualizar Cliente</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection