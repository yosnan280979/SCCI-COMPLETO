@extends('layouts.app')

@section('title', 'Detalles SOE')

@section('header', 'Detalles del Suplemento de Operación de Exportación')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">SOE #{{ $datosSOE->{'Id SOE'} }}</h5>
                    <div>
                        <a href="{{ route('datos-soe.edit', $datosSOE->{'Id SOE'}) }}" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                        <a href="{{ route('datos-soe.print', $datosSOE->{'Id SOE'}) }}" class="btn btn-info btn-sm" target="_blank">
                            <i class="fas fa-print"></i> Imprimir
                        </a>
                        <a href="{{ route('datos-soe.index') }}" class="btn btn-secondary btn-sm">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Información Básica -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6 class="border-bottom pb-2">Información Básica</h6>
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <th width="40%">ID SOE:</th>
                                    <td>{{ $datosSOE->{'Id SOE'} }}</td>
                                </tr>
                                <tr>
                                    <th>Contrato:</th>
                                    <td>{{ $datosSOE->contrato->{'No Ctto'} ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <th>Solicitud:</th>
                                    <td>{{ $datosSOE->{'Id Solicitud'} ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <th>No. Suplemento:</th>
                                    <td>{{ $datosSOE->{'No Suplemento'} ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <th>Fecha Comité:</th>
                                    <td>{{ $datosSOE->{'Fecha Comite'} ? \Carbon\Carbon::parse($datosSOE->{'Fecha Comite'})->format('d/m/Y H:i') : 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <th>No. Acta:</th>
                                    <td>{{ $datosSOE->{'No Acta'} ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <th>No. Acuerdo:</th>
                                    <td>{{ $datosSOE->{'No Acuerdo'} ?? 'N/A' }}</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="border-bottom pb-2">Información Financiera</h6>
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <th width="40%">Valor Mercancía:</th>
                                    <td>${{ number_format($datosSOE->{'Valor Mercancia'}, 2) }}</td>
                                </tr>
                                <tr>
                                    <th>Valor Contrato CUC:</th>
                                    <td>${{ number_format($datosSOE->{'Valor Ctto CUC'}, 2) }}</td>
                                </tr>
                                <tr>
                                    <th>Moneda:</th>
                                    <td>{{ $datosSOE->moneda->Moneda ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <th>Valor Moneda Proveedor:</th>
                                    <td>${{ number_format($datosSOE->{'Valor Mon Prov'}, 2) }}</td>
                                </tr>
                                <tr>
                                    <th>Línea de Crédito:</th>
                                    <td>{{ $datosSOE->lineaCredito->{'Linea de Crédito'} ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <th>Año Financiero:</th>
                                    <td>{{ $datosSOE->{'Año finan'} ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <th>Forma de Pago:</th>
                                    <td>{{ $datosSOE->{'Forma de Pago'} ?? 'N/A' }}</td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- Fechas Importantes -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2">Fechas Importantes</h6>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="card card-body bg-light">
                                        <small class="text-muted">CAD Gescons</small>
                                        <div>{{ $datosSOE->{'Fecha CAD Gescons'} ? \Carbon\Carbon::parse($datosSOE->{'Fecha CAD Gescons'})->format('d/m/Y') : 'N/A' }}</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="card card-body bg-light">
                                        <small class="text-muted">CAD MICONS</small>
                                        <div>{{ $datosSOE->{'Fecha CAD MICONS'} ? \Carbon\Carbon::parse($datosSOE->{'Fecha CAD MICONS'})->format('d/m/Y') : 'N/A' }}</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="card card-body bg-light">
                                        <small class="text-muted">Firma Contrato</small>
                                        <div>{{ $datosSOE->{'Fecha firma Ctto'} ? \Carbon\Carbon::parse($datosSOE->{'Fecha firma Ctto'})->format('d/m/Y') : 'N/A' }}</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="card card-body bg-light">
                                        <small class="text-muted">Emisión Certificado</small>
                                        <div>{{ $datosSOE->{'Fecha emision certif'} ? \Carbon\Carbon::parse($datosSOE->{'Fecha emision certif'})->format('d/m/Y') : 'N/A' }}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Pendientes Financieros -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0">Pendientes Financieros</h6>
                                </div>
                                <div class="card-body">
                                    <table class="table table-sm">
                                        <tr>
                                            <th>Pendiente CUC:</th>
                                            <td class="text-end">${{ number_format($datosSOE->{'Pendiente finan CUC'}, 2) }}</td>
                                        </tr>
                                        <tr>
                                            <th>Pendiente CUP:</th>
                                            <td class="text-end">${{ number_format($datosSOE->{'Pendiente finan CUP'}, 2) }}</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0">Información Adicional</h6>
                                </div>
                                <div class="card-body">
                                    <table class="table table-sm">
                                        <tr>
                                            <th>No. Referencia:</th>
                                            <td>{{ $datosSOE->{'No Referencia'} ?? 'N/A' }}</td>
                                        </tr>
                                        <tr>
                                            <th>Total Embarques:</th>
                                            <td>{{ $datosSOE->{'Total embarques'} ?? '0' }}</td>
                                        </tr>
                                        <tr>
                                            <th>Momento SOE:</th>
                                            <td>
                                                @if($datosSOE->momentoSOE)
                                                    <span class="badge bg-info">{{ $datosSOE->momentoSOE->{'Momento SOE'} }}</span>
                                                @else
                                                    <span class="badge bg-secondary">Sin definir</span>
                                                @endif
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Estado:</th>
                                            <td>
                                                @if($datosSOE->{'Cancelado SOE'})
                                                    <span class="badge bg-danger">Cancelado</span>
                                                @else
                                                    <span class="badge bg-success">Activo</span>
                                                @endif
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Anular Valores:</th>
                                            <td>
                                                @if($datosSOE->{'Anular Valores'})
                                                    <span class="badge bg-warning">Sí</span>
                                                @else
                                                    <span class="badge bg-secondary">No</span>
                                                @endif
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Observaciones -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0">Observaciones</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <h6>Jurídico:</h6>
                                            <div class="border p-2 bg-light rounded">
                                                {{ $datosSOE->{'Observaciones Juridico'} ?: 'Sin observaciones' }}
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <h6>SOE:</h6>
                                            <div class="border p-2 bg-light rounded">
                                                {{ $datosSOE->{'Observaciones SOE'} ?: 'Sin observaciones' }}
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <h6>Especialista:</h6>
                                            <div class="border p-2 bg-light rounded">
                                                {{ $datosSOE->{'Observaciones Especialista'} ?: 'Sin observaciones' }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-3">
                                        <h6>Observaciones Generales:</h6>
                                        <div class="border p-3 bg-light rounded">
                                            {{ $datosSOE->{'Observaciones'} ?: 'Sin observaciones generales' }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Botones de Acción -->
                    <div class="mt-4">
                        <a href="{{ route('datos-soe.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver al Listado
                        </a>
                        <a href="{{ route('datos-soe.edit', $datosSOE->{'Id SOE'}) }}" class="btn btn-warning">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                        <form action="{{ route('datos-soe.destroy', $datosSOE->{'Id SOE'}) }}" method="POST" class="d-inline" onsubmit="return confirm('¿Está seguro de eliminar este SOE?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-trash"></i> Eliminar
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection