@extends('layouts.app')

@section('title', 'Crear Asignación por Solicitud')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Crear Asignación por Solicitud</h5>
        </div>
        <div class="card-body">
            <form action="{{ route('asigporsolic.store') }}" method="POST">
                @csrf
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Id Solicitud" class="form-label">Solicitud *</label>
                        <select class="form-select" id="Id Solicitud" name="Id Solicitud" required>
                            <option value="">Seleccionar Solicitud</option>
                            @foreach($solicitudes as $solicitud)
                                <option value="{{ $solicitud->{'Id Solicitud'} }}" 
                                    {{ old('Id Solicitud') == $solicitud->{'Id Solicitud'} ? 'selected' : '' }}>
                                    {{ $solicitud->{'Id Solicitud'} }} - {{ $solicitud->{'No Solicitud'} }}
                                    @if($solicitud->cliente)
                                        ({{ $solicitud->cliente->{'Cliente'} }})
                                    @endif
                                </option>
                            @endforeach
                        </select>
                        @error('Id Solicitud')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <div class="col-md-6">
                        <label for="Año finan" class="form-label">Año financiero *</label>
                        <input type="number" class="form-control" id="Año finan" name="Año finan" 
                               value="{{ old('Año finan', date('Y')) }}" min="2000" max="2100" required>
                        @error('Año finan')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="Asig MCUC" class="form-label">Asignación MCUC</label>
                        <input type="number" step="0.01" class="form-control" id="Asig MCUC" name="Asig MCUC" 
                               value="{{ old('Asig MCUC') }}" min="0">
                        @error('Asig MCUC')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="{{ route('asigporsolic.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Cancelar
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Guardar Asignación
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sugerir año actual por defecto
    const anoInput = document.getElementById('Año finan');
    if (anoInput && !anoInput.value) {
        anoInput.value = new Date().getFullYear();
    }
});
</script>
@endsection