<?php

namespace App\Exports;

use App\Models\AsigPorSolic;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class AsigPorSolicExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $asigporsolic;

    public function __construct($asigporsolic)
    {
        $this->asigporsolic = $asigporsolic;
    }

    public function collection()
    {
        return $this->asigporsolic;
    }

    public function headings(): array
    {
        return [
            'ID Solicitud',
            'Año finan',
            'Asig MCUC',
        ];
    }

    public function map($asignacion): array
    {
        return [
            $asignacion->{'Id Solicitud'},
            $asignacion->{'Año finan'},
            $asignacion->{'Asig MCUC'} ?? '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}