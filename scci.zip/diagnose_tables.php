<?php
require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\DB;

echo "=== DIAGNÓSTICO DE TABLAS ===\n\n";

// Verificar todas las tablas
$tables = DB::select("SHOW TABLES");
echo "Tablas en la base de datos:\n";
foreach ($tables as $table) {
    foreach ($table as $key => $value) {
        echo "- $value\n";
    }
}

echo "\n=== VERIFICAR ESTRUCTURA ===\n";

// Verificar si existe la tabla permissions
$permissionsExists = DB::select("SHOW TABLES LIKE 'permissions'");
if (empty($permissionsExists)) {
    echo "✗ La tabla 'permissions' NO existe\n";
} else {
    echo "✓ La tabla 'permissions' EXISTE\n";
    
    // Mostrar estructura
    $structure = DB::select("DESCRIBE permissions");
    echo "\nEstructura de la tabla 'permissions':\n";
    foreach ($structure as $column) {
        echo "  - {$column->Field} ({$column->Type})\n";
    }
}

// Verificar si existe la tabla modules
$modulesExists = DB::select("SHOW TABLES LIKE 'modules'");
if (empty($modulesExists)) {
    echo "\n✗ La tabla 'modules' NO existe\n";
} else {
    echo "\n✓ La tabla 'modules' EXISTE\n";
    
    // Mostrar estructura
    $structure = DB::select("DESCRIBE modules");
    echo "\nEstructura de la tabla 'modules':\n";
    foreach ($structure as $column) {
        echo "  - {$column->Field} ({$column->Type})\n";
    }
}

// Verificar tabla de áreas
$areasExists = DB::select("SHOW TABLES LIKE 'Nomenclador Areas'");
if (empty($areasExists)) {
    echo "\n✗ La tabla 'Nomenclador Areas' NO existe\n";
} else {
    echo "\n✓ La tabla 'Nomenclador Areas' EXISTE\n";
    
    // Mostrar algunas áreas
    $areas = DB::table('Nomenclador Areas')->select('`Id Area`', 'Area')->limit(5)->get();
    echo "\nPrimeras 5 áreas:\n";
    foreach ($areas as $area) {
        echo "  - ID: {$area->{'Id Area'}}, Nombre: {$area->Area}\n";
    }
}
