@extends('layouts.app')

@section('title', 'Editar Carga')
@section('header', 'Editar Carga')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Editar Carga</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('cargas.update', $carga->{'Id Carga'}) }}" method="POST">
                        @csrf
                        @method('PUT')
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="Id Tipo Carga" class="form-label">Tipo de Carga *</label>
                                    <select class="form-control @error('Id Tipo Carga') is-invalid @enderror" 
                                            id="Id Tipo Carga" name="Id Tipo Carga" required>
                                        <option value="">Seleccionar Tipo de Carga...</option>
                                        @foreach($tiposCarga as $tipo)
                                        <option value="{{ $tipo->{'Id Tipo Carga'} }}" 
                                            {{ old('Id Tipo Carga', $carga->{'Id Tipo Carga'}) == $tipo->{'Id Tipo Carga'} ? 'selected' : '' }}>
                                            {{ $tipo->{'Tipo Carga'} }}
                                        </option>
                                        @endforeach
                                    </select>
                                    @error('Id Tipo Carga')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="Id Embarque" class="form-label">ID Embarque *</label>
                                    <input type="number" class="form-control @error('Id Embarque') is-invalid @enderror" 
                                           id="Id Embarque" name="Id Embarque" 
                                           value="{{ old('Id Embarque', $carga->{'Id Embarque'}) }}" required>
                                    @error('Id Embarque')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="Cantidad" class="form-label">Cantidad</label>
                                    <input type="number" step="0.01" class="form-control @error('Cantidad') is-invalid @enderror" 
                                           id="Cantidad" name="Cantidad" 
                                           value="{{ old('Cantidad', $carga->Cantidad) }}">
                                    @error('Cantidad')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="Real" class="form-label">Real</label>
                                    <input type="number" step="0.01" class="form-control @error('Real') is-invalid @enderror" 
                                           id="Real" name="Real" 
                                           value="{{ old('Real', $carga->Real) }}">
                                    @error('Real')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-3">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Actualizar
                            </button>
                            <a href="{{ route('cargas.index') }}" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancelar
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection