@extends('layouts.app')

@section('title','Listado de Clientes Estatales')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Clientes Estatales</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('clientes-estatales.create') }}" class="btn btn-primary btn-sm">➕ Nuevo</a>
                
                <!-- Formulario Excel -->
                <form method="GET" action="{{ route('clientes-estatales.export.excel') }}" style="display: inline" id="exportExcelForm">
                    <input type="hidden" name="selected" id="exportSelectedExcel" value="">
                    <!-- Filtros ocultos para exportar -->
                    <input type="hidden" name="ministerio" value="{{ request('ministerio') }}">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                
                <!-- Formulario PDF -->
                <form method="GET" action="{{ route('clientes-estatales.export.pdf') }}" style="display: inline" id="exportPdfForm">
                    <input type="hidden" name="selected" id="exportSelectedPdf" value="">
                    <input type="hidden" name="ministerio" value="{{ request('ministerio') }}">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                
                <!-- Formulario Imprimir -->
                <form method="GET" action="{{ route('clientes-estatales.print') }}" style="display: inline" id="printForm" target="_blank">
                    <input type="hidden" name="selected" id="exportSelectedPrint" value="">
                    <input type="hidden" name="ministerio" value="{{ request('ministerio') }}">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Filtros -->
            <form method="GET" action="{{ route('clientes-estatales.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-4">
                        <input type="text" name="search" class="form-control" placeholder="Buscar (Empresa, NIT, Director...)" 
                               value="{{ request('search') }}">
                    </div>
                    <div class="col-md-3">
                        <select name="ministerio" class="form-select">
                            <option value="">Todos los Ministerios</option>
                            @foreach($ministerios as $min)
                                <option value="{{ $min }}" {{ request('ministerio') == $min ? 'selected' : '' }}>
                                    {{ $min }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('clientes-estatales.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
                <!-- Campos ocultos para ordenación -->
                <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
            </form>

            @if($items->isEmpty())
                <div class="alert alert-info">No hay clientes estatales registrados.</div>
            @else
                <!-- Formulario para eliminación múltiple (DELETE) -->
                <form id="deleteForm" method="POST" action="{{ route('clientes-estatales.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <!-- Tabla con scroll horizontal -->
                    <div class="table-responsive" style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
                        <table class="table table-bordered table-hover table-sm align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="selectAll">
                                    </th>
                                    <th width="30%">
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'nombre_empresa';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'nombre_empresa' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('clientes-estatales.index', $queryParams) }}">
                                            Empresa
                                            @if(request('sort_by') == 'nombre_empresa')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="15%">
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'ministerio';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'ministerio' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('clientes-estatales.index', $queryParams) }}">
                                            Ministerio
                                            @if(request('sort_by') == 'ministerio')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="15%">NIT / REEUP</th>
                                    <th width="15%">Director</th>
                                    <th width="10%">Email</th>
                                    <th width="150">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($items as $item)
                                <tr>
                                    <td>
                                        <input type="checkbox" name="selected[]" value="{{ $item->id }}" class="select-item">
                                    </td>
                                    <td><strong>{{ $item->nombre_empresa }}</strong></td>
                                    <td>{{ $item->ministerio ?? '---' }}</td>
                                    <td>{{ $item->codigo_nit ?? '---' }}</td>
                                    <td>{{ $item->nombre_director ?? '---' }}</td>
                                    <td>{{ $item->email ?? '---' }}</td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="{{ route('clientes-estatales.show', $item->id) }}" class="btn btn-info btn-sm">Ver</a>
                                            <a href="{{ route('clientes-estatales.edit', $item->id) }}" class="btn btn-warning btn-sm">Editar</a>
                                            <form action="{{ route('clientes-estatales.destroy', $item->id) }}" method="POST" style="display:inline-block;">
                                                @csrf @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar este registro?')">Eliminar</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar los clientes seleccionados?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación homogénea a Asignaciones -->
                @if($items->hasPages())
                    @php 
                        // Preservar todos los parámetros de búsqueda en la paginación
                        $queryParams = request()->all();
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $items->firstItem() }}–{{ $items->lastItem() }} de {{ $items->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    @php $queryParams['page'] = 1; @endphp
                                    <a class="page-link" href="{{ route('clientes-estatales.index', $queryParams) }}">« Primera</a>
                                </li>
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    @php $queryParams['page'] = $items->currentPage() - 1; @endphp
                                    <a class="page-link" href="{{ route('clientes-estatales.index', $queryParams) }}">‹</a>
                                </li>
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $items->currentPage() }} de {{ $items->lastPage() }}</span>
                                </li>
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    @php $queryParams['page'] = $items->currentPage() + 1; @endphp
                                    <a class="page-link" href="{{ route('clientes-estatales.index', $queryParams) }}">›</a>
                                </li>
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    @php $queryParams['page'] = $items->lastPage(); @endphp
                                    <a class="page-link" href="{{ route('clientes-estatales.index', $queryParams) }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<!-- Estilos homogéneos -->
<style>
.table-responsive {
    border: 1px solid #dee2e6;
    border-radius: 4px;
    margin-bottom: 1rem;
}
.table th, .table td {
    white-space: nowrap;
    vertical-align: middle;
    padding: 0.5rem;
}
.btn-group .btn-sm {
    padding: 0.25rem 0.5rem;
}
@media (max-width: 768px) {
    .table-responsive {
        -webkit-overflow-scrolling: touch;
    }
    .card-body {
        padding: 0.75rem;
    }
}
.table-hover tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.075);
}
</style>

<!-- Script homogéneo para exportación y checkboxes -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        document.getElementById('exportSelectedExcel').value = selectedString;
        document.getElementById('exportSelectedPdf').value = selectedString;
        document.getElementById('exportSelectedPrint').value = selectedString;
    }
    
    updateExportSelected();
});
</script>
@endsection