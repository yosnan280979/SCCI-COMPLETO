<div class="card">
    <div class="card-header">
        <h3 class="card-title">{{ $title ?? 'Tabla' }}</h3>
        <div class="card-tools">
            <!-- Botones de exportación -->
            @if(isset($exportExcelRoute) && Route::has($exportExcelRoute))
            <a href="{{ route($exportExcelRoute) }}" class="btn btn-success btn-sm">
                <i class="fas fa-file-excel"></i> Excel
            </a>
            @endif
            
            @if(isset($exportPdfRoute) && Route::has($exportPdfRoute))
            <a href="{{ route($exportPdfRoute) }}" class="btn btn-danger btn-sm">
                <i class="fas fa-file-pdf"></i> PDF
            </a>
            @endif
            
            @if(isset($printRoute) && Route::has($printRoute))
            <a href="{{ route($printRoute) }}" class="btn btn-info btn-sm">
                <i class="fas fa-print"></i> Imprimir
            </a>
            @else
            <button class="btn btn-info btn-sm" onclick="window.print()">
                <i class="fas fa-print"></i> Imprimir
            </button>
            @endif
            
            @if(isset($createRoute) && Route::has($createRoute))
            <a href="{{ route($createRoute) }}" class="btn btn-primary btn-sm">
                <i class="fas fa-plus"></i> Nuevo
            </a>
            @endif
        </div>
    </div>
    <div class="card-body">
        <!-- Filtros -->
        @if(isset($showFilters) && $showFilters)
        <div class="row mb-3">
            <div class="col-md-12">
                <form id="filterForm" class="form-inline">
                    @foreach($filters ?? [] as $filter)
                    <div class="form-group mr-2 mb-2">
                        <input type="text" class="form-control form-control-sm" 
                               placeholder="Filtrar {{ $filter['label'] }}" 
                               id="filter-{{ $filter['field'] }}">
                    </div>
                    @endforeach
                    <button type="button" class="btn btn-secondary btn-sm mb-2" id="btnFilter">
                        <i class="fas fa-filter"></i> Filtrar
                    </button>
                    <button type="button" class="btn btn-outline-secondary btn-sm mb-2" id="btnReset">
                        <i class="fas fa-redo"></i> Limpiar
                    </button>
                </form>
            </div>
        </div>
        @endif
        
        <!-- Tabla -->
        <div class="table-responsive">
            <table id="{{ $tableId ?? 'dataTable' }}" class="table table-bordered table-hover table-striped data-table">
                <thead>
                    <tr>
                        @if(isset($showCheckboxes) && $showCheckboxes)
                        <th width="5%">
                            <input type="checkbox" id="selectAll">
                        </th>
                        @endif
                        {!! $header ?? '' !!}
                    </tr>
                </thead>
                <tbody>
                    {{ $body ?? '' }}
                </tbody>
            </table>
        </div>
        
        <!-- Acciones múltiples -->
        @if(isset($showCheckboxes) && $showCheckboxes)
        <div class="row mt-3">
            <div class="col-md-12">
                <button id="btnDeleteSelected" class="btn btn-danger btn-sm" disabled>
                    <i class="fas fa-trash"></i> Eliminar Seleccionados
                </button>
                <span id="selectedCount" class="badge bg-info ml-2">0 seleccionados</span>
            </div>
        </div>
        @endif
    </div>
    <div class="card-footer">
        <!-- Información de paginación -->
        @if(isset($showPagination) && $showPagination)
        <div class="row">
            <div class="col-md-6">
                Mostrando {{ $items->firstItem() ?? 0 }} a {{ $items->lastItem() ?? 0 }} de {{ $items->total() ?? 0 }} registros
            </div>
            <div class="col-md-6">
                <div class="float-right">
                    {{ $items->links() ?? '' }}
                </div>
            </div>
        </div>
        @endif
    </div>
</div>

@push('scripts')
<script>
    $(document).ready(function() {
        // Inicializar DataTable
        var table = $('#{{ $tableId ?? 'dataTable' }}').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json"
            },
            "responsive": true,
            "order": [[0, "desc"]],
            "pageLength": 25,
            "dom": '<"row"<"col-md-6"l><"col-md-6"f>>rt<"row"<"col-md-6"i><"col-md-6"p>>B',
            "buttons": [
                {
                    extend: 'print',
                    text: '<i class="fas fa-print"></i> Imprimir',
                    className: 'btn btn-info btn-sm'
                },
                {
                    extend: 'excel',
                    text: '<i class="fas fa-file-excel"></i> Excel',
                    className: 'btn btn-success btn-sm'
                },
                {
                    extend: 'pdf',
                    text: '<i class="fas fa-file-pdf"></i> PDF',
                    className: 'btn btn-danger btn-sm'
                }
            ]
        });
        
        // Seleccionar todos los checkboxes
        $('#selectAll').click(function() {
            $('.row-checkbox').prop('checked', this.checked);
            updateSelectedCount();
        });
        
        // Actualizar contador de seleccionados
        function updateSelectedCount() {
            var selectedCount = $('.row-checkbox:checked').length;
            $('#selectedCount').text(selectedCount + ' seleccionados');
            $('#btnDeleteSelected').prop('disabled', selectedCount === 0);
        }
        
        // Cuando se cambia un checkbox individual
        $('.row-checkbox').change(function() {
            if (!this.checked) {
                $('#selectAll').prop('checked', false);
            } else {
                var allChecked = $('.row-checkbox:checked').length === $('.row-checkbox').length;
                $('#selectAll').prop('checked', allChecked);
            }
            updateSelectedCount();
        });
        
        // Eliminar elementos seleccionados
        $('#btnDeleteSelected').click(function() {
            var selectedIds = [];
            $('.row-checkbox:checked').each(function() {
                selectedIds.push($(this).val());
            });
            
            if (selectedIds.length > 0) {
                if (confirm('¿Está seguro de eliminar los elementos seleccionados?')) {
                    // Enviar petición AJAX para eliminar múltiples
                    $.ajax({
                        url: '{{ $deleteMultipleRoute ?? "" }}',
                        method: 'DELETE',
                        data: {
                            ids: selectedIds,
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            if (response.success) {
                                location.reload();
                            }
                        }
                    });
                }
            }
        });
        
        // Filtros
        @if(isset($showFilters) && $showFilters)
        $('#btnFilter').click(function() {
            @foreach($filters ?? [] as $filter)
            var filterValue = $('#filter-{{ $filter['field'] }}').val();
            if (filterValue) {
                table.column('{{ $filter['column'] ?? 0 }}:name').search(filterValue).draw();
            }
            @endforeach
        });
        
        $('#btnReset').click(function() {
            @foreach($filters ?? [] as $filter)
            $('#filter-{{ $filter['field'] }}').val('');
            @endforeach
            table.search('').columns().search('').draw();
        });
        @endif
        
        // Confirmación para eliminar individual
        window.confirmDelete = function(formId) {
            if (confirm('¿Está seguro de que desea eliminar este registro?')) {
                document.getElementById(formId).submit();
            }
        };
    });
</script>
@endpush