<?php

namespace App\Exports;

use App\Models\ProveedorDITEC;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ProveedorDITECExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function collection()
    {
        return $this->items;
    }

    public function headings(): array
    {
        return [
            'ID',
            'ID DITEC',
            'No. DITEC',
            'Producto DITEC',
            'Fabricante',
            'ID Proveedor',
            'Proveedor',
            'País Proveedor',
            'Código Proveedor',
            'Activo',
            'Tipo Proveedor',
            'Contacto',
            'Teléfono',
            'Email',
            'Dirección',
            'Fecha Creación'
        ];
    }

    public function map($item): array
    {
        return [
            $item->Id,
            $item->{'Id DITEC'},
            $item->ditec?->{'No DITEC'} ?? 'N/A',
            $item->ditec?->Producto ?? 'N/A',
            $item->ditec?->Fabricante ?? 'N/A',
            $item->{'Id Proveedor'},
            $item->proveedor?->Proveedor ?? 'N/A',
            $item->proveedor?->{'País'} ?? 'N/A',
            $item->proveedor?->{'Codigo Proveedor'} ?? 'N/A',
            $item->proveedor?->Activo ? 'Sí' : 'No',
            $item->proveedor?->{'Tipo de Proveedor'} ?? 'N/A',
            $item->proveedor?->Contacto ?? 'N/A',
            $item->proveedor?->{'Teléfono Proveedor'} ?? 'N/A',
            $item->proveedor?->{'e-mail'} ?? 'N/A',
            $item->proveedor?->{'Direccion Proveedor'} ?? 'N/A',
            $item->proveedor?->{'created_at'} ? \Carbon\Carbon::parse($item->proveedor->{'created_at'})->format('d/m/Y') : ''
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }
}