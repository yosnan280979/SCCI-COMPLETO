<?php

namespace App\Exports;

use App\Models\DatosCttoSuministro;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class DatosCttoSuministroExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function collection()
    {
        return $this->items;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Contrato Suministro',
            'No. Suplemento',
            'Fecha Firma',
            'Importe CUC',
            'Importe CUP',
            'Pendiente Financiar CUC',
            'Pendiente CUP',
            'Forma de Pago',
        ];
    }

    public function map($item): array
    {
        return [
            $item->{'Id Supsum'},
            $item->contratoSuministro ? $item->contratoSuministro->Descripcion : 'N/A',
            $item->{'No Suplemento'},
            $item->{'Fecha firma Ctto'} ? \Carbon\Carbon::parse($item->{'Fecha firma Ctto'})->format('d/m/Y') : '',
            $item->{'Importe CUC'} ?? 0,
            $item->{'Importe CUP'} ?? 0,
            $item->{'Pendiente Finan CUC'} ?? 0,
            $item->{'Pendiente CUP'} ?? 0,
            $item->{'Forma de Pago'} ?? '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}