<!DOCTYPE html>
<html>
<head>
    <title>Certificados de Compra (CC) - Impresión</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            font-size: 11px;
            margin: 0;
            padding: 15px;
        }
        .header { 
            text-align: center; 
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #333;
        }
        .title { 
            font-size: 16px; 
            font-weight: bold;
        }
        .subtitle { 
            font-size: 12px; 
            color: #666;
            margin-bottom: 5px;
        }
        .filters { 
            margin-bottom: 15px; 
            padding: 10px; 
            background: #f5f5f5; 
            border-radius: 5px; 
            font-size: 10px;
            border: 1px solid #ddd;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 10px; 
            font-size: 9px;
        }
        th { 
            background-color: #f2f2f2; 
            font-weight: bold; 
            text-align: left; 
            padding: 6px; 
            border: 1px solid #ddd; 
            white-space: nowrap;
        }
        td { 
            padding: 6px; 
            border: 1px solid #ddd; 
            vertical-align: top;
        }
        .footer { 
            margin-top: 30px; 
            padding-top: 10px;
            text-align: center; 
            font-size: 9px; 
            color: #666;
            border-top: 1px solid #ddd;
        }
        @media print {
            .no-print { 
                display: none; 
            }
            .page-break { 
                page-break-before: always; 
            }
            body { 
                font-size: 10px;
            }
            table {
                font-size: 8px;
            }
        }
        .text-right { 
            text-align: right; 
        }
        .text-center { 
            text-align: center; 
        }
        .text-left { 
            text-align: left; 
        }
        .nowrap { 
            white-space: nowrap; 
        }
        .wrap {
            word-wrap: break-word;
            word-break: break-all;
            max-width: 150px;
        }
        .total-row {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        @media print {
            @page {
                size: landscape;
                margin: 0.5cm;
            }
        }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; margin-right: 10px;">
            🖨️ Imprimir
        </button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #6c757d; color: white; border: none; border-radius: 5px; cursor: pointer;">
            ✖️ Cerrar
        </button>
    </div>
    
    <div class="header">
        <div class="title">LISTADO DE CERTIFICADOS DE COMPRA (CC)</div>
        <div class="subtitle">Fecha de generación: {{ now()->format('d/m/Y H:i:s') }}</div>
        <div class="subtitle">Total de registros: {{ $items->count() }}</div>
    </div>
    
    @if(!empty($filtros))
    <div class="filters">
        <strong>Filtros aplicados:</strong><br>
        @foreach($filtros as $filtro)
            @if(!empty($filtro))
                • {{ $filtro }}<br>
            @endif
        @endforeach
    </div>
    @endif
    
    @if($items->count() > 0)
    <table>
        <thead>
            <tr>
                <th width="30">ID</th>
                <th width="60">No. CC</th>
                <th width="60">ID SOE</th>
                <th width="80">SOE</th>
                <th width="70">Valor CC</th>
                <th width="50">Moneda</th>
                <th width="80">Capacidad</th>
                <th width="80">Momento CC</th>
                <th width="70">Fecha Presentada</th>
                <th width="70">Fecha Apertura</th>
                <th width="70">Fecha Pedido Cap</th>
                <th width="70">Fecha Asignada Cap</th>
                <th width="50">Año finan</th>
                <th width="90">Línea Crédito</th>
                <th width="100">Observaciones</th>
                <!-- Agregar más columnas si existen -->
                <th width="70">Usuario</th>
                <th width="60">Activo</th>
            </tr>
        </thead>
        <tbody>
            @foreach($items as $item)
                <tr>
                    <td class="text-center">{{ $item->{'Id CC'} }}</td>
                    <td class="text-center">{{ $item->{'No CC'} }}</td>
                    <td class="text-center">{{ $item->{'Id SOE'} }}</td>
                    <td>{{ $item->soe->{'Id SOE'} ?? 'N/A' }}</td>
                    <td class="text-right">{{ number_format($item->{'Valor CC'}, 2) }}</td>
                    <td class="text-center">{{ $item->moneda->Moneda ?? 'N/A' }}</td>
                    <td>{{ $item->capacidad->Capacidad ?? 'N/A' }}</td>
                    <td>{{ $item->momentoCC->{'Momento CC'} ?? 'N/A' }}</td>
                    <td class="nowrap">{{ $item->{'Fecha Presentada CC'} ? \Carbon\Carbon::parse($item->{'Fecha Presentada CC'})->format('d/m/Y') : '' }}</td>
                    <td class="nowrap">{{ $item->{'Fecha Apertura CC'} ? \Carbon\Carbon::parse($item->{'Fecha Apertura CC'})->format('d/m/Y') : '' }}</td>
                    <td class="nowrap">{{ $item->{'Fecha Pedido Cap'} ? \Carbon\Carbon::parse($item->{'Fecha Pedido Cap'})->format('d/m/Y') : '' }}</td>
                    <td class="nowrap">{{ $item->{'Fecha Asignada Cap'} ? \Carbon\Carbon::parse($item->{'Fecha Asignada Cap'})->format('d/m/Y') : '' }}</td>
                    <td class="text-center">{{ $item->{'Año finan'} }}</td>
                    <td>{{ $item->lineaCredito->{'Linea de Crédito'} ?? 'N/A' }}</td>
                    <td class="wrap">{{ $item->{'Observaciones CC'} ?? '' }}</td>
                    <td>{{ $item->{'Usuario'} ?? 'N/A' }}</td>
                    <td class="text-center">{{ $item->{'Activo'} ?? 'N/A' }}</td>
                </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr class="total-row">
                <td colspan="4" class="text-right"><strong>TOTALES:</strong></td>
                <td class="text-right"><strong>{{ number_format($items->sum('Valor CC'), 2) }}</strong></td>
                <td colspan="13" class="text-center">
                    <strong>Total de registros: {{ $items->count() }}</strong>
                </td>
            </tr>
        </tfoot>
    </table>
    
    <div class="footer">
        <p>Generado por: {{ auth()->user()->{'Usuario'} ?? 'Sistema' }}</p>
        <p>Sistema de Control de Contratación e Importaciones (SCCI)</p>
    </div>
    @else
    <div class="text-center" style="margin-top: 50px; font-style: italic; font-size: 12px;">
        No hay datos para mostrar con los filtros aplicados.
    </div>
    @endif
    
    <script>
        // Auto-print on load (opcional)
        // window.onload = function() { window.print(); }
    </script>
</body>
</html>