@extends('layouts.app')

@section('title', 'Datos CC')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Certificados de Compra (CC)</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('datos-cc.create') }}" class="btn btn-primary btn-sm">➕ Nuevo CC</a>
                <!-- Formularios de exportación (GET) - ELIMINADO @csrf -->
                <form id="exportForm" method="GET" action="{{ route('datos-cc.export.excel') }}" style="display: inline">
                    <input type="hidden" name="selected" id="exportSelected" value="">
                    <input type="hidden" name="No_CC" value="{{ request('No_CC') }}">
                    <input type="hidden" name="Id_SOE" value="{{ request('Id_SOE') }}">
                    <input type="hidden" name="Id_Capacidad" value="{{ request('Id_Capacidad') }}">
                    <input type="hidden" name="Id_MomentoCC" value="{{ request('Id_MomentoCC') }}">
                    <input type="hidden" name="Id_Linea_credito" value="{{ request('Id_Linea_credito') }}">
                    <input type="hidden" name="Año_finan" value="{{ request('Año_finan') }}">
                    <input type="hidden" name="fecha_inicio" value="{{ request('fecha_inicio') }}">
                    <input type="hidden" name="fecha_fin" value="{{ request('fecha_fin') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                <form id="exportPdfForm" method="GET" action="{{ route('datos-cc.export.pdf') }}" style="display: inline">
                    <input type="hidden" name="selected" id="exportPdfSelected" value="">
                    <input type="hidden" name="No_CC" value="{{ request('No_CC') }}">
                    <input type="hidden" name="Id_SOE" value="{{ request('Id_SOE') }}">
                    <input type="hidden" name="Id_Capacidad" value="{{ request('Id_Capacidad') }}">
                    <input type="hidden" name="Id_MomentoCC" value="{{ request('Id_MomentoCC') }}">
                    <input type="hidden" name="Id_Linea_credito" value="{{ request('Id_Linea_credito') }}">
                    <input type="hidden" name="Año_finan" value="{{ request('Año_finan') }}">
                    <input type="hidden" name="fecha_inicio" value="{{ request('fecha_inicio') }}">
                    <input type="hidden" name="fecha_fin" value="{{ request('fecha_fin') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                <form id="printForm" method="GET" action="{{ route('datos-cc.print') }}" style="display: inline" target="_blank">
                    <input type="hidden" name="selected" id="printSelected" value="">
                    <input type="hidden" name="No_CC" value="{{ request('No_CC') }}">
                    <input type="hidden" name="Id_SOE" value="{{ request('Id_SOE') }}">
                    <input type="hidden" name="Id_Capacidad" value="{{ request('Id_Capacidad') }}">
                    <input type="hidden" name="Id_MomentoCC" value="{{ request('Id_MomentoCC') }}">
                    <input type="hidden" name="Id_Linea_credito" value="{{ request('Id_Linea_credito') }}">
                    <input type="hidden" name="Año_finan" value="{{ request('Año_finan') }}">
                    <input type="hidden" name="fecha_inicio" value="{{ request('fecha_inicio') }}">
                    <input type="hidden" name="fecha_fin" value="{{ request('fecha_fin') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Filtros -->
            <form method="GET" action="{{ route('datos-cc.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-2">
                        <input type="text" name="No_CC" class="form-control" placeholder="No. CC" 
                               value="{{ request('No_CC') }}">
                    </div>
                    <div class="col-md-2">
                        <input type="text" name="Id_SOE" class="form-control" placeholder="ID SOE" 
                               value="{{ request('Id_SOE') }}">
                    </div>
                    <div class="col-md-2">
                        <select name="Id_Capacidad" class="form-select">
                            <option value="">Capacidad</option>
                            @foreach($capacidades as $capacidad)
                                <option value="{{ $capacidad->{'Id Capacidad'} }}" 
                                    {{ request('Id_Capacidad') == $capacidad->{'Id Capacidad'} ? 'selected' : '' }}>
                                    {{ $capacidad->Capacidad }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="Id_MomentoCC" class="form-select">
                            <option value="">Momento CC</option>
                            @foreach($momentosCC as $momento)
                                <option value="{{ $momento->{'Id MomentoCC'} }}" 
                                    {{ request('Id_MomentoCC') == $momento->{'Id MomentoCC'} ? 'selected' : '' }}>
                                    {{ $momento->{'Momento CC'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="Id_Linea_credito" class="form-select">
                            <option value="">Línea Crédito</option>
                            @foreach($lineasCredito as $linea)
                                <option value="{{ $linea->{'Id Lineacredito'} }}" 
                                    {{ request('Id_Linea_credito') == $linea->{'Id Lineacredito'} ? 'selected' : '' }}>
                                    {{ $linea->{'Linea de Crédito'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2">
                        <input type="number" name="Año_finan" class="form-control" placeholder="Año finan" 
                               value="{{ request('Año_finan') }}">
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-2">
                        <input type="date" name="fecha_inicio" class="form-control" 
                               value="{{ request('fecha_inicio') }}" placeholder="Fecha inicio">
                    </div>
                    <div class="col-md-2">
                        <input type="date" name="fecha_fin" class="form-control" 
                               value="{{ request('fecha_fin') }}" placeholder="Fecha fin">
                    </div>
                    <div class="col-md-2">
                        <select name="sort_by" class="form-select">
                            <option value="">Ordenar por</option>
                            <option value="Id CC" {{ request('sort_by') == 'Id CC' ? 'selected' : '' }}>
                                ID
                            </option>
                            <option value="No CC" {{ request('sort_by') == 'No CC' ? 'selected' : '' }}>
                                No. CC
                            </option>
                            <option value="Valor CC" {{ request('sort_by') == 'Valor CC' ? 'selected' : '' }}>
                                Valor CC
                            </option>
                            <option value="Fecha Presentada CC" {{ request('sort_by') == 'Fecha Presentada CC' ? 'selected' : '' }}>
                                Fecha Presentada
                            </option>
                            <option value="Año finan" {{ request('sort_by') == 'Año finan' ? 'selected' : '' }}>
                                Año Finan
                            </option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="sort_dir" class="form-select">
                            <option value="desc" {{ request('sort_dir', 'desc') == 'desc' ? 'selected' : '' }}>
                                Descendente
                            </option>
                            <option value="asc" {{ request('sort_dir') == 'asc' ? 'selected' : '' }}>
                                Ascendente
                            </option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('datos-cc.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
            </form>

            @if($items->isEmpty())
                <div class="alert alert-info">No hay certificados de compra registrados.</div>
            @else
                <!-- Formulario principal para eliminación múltiple (DELETE) -->
                <form id="deleteForm" method="POST" action="{{ route('datos-cc.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <!-- Tabla con scroll horizontal -->
                    <div class="table-responsive" style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
                        <table class="table table-bordered table-hover table-sm align-middle" style="min-width: 1600px;">
                            <thead class="table-light">
                                <tr>
                                    <th width="50"><input type="checkbox" id="selectAll"></th>
                                    <th width="80">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Id CC';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Id CC' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-cc.index', $queryParams) }}">
                                            ID
                                            @if(request('sort_by') == 'Id CC')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="100">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'No CC';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'No CC' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-cc.index', $queryParams) }}">
                                            No CC
                                            @if(request('sort_by') == 'No CC')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="100">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Id SOE';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Id SOE' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-cc.index', $queryParams) }}">
                                            ID SOE
                                            @if(request('sort_by') == 'Id SOE')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="100">SOE</th>
                                    <th width="120">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Valor CC';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Valor CC' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-cc.index', $queryParams) }}">
                                            Valor CC
                                            @if(request('sort_by') == 'Valor CC')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="90">Moneda</th>
                                    <th width="120">Capacidad</th>
                                    <th width="120">Momento CC</th>
                                    <th width="120">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Fecha Presentada CC';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Fecha Presentada CC' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-cc.index', $queryParams) }}">
                                            Fecha Presentada
                                            @if(request('sort_by') == 'Fecha Presentada CC')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="120">Fecha Apertura</th>
                                    <th width="120">Fecha Pedido Cap</th>
                                    <th width="120">Fecha Asignada Cap</th>
                                    <th width="120">
                                        <!-- Enlace de ordenación corregido -->
                                        @php
                                            $queryParams = request()->all();
                                            $queryParams['sort_by'] = 'Año finan';
                                            $queryParams['sort_dir'] = (request('sort_by') == 'Año finan' && request('sort_dir', 'desc') == 'desc') ? 'asc' : 'desc';
                                        @endphp
                                        <a href="{{ route('datos-cc.index', $queryParams) }}">
                                            Año Finan
                                            @if(request('sort_by') == 'Año finan')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th width="150">Línea Crédito</th>
                                    <th width="200">Observaciones</th>
                                    <th width="150">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($items as $item)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="ids[]" value="{{ $item->{'Id CC'} }}" class="select-item">
                                        </td>
                                        <td>{{ $item->{'Id CC'} }}</td>
                                        <td>{{ $item->{'No CC'} }}</td>
                                        <td>{{ $item->{'Id SOE'} }}</td>
                                        <td>{{ $item->soe->{'Id SOE'} ?? 'N/A' }}</td>
                                        <td class="text-end">{{ number_format($item->{'Valor CC'}, 2) }}</td>
                                        <td>{{ $item->moneda->Moneda ?? 'N/A' }}</td>
                                        <td>{{ $item->capacidad->Capacidad ?? 'N/A' }}</td>
                                        <td>{{ $item->momentoCC->{'Momento CC'} ?? 'N/A' }}</td>
                                        <td>{{ $item->{'Fecha Presentada CC'} ? \Carbon\Carbon::parse($item->{'Fecha Presentada CC'})->format('d/m/Y') : '' }}</td>
                                        <td>{{ $item->{'Fecha Apertura CC'} ? \Carbon\Carbon::parse($item->{'Fecha Apertura CC'})->format('d/m/Y') : '' }}</td>
                                        <td>{{ $item->{'Fecha Pedido Cap'} ? \Carbon\Carbon::parse($item->{'Fecha Pedido Cap'})->format('d/m/Y') : '' }}</td>
                                        <td>{{ $item->{'Fecha Asignada Cap'} ? \Carbon\Carbon::parse($item->{'Fecha Asignada Cap'})->format('d/m/Y') : '' }}</td>
                                        <td class="text-center">{{ $item->{'Año finan'} }}</td>
                                        <td>{{ $item->lineaCredito->{'Linea de Crédito'} ?? 'N/A' }}</td>
                                        <td title="{{ $item->{'Observaciones CC'} }}">
                                            {{ Str::limit($item->{'Observaciones CC'} ?? '', 30) }}
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('datos-cc.show', $item->{'Id CC'}) }}" class="btn btn-info btn-sm">Ver</a>
                                                <a href="{{ route('datos-cc.edit', $item->{'Id CC'}) }}" class="btn btn-warning btn-sm">Editar</a>
                                                <form action="{{ route('datos-cc.destroy', $item->{'Id CC'}) }}" method="POST" style="display:inline-block">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar este certificado?')">Eliminar</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            @if($items->isNotEmpty())
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="5" class="text-end"><strong>Totales:</strong></td>
                                    <td class="text-end">
                                        <strong>
                                            @php
                                                $totalValor = $items->sum('Valor CC');
                                            @endphp
                                            {{ number_format($totalValor, 2) }}
                                        </strong>
                                    </td>
                                    <td colspan="11"><strong>{{ $items->count() }} registros</strong></td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar los certificados seleccionados?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación corregida -->
                @if($items->hasPages())
                    @php 
                        // Preservar todos los parámetros de búsqueda en la paginación
                        $queryParams = request()->all();
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $items->firstItem() }}–{{ $items->lastItem() }} de {{ $items->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <!-- Primera página -->
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-cc.index', $queryParams) }}">« Primera</a>
                                </li>
                                
                                <!-- Página anterior -->
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = $items->currentPage() - 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-cc.index', $queryParams) }}">‹</a>
                                </li>
                                
                                <!-- Página actual -->
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $items->currentPage() }} de {{ $items->lastPage() }}</span>
                                </li>
                                
                                <!-- Página siguiente -->
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $items->currentPage() + 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-cc.index', $queryParams) }}">›</a>
                                </li>
                                
                                <!-- Última página -->
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $items->lastPage();
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-cc.index', $queryParams) }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<style>
/* Estilos para la tabla con scroll horizontal */
.table-responsive {
    border: 1px solid #dee2e6;
    border-radius: 4px;
    margin-bottom: 1rem;
}

/* Asegurar que las celdas mantengan su tamaño */
.table th, .table td {
    white-space: nowrap;
    vertical-align: middle;
    padding: 0.5rem;
}

/* Tooltips para texto largo */
[title] {
    cursor: help;
    position: relative;
}

/* Estilo para columnas numéricas */
.text-end {
    font-family: 'Courier New', monospace;
    font-weight: 500;
}

/* Mejorar visualización de botones */
.btn-group .btn-sm {
    padding: 0.25rem 0.5rem;
}

/* Scroll suave en móviles */
@media (max-width: 768px) {
    .table-responsive {
        -webkit-overflow-scrolling: touch;
    }
    
    .card-body {
        padding: 0.75rem;
    }
}

/* Ajustar tamaño de letra para que sea consistente con otras vistas */
.table-sm {
    font-size: 0.875rem;
}

/* Títulos de columnas más compactos pero legibles */
.table th {
    font-weight: 600;
    background-color: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
}

/* Hover para filas */
.table-hover tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.075);
}

/* Badges con mejor espaciado */
.badge {
    padding: 0.35em 0.65em;
    font-size: 0.75em;
    font-weight: 600;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar exportSelected cuando cambian las selecciones
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportSelected').value = selectedString;
        document.getElementById('exportPdfSelected').value = selectedString;
        document.getElementById('printSelected').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
    
    // Tooltips de Bootstrap para las observaciones truncadas
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
});
</script>
@endsection