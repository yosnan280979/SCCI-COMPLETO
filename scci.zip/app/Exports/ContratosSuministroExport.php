<?php

namespace App\Exports;

use App\Models\ContratoSuministro;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ContratosSuministroExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $contratos;

    public function __construct($contratos)
    {
        $this->contratos = $contratos;
    }

    public function collection()
    {
        return $this->contratos;
    }

    public function headings(): array
    {
        return [
            'ID',
            'No. Contrato Suministro',
            'Cliente',
            'Descripción',
            'Observaciones',
        ];
    }

    public function map($contrato): array
    {
        return [
            $contrato->{'Id Cttosuministro'},
            $contrato->{'No Ctto Suministro'},
            $contrato->cliente?->{'Cliente'} ?? '',
            $contrato->{'Descripcion'} ?? '',
            $contrato->{'Observaciones Ctto Sum'} ?? '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}