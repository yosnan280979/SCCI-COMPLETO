<?php
echo "=== Corrigiendo rutas en vistas Blade ===\n\n";

// Lista de correcciones
$corrections = [
    // Clientes - inglés a español
    'nomencladores\.clients\.' => 'nomencladores\.clientes\.',
    
    // Proveedores - inglés a español
    'nomencladores\.providers\.' => 'proveedores\.',
    
    // Tipo Proveedor - guión bajo a guión
    'nomencladores\.tipo_proveedor\.' => 'nomencladores\.tipo-proveedor\.',
    
    // Specialists - inglés a español
    'nomencladores\.specialists\.' => 'nomencladores\.especialistas\.',
    
    // User Types - inglés a español
    'nomencladores\.user_types\.' => 'nomencladores\.tipos-usuario\.',
    
    // Otras posibles correcciones
    'nomencladores\.balance_centers\.' => 'nomencladores\.centros-balance\.',
    'nomencladores\.financing_sources\.' => 'nomencladores\.financing-sources\.',
    'nomencladores\.tipo_productos_general\.' => 'nomencladores\.tipo-productos-general\.',
    'nomencladores\.tipos_productos\.' => 'nomencladores\.tipo-productos\.',
    'nomencladores\.tipo_ctto_cubano\.' => 'nomencladores\.tipo-contrato-cubano\.',
    'nomencladores\.tipo_respuesta\.' => 'nomencladores\.tipo-respuesta\.',
    'nomencladores\.momentos_cc\.' => 'nomencladores\.momentos-cc\.',
    'nomencladores\.momentos_soe\.' => 'nomencladores\.momentos-soe\.',
    'nomencladores\.actualizar\.' => 'nomencladores\.tipos-actualizacion\.',
];

// Directorio de vistas
$viewsDir = 'resources/views/';

// Recorrer todos los archivos blade
$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($viewsDir),
    RecursiveIteratorIterator::SELF_FIRST
);

$filesFixed = 0;

foreach ($iterator as $file) {
    if ($file->isFile() && $file->getExtension() === 'php') {
        $content = file_get_contents($file->getPathname());
        $originalContent = $content;
        
        foreach ($corrections as $wrong => $right) {
            $content = preg_replace("/$wrong/", $right, $content);
        }
        
        if ($content !== $originalContent) {
            file_put_contents($file->getPathname(), $content);
            echo "✓ Corregido: " . $file->getPathname() . "\n";
            $filesFixed++;
        }
    }
}

echo "\n=== Resumen ===\n";
echo "Archivos corregidos: $filesFixed\n";
echo "¡Proceso completado!\n";

// Mostrar rutas disponibles después de la corrección
echo "\n=== Rutas disponibles (relacionadas) ===\n";
exec('php artisan route:list | grep -E "(clientes|proveedores|tipo-proveedor|especialistas|tipos-usuario)"', $output);
foreach ($output as $line) {
    echo $line . "\n";
}
