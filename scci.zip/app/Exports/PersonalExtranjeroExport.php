<?php

namespace App\Exports;

use App\Models\DatosPersonalExtranjero;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class PersonalExtranjeroExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function collection()
    {
        return $this->items;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Proveedor',
            'Funcionario',
            'Cargo',
            'Email',
            'Teléfono',
            'Activo',
            'Firmante',
            'Permiso Trabajo',
            'Fecha Vencimiento',
        ];
    }

    public function map($item): array
    {
        return [
            $item->Id,
            $item->proveedor->Proveedor ?? 'N/A',
            $item->Funcionario_extranjero,
            $item->Cargo ?? '',
            $item->Email ?? '',
            $item->Telef ?? '',
            $item->Activo ? 'Sí' : 'No',
            $item->Firmante ? 'Sí' : 'No',
            $item->Permiso_de_Trabajo ?? '',
            $item->Fecha_Vencimiento ? \Carbon\Carbon::parse($item->Fecha_Vencimiento)->format('d/m/Y') : '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}