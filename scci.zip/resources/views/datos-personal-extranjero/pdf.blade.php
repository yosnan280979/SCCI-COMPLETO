<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Personal Extranjero - PDF</title>
    <style>
        @page {
            size: landscape;
            margin: 10px;
        }
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 8px;
            margin: 0;
            padding: 10px;
        }
        .header {
            text-align: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #333;
        }
        .header h1 {
            margin: 0;
            font-size: 16px;
            color: #2c3e50;
        }
        .header .info {
            font-size: 8px;
            color: #7f8c8d;
            margin-top: 5px;
        }
        .filters {
            margin-bottom: 10px;
            padding: 8px;
            background-color: #f8f9fa;
            border-radius: 3px;
            font-size: 8px;
            border-left: 4px solid #007bff;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            table-layout: fixed;
        }
        .table th {
            background-color: #2c3e50;
            color: white;
            border: 1px solid #34495e;
            padding: 6px 4px;
            text-align: left;
            font-size: 8px;
            font-weight: bold;
        }
        .table td {
            border: 1px solid #bdc3c7;
            padding: 5px 3px;
            font-size: 7.5px;
            vertical-align: top;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }
        .badge {
            padding: 2px 5px;
            border-radius: 2px;
            font-size: 7px;
            font-weight: bold;
            display: inline-block;
            text-align: center;
            min-width: 25px;
        }
        .badge-success {
            background-color: #28a745;
            color: white;
        }
        .badge-danger {
            background-color: #dc3545;
            color: white;
        }
        .badge-secondary {
            background-color: #6c757d;
            color: white;
        }
        .badge-warning {
            background-color: #ffc107;
            color: #212529;
        }
        .summary {
            margin-bottom: 10px;
            padding: 8px;
            background-color: #f8f9fa;
            border-radius: 3px;
            font-size: 8px;
            border: 1px solid #dee2e6;
        }
        .summary-item {
            margin-bottom: 2px;
        }
        .footer {
            margin-top: 15px;
            text-align: center;
            font-size: 7px;
            color: #7f8c8d;
            border-top: 1px solid #ecf0f1;
            padding-top: 8px;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
        .page-number:after {
            content: counter(page);
        }
        /* Column widths */
        .col-id { width: 30px; }
        .col-provider { width: 100px; }
        .col-funcionario { width: 120px; }
        .col-cargo { width: 100px; }
        .col-email { width: 120px; }
        .col-telefono { width: 80px; }
        .col-activo { width: 40px; }
        .col-permiso { width: 80px; }
        .col-pais { width: 40px; }
        .col-vencimiento { width: 60px; }
        .col-firmante { width: 40px; }
        .col-escnot { width: 40px; }
        .col-aprot { width: 40px; }
        .col-fechavenpod { width: 60px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>REPORTE DE PERSONAL EXTRANJERO</h1>
        <div class="info">
            Sistema SCCI | Fecha: {{ \Carbon\Carbon::now()->format('d/m/Y H:i:s') }} | Página: <span class="page-number"></span>
        </div>
    </div>

    @if(!empty($filtros))
    <div class="filters">
        <strong>Filtros aplicados:</strong><br>
        @foreach($filtros as $filtro)
        • {{ $filtro }}<br>
        @endforeach
    </div>
    @endif

    <div class="summary">
        <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
            <div class="summary-item"><strong>Total registros:</strong> {{ $items->count() }}</div>
            <div class="summary-item"><strong>Activos:</strong> {{ $items->where('Activo', 1)->count() }}</div>
            <div class="summary-item"><strong>Inactivos:</strong> {{ $items->where('Activo', 0)->count() }}</div>
            <div class="summary-item"><strong>Firmantes:</strong> {{ $items->where('Firmante', 1)->count() }}</div>
            <div class="summary-item"><strong>No firmantes:</strong> {{ $items->where('Firmante', 0)->count() }}</div>
        </div>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th class="col-id">ID</th>
                <th class="col-provider">Proveedor</th>
                <th class="col-funcionario">Funcionario</th>
                <th class="col-cargo">Cargo</th>
                <th class="col-email">Email</th>
                <th class="col-telefono">Teléfono</th>
                <th class="col-activo">Activo</th>
                <th class="col-permiso">Permiso Trabajo</th>
                <th class="col-pais">ID País</th>
                <th class="col-vencimiento">Fecha Vencimiento</th>
                <th class="col-firmante">Firmante</th>
                <th class="col-escnot">Escnot</th>
                <th class="col-aprot">Aprot</th>
                <th class="col-fechavenpod">Fechavenpod</th>
            </tr>
        </thead>
        <tbody>
            @foreach($items as $item)
                <tr>
                    <td class="text-center">{{ $item->Id ?? $item->id }}</td>
                    <td>{{ $item->proveedor->Proveedor ?? 'N/A' }}</td>
                    <td>{{ $item->Funcionario_extranjero }}</td>
                    <td>{{ $item->Cargo ?? 'N/A' }}</td>
                    <td>{{ $item->Email ?? 'N/A' }}</td>
                    <td>{{ $item->Telef ?? 'N/A' }}</td>
                    <td class="text-center">
                        <span class="badge {{ $item->Activo ? 'badge-success' : 'badge-danger' }}">
                            {{ $item->Activo ? 'Sí' : 'No' }}
                        </span>
                    </td>
                    <td>{{ $item->Permiso_de_Trabajo ?? 'N/A' }}</td>
                    <td class="text-center">{{ $item->Id_pais ?? 'N/A' }}</td>
                    <td class="text-center">
                        @if($item->Fecha_Vencimiento)
                            {{ \Carbon\Carbon::parse($item->Fecha_Vencimiento)->format('d/m/Y') }}
                        @else
                            N/A
                        @endif
                    </td>
                    <td class="text-center">
                        <span class="badge {{ $item->Firmante ? 'badge-warning' : 'badge-secondary' }}">
                            {{ $item->Firmante ? 'Sí' : 'No' }}
                        </span>
                    </td>
                    <td class="text-center">{{ $item->Escnot ?? 'N/A' }}</td>
                    <td class="text-center">{{ $item->Aprot ?? 'N/A' }}</td>
                    <td class="text-center">
                        @if($item->Fechavenpod)
                            {{ \Carbon\Carbon::parse($item->Fechavenpod)->format('d/m/Y') }}
                        @else
                            N/A
                        @endif
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <div class="footer">
        Documento confidencial - Sistema SCCI<br>
        Generado por: {{ auth()->user()->{'Nombre completo'} ?? 'Usuario' }}<br>
        {{ \Carbon\Carbon::now()->format('d/m/Y H:i:s') }}
    </div>
</body>
</html>