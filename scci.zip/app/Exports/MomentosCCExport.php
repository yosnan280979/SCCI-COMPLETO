<?php

namespace App\Exports;

use App\Models\MomentoCC;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class MomentosCCExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $momentosCC;

    public function __construct($momentosCC)
    {
        $this->momentosCC = $momentosCC;
    }

    public function collection()
    {
        return $this->momentosCC;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Momento CC',
        ];
    }

    public function map($momentoCC): array
    {
        return [
            $momentoCC->{'Id MomentoCC'},
            $momentoCC->{'Momento CC'},
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}