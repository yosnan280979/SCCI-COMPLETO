<?php
require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

echo "=== VERIFICACIÓN Y CORRECCIÓN DE PERMISOS ===\n\n";

// 1. Verificar tablas existentes (sin usar parámetros vinculados)
echo "1. Verificando tablas...\n";
$tables = DB::select("SHOW TABLES");

$existingTables = [];
foreach ($tables as $table) {
    foreach ($table as $key => $value) {
        $existingTables[] = $value;
    }
}

$requiredTables = ['modules', 'permissions', 'Nomenclador Usuarios', 'Nomenclador Areas'];
foreach ($requiredTables as $table) {
    echo in_array($table, $existingTables) ? "  ✓ $table\n" : "  ✗ $table\n";
}

// 2. Crear tablas si no existen
echo "\n2. Creando tablas si no existen...\n";

// Tabla modules
if (!in_array('modules', $existingTables)) {
    DB::statement("
        CREATE TABLE modules (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL,
            `order` INT DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    echo "  ✓ Tabla 'modules' creada\n";
} else {
    echo "  ✓ Tabla 'modules' ya existe\n";
}

// Tabla permissions
if (!in_array('permissions', $existingTables)) {
    DB::statement("
        CREATE TABLE permissions (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            id_area INT NOT NULL,
            id_module INT NOT NULL,
            view TINYINT DEFAULT 0,
            create_p TINYINT DEFAULT 0,
            edit TINYINT DEFAULT 0,
            delete_p TINYINT DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    echo "  ✓ Tabla 'permissions' creada\n";
} else {
    echo "  ✓ Tabla 'permissions' ya existe\n";
}

// 3. Verificar Nomenclador Areas
if (!in_array('Nomenclador Areas', $existingTables)) {
    echo "  ✗ ERROR: La tabla 'Nomenclador Areas' no existe\n";
    echo "  No se puede continuar sin la tabla de áreas.\n";
    exit(1);
}

// 4. Verificar Nomenclador Usuarios
if (!in_array('Nomenclador Usuarios', $existingTables)) {
    echo "  ✗ ERROR: La tabla 'Nomenclador Usuarios' no existe\n";
    echo "  No se puede continuar sin la tabla de usuarios.\n";
    exit(1);
}

// 5. Insertar módulos básicos si no existen
echo "\n3. Insertando módulos básicos...\n";
$modules = [
    ['name' => 'Dashboard', 'slug' => 'dashboard', 'order' => 1],
    ['name' => 'Solicitudes', 'slug' => 'solicitudes', 'order' => 2],
    ['name' => 'Contratos', 'slug' => 'contratos', 'order' => 3],
    ['name' => 'Asignaciones', 'slug' => 'asignaciones', 'order' => 4],
    ['name' => 'Logística', 'slug' => 'logistica', 'order' => 5],
    ['name' => 'Proveedores', 'slug' => 'proveedores', 'order' => 6],
    ['name' => 'DITEC', 'slug' => 'ditec', 'order' => 7],
    ['name' => 'Finanzas', 'slug' => 'finanzas', 'order' => 8],
    ['name' => 'Operaciones', 'slug' => 'operaciones', 'order' => 9],
    ['name' => 'Organización', 'slug' => 'organizacion', 'order' => 10],
    ['name' => 'Usuarios', 'slug' => 'usuarios', 'order' => 11],
];

$modulesInserted = 0;
foreach ($modules as $module) {
    $exists = DB::table('modules')->where('slug', $module['slug'])->exists();
    if (!$exists) {
        DB::table('modules')->insert($module);
        $modulesInserted++;
    }
}
echo "  ✓ Módulos insertados/verificados: $modulesInserted nuevos\n";

// 6. Limpiar permisos existentes y crear nuevos
echo "\n4. Configurando permisos...\n";

// Primero, eliminar todos los permisos existentes
DB::table('permissions')->truncate();
echo "  ✓ Permisos anteriores eliminados\n";

// Obtener todas las áreas
$areas = DB::table('Nomenclador Areas')->get();
$modules = DB::table('modules')->get();

$permissionsCount = 0;
foreach ($areas as $area) {
    foreach ($modules as $module) {
        $view = 0;
        $create = 0;
        $edit = 0;
        $delete = 0;
        
        // Informática tiene acceso completo
        if ($area->Area === 'Informatica') {
            $view = 1;
            $create = 1;
            $edit = 1;
            $delete = 1;
        }
        // Dashboard para todos
        else if ($module->slug === 'dashboard') {
            $view = 1;
        }
        // Otros permisos básicos (puedes expandir esto)
        else if (in_array($area->Area, ['Dirección', 'Comerciales', 'Dir. UEB Importaciones'])) {
            if (in_array($module->slug, ['solicitudes', 'contratos', 'proveedores'])) {
                $view = 1;
                $create = 1;
            }
        }
        
        DB::table('permissions')->insert([
            'id_area' => $area->{'Id Area'},
            'id_module' => $module->id,
            'view' => $view,
            'create_p' => $create,
            'edit' => $edit,
            'delete_p' => $delete,
        ]);
        
        $permissionsCount++;
    }
}

echo "  ✓ $permissionsCount permisos creados\n";

// 7. Verificar usuarios
echo "\n5. Verificando usuarios...\n";
try {
    $users = DB::table('Nomenclador Usuarios as u')
        ->join('Nomenclador Areas as a', 'u.id_area', '=', 'a.`Id Area`')
        ->select(
            'u.Usuario',
            DB::raw('u.`Nombre completo` as nombre_completo'),
            'a.Area'
        )
        ->limit(5)
        ->get();

    echo "  Primeros " . count($users) . " usuarios:\n";
    foreach ($users as $user) {
        echo "    - " . $user->Usuario . " (" . $user->nombre_completo . ") - Área: " . $user->Area . "\n";
    }
} catch (\Exception $e) {
    echo "  Error al obtener usuarios: " . $e->getMessage() . "\n";
}

// 8. Probar el sistema con el primer usuario
echo "\n6. Probando sistema con el primer usuario...\n";
try {
    $user = \App\Models\User::first();
    
    if ($user) {
        echo "  Usuario: " . ($user->{'Nombre completo'} ?? $user->Usuario) . "\n";
        echo "  Área: " . ($user->area->Area ?? 'Sin área') . "\n";
        echo "  Es Informática: " . ($user->isInformatica() ? 'Sí' : 'No') . "\n";
        
        // Probar permisos
        echo "\n  Permisos de este usuario:\n";
        $testModules = ['dashboard', 'solicitudes', 'contratos', 'usuarios'];
        
        foreach ($testModules as $module) {
            $canView = $user->hasPermission($module, 'view') ? '✅' : '❌';
            echo "    $module: $canView\n";
        }
        
        // Verificar si Informática ve todos los módulos
        if ($user->isInformatica()) {
            $allModules = DB::table('modules')->count();
            $userModules = $user->getAllPermissions()->count();
            
            echo "\n  Verificación Informática:\n";
            echo "    Módulos totales: $allModules\n";
            echo "    Módulos con acceso: $userModules\n";
            
            if ($allModules == $userModules) {
                echo "    ✓ Informática puede ver todos los módulos\n";
            } else {
                echo "    ✗ Problema: Informática solo ve $userModules de $allModules módulos\n";
            }
        }
    } else {
        echo "  No se encontraron usuarios\n";
    }
} catch (\Exception $e) {
    echo "  Error: " . $e->getMessage() . "\n";
    echo "  Detalle: " . $e->getTraceAsString() . "\n";
}

// 9. Verificar estructura final
echo "\n7. Verificando estructura final...\n";
echo "  Módulos en BD: " . DB::table('modules')->count() . "\n";
echo "  Permisos en BD: " . DB::table('permissions')->count() . "\n";
echo "  Áreas en BD: " . DB::table('Nomenclador Areas')->count() . "\n";
echo "  Usuarios en BD: " . DB::table('Nomenclador Usuarios')->count() . "\n";

// 10. Resumen por área
echo "\n8. Resumen de permisos por área:\n";
$areasSummary = DB::table('Nomenclador Areas as a')
    ->leftJoin('permissions as p', 'a.`Id Area`', '=', 'p.id_area')
    ->select('a.Area', DB::raw('COUNT(p.id) as total_permisos'), DB::raw('SUM(p.view) as puede_ver'))
    ->groupBy('a.`Id Area`', 'a.Area')
    ->orderBy('a.Area')
    ->get();

foreach ($areasSummary as $area) {
    echo "  - " . $area->Area . ": " . $area->puede_ver . " módulos visibles\n";
}

echo "\n=== PROCESO COMPLETADO ===\n";
echo "\nInstrucciones:\n";
echo "1. Inicia sesión con un usuario de Informática\n";
echo "2. Deberías ver todos los menús\n";
echo "3. Inicia sesión con un usuario de otra área\n";
echo "4. Solo deberías ver Dashboard y otros módulos asignados\n";
echo "\nSi hay problemas, revisa:\n";
echo "- El modelo User.php (debe tener el método hasPermission)\n";
echo "- El helper PermissionsHelper.php\n";
echo "- La vista app.blade.php (debe usar canView())\n";