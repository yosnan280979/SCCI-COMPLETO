@extends('layouts.app')

@section('title', 'Detalle de Asignación')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Detalle de Asignación</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Centro de Balance:</strong> {{ $asignacion->centroBalance?->{'Centro Balance'} ?? '---' }}</p>
                    <p><strong>Línea de Crédito:</strong> {{ $asignacion->lineaCredito?->{'Linea de Crédito'} ?? '---' }}</p>
                    <p><strong>Fuente de Financiamiento:</strong> {{ $asignacion->fuenteFinanciamiento?->{'Fuente Financiamiento'} ?? '---' }}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Año:</strong> {{ $asignacion->{'Año Asignacion'} }}</p>
                    <p><strong>Valor:</strong> {{ number_format($asignacion->Valor, 2) }}</p>
                </div>
            </div>
            
            <div class="mt-4">
                <a href="{{ route('asignaciones.index') }}" class="btn btn-secondary">Volver</a>
                <a href="{{ route('asignaciones.edit', [
                    'cb' => $asignacion->{'Id Centro Balance'},
                    'lc' => $asignacion->{'Id Lineacredito'},
                    'ff' => $asignacion->{'Id Fuentafinan'},
                    'anio' => $asignacion->{'Año Asignacion'}
                ]) }}" class="btn btn-warning">Editar</a>
                <form action="{{ route('asignaciones.destroy', [
                    'cb' => $asignacion->{'Id Centro Balance'},
                    'lc' => $asignacion->{'Id Lineacredito'},
                    'ff' => $asignacion->{'Id Fuentafinan'},
                    'anio' => $asignacion->{'Año Asignacion'}
                ]) }}" method="POST" style="display:inline-block;">
                    @csrf @method('DELETE')
                    <button type="submit" class="btn btn-danger" onclick="return confirm('¿Eliminar esta asignación?')">Eliminar</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection