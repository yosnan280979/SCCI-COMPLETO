<table>
    <thead>
        <tr>
            <th style="background-color:#4e73df; color:#fff;">Empresa</th>
            <th style="background-color:#4e73df; color:#fff;">Ministerio</th>
            <th style="background-color:#4e73df; color:#fff;">NIT / REEUP</th>
            <th style="background-color:#4e73df; color:#fff;">Director</th>
            <th style="background-color:#4e73df; color:#fff;">Email</th>
        </tr>
    </thead>
    <tbody>
        @foreach($items as $item)
        <tr>
            <td>{{ $item->nombre_empresa }}</td>
            <td>{{ $item->ministerio ?? '' }}</td>
            <td>{{ $item->codigo_nit }}</td>
            <td>{{ $item->nombre_director }}</td>
            <td>{{ $item->email }}</td>
        </tr>
        @endforeach
    </tbody>
</table>