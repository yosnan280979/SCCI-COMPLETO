@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="card-title">Cache</h3>
                        <div>
                            <a href="{{ route('cache.create') }}" class="btn btn-primary">
                                <i class="fas fa-plus"></i> Nuevo Cache
                            </a>
                            <a href="{{ route('cache.export.excel') }}" class="btn btn-success">
                                <i class="fas fa-file-export"></i> Exportar Excel
                            </a>
                            <a href="{{ route('cache.export.pdf') }}" class="btn btn-danger" target="_blank">
                                <i class="fas fa-file-pdf"></i> PDF
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="cache-table" class="table table-bordered table-hover">
                            <!-- Contenido de la tabla -->
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection