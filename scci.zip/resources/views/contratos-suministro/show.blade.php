@extends('layouts.app')

@section('title', 'Detalle de Contrato Suministro')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Detalle de Contrato Suministro #{{ $contratoSuministro->{'Id Cttosuministro'} }}</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>ID:</strong> {{ $contratoSuministro->{'Id Cttosuministro'} }}</p>
                    <p><strong>No. Contrato Suministro:</strong> {{ $contratoSuministro->{'No Ctto Suministro'} }}</p>
                    <p><strong>Cliente:</strong> {{ $contratoSuministro->cliente?->{'Cliente'} }}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Descripción:</strong> {{ $contratoSuministro->{'Descripcion'} }}</p>
                    <p><strong>Observaciones:</strong> {{ $contratoSuministro->{'Observaciones Ctto Sum'} }}</p>
                </div>
            </div>
            
            <div class="mt-3">
                <a href="{{ route('contratos-suministro.index') }}" class="btn btn-secondary">Volver</a>
                <a href="{{ route('contratos-suministro.edit', $contratoSuministro->{'Id Cttosuministro'}) }}" class="btn btn-warning">Editar</a>
                <form action="{{ route('contratos-suministro.destroy', $contratoSuministro->{'Id Cttosuministro'}) }}" method="POST" style="display:inline-block">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger" onclick="return confirm('¿Eliminar este contrato de suministro?')">Eliminar</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection