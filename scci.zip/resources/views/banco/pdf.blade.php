<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Banco</title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            line-height: 1.5;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        .header h1 {
            margin: 0;
            color: #333;
            font-size: 24px;
        }
        .header .subtitle {
            color: #666;
            font-size: 14px;
        }
        .info-box {
            margin-bottom: 20px;
            padding: 10px;
            background-color: #f8f9fa;
            border-left: 4px solid #007bff;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table th {
            background-color: #343a40;
            color: white;
            padding: 8px;
            text-align: left;
            border: 1px solid #dee2e6;
        }
        .table td {
            padding: 8px;
            border: 1px solid #dee2e6;
        }
        .table tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 10px;
            color: #666;
            border-top: 1px solid #dee2e6;
            padding-top: 10px;
        }
        .text-right { text-align: right; }
        .page-break { page-break-before: always; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Reporte de Banco</h1>
        <div class="subtitle">
            Generado el: {{ date('d/m/Y H:i:s') }}
        </div>
    </div>
    
    <div class="info-box">
        <strong>Información del Reporte:</strong><br>
        Total de registros: {{ $banco->count() }}<br>
        @if(request('fecha_inicio'))
            Período: {{ request('fecha_inicio') }} al {{ request('fecha_fin') }}
        @endif
    </div>
    
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>País ID</th>
                
            </tr>
        </thead>
        <tbody>
            @foreach($banco as $banco)
            <tr>
                <td>{{ $banco->id }}</td>
                <td>{{ $banco->nombre }}</td>
                <td>{{ $banco->pais_id }}</td>
                
            </tr>
            @endforeach
        </tbody>
    </table>
    
    <div class="footer">
        Página {{ $pageNumber ?? 1 }}<br>
        Sistema de Gestión - Generado automáticamente
    </div>
</body>
</html>