@extends('layouts.app')

@section('title', 'Personal Cubano')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Personal Cubano</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('datos-personal-cubano.create') }}" class="btn btn-primary btn-sm">➕ Nuevo</a>
                
                <!-- Formularios de exportación separados (GET) -->
                <form id="exportExcelForm" method="GET" action="{{ route('datos-personal-cubano.export.excel') }}" style="display: inline">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="proveedor" value="{{ request('proveedor') }}">
                    <input type="hidden" name="activo" value="{{ request('activo') }}">
                    <input type="hidden" name="id_tipo_ctto" value="{{ request('id_tipo_ctto') }}">
                    <input type="hidden" name="vigencia_desde" value="{{ request('vigencia_desde') }}">
                    <input type="hidden" name="vigencia_hasta" value="{{ request('vigencia_hasta') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="exportSelectedIds" value="">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                
                <form id="exportPdfForm" method="GET" action="{{ route('datos-personal-cubano.export.pdf') }}" style="display: inline">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="proveedor" value="{{ request('proveedor') }}">
                    <input type="hidden" name="activo" value="{{ request('activo') }}">
                    <input type="hidden" name="id_tipo_ctto" value="{{ request('id_tipo_ctto') }}">
                    <input type="hidden" name="vigencia_desde" value="{{ request('vigencia_desde') }}">
                    <input type="hidden" name="vigencia_hasta" value="{{ request('vigencia_hasta') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="pdfSelectedIds" value="">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                
                <form id="printForm" method="GET" action="{{ route('datos-personal-cubano.print') }}" style="display: inline" target="_blank">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="proveedor" value="{{ request('proveedor') }}">
                    <input type="hidden" name="activo" value="{{ request('activo') }}">
                    <input type="hidden" name="id_tipo_ctto" value="{{ request('id_tipo_ctto') }}">
                    <input type="hidden" name="vigencia_desde" value="{{ request('vigencia_desde') }}">
                    <input type="hidden" name="vigencia_hasta" value="{{ request('vigencia_hasta') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="printSelectedIds" value="">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Filtros -->
            <form method="GET" action="{{ route('datos-personal-cubano.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" name="search" value="{{ request('search') }}" class="form-control"
                               placeholder="Buscar (funcionario, carnet, correo...)">
                    </div>
                    <div class="col-md-3">
                        <select name="proveedor" class="form-select">
                            <option value="">Proveedor</option>
                            @foreach($providers as $provider)
                                <option value="{{ $provider->{'Id Proveedor'} }}" {{ request('proveedor') == $provider->{'Id Proveedor'} ? 'selected' : '' }}>
                                    {{ $provider->Proveedor }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="activo" class="form-select">
                            <option value="">Estado</option>
                            <option value="1" {{ request('activo') == '1' ? 'selected' : '' }}>Activo</option>
                            <option value="0" {{ request('activo') == '0' ? 'selected' : '' }}>Inactivo</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="id_tipo_ctto" class="form-select">
                            <option value="">Tipo Contrato</option>
                            @foreach($tiposContrato as $tipo)
                                <option value="{{ $tipo->{'Id Tipo Ctto'} }}" {{ request('id_tipo_ctto') == $tipo->{'Id Tipo Ctto'} ? 'selected' : '' }}>
                                    {{ $tipo->{'Tipo Ctto'} }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <input type="date" name="vigencia_desde" value="{{ request('vigencia_desde') }}" class="form-control" placeholder="Vigencia desde">
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="vigencia_hasta" value="{{ request('vigencia_hasta') }}" class="form-control" placeholder="Vigencia hasta">
                    </div>
                    <div class="col-md-3">
                        <select name="sort_by" class="form-select">
                            <option value="">Ordenar por</option>
                            <option value="Id" {{ request('sort_by') == 'Id' ? 'selected' : '' }}>ID</option>
                            <option value="Funcionario_cubano" {{ request('sort_by') == 'Funcionario_cubano' ? 'selected' : '' }}>Funcionario</option>
                            <option value="Carnet_Acorec" {{ request('sort_by') == 'Carnet_Acorec' ? 'selected' : '' }}>Carnet</option>
                            <option value="Vigencia" {{ request('sort_by') == 'Vigencia' ? 'selected' : '' }}>Vigencia</option>
                            <option value="Activo" {{ request('sort_by') == 'Activo' ? 'selected' : '' }}>Activo</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="sort_dir" class="form-select">
                            <option value="desc" {{ request('sort_dir', 'desc') == 'desc' ? 'selected' : '' }}>Descendente</option>
                            <option value="asc" {{ request('sort_dir') == 'asc' ? 'selected' : '' }}>Ascendente</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('datos-personal-cubano.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
            </form>

            @if($items->isEmpty())
                <div class="alert alert-info">No hay personal registrado.</div>
            @else
                <!-- Formulario para eliminación múltiple (DELETE) -->
                <form id="deleteForm" method="POST" action="{{ route('datos-personal-cubano.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <div class="table-responsive" style="overflow-x: auto;">
                        <table class="table table-bordered table-hover table-sm" style="font-size: 0.9rem;">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="select-all-checkbox">
                                    </th>
                                    <th>ID</th>
                                    <th>Funcionario Cubano</th>
                                    <th>Proveedor</th>
                                    <th>Teléfono</th>
                                    <th>Email</th>
                                    <th>Carnet Acorec</th>
                                    <th>Vigencia</th>
                                    <th>Tipo Contrato</th>
                                    <th>Activo</th>
                                    <th>Cargo</th>
                                    <th>Dirección</th>
                                    <th>Observaciones</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($items as $item)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="selected_ids[]" value="{{ $item->Id }}" class="select-item">
                                        </td>
                                        <td>{{ $item->Id }}</td>
                                        <td>{{ $item->Funcionario_cubano }}</td>
                                        <td>
                                            @if(isset($item->provider) && $item->provider)
                                                {{ $item->provider->Proveedor }}
                                            @else
                                                N/A
                                            @endif
                                        </td>
                                        <td>{{ $item->telef }}</td>
                                        <td>{{ $item->Email }}</td>
                                        <td>{{ $item->Carnet_Acorec }}</td>
                                        <td>{{ $item->Vigencia ? \Carbon\Carbon::parse($item->Vigencia)->format('d/m/Y') : '' }}</td>
                                        <td>
                                            @if(isset($item->tipoCtto) && $item->tipoCtto)
                                                {{ $item->tipoCtto->{'Tipo Ctto'} }}
                                            @else
                                                N/A
                                            @endif
                                        </td>
                                        <td>
                                            <span class="badge bg-{{ $item->Activo ? 'success' : 'danger' }}">
                                                {{ $item->Activo ? 'Sí' : 'No' }}
                                            </span>
                                        </td>
                                        <td>{{ $item->Cargo ?? '' }}</td>
                                        <td>{{ Str::limit($item->Direccion ?? '', 30) }}</td>
                                        <td>{{ Str::limit($item->Observaciones ?? '', 30) }}</td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('datos-personal-cubano.show', $item->Id) }}" class="btn btn-info btn-sm">Ver</a>
                                                <a href="{{ route('datos-personal-cubano.edit', $item->Id) }}" class="btn btn-warning btn-sm">Editar</a>
                                                <form action="{{ route('datos-personal-cubano.destroy', $item->Id) }}" method="POST" style="display:inline-block;">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar este registro?')">Eliminar</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            @if($items->isNotEmpty())
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="5" class="text-end"><strong>Total:</strong></td>
                                    <td colspan="9">
                                        <strong>
                                            {{ $items->count() }} registros | 
                                            Activos: {{ $items->where('Activo', 1)->count() }} | 
                                            Inactivos: {{ $items->where('Activo', 0)->count() }}
                                        </strong>
                                    </td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar los registros seleccionados?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación corregida -->
                @if($items->hasPages())
                    @php 
                        $queryParams = request()->all();
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $items->firstItem() }}–{{ $items->lastItem() }} de {{ $items->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    @php $queryParams['page'] = 1; @endphp
                                    <a class="page-link" href="{{ route('datos-personal-cubano.index', $queryParams) }}">« Primera</a>
                                </li>
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    @php $queryParams['page'] = $items->currentPage() - 1; @endphp
                                    <a class="page-link" href="{{ route('datos-personal-cubano.index', $queryParams) }}">‹</a>
                                </li>
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $items->currentPage() }} de {{ $items->lastPage() }}</span>
                                </li>
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    @php $queryParams['page'] = $items->currentPage() + 1; @endphp
                                    <a class="page-link" href="{{ route('datos-personal-cubano.index', $queryParams) }}">›</a>
                                </li>
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    @php $queryParams['page'] = $items->lastPage(); @endphp
                                    <a class="page-link" href="{{ route('datos-personal-cubano.index', $queryParams) }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const selectAll = document.getElementById('select-all-checkbox');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        document.getElementById('exportSelectedIds').value = selectedString;
        document.getElementById('pdfSelectedIds').value = selectedString;
        document.getElementById('printSelectedIds').value = selectedString;
    }
    
    updateExportSelected();
});
</script>
@endsection