<table>
    <thead>
        <tr>
            <th style="background-color:#36b9cc; color:#fff;">Nombre</th>
            <th style="background-color:#36b9cc; color:#fff;">Código FGNE</th>
            <th style="background-color:#36b9cc; color:#fff;">NIT</th>
            <th style="background-color:#36b9cc; color:#fff;">Objeto Social</th>
            <th style="background-color:#36b9cc; color:#fff;">Representación</th>
            <th style="background-color:#36b6cc; color:#fff;">Email</th>
        </tr>
    </thead>
    <tbody>
        @foreach($items as $item)
        <tr>
            <td>{{ $item->nombre }}</td>
            <td>{{ $item->fgne_codigo }}</td>
            <td>{{ $item->codigo_nit }}</td>
            <td>{{ $item->objeto_social }}</td>
            <td>{{ $item->representacion }}</td>
            <td>{{ $item->email }}</td>
        </tr>
        @endforeach
    </tbody>
</table>