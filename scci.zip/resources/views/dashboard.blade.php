@extends('layouts.app')

@section('title', 'Dashboard')
@section('header', 'Dashboard')

@section('content')
<div class="container-fluid">
  <div class="row">
    <!-- Estadísticas rápidas -->
    <div class="col-12">
      <div class="row dashboard-cards">

        <!-- Solicitudes -->
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center py-2">
              <h6 class="mb-0">Solicitudes</h6>
              <i class="fas fa-file-alt"></i>
            </div>
            <div class="card-body text-center py-3">
              <h3 class="text-primary mb-1">{{ $totales['solicitudes'] ?? 0 }}</h3>
              <p class="text-muted mb-0 small">Total de solicitudes</p>
            </div>
            <div class="card-footer bg-transparent border-top-0 text-center py-2">
              <a href="{{ route('solicitudes.index') }}" class="btn btn-primary btn-sm">
                <i class="fas fa-eye me-1"></i> Ver todas
              </a>
            </div>
          </div>
        </div>

        <!-- Contratos -->
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-header bg-success text-white d-flex justify-content-between align-items-center py-2">
              <h6 class="mb-0">Contratos</h6>
              <i class="fas fa-file-contract"></i>
            </div>
            <div class="card-body text-center py-3">
              <h3 class="text-success mb-1">{{ $totales['contratos'] ?? 0 }}</h3>
              <p class="text-muted mb-0 small">Total de contratos</p>
            </div>
            <div class="card-footer bg-transparent border-top-0 text-center py-2">
              <a href="{{ route('contratos.index') }}" class="btn btn-success btn-sm">
                <i class="fas fa-eye me-1"></i> Ver todos
              </a>
            </div>
          </div>
        </div>

        <!-- Proveedores -->
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-header bg-warning text-white d-flex justify-content-between align-items-center py-2">
              <h6 class="mb-0">Proveedores</h6>
              <i class="fas fa-truck"></i>
            </div>
            <div class="card-body text-center py-3">
              <h3 class="text-warning mb-1">{{ $totales['proveedores'] ?? 0 }}</h3>
              <p class="text-muted mb-0 small">Total de proveedores</p>
            </div>
            <div class="card-footer bg-transparent border-top-0 text-center py-2">
              <a href="{{ route('proveedores.index') }}" class="btn btn-warning btn-sm">
                <i class="fas fa-eye me-1"></i> Ver todos
              </a>
            </div>
          </div>
        </div>

        <!-- Usuarios -->
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-header bg-info text-white d-flex justify-content-between align-items-center py-2">
              <h6 class="mb-0">Usuarios</h6>
              <i class="fas fa-users"></i>
            </div>
            <div class="card-body text-center py-3">
              <h3 class="text-info mb-1">{{ $totales['usuarios'] ?? 0 }}</h3>
              <p class="text-muted mb-0 small">Total de usuarios</p>
            </div>
            <div class="card-footer bg-transparent border-top-0 text-center py-2">
              @if(auth()->check() && auth()->user()->area && auth()->user()->area->Area === 'Informatica')
                <a href="{{ route('usuarios.index') }}" class="btn btn-info btn-sm">
                  <i class="fas fa-eye me-1"></i> Ver todos
                </a>
              @else
                <span class="text-muted small">Solo Informática</span>
              @endif
            </div>
          </div>
        </div>

        <!-- Asignaciones -->
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center py-2">
              <h6 class="mb-0">Asignaciones</h6>
              <i class="fas fa-money-check-alt"></i>
            </div>
            <div class="card-body text-center py-3">
              <h3 class="text-danger mb-1">{{ $totales['asignaciones'] ?? 0 }}</h3>
              <p class="text-muted mb-0 small">Total de asignaciones</p>
            </div>
            <div class="card-footer bg-transparent border-top-0 text-center py-2">
              <a href="{{ route('asignaciones.index') }}" class="btn btn-danger btn-sm">
                <i class="fas fa-eye me-1"></i> Ver todas
              </a>
            </div>
          </div>
        </div>

        <!-- Logística -->
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-header bg-teal text-white d-flex justify-content-between align-items-center py-2">
              <h6 class="mb-0">Logística</h6>
              <i class="fas fa-shipping-fast"></i>
            </div>
            <div class="card-body text-center py-3">
              <h3 class="text-teal mb-1">{{ $totales['logistica'] ?? 0 }}</h3>
              <p class="text-muted mb-0 small">Total de embarques</p>
            </div>
            <div class="card-footer bg-transparent border-top-0 text-center py-2">
              <a href="{{ route('embarques.index') }}" class="btn btn-teal btn-sm">
                <i class="fas fa-eye me-1"></i> Ver todos
              </a>
            </div>
          </div>
        </div>

        <!-- DITEC -->
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-header bg-indigo text-white d-flex justify-content-between align-items-center py-2">
              <h6 class="mb-0">DITEC</h6>
              <i class="fas fa-certificate"></i>
            </div>
            <div class="card-body text-center py-3">
              <h3 class="text-indigo mb-1">{{ $totales['ditec'] ?? 0 }}</h3>
              <p class="text-muted mb-0 small">Total de certificados</p>
            </div>
            <div class="card-footer bg-transparent border-top-0 text-center py-2">
              <a href="{{ route('ditec.index') }}" class="btn btn-indigo btn-sm">
                <i class="fas fa-eye me-1"></i> Ver todos
              </a>
            </div>
          </div>
        </div>

        <!-- Clientes -->
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-header bg-orange text-white d-flex justify-content-between align-items-center py-2">
              <h6 class="mb-0">Clientes</h6>
              <i class="fas fa-building"></i>
            </div>
            <div class="card-body text-center py-3">
              <h3 class="text-orange mb-1">{{ $totales['clientes'] ?? 0 }}</h3>
              <p class="text-muted mb-0 small">Total de clientes</p>
            </div>
            <div class="card-footer bg-transparent border-top-0 text-center py-2">
              <a href="{{ route('nomencladores.clientes.index') }}" class="btn btn-orange btn-sm">
                <i class="fas fa-eye me-1"></i> Ver todos
              </a>
            </div>
          </div>
        </div>

        <!-- Finanzas -->
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center py-2">
              <h6 class="mb-0">Finanzas</h6>
              <i class="fas fa-dollar-sign"></i>
            </div>
            <div class="card-body text-center py-3">
              <h3 class="text-dark mb-1">{{ $totales['finanzas'] ?? 0 }}</h3>
              <p class="text-muted mb-0 small">Total de pagos</p>
            </div>
            <div class="card-footer bg-transparent border-top-0 text-center py-2">
              <a href="{{ route('pagos.index') }}" class="btn btn-dark btn-sm">
                <i class="fas fa-eye me-1"></i> Ver todos
              </a>
            </div>
          </div>
        </div>

        <!-- Operaciones -->
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-4">
          <div class="card h-100 border-0 shadow-sm">
            <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center py-2">
              <h6 class="mb-0">Operaciones</h6>
              <i class="fas fa-industry"></i>
            </div>
            <div class="card-body text-center py-3">
              <h3 class="text-secondary mb-1">{{ $totales['operaciones'] ?? 0 }}</h3>
              <p class="text-muted mb-0 small">Total de salidas</p>
            </div>
            <div class="card-footer bg-transparent border-top-0 text-center py-2">
              <a href="{{ route('operaciones.index') }}" class="btn btn-secondary btn-sm">
                <i class="fas fa-eye me-1"></i> Ver todos
              </a>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- Gráfico unificado -->
    <div class="row mt-4">
      <div class="col-12">
        <div class="card">
          <div class="card-header bg-gradient-primary text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Resumen General del Sistema</h5>
            <div class="dropdown">
              <button class="btn btn-sm btn-light dropdown-toggle" type="button" id="chartFilterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-filter me-1"></i>Filtrar
              </button>
              <ul class="dropdown-menu" aria-labelledby="chartFilterDropdown">
                <li><a class="dropdown-item chart-filter" href="#" data-filter="all">Todos los módulos</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item chart-filter" href="#" data-filter="primary">Solo principales</a></li>
                <li><a class="dropdown-item chart-filter" href="#" data-filter="high">Mayores a 0</a></li>
              </ul>
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-md-8">
                <div class="chart-container" style="position: relative; height: 400px;">
                  <canvas id="dashboardChart"></canvas>
                </div>
              </div>
              <div class="col-md-4">
                <div class="card h-100 border-0">
                  <div class="card-header bg-light">
                    <h6 class="mb-0">Estadísticas Totales</h6>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-sm table-hover">
                        <thead>
                          <tr>
                            <th>Módulo</th>
                            <th class="text-end">Cantidad</th>
                            <th class="text-end">%</th>
                          </tr>
                        </thead>
                        <tbody id="statsTableBody">
                          <!-- Los datos se llenarán con JavaScript -->
                        </tbody>
                        <tfoot>
                          <tr class="table-active">
                            <td><strong>Total General</strong></td>
                            <td class="text-end"><strong id="totalGeneral">0</strong></td>
                            <td class="text-end"><strong>100%</strong></td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                    <div class="mt-3">
                      <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted small">Módulo con más registros:</span>
                        <span class="fw-bold" id="maxModule">-</span>
                      </div>
                      <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted small">Módulo con menos registros:</span>
                        <span class="fw-bold" id="minModule">-</span>
                      </div>
                      <div class="d-flex justify-content-between">
                        <span class="text-muted small">Promedio por módulo:</span>
                        <span class="fw-bold" id="avgCount">0</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card-footer text-muted small d-flex justify-content-between align-items-center">
            <div>
              <i class="fas fa-info-circle me-1"></i>
              Gráfico actualizado en tiempo real
            </div>
            <div>
              <button id="refreshChart" class="btn btn-sm btn-outline-primary">
                <i class="fas fa-sync-alt me-1"></i> Actualizar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Mensaje de error si existe -->
    @if(session('error'))
      <div class="row mt-3">
        <div class="col-12">
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        </div>
      </div>
    @endif

  </div>
</div>

<!-- Incluir Chart.js desde CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
/* Estilos para colores personalizados */
.bg-teal { background-color: #20c997 !important; }
.text-teal { color: #20c997 !important; }
.btn-teal { 
  background-color: #20c997; 
  border-color: #20c997; 
  color: white;
}
.btn-teal:hover { 
  background-color: #1aa179; 
  border-color: #1aa179; 
  color: white;
}

.bg-indigo { background-color: #6610f2 !important; }
.text-indigo { color: #6610f2 !important; }
.btn-indigo { 
  background-color: #6610f2; 
  border-color: #6610f2; 
  color: white;
}
.btn-indigo:hover { 
  background-color: #520dc2; 
  border-color: #520dc2; 
  color: white;
}

.bg-orange { background-color: #fd7e14 !important; }
.text-orange { color: #fd7e14 !important; }
.btn-orange { 
  background-color: #fd7e14; 
  border-color: #fd7e14; 
  color: white;
}
.btn-orange:hover { 
  background-color: #e8690b; 
  border-color: #e8690b; 
  color: white;
}

.bg-gradient-primary {
  background: linear-gradient(135deg, #4e73df 0%, #224abe 100%) !important;
}

/* Estilos para las tarjetas del dashboard */
.dashboard-cards .card {
  transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}

.dashboard-cards .card:hover {
  transform: translateY(-5px);
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
}

.dashboard-cards .card-header {
  border-bottom: none;
}

.dashboard-cards .card-body h3 {
  font-weight: 700;
}

.dashboard-cards .card-footer {
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

/* Estilos para el gráfico */
.chart-container {
  position: relative;
  margin: auto;
}

/* Estilos para la tabla de estadísticas */
.table-sm th, .table-sm td {
  padding: 0.5rem;
}

.table-hover tbody tr:hover {
  background-color: rgba(0, 0, 0, 0.04);
}

/* Responsive */
@media (max-width: 768px) {
  .dashboard-cards .col-sm-6 {
    flex: 0 0 50%;
    max-width: 50%;
  }
  
  .chart-container {
    height: 300px !important;
  }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Datos para el gráfico (tomados de las tarjetas)
  const dashboardData = {
    labels: [
      'Solicitudes', 
      'Contratos', 
      'Proveedores', 
      'Usuarios', 
      'Asignaciones', 
      'Logística', 
      'DITEC', 
      'Clientes', 
      'Finanzas', 
      'Operaciones'
    ],
    datasets: [{
      label: 'Registros por Módulo',
      data: [
        {{ $totales['solicitudes'] ?? 0 }},
        {{ $totales['contratos'] ?? 0 }},
        {{ $totales['proveedores'] ?? 0 }},
        {{ $totales['usuarios'] ?? 0 }},
        {{ $totales['asignaciones'] ?? 0 }},
        {{ $totales['logistica'] ?? 0 }},
        {{ $totales['ditec'] ?? 0 }},
        {{ $totales['clientes'] ?? 0 }},
        {{ $totales['finanzas'] ?? 0 }},
        {{ $totales['operaciones'] ?? 0 }}
      ],
      backgroundColor: [
        '#4e73df', '#1cc88a', '#f6c23e', '#36b9cc', '#e74a3b',
        '#20c997', '#6610f2', '#fd7e14', '#5a5c69', '#858796'
      ],
      borderColor: [
        '#4e73df', '#1cc88a', '#f6c23e', '#36b9cc', '#e74a3b',
        '#20c997', '#6610f2', '#fd7e14', '#5a5c69', '#858796'
      ],
      borderWidth: 1,
      borderRadius: 5,
      hoverBackgroundColor: [
        '#2e59d9', '#17a673', '#dda20a', '#2c9faf', '#be2617',
        '#1aa179', '#520dc2', '#e8690b', '#424244', '#6b6d7d'
      ]
    }]
  };

  // Configuración del gráfico
  const chartConfig = {
    type: 'bar',
    data: dashboardData,
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              let label = context.dataset.label || '';
              if (label) {
                label += ': ';
              }
              label += context.parsed.y.toLocaleString();
              return label;
            }
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: function(value) {
              return value.toLocaleString();
            }
          },
          grid: {
            drawBorder: false
          }
        },
        x: {
          grid: {
            display: false
          },
          ticks: {
            maxRotation: 45,
            minRotation: 45
          }
        }
      }
    }
  };

  // Inicializar el gráfico
  const ctx = document.getElementById('dashboardChart').getContext('2d');
  const dashboardChart = new Chart(ctx, chartConfig);

  // Función para actualizar estadísticas
  function updateStats() {
    const data = dashboardData.datasets[0].data;
    const labels = dashboardData.labels;
    const colors = dashboardData.datasets[0].backgroundColor;
    
    let total = 0;
    let maxValue = -Infinity;
    let minValue = Infinity;
    let maxIndex = 0;
    let minIndex = 0;
    
    // Calcular total y encontrar máximos/mínimos
    data.forEach((value, index) => {
      total += value;
      if (value > maxValue) {
        maxValue = value;
        maxIndex = index;
      }
      if (value < minValue) {
        minValue = value;
        minIndex = index;
      }
    });
    
    // Actualizar tabla de estadísticas
    const tableBody = document.getElementById('statsTableBody');
    tableBody.innerHTML = '';
    
    data.forEach((value, index) => {
      const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
      const row = document.createElement('tr');
      
      row.innerHTML = `
        <td>
          <span class="badge" style="background-color: ${colors[index]}; width: 12px; height: 12px; display: inline-block; margin-right: 8px;"></span>
          ${labels[index]}
        </td>
        <td class="text-end">${value.toLocaleString()}</td>
        <td class="text-end">${percentage}%</td>
      `;
      
      tableBody.appendChild(row);
    });
    
    // Actualizar total general
    document.getElementById('totalGeneral').textContent = total.toLocaleString();
    
    // Actualizar estadísticas adicionales
    document.getElementById('maxModule').textContent = `${labels[maxIndex]} (${maxValue.toLocaleString()})`;
    document.getElementById('minModule').textContent = `${labels[minIndex]} (${minValue.toLocaleString()})`;
    document.getElementById('avgCount').textContent = Math.round(total / data.length).toLocaleString();
  }

  // Llamar a updateStats inicialmente
  updateStats();

  // Filtros del gráfico
  document.querySelectorAll('.chart-filter').forEach(filter => {
    filter.addEventListener('click', function(e) {
      e.preventDefault();
      const filterType = this.getAttribute('data-filter');
      const originalData = [
        {{ $totales['solicitudes'] ?? 0 }},
        {{ $totales['contratos'] ?? 0 }},
        {{ $totales['proveedores'] ?? 0 }},
        {{ $totales['usuarios'] ?? 0 }},
        {{ $totales['asignaciones'] ?? 0 }},
        {{ $totales['logistica'] ?? 0 }},
        {{ $totales['ditec'] ?? 0 }},
        {{ $totales['clientes'] ?? 0 }},
        {{ $totales['finanzas'] ?? 0 }},
        {{ $totales['operaciones'] ?? 0 }}
      ];
      
      let filteredData = [...originalData];
      let filteredLabels = [...dashboardData.labels];
      
      if (filterType === 'primary') {
        // Mostrar solo los módulos principales (los primeros 5)
        filteredData = filteredData.slice(0, 5);
        filteredLabels = filteredLabels.slice(0, 5);
      } else if (filterType === 'high') {
        // Mostrar solo módulos con más de 0 registros
        const newData = [];
        const newLabels = [];
        originalData.forEach((value, index) => {
          if (value > 0) {
            newData.push(value);
            newLabels.push(dashboardData.labels[index]);
          }
        });
        filteredData = newData;
        filteredLabels = newLabels;
      }
      // 'all' muestra todos los datos
      
      dashboardChart.data.datasets[0].data = filteredData;
      dashboardChart.data.labels = filteredLabels;
      dashboardChart.update();
      updateStats();
    });
  });

  // Botón de actualizar
  document.getElementById('refreshChart').addEventListener('click', function() {
    // Aquí podrías agregar una llamada AJAX para obtener datos actualizados
    // Por ahora, solo actualizamos el gráfico
    dashboardChart.update();
    updateStats();
    
    // Mostrar notificación de actualización
    const button = this;
    const originalHTML = button.innerHTML;
    button.innerHTML = '<i class="fas fa-check me-1"></i> Actualizado';
    button.classList.remove('btn-outline-primary');
    button.classList.add('btn-success');
    
    setTimeout(() => {
      button.innerHTML = originalHTML;
      button.classList.remove('btn-success');
      button.classList.add('btn-outline-primary');
    }, 2000);
  });

  // Actualizar automáticamente cada 2 minutos
  setInterval(() => {
    // En un caso real, aquí harías una petición AJAX para obtener datos actualizados
    // Por ahora, solo actualizamos la visualización
    dashboardChart.update();
    updateStats();
  }, 120000); // 2 minutos
});
</script>
@endsection