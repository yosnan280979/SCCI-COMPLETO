-- SOLUCIÓN EXTREMA: Crear tablas sin restricciones únicas
-- Esto funcionará seguro

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Eliminar si existen
DROP TABLE IF EXISTS permissions;
DROP TABLE IF EXISTS modules;

-- 2. Crear tabla modules (sin índice único)
CREATE TABLE modules (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL,
    `order` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Crear tabla permissions (sin índice único)
CREATE TABLE permissions (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_area INT NOT NULL,
    id_module INT NOT NULL,
    view TINYINT DEFAULT 0,
    create_p TINYINT DEFAULT 0,
    edit TINYINT DEFAULT 0,
    delete_p TINYINT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- 4. Insertar módulos (usar INSERT IGNORE para evitar duplicados)
INSERT IGNORE INTO modules (name, slug, `order`) VALUES
('Dashboard', 'dashboard', 1),
('Solicitudes', 'solicitudes', 2),
('Contratos', 'contratos', 3),
('Asignaciones', 'asignaciones', 4),
('Logística', 'logistica', 5),
('Proveedores', 'proveedores', 6),
('DITEC', 'ditec', 7),
('Finanzas', 'finanzas', 8),
('Operaciones', 'operaciones', 9),
('Organización', 'organizacion', 10),
('Usuarios', 'usuarios', 11);

-- 5. Eliminar duplicados antes de insertar permisos
DELETE FROM permissions;

-- 6. Insertar permisos básicos
INSERT INTO permissions (id_area, id_module, view, create_p, edit, delete_p)
SELECT 
    a.`Id Area`,
    m.id,
    CASE 
        WHEN a.Area = 'Informatica' THEN 1
        WHEN m.slug = 'dashboard' THEN 1
        ELSE 0
    END,
    CASE WHEN a.Area = 'Informatica' THEN 1 ELSE 0 END,
    CASE WHEN a.Area = 'Informatica' THEN 1 ELSE 0 END,
    CASE WHEN a.Area = 'Informatica' THEN 1 ELSE 0 END
FROM `Nomenclador Areas` a
CROSS JOIN modules m;

-- 7. Verificar
SELECT 
    a.Area,
    COUNT(p.id) as total_permisos,
    SUM(p.view) as puede_ver
FROM `Nomenclador Areas` a
LEFT JOIN permissions p ON a.`Id Area` = p.id_area
GROUP BY a.Area
ORDER BY a.Area;