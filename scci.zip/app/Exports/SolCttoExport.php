<?php

namespace App\Exports;

use App\Models\SolCtto;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class SolCttoExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function collection()
    {
        return $this->items;
    }

    public function headings(): array
    {
        return [
            'ID',
            'ID Solicitud',
            'No. Solicitud',
            'ID Contrato',
            'No. Contrato',
            'ID SOE',
            'Observaciones',
            'ID Clasificación',
            'ID Actualizado',
            'Valor Real Sol',
        ];
    }

    public function map($item): array
    {
        return [
            $item->Id,
            $item->Id_Solicitud,
            $item->solicitud?->{'No Solicitud'} ?? 'N/A',
            $item->Id_Ctto,
            $item->contrato?->{'No Ctto'} ?? 'N/A',
            $item->Id_SOE,
            $item->Observaciones,
            $item->Id_Clasificacion,
            $item->Id_Actualizado,
            $item->Valor_Real_Sol,
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}