<?php

namespace App\Exports;

use App\Models\DescripcionSolicitud;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class DescripcionSolicitudExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $descripciones;

    public function __construct($descripciones)
    {
        $this->descripciones = $descripciones;
    }

    public function collection()
    {
        return $this->descripciones;
    }

    public function headings(): array
    {
        return [
            'ID',
            'No. Solicitud',
            'Producto',
            'UM',
            'Cantidad',
            'Precio CUC',
            'Precio Moneda Proveedor',
            'Moneda',
        ];
    }

    public function map($descripcion): array
    {
        return [
            $descripcion->Id,
            $descripcion->solicitud?->{'No Solicitud'} ?? '',
            $descripcion->Producto,
            $descripcion->UM,
            $descripcion->Cantidad,
            $descripcion->{'Precio CUC'},
            $descripcion->{'Precio Mon Prov'} ?? '',
            $descripcion->moneda?->Moneda ?? '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}