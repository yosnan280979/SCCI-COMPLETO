<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CheckPermissions
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string  $permission  El permiso requerido (view, create, edit, delete)
     * @param  string|null  $module  El módulo (opcional, se infiere de la ruta)
     * @return mixed
     */
    public function handle(Request $request, Closure $next, $permission = 'view', $module = null)
    {
        $user = auth()->user();
        
        if (!$user) {
            abort(403, 'No autenticado');
        }
        
        // Si el usuario es de Informática, permitir todo
        if ($user->isInformatica()) {
            return $next($request);
        }
        
        // Determinar el módulo si no se proporciona
        if (!$module) {
            $module = $this->getModuleFromRoute($request);
        }
        
        if (!$module) {
            abort(403, 'No se pudo determinar el módulo');
        }
        
        // Verificar el permiso usando la función helper
        $hasPermission = false;
        
        switch ($permission) {
            case 'view':
                $hasPermission = canView($module);
                break;
            case 'create':
                $hasPermission = canCreate($module);
                break;
            case 'edit':
                $hasPermission = canEdit($module);
                break;
            case 'delete':
                $hasPermission = canDelete($module);
                break;
            default:
                $hasPermission = canView($module);
        }
        
        if (!$hasPermission) {
            abort(403, 'No tiene permisos para acceder a esta sección');
        }
        
        return $next($request);
    }
    
    /**
     * Obtiene el módulo basado en la ruta actual
     */
    private function getModuleFromRoute(Request $request)
    {
        $routeName = $request->route()->getName();
        
        // Mapeo de prefijos de ruta a módulos
        $routeModuleMap = [
            'dashboard' => 'dashboard',
            'solicitudes' => 'solicitudes',
            'contratos' => 'contratos',
            'asignaciones' => 'asignaciones',
            'embarques' => 'logistica',
            'cargas' => 'logistica',
            'facturacion' => 'logistica',
            'reclamaciones' => 'logistica',
            'proveedores' => 'proveedores',
            'ditec' => 'ditec',
            'pagos' => 'finanzas',
            'operaciones' => 'operaciones',
            'nomencladores.clientes' => 'organizacion',
            'nomencladores.' => 'organizacion', // Para otros nomencladores
            'usuarios' => 'usuarios',
        ];
        
        foreach ($routeModuleMap as $routePrefix => $module) {
            if (strpos($routeName, $routePrefix) === 0) {
                return $module;
            }
        }
        
        return null;
    }
}