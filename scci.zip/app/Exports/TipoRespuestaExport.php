<?php

namespace App\Exports;

use App\Models\TipoRespuesta;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class TipoRespuestaExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $tipoRespuestas;

    public function __construct($tipoRespuestas)
    {
        $this->tipoRespuestas = $tipoRespuestas;
    }

    public function collection()
    {
        return $this->tipoRespuestas;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Tipo de Respuesta',
        ];
    }

    public function map($tipoRespuesta): array
    {
        return [
            $tipoRespuesta->{'Id Tipo respuesta'} ?? '',
            $tipoRespuesta->{'Tipo Respuesta'} ?? '',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}