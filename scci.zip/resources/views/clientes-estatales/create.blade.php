@extends('layouts.app')

@section('title', 'Crear Cliente Estatal')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header">
            <h3>Crear Cliente Estatal</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('clientes-estatales.store') }}" method="POST">
                @csrf
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="ministerio" class="form-label">Ministerio</label>
                        <input type="text" id="ministerio" name="ministerio" class="form-control" value="{{ old('ministerio') }}">
                    </div>
                    <div class="col-md-6">
                        <label for="nombre_empresa" class="form-label">Nombre de la Empresa *</label>
                        <input type="text" id="nombre_empresa" name="nombre_empresa" class="form-control" required value="{{ old('nombre_empresa') }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="codigo_nit" class="form-label">Código NIT / REEUP</label>
                        <input type="text" id="codigo_nit" name="codigo_nit" class="form-control" value="{{ old('codigo_nit') }}">
                    </div>
                    <div class="col-md-8">
                        <label for="resolucion_creacion" class="form-label">Resolución Creación</label>
                        <input type="text" id="resolucion_creacion" name="resolucion_creacion" class="form-control" value="{{ old('resolucion_creacion') }}">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-12">
                        <label for="direccion" class="form-label">Dirección</label>
                        <input type="text" id="direccion" name="direccion" class="form-control" value="{{ old('direccion') }}">
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="telefono" class="form-label">Teléfonos</label>
                        <input type="text" id="telefono" name="telefono" class="form-control" value="{{ old('telefono') }}">
                    </div>
                    <div class="col-md-4">
                        <label for="nombre_director" class="form-label">Nombre Director(a)</label>
                        <input type="text" id="nombre_director" name="nombre_director" class="form-control" value="{{ old('nombre_director') }}">
                    </div>
                    <div class="col-md-4">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" id="email" name="email" class="form-control" value="{{ old('email') }}">
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-12">
                        <h6>Información Bancaria y Convenios</h6>
                        <hr>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-12">
                        <label for="cuentas_bancarias" class="form-label">Cuentas Bancarias</label>
                        <textarea id="cuentas_bancarias" name="cuentas_bancarias" class="form-control" rows="3">{{ old('cuentas_bancarias') }}</textarea>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-12">
                        <label for="convenios_firmados" class="form-label">Convenios Firmados</label>
                        <textarea id="convenios_firmados" name="convenios_firmados" class="form-form-control" rows="3">{{ old('convenios_firmados') }}</textarea>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-12">
                        <h6>Historial por Año</h6>
                        <hr>
                    </div>
                </div>

                <div class="row">
                    @for($i = 2020; $i <= 2026; $i++)
                    <div class="col-md-3 mb-3">
                        <label for="anno_{{ $i }}" class="form-label">Año {{ $i }}</label>
                        <input type="text" id="anno_{{ $i }}" name="anno_{{ $i }}" class="form-control" placeholder="Ej: Activo / Inactivo" value="{{ old("anno_$i") }}">
                    </div>
                    @endfor
                </div>
                
                <div class="d-flex justify-content-end mt-4">
                    <a href="{{ route('clientes-estatales.index') }}" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar Cliente</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection