<?php

namespace App\Exports;

use App\Models\OSDE;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class OSDEExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $osdes;

    public function __construct($osdes)
    {
        $this->osdes = $osdes;
    }

    public function collection()
    {
        return $this->osdes;
    }

    public function headings(): array
    {
        return [
            'ID',
            'OSDE',
            'MICONS',
        ];
    }

    public function map($osde): array
    {
        return [
            $osde->{'Id Osde'},
            $osde->OSDE ?? '',
            $osde->MICONS ? 'Sí' : 'No',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}