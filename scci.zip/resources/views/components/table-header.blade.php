{{-- Componente reutilizable para encabezado de tabla con acciones --}}
@props([
    'title',
    'routePrefix',
    'showCreate' => true,
    'showExport' => true,
    'showPdf' => true,
    'showPrint' => true,
    'showSearch' => true,
])

<div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
        <h3 class="card-title">{{ $title }}</h3>
        <div class="d-flex">
            @if($showSearch)
            <div class="mr-2">
                <form action="{{ route($routePrefix . '.index') }}" method="GET" class="form-inline">
                    <div class="input-group input-group-sm">
                        <input type="text" name="search" class="form-control" 
                               placeholder="Buscar..." value="{{ request('search') }}">
                        <div class="input-group-append">
                            <button class="btn btn-outline-secondary" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            @endif
            
            @if($showCreate)
            <a href="{{ route($routePrefix . '.create') }}" class="btn btn-sm btn-primary mr-2">
                <i class="fas fa-plus"></i> Nuevo
            </a>
            @endif
            
            @if($showExport)
            <a href="{{ route($routePrefix . '.export.excel') }}" class="btn btn-sm btn-success mr-2">
                <i class="fas fa-file-excel"></i> Excel
            </a>
            @endif
            
            @if($showPdf)
            <a href="{{ route($routePrefix . '.export.pdf') }}" class="btn btn-sm btn-danger mr-2" target="_blank">
                <i class="fas fa-file-pdf"></i> PDF
            </a>
            @endif
            
            @if($showPrint)
            <button onclick="window.print()" class="btn btn-sm btn-secondary">
                <i class="fas fa-print"></i> Imprimir
            </button>
            @endif
        </div>
    </div>
</div>