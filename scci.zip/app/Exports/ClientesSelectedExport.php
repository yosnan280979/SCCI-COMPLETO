<?php

namespace App\Exports;

use App\Models\Cliente;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ClientesSelectedExport implements FromCollection, WithHeadings, WithMapping, WithStyles
{
    protected $ids;

    public function __construct(array $ids)
    {
        $this->ids = $ids;
    }

    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        return Cliente::whereIn('Id Cliente', $this->ids)
            ->orderBy('Cliente', 'asc')
            ->get();
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'ID',
            'Cliente',
            'OSDE',
            'Bases Presentadas',
            'Fecha de Bases',
            'Fecha de Creación',
            'Fecha de Actualización'
        ];
    }

    /**
     * @param Cliente $cliente
     * @return array
     */
    public function map($cliente): array
    {
        return [
            $cliente->{'Id Cliente'},
            $cliente->Cliente,
            $cliente->OSDE ?? 'N/A',
            $cliente->BasesPresentadas ? 'Sí' : 'No',
            $cliente->FechaBases ? date('d/m/Y', strtotime($cliente->FechaBases)) : 'N/A',
            $cliente->created_at->format('d/m/Y H:i'),
            $cliente->updated_at->format('d/m/Y H:i')
        ];
    }

    /**
     * @param Worksheet $sheet
     * @return array
     */
    public function styles(Worksheet $sheet)
    {
        return [
            // Style the first row as bold text.
            1 => ['font' => ['bold' => true]],
            
            // Set column widths
            'A' => ['width' => 10],
            'B' => ['width' => 30],
            'C' => ['width' => 25],
            'D' => ['width' => 20],
            'E' => ['width' => 20],
            'F' => ['width' => 25],
            'G' => ['width' => 25],
        ];
    }
}