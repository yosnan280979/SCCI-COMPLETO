<div class="btn-group" role="group">
    <a href="{{ route('contratodescription.show', $contrato_description->id) }}" class="btn btn-info btn-sm">
        <i class="fas fa-eye"></i>
    </a>
    <a href="{{ route('contratodescription.edit', $contrato_description->id) }}" class="btn btn-warning btn-sm">
        <i class="fas fa-edit"></i>
    </a>
    <form action="{{ route('contratodescription.destroy', $contrato_description->id) }}" method="POST" class="d-inline delete-form">
        @csrf
        @method('DELETE')
        <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="{{ $contrato_description->id }}">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>