<?php

namespace App\Exports;

use App\Models\Ministerio;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class MinisteriosExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected $ministerios;

    public function __construct($ministerios)
    {
        $this->ministerios = $ministerios;
    }

    public function collection()
    {
        return $this->ministerios;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Ministerio',
        ];
    }

    public function map($ministerio): array
    {
        return [
            $ministerio->{'Id Ministerio'},
            $ministerio->Ministerio,
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FFE0E0E0'],
                ],
            ],
        ];
    }
}