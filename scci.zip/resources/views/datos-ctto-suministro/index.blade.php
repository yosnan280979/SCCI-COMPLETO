@extends('layouts.app')

@section('title', 'Datos Contrato Suministro')

@section('content')
<div class="container-fluid">
    @include('partials.messages')
    
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Datos Contrato Suministro</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('datos-ctto-suministro.create') }}" class="btn btn-primary btn-sm">➕ Nuevo</a>
                <!-- Formulario para exportaciones (GET) -->
                <form id="exportForm" method="GET" action="{{ route('datos-ctto-suministro.export.excel') }}" style="display: inline">
                    @csrf
                    <input type="hidden" name="selected" id="exportSelected" value="">
                    <input type="hidden" name="contrato" value="{{ request('contrato') }}">
                    <input type="hidden" name="suplemento" value="{{ request('suplemento') }}">
                    <input type="hidden" name="fecha_firma" value="{{ request('fecha_firma') }}">
                    <input type="hidden" name="importe_cuc_desde" value="{{ request('importe_cuc_desde') }}">
                    <input type="hidden" name="importe_cuc_hasta" value="{{ request('importe_cuc_hasta') }}">
                    <input type="hidden" name="importe_cup_desde" value="{{ request('importe_cup_desde') }}">
                    <input type="hidden" name="importe_cup_hasta" value="{{ request('importe_cup_hasta') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                <form id="exportPdfForm" method="GET" action="{{ route('datos-ctto-suministro.export.pdf') }}" style="display: inline">
                    @csrf
                    <input type="hidden" name="selected" id="exportPdfSelected" value="">
                    <input type="hidden" name="contrato" value="{{ request('contrato') }}">
                    <input type="hidden" name="suplemento" value="{{ request('suplemento') }}">
                    <input type="hidden" name="fecha_firma" value="{{ request('fecha_firma') }}">
                    <input type="hidden" name="importe_cuc_desde" value="{{ request('importe_cuc_desde') }}">
                    <input type="hidden" name="importe_cuc_hasta" value="{{ request('importe_cuc_hasta') }}">
                    <input type="hidden" name="importe_cup_desde" value="{{ request('importe_cup_desde') }}">
                    <input type="hidden" name="importe_cup_hasta" value="{{ request('importe_cup_hasta') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                <form id="printForm" method="GET" action="{{ route('datos-ctto-suministro.print') }}" style="display: inline" target="_blank">
                    @csrf
                    <input type="hidden" name="selected" id="printSelected" value="">
                    <input type="hidden" name="contrato" value="{{ request('contrato') }}">
                    <input type="hidden" name="suplemento" value="{{ request('suplemento') }}">
                    <input type="hidden" name="fecha_firma" value="{{ request('fecha_firma') }}">
                    <input type="hidden" name="importe_cuc_desde" value="{{ request('importe_cuc_desde') }}">
                    <input type="hidden" name="importe_cuc_hasta" value="{{ request('importe_cuc_hasta') }}">
                    <input type="hidden" name="importe_cup_desde" value="{{ request('importe_cup_desde') }}">
                    <input type="hidden" name="importe_cup_hasta" value="{{ request('importe_cup_hasta') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Filtros -->
            <form method="GET" action="{{ route('datos-ctto-suministro.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" name="contrato" class="form-control" placeholder="Contrato Suministro" 
                               value="{{ request('contrato') }}">
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="suplemento" class="form-control" placeholder="No. Suplemento" 
                               value="{{ request('suplemento') }}">
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="fecha_firma" class="form-control" 
                               value="{{ request('fecha_firma') }}">
                    </div>
                    <div class="col-md-3">
                        <select name="sort_by" class="form-select">
                            <option value="">Ordenar por</option>
                            <option value="Id_Supsum" {{ request('sort_by') == 'Id_Supsum' ? 'selected' : '' }}>
                                ID
                            </option>
                            <option value="No_Suplemento" {{ request('sort_by') == 'No_Suplemento' ? 'selected' : '' }}>
                                No. Suplemento
                            </option>
                            <option value="Importe_CUC" {{ request('sort_by') == 'Importe_CUC' ? 'selected' : '' }}>
                                Importe CUC
                            </option>
                            <option value="Importe_CUP" {{ request('sort_by') == 'Importe_CUP' ? 'selected' : '' }}>
                                Importe CUP
                            </option>
                            <option value="Fecha_firma_Ctto" {{ request('sort_by') == 'Fecha_firma_Ctto' ? 'selected' : '' }}>
                                Fecha Firma
                            </option>
                        </select>
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="importe_cuc_desde" class="form-control" 
                               placeholder="Importe CUC desde" value="{{ request('importe_cuc_desde') }}" min="0">
                    </div>
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="importe_cuc_hasta" class="form-control" 
                               placeholder="Importe CUC hasta" value="{{ request('importe_cuc_hasta') }}" min="0">
                    </div>
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="importe_cup_desde" class="form-control" 
                               placeholder="Importe CUP desde" value="{{ request('importe_cup_desde') }}" min="0">
                    </div>
                    <div class="col-md-3">
                        <input type="number" step="0.01" name="importe_cup_hasta" class="form-control" 
                               placeholder="Importe CUP hasta" value="{{ request('importe_cup_hasta') }}" min="0">
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <select name="sort_dir" class="form-select">
                            <option value="desc" {{ request('sort_dir', 'desc') == 'desc' ? 'selected' : '' }}>
                                Descendente
                            </option>
                            <option value="asc" {{ request('sort_dir') == 'asc' ? 'selected' : '' }}>
                                Ascendente
                            </option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('datos-ctto-suministro.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
            </form>

            @if($items->isEmpty())
                <div class="alert alert-info">No hay datos de contratos registrados.</div>
            @else
                <!-- Formulario para eliminación múltiple -->
                <form id="deleteForm" method="POST" action="{{ route('datos-ctto-suministro.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-sm align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="selectAll">
                                    </th>
                                    <th>
                                        <a href="{{ route('datos-ctto-suministro.index', array_merge(request()->except(['sort_by', 'sort_dir']), ['sort_by' => 'Id_Supsum', 'sort_dir' => request('sort_by') == 'Id_Supsum' && request('sort_dir', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            ID
                                            @if(request('sort_by') == 'Id_Supsum')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>
                                        <a href="{{ route('datos-ctto-suministro.index', array_merge(request()->except(['sort_by', 'sort_dir']), ['sort_by' => 'contratoSuministro.Descripcion', 'sort_dir' => request('sort_by') == 'contratoSuministro.Descripcion' && request('sort_dir', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            Contrato Suministro
                                            @if(request('sort_by') == 'contratoSuministro.Descripcion')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>
                                        <a href="{{ route('datos-ctto-suministro.index', array_merge(request()->except(['sort_by', 'sort_dir']), ['sort_by' => 'No_Suplemento', 'sort_dir' => request('sort_by') == 'No_Suplemento' && request('sort_dir', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            No. Suplemento
                                            @if(request('sort_by') == 'No_Suplemento')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>
                                        <a href="{{ route('datos-ctto-suministro.index', array_merge(request()->except(['sort_by', 'sort_dir']), ['sort_by' => 'Importe_CUC', 'sort_dir' => request('sort_by') == 'Importe_CUC' && request('sort_dir', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            Importe CUC
                                            @if(request('sort_by') == 'Importe_CUC')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>
                                        <a href="{{ route('datos-ctto-suministro.index', array_merge(request()->except(['sort_by', 'sort_dir']), ['sort_by' => 'Importe_CUP', 'sort_dir' => request('sort_by') == 'Importe_CUP' && request('sort_dir', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            Importe CUP
                                            @if(request('sort_by') == 'Importe_CUP')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>
                                        <a href="{{ route('datos-ctto-suministro.index', array_merge(request()->except(['sort_by', 'sort_dir']), ['sort_by' => 'Fecha_firma_Ctto', 'sort_dir' => request('sort_by') == 'Fecha_firma_Ctto' && request('sort_dir', 'desc') == 'desc' ? 'asc' : 'desc'])) }}">
                                            Fecha Firma
                                            @if(request('sort_by') == 'Fecha_firma_Ctto')
                                                @if(request('sort_dir', 'desc') == 'desc')
                                                    <i class="fas fa-sort-down"></i>
                                                @else
                                                    <i class="fas fa-sort-up"></i>
                                                @endif
                                            @else
                                                <i class="fas fa-sort"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($items as $item)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="ids[]" value="{{ $item->Id_Supsum ?? $item->id }}" class="select-item">
                                        </td>
                                        <td>{{ $item->Id_Supsum ?? $item->id }}</td>
                                        <td>{{ $item->contratoSuministro->Descripcion ?? 'N/A' }}</td>
                                        <td>{{ $item->No_Suplemento }}</td>
                                        <td>{{ number_format($item->Importe_CUC, 2) }}</td>
                                        <td>{{ number_format($item->Importe_CUP, 2) }}</td>
                                        <td>{{ $item->Fecha_firma_Ctto ? \Carbon\Carbon::parse($item->Fecha_firma_Ctto)->format('d/m/Y') : '' }}</td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('datos-ctto-suministro.show', $item->Id_Supsum ?? $item->id) }}" class="btn btn-info btn-sm">Ver</a>
                                                <a href="{{ route('datos-ctto-suministro.edit', $item->Id_Supsum ?? $item->id) }}" class="btn btn-warning btn-sm">Editar</a>
                                                <form action="{{ route('datos-ctto-suministro.destroy', $item->Id_Supsum ?? $item->id) }}" method="POST" style="display:inline-block">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar este contrato?')">Eliminar</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            @if($items->isNotEmpty())
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="3" class="text-end"><strong>Totales:</strong></td>
                                    <td><strong>{{ $items->count() }} registros</strong></td>
                                    <td>
                                        <strong>
                                            @php
                                                $totalCUC = $items->sum('Importe_CUC');
                                            @endphp
                                            {{ number_format($totalCUC, 2) }}
                                        </strong>
                                    </td>
                                    <td>
                                        <strong>
                                            @php
                                                $totalCUP = $items->sum('Importe_CUP');
                                            @endphp
                                            {{ number_format($totalCUP, 2) }}
                                        </strong>
                                    </td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar los contratos seleccionados?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación -->
                @if($items->hasPages())
                    @php 
                        $queryParams = request()->except('page');
                        $queryString = http_build_query($queryParams);
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $items->firstItem() }}–{{ $items->lastItem() }} de {{ $items->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    <a class="page-link" href="{{ $items->url(1) }}?{{ $queryString }}">« Primera</a>
                                </li>
                                <li class="page-item {{ $items->onFirstPage() ? 'disabled' : '' }}">
                                    <a class="page-link" href="{{ $items->previousPageUrl() }}?{{ $queryString }}">‹</a>
                                </li>
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $items->currentPage() }} de {{ $items->lastPage() }}</span>
                                </li>
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    <a class="page-link" href="{{ $items->nextPageUrl() }}?{{ $queryString }}">›</a>
                                </li>
                                <li class="page-item {{ $items->hasMorePages() ? '' : 'disabled' }}">
                                    <a class="page-link" href="{{ $items->url($items->lastPage()) }}?{{ $queryString }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar exportSelected cuando cambian las selecciones
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportSelected').value = selectedString;
        document.getElementById('exportPdfSelected').value = selectedString;
        document.getElementById('printSelected').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
});
</script>
@endsection