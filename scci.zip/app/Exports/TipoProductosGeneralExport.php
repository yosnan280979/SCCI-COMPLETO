<?php

namespace App\Exports;

use App\Models\TipoProductoGeneral;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class TipoProductosGeneralExport implements FromCollection, WithHeadings, WithMapping
{
    protected $tipoProductosGenerales;

    public function __construct($tipoProductosGenerales)
    {
        $this->tipoProductosGenerales = $tipoProductosGenerales;
    }

    public function collection()
    {
        return $this->tipoProductosGenerales;
    }

    public function map($tipoProductoGeneral): array
    {
        return [
            $tipoProductoGeneral->IdTipoprodg,
            $tipoProductoGeneral->{'Tipo Prod general'},
            $tipoProductoGeneral->Grupo ?? '',
            $tipoProductoGeneral->{'Arancel CUC'} ?? '0.00',
            $tipoProductoGeneral->{'Arancel CUP'} ?? '0.00',
        ];
    }

    public function headings(): array
    {
        return [
            'ID',
            'Tipo Producto General',
            'Grupo',
            'Arancel CUC',
            'Arancel CUP'
        ];
    }
}