import { defineConfig } from 'vite';

export default defineConfig({
    plugins: [],
    resolve: {
        alias: {
            '@': '/resources/js',
            '@css': '/resources/css',
        },
    },
    build: {
        outDir: 'public/build',
        assetsDir: 'build/assets',
        manifest: true,
        rollupOptions: {
            input: {
                css: 'resources/css/app.css',
                js: 'resources/js/app.js',
            },
        },
    },
});