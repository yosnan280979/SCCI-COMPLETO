<!DOCTYPE html>
<html>
<head>
    <title>Personal Extranjero - Impresión</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; }
        .title { font-size: 18px; font-weight: bold; }
        .subtitle { font-size: 14px; color: #666; }
        .filters { margin-bottom: 15px; padding: 10px; background: #f5f5f5; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background-color: #f2f2f2; font-weight: bold; text-align: left; padding: 8px; border: 1px solid #ddd; }
        td { padding: 8px; border: 1px solid #ddd; font-size: 11px; }
        .footer { margin-top: 30px; text-align: right; font-size: 10px; color: #666; }
        .text-end { text-align: right; }
        .text-center { text-align: center; }
        .badge { padding: 3px 8px; border-radius: 3px; font-size: 11px; display: inline-block; }
        .badge-success { background-color: #d4edda; color: #155724; }
        .badge-danger { background-color: #f8d7da; color: #721c24; }
        .badge-secondary { background-color: #e2e3e5; color: #383d41; }
        .badge-warning { background-color: #fff3cd; color: #856404; }
        .badge-info { background-color: #d1ecf1; color: #0c5460; }
        @media print {
            .no-print { display: none; }
            .page-break { page-break-before: always; }
            body { font-size: 11px; }
            table { font-size: 10px; }
        }
        .page-break { page-break-after: always; }
        .person-container { margin-bottom: 20px; page-break-inside: avoid; padding-bottom: 15px; }
        .person-header { background-color: #e9ecef; padding: 10px; font-weight: bold; border-radius: 5px 5px 0 0; }
        .observation { background-color: #f8f9fa; padding: 8px; margin-top: 5px; border-radius: 3px; }
        .section-title { background-color: #f0f0f0; padding: 6px 10px; margin: 10px 0 5px 0; font-weight: bold; border-left: 4px solid #007bff; }
        .status-active { color: #155724; font-weight: bold; }
        .status-inactive { color: #721c24; font-weight: bold; }
        .warning-date { background-color: #fff3cd; padding: 3px 6px; border-radius: 3px; font-weight: bold; }
        .expired-date { background-color: #f8d7da; padding: 3px 6px; border-radius: 3px; font-weight: bold; }
        .valid-date { background-color: #d4edda; padding: 3px 6px; border-radius: 3px; }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">
            🖨️ Imprimir
        </button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #6c757d; color: white; border: none; border-radius: 5px; cursor: pointer;">
            ✖️ Cerrar
        </button>
    </div>
    
    <div class="header">
        <div class="title">Listado de Personal Extranjero</div>
        <div class="subtitle">Fecha de generación: {{ now()->format('d/m/Y H:i:s') }}</div>
        <div class="subtitle">Total de registros: {{ $items->count() }}</div>
    </div>
    
    @if(!empty($filtros))
    <div class="filters">
        <strong>Filtros aplicados:</strong><br>
        @foreach($filtros as $filtro)
        • {{ $filtro }}<br>
        @endforeach
    </div>
    @endif
    
    @foreach($items as $item)
    <div class="person-container">
        <div class="person-header">
            Personal #{{ $item->Id ?? $item->id }} - {{ $item->Funcionario_extranjero }}
            <span style="float: right;">
                @if($item->Activo)
                    <span class="badge badge-success">Activo</span>
                @else
                    <span class="badge badge-danger">Inactivo</span>
                @endif
                @if($item->Firmante)
                    <span class="badge badge-warning" style="margin-left: 5px;">Firmante</span>
                @endif
            </span>
        </div>
        
        <!-- Información Básica -->
        <div class="section-title">Información Personal</div>
        <table>
            <tbody>
                <tr>
                    <td width="20%"><strong>ID Personal:</strong></td>
                    <td width="30%">{{ $item->Id ?? $item->id }}</td>
                    <td width="20%"><strong>Proveedor:</strong></td>
                    <td width="30%">
                        {{ $item->proveedor->Proveedor ?? 'N/A' }}
                        @if($item->proveedor && $item->proveedor->{'Id Proveedor'})
                            (ID: {{ $item->proveedor->{'Id Proveedor'} }})
                        @endif
                    </td>
                </tr>
                <tr>
                    <td><strong>Funcionario Extranjero:</strong></td>
                    <td colspan="3">{{ $item->Funcionario_extranjero }}</td>
                </tr>
                <tr>
                    <td><strong>Cargo:</strong></td>
                    <td>{{ $item->Cargo ?? 'N/A' }}</td>
                    <td><strong>País de Origen:</strong></td>
                    <td>{{ $item->Id_pais ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td><strong>Correo Electrónico:</strong></td>
                    <td>{{ $item->Email ?? 'N/A' }}</td>
                    <td><strong>Teléfono:</strong></td>
                    <td>{{ $item->Telef ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td><strong>Permiso de Trabajo:</strong></td>
                    <td>{{ $item->Permiso_de_Trabajo ?? 'N/A' }}</td>
                    <td><strong>Estado:</strong></td>
                    <td class="text-center">
                        @if($item->Activo)
                            <span class="badge badge-success">Activo</span>
                        @else
                            <span class="badge badge-danger">Inactivo</span>
                        @endif
                    </td>
                </tr>
            </tbody>
        </table>
        
        <!-- Información de Documentación -->
        <div class="section-title">Documentación y Autorizaciones</div>
        <table>
            <tbody>
                <tr>
                    <td width="20%"><strong>Fecha de Vencimiento:</strong></td>
                    <td width="30%">
                        @if($item->Fecha_Vencimiento)
                            @php
                                $fechaVencimiento = \Carbon\Carbon::parse($item->Fecha_Vencimiento);
                                $hoy = \Carbon\Carbon::now();
                                $diasDiferencia = $hoy->diffInDays($fechaVencimiento, false);
                            @endphp
                            
                            {{ $fechaVencimiento->format('d/m/Y') }}
                            
                            @if($diasDiferencia < 0)
                                <span class="badge badge-danger" style="margin-left: 5px;">
                                    Vencido hace {{ abs($diasDiferencia) }} días
                                </span>
                            @elseif($diasDiferencia <= 30)
                                <span class="badge badge-warning" style="margin-left: 5px;">
                                    Vence en {{ $diasDiferencia }} días
                                </span>
                            @else
                                <span class="badge badge-success" style="margin-left: 5px;">
                                    Vigente
                                </span>
                            @endif
                        @else
                            N/A
                        @endif
                    </td>
                    <td width="20%"><strong>Firmante Autorizado:</strong></td>
                    <td width="30%" class="text-center">
                        @if($item->Firmante)
                            <span class="badge badge-warning">Sí</span>
                        @else
                            <span class="badge badge-secondary">No</span>
                        @endif
                    </td>
                </tr>
                <tr>
                    <td><strong>Escritura Notarial:</strong></td>
                    <td>{{ $item->Escnot ?? 'N/A' }}</td>
                    <td><strong>Aprobación de Protocolo:</strong></td>
                    <td>{{ $item->Aprot ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td><strong>Fecha Vencimiento Poder:</strong></td>
                    <td>
                        @if($item->Fechavenpod)
                            @php
                                $fechaVencimientoPod = \Carbon\Carbon::parse($item->Fechavenpod);
                                $diasDiferenciaPod = $hoy->diffInDays($fechaVencimientoPod, false);
                            @endphp
                            
                            {{ $fechaVencimientoPod->format('d/m/Y') }}
                            
                            @if($diasDiferenciaPod < 0)
                                <span class="badge badge-danger" style="margin-left: 5px;">
                                    Vencido
                                </span>
                            @elseif($diasDiferenciaPod <= 30)
                                <span class="badge badge-warning" style="margin-left: 5px;">
                                    Por vencer
                                </span>
                            @endif
                        @else
                            N/A
                        @endif
                    </td>
                    <td colspan="2"></td>
                </tr>
            </tbody>
        </table>
        
        <!-- Información Adicional -->
        <div class="section-title">Información Adicional</div>
        <table>
            <tbody>
                <tr>
                    <td width="20%"><strong>Proveedor Asociado:</strong></td>
                    <td colspan="3">
                        @if($item->proveedor)
                            {{ $item->proveedor->Proveedor ?? 'N/A' }}
                            @if($item->proveedor->{'Codigo MINCEX'})
                                (Código MINCEX: {{ $item->proveedor->{'Codigo MINCEX'} }})
                            @endif
                        @else
                            N/A
                        @endif
                    </td>
                </tr>
                <tr>
                    <td><strong>Estado del Proveedor:</strong></td>
                    <td>
                        @if($item->proveedor)
                            @if($item->proveedor->Activo)
                                <span class="badge badge-success">Activo</span>
                            @else
                                <span class="badge badge-danger">Inactivo</span>
                            @endif
                        @else
                            N/A
                        @endif
                    </td>
                    <td><strong>País del Proveedor:</strong></td>
                    <td>{{ $item->proveedor->{'País'} ?? 'N/A' }}</td>
                </tr>
            </tbody>
        </table>
        
        <!-- Resumen de Estado -->
        <div style="margin-top: 15px; padding: 10px; background-color: #f8f9fa; border-radius: 5px;">
            <strong>Resumen de Estado:</strong><br>
            @php
                $estadoGeneral = 'Vigente';
                $claseEstado = 'badge-success';
                
                if($item->Fecha_Vencimiento) {
                    $fechaVencimiento = \Carbon\Carbon::parse($item->Fecha_Vencimiento);
                    if($fechaVencimiento->isPast()) {
                        $estadoGeneral = 'Documentación Vencida';
                        $claseEstado = 'badge-danger';
                    } elseif($fechaVencimiento->diffInDays(\Carbon\Carbon::now()) <= 30) {
                        $estadoGeneral = 'Por Vencer Pronto';
                        $claseEstado = 'badge-warning';
                    }
                }
                
                if(!$item->Activo) {
                    $estadoGeneral = 'Inactivo';
                    $claseEstado = 'badge-danger';
                }
            @endphp
            
            • Estado General: <span class="badge {{ $claseEstado }}">{{ $estadoGeneral }}</span><br>
            • Activo en Sistema: {{ $item->Activo ? 'Sí' : 'No' }}<br>
            • Autorizado para Firmar: {{ $item->Firmante ? 'Sí' : 'No' }}<br>
            • Documentación: 
                @if($item->Fecha_Vencimiento)
                    {{ \Carbon\Carbon::parse($item->Fecha_Vencimiento)->format('d/m/Y') }}
                @else
                    Sin fecha de vencimiento
                @endif
        </div>
        
        @if(!$loop->last)
            <hr style="border-top: 1px dashed #ddd; margin: 20px 0;">
        @endif
    </div>
    @endforeach
    
    <!-- Totales generales -->
    <div style="margin-top: 30px; padding: 15px; background-color: #f8f9fa; border-radius: 5px;">
        <strong>Resumen General:</strong><br>
        • Total Registros: {{ $items->count() }}<br>
        • Personal Activo: {{ $items->where('Activo', 1)->count() }}<br>
        • Personal Inactivo: {{ $items->where('Activo', 0)->count() }}<br>
        • Firmantes Autorizados: {{ $items->where('Firmante', 1)->count() }}<br>
        @php
            $vencidos = 0;
            $porVencer = 0;
            foreach($items as $item) {
                if($item->Fecha_Vencimiento) {
                    $fechaVencimiento = \Carbon\Carbon::parse($item->Fecha_Vencimiento);
                    if($fechaVencimiento->isPast()) {
                        $vencidos++;
                    } elseif($fechaVencimiento->diffInDays(\Carbon\Carbon::now()) <= 30) {
                        $porVencer++;
                    }
                }
            }
        @endphp
        • Documentación Vencida: {{ $vencidos }}<br>
        • Documentación por Vencer (≤30 días): {{ $porVencer }}
    </div>
    
    <div class="footer">
        <p>Total de registros: {{ $items->count() }}</p>
        <p>Generado por: {{ auth()->user()->{'Usuario'} ?? auth()->user()->{'Nombre completo'} ?? 'Sistema' }}</p>
        <p>SCCI - Sistema de Control de Contratación e Importaciones</p>
    </div>
    
    <script>
        // Auto-print opcional (descomentar si se necesita)
        // window.onload = function() { window.print(); }
        
        // Resaltar vencimientos próximos
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date();
            const vencimientoElements = document.querySelectorAll('[data-vencimiento]');
            
            vencimientoElements.forEach(function(el) {
                const fechaStr = el.getAttribute('data-vencimiento');
                if (fechaStr) {
                    const fechaVencimiento = new Date(fechaStr.split('/').reverse().join('-'));
                    const diffTime = fechaVencimiento - today;
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    
                    if (diffDays < 0) {
                        el.classList.add('expired-date');
                    } else if (diffDays <= 30) {
                        el.classList.add('warning-date');
                    } else {
                        el.classList.add('valid-date');
                    }
                }
            });
        });
    </script>
</body>
</html>