@extends('layouts.app')

@section('title', 'Datos Bancos de Proveedores')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Listado de Datos Bancos de Proveedores</h3>
            <div class="d-flex gap-2">
                <a href="{{ route('datos-bancos-proveedores.create') }}" class="btn btn-primary btn-sm">➕ Nuevo Registro</a>
                
                <!-- Formularios de exportación separados (GET) -->
                <form id="exportExcelForm" method="GET" action="{{ route('datos-bancos-proveedores.export.excel') }}" style="display: inline">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="proveedor" value="{{ request('proveedor') }}">
                    <input type="hidden" name="banco" value="{{ request('banco') }}">
                    <input type="hidden" name="moneda" value="{{ request('moneda') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="exportSelectedIds" value="">
                    <button type="submit" class="btn btn-success btn-sm">📊 Excel</button>
                </form>
                
                <form id="exportPdfForm" method="GET" action="{{ route('datos-bancos-proveedores.export.pdf') }}" style="display: inline">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="proveedor" value="{{ request('proveedor') }}">
                    <input type="hidden" name="banco" value="{{ request('banco') }}">
                    <input type="hidden" name="moneda" value="{{ request('moneda') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="pdfSelectedIds" value="">
                    <button type="submit" class="btn btn-danger btn-sm">📄 PDF</button>
                </form>
                
                <form id="printForm" method="GET" action="{{ route('datos-bancos-proveedores.print') }}" style="display: inline" target="_blank">
                    <input type="hidden" name="search" value="{{ request('search') }}">
                    <input type="hidden" name="proveedor" value="{{ request('proveedor') }}">
                    <input type="hidden" name="banco" value="{{ request('banco') }}">
                    <input type="hidden" name="moneda" value="{{ request('moneda') }}">
                    <input type="hidden" name="sort_by" value="{{ request('sort_by') }}">
                    <input type="hidden" name="sort_dir" value="{{ request('sort_dir') }}">
                    <input type="hidden" name="selected_ids" id="printSelectedIds" value="">
                    <button type="submit" class="btn btn-secondary btn-sm">🖨️ Imprimir</button>
                </form>
            </div>
        </div>

        <div class="card-body">
            <!-- Filtros -->
            <form method="GET" action="{{ route('datos-bancos-proveedores.index') }}" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-3">
                        <select name="proveedor" class="form-select">
                            <option value="">Proveedor</option>
                            @foreach($proveedores as $prov)
                                <option value="{{ $prov->{'Id Proveedor'} }}" {{ request('proveedor') == $prov->{'Id Proveedor'} ? 'selected' : '' }}>
                                    {{ $prov->{'Proveedor'} }} (ID: {{ $prov->{'Id Proveedor'} }})
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="banco" class="form-select">
                            <option value="">Banco</option>
                            @foreach($bancos as $banco)
                                <option value="{{ $banco->{'Id Banco'} }}" {{ request('banco') == $banco->{'Id Banco'} ? 'selected' : '' }}>
                                    {{ $banco->{'Banco'} }} (ID: {{ $banco->{'Id Banco'} }})
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="moneda" class="form-select">
                            <option value="">Moneda</option>
                            @foreach($monedas as $moneda)
                                <option value="{{ $moneda->{'Id Moneda'} }}" {{ request('moneda') == $moneda->{'Id Moneda'} ? 'selected' : '' }}>
                                    {{ $moneda->{'Moneda'} }} (ID: {{ $moneda->{'Id Moneda'} }})
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="search" class="form-control" placeholder="Buscar (Cuenta, Titular, SWIFT...)"
                               value="{{ request('search') }}">
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-3">
                        <select name="sort_by" class="form-select">
                            <option value="">Ordenar por</option>
                            <option value="Id" {{ request('sort_by') == 'Id' ? 'selected' : '' }}>ID</option>
                            <option value="Id proveedor" {{ request('sort_by') == 'Id proveedor' ? 'selected' : '' }}>Proveedor</option>
                            <option value="Numero Cuenta" {{ request('sort_by') == 'Numero Cuenta' ? 'selected' : '' }}>Número Cuenta</option>
                            <option value="Titular" {{ request('sort_by') == 'Titular' ? 'selected' : '' }}>Titular</option>
                            <option value="Activo" {{ request('sort_by') == 'Activo' ? 'selected' : '' }}>Activo</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="sort_dir" class="form-select">
                            <option value="desc" {{ request('sort_dir', 'desc') == 'desc' ? 'selected' : '' }}>Descendente</option>
                            <option value="asc" {{ request('sort_dir') == 'asc' ? 'selected' : '' }}>Ascendente</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">Buscar</button>
                        <a href="{{ route('datos-bancos-proveedores.index') }}" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </div>
            </form>

            @if($datosBancos->isEmpty())
                <div class="alert alert-info">No hay registros.</div>
            @else
                <!-- Formulario para eliminación múltiple (DELETE) -->
                <form id="deleteForm" method="POST" action="{{ route('datos-bancos-proveedores.destroy.multiple') }}">
                    @csrf
                    @method('DELETE')
                    
                    <div class="table-responsive" style="overflow-x: auto;">
                        <table class="table table-bordered table-hover table-sm" style="font-size: 0.9rem;">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="select-all-checkbox">
                                    </th>
                                    <th>ID</th>
                                    <th>Proveedor</th>
                                    <th>Banco</th>
                                    <th>Moneda</th>
                                    <th>Número de Cuenta</th>
                                    <th>Titular</th>
                                    <th>Tipo de Cuenta</th>
                                    <th>SWIFT/BIC</th>
                                    <th>Dirección Banco</th>
                                    <th>Teléfono Banco</th>
                                    <th>Email Banco</th>
                                    <th>Contacto Banco</th>
                                    <th>Observaciones</th>
                                    <th>Activo</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($datosBancos as $dato)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="selected_ids[]" value="{{ $dato->Id }}" class="select-item">
                                        </td>
                                        <td>{{ $dato->Id }}</td>
                                        <td>
                                            {{ $dato->proveedor?->{'Proveedor'} ?? 'N/A' }}
                                            @if($dato->proveedor)
                                                <br><small class="text-muted">ID: {{ $dato->{'Id proveedor'} }}</small>
                                            @endif
                                        </td>
                                        <td>
                                            {{ $dato->banco?->{'Banco'} ?? 'N/A' }}
                                            @if($dato->banco)
                                                <br><small class="text-muted">ID: {{ $dato->{'Id banco'} }}</small>
                                            @endif
                                        </td>
                                        <td>
                                            {{ $dato->moneda?->{'Moneda'} ?? 'N/A' }}
                                            @if($dato->moneda)
                                                <br><small class="text-muted">ID: {{ $dato->{'Id moneda'} }}</small>
                                            @endif
                                        </td>
                                        <td>{{ $dato->{'Numero Cuenta'} }}</td>
                                        <td>{{ $dato->Titular ?? '' }}</td>
                                        <td>{{ $dato->{'Tipo Cuenta'} ?? '' }}</td>
                                        <td>{{ $dato->{'SWIFT_BIC'} ?? '' }}</td>
                                        <td>{{ Str::limit($dato->{'Direccion Banco'} ?? '', 30) }}</td>
                                        <td>{{ $dato->{'Telefono Banco'} ?? '' }}</td>
                                        <td>{{ $dato->{'Email Banco'} ?? '' }}</td>
                                        <td>{{ $dato->{'Contacto Banco'} ?? '' }}</td>
                                        <td>{{ Str::limit($dato->Observaciones ?? '', 30) }}</td>
                                        <td>
                                            <span class="badge bg-{{ $dato->Activo ? 'success' : 'secondary' }}">
                                                {{ $dato->Activo ? 'Sí' : 'No' }}
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('datos-bancos-proveedores.show', $dato->Id) }}" class="btn btn-info btn-sm">Ver</a>
                                                <a href="{{ route('datos-bancos-proveedores.edit', $dato->Id) }}" class="btn btn-warning btn-sm">Editar</a>
                                                <form action="{{ route('datos-bancos-proveedores.destroy', $dato->Id) }}" method="POST" style="display:inline-block;">
                                                    @csrf @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar este registro?')">Eliminar</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            @if($datosBancos->isNotEmpty())
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="5" class="text-end"><strong>Totales:</strong></td>
                                    <td colspan="11">
                                        <strong>
                                            {{ $datosBancos->count() }} registros |
                                            @php
                                                $activos = $datosBancos->where('Activo', 1)->count();
                                                $inactivos = $datosBancos->where('Activo', 0)->count();
                                            @endphp
                                            Activos: {{ $activos }} |
                                            Inactivos: {{ $inactivos }}
                                        </strong>
                                    </td>
                                </tr>
                            </tfoot>
                            @endif
                        </table>
                    </div>
                    
                    <!-- Botón para eliminar múltiple -->
                    <button type="submit" class="btn btn-danger btn-sm mt-2" onclick="return confirm('¿Eliminar los registros seleccionados?')">
                        🗑️ Eliminar Seleccionados
                    </button>
                </form>

                <!-- Paginación corregida -->
                @if($datosBancos->hasPages())
                    @php 
                        // Preservar todos los parámetros de búsqueda en la paginación
                        $queryParams = request()->all();
                    @endphp
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="text-muted">
                            Mostrando {{ $datosBancos->firstItem() }}–{{ $datosBancos->lastItem() }} de {{ $datosBancos->total() }} registros
                        </div>
                        <nav>
                            <ul class="pagination mb-0">
                                <!-- Primera página -->
                                <li class="page-item {{ $datosBancos->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-bancos-proveedores.index', $queryParams) }}">« Primera</a>
                                </li>
                                
                                <!-- Página anterior -->
                                <li class="page-item {{ $datosBancos->onFirstPage() ? 'disabled' : '' }}">
                                    @php
                                        $queryParams['page'] = $datosBancos->currentPage() - 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-bancos-proveedores.index', $queryParams) }}">‹</a>
                                </li>
                                
                                <!-- Página actual -->
                                <li class="page-item disabled">
                                    <span class="page-link">Página {{ $datosBancos->currentPage() }} de {{ $datosBancos->lastPage() }}</span>
                                </li>
                                
                                <!-- Página siguiente -->
                                <li class="page-item {{ $datosBancos->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $datosBancos->currentPage() + 1;
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-bancos-proveedores.index', $queryParams) }}">›</a>
                                </li>
                                
                                <!-- Última página -->
                                <li class="page-item {{ $datosBancos->hasMorePages() ? '' : 'disabled' }}">
                                    @php
                                        $queryParams['page'] = $datosBancos->lastPage();
                                    @endphp
                                    <a class="page-link" href="{{ route('datos-bancos-proveedores.index', $queryParams) }}">Última »</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Seleccionar/deseleccionar todos
    const selectAll = document.getElementById('select-all-checkbox');
    if (selectAll) {
        selectAll.addEventListener('click', function(e) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = e.target.checked);
            updateExportSelected();
        });
    }
    
    // Actualizar selecciones cuando cambian los checkboxes individuales
    document.querySelectorAll('.select-item').forEach(cb => {
        cb.addEventListener('change', updateExportSelected);
    });
    
    function updateExportSelected() {
        const selected = [];
        document.querySelectorAll('.select-item:checked').forEach(cb => {
            selected.push(cb.value);
        });
        
        const selectedString = selected.join(',');
        
        // Actualizar todos los formularios de exportación
        document.getElementById('exportSelectedIds').value = selectedString;
        document.getElementById('pdfSelectedIds').value = selectedString;
        document.getElementById('printSelectedIds').value = selectedString;
    }
    
    // Inicializar
    updateExportSelected();
});
</script>
@endsection