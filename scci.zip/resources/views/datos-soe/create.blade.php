@extends('layouts.app')

@section('title', 'Crear SOE')

@section('header', 'Crear Suplemento de Operación de Exportación (SOE)')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Nuevo SOE</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="{{ route('datos-soe.store') }}">
                        @csrf

                        <div class="row">
                            <!-- Columna Izquierda -->
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="Id_Ctto" class="form-label">Contrato *</label>
                                    <select class="form-control select2" id="Id_Ctto" name="Id_Ctto" required>
                                        <option value="">Seleccione un contrato</option>
                                        @foreach($contratos as $contrato)
                                            <option value="{{ $contrato->{'Id Ctto'} }}" {{ old('Id_Ctto') == $contrato->{'Id Ctto'} ? 'selected' : '' }}>
                                                {{ $contrato->{'No Ctto'} }} - {{ $contrato->{'Valor Ctto CUC'} ?? 'N/A' }} CUC
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('Id_Ctto')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="Id_Solicitud" class="form-label">Solicitud</label>
                                    <select class="form-control select2" id="Id_Solicitud" name="Id_Solicitud">
                                        <option value="">Seleccione una solicitud</option>
                                        @foreach($solicitudes as $solicitud)
                                            <option value="{{ $solicitud->{'Id Solicitud'} }}" {{ old('Id_Solicitud') == $solicitud->{'Id Solicitud'} ? 'selected' : '' }}>
                                                {{ $solicitud->{'No Solicitud'} }} - {{ $solicitud->{'Decripción Solicitud'} }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('Id_Solicitud')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="No_Suplemento" class="form-label">No. Suplemento</label>
                                    <input type="number" class="form-control" id="No_Suplemento" name="No_Suplemento" 
                                           value="{{ old('No_Suplemento') }}">
                                    @error('No_Suplemento')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="Fecha_Comite" class="form-label">Fecha Comité</label>
                                    <input type="datetime-local" class="form-control" id="Fecha_Comite" name="Fecha_Comite" 
                                           value="{{ old('Fecha_Comite') }}">
                                    @error('Fecha_Comite')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="No_Acta" class="form-label">No. Acta</label>
                                    <input type="text" class="form-control" id="No_Acta" name="No_Acta" 
                                           value="{{ old('No_Acta') }}" maxlength="50">
                                    @error('No_Acta')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="No_Acuerdo" class="form-label">No. Acuerdo</label>
                                    <input type="text" class="form-control" id="No_Acuerdo" name="No_Acuerdo" 
                                           value="{{ old('No_Acuerdo') }}" maxlength="50">
                                    @error('No_Acuerdo')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="Valor_Mercancia" class="form-label">Valor Mercancía</label>
                                    <input type="number" step="0.01" class="form-control" id="Valor_Mercancia" name="Valor_Mercancia" 
                                           value="{{ old('Valor_Mercancia') }}">
                                    @error('Valor_Mercancia')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <!-- Columna Derecha -->
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="Valor_Ctto_CUC" class="form-label">Valor Contrato CUC</label>
                                    <input type="number" step="0.01" class="form-control" id="Valor_Ctto_CUC" name="Valor_Ctto_CUC" 
                                           value="{{ old('Valor_Ctto_CUC') }}">
                                    @error('Valor_Ctto_CUC')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="Id_Moneda" class="form-label">Moneda</label>
                                    <select class="form-control select2" id="Id_Moneda" name="Id_Moneda">
                                        <option value="">Seleccione moneda</option>
                                        @foreach($monedas as $moneda)
                                            <option value="{{ $moneda->{'Id Moneda'} }}" {{ old('Id_Moneda') == $moneda->{'Id Moneda'} ? 'selected' : '' }}>
                                                {{ $moneda->Moneda }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('Id_Moneda')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="Valor_Mon_Prov" class="form-label">Valor Moneda Proveedor</label>
                                    <input type="number" step="0.01" class="form-control" id="Valor_Mon_Prov" name="Valor_Mon_Prov" 
                                           value="{{ old('Valor_Mon_Prov') }}">
                                    @error('Valor_Mon_Prov')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="No_Referencia" class="form-label">No. Referencia</label>
                                    <input type="text" class="form-control" id="No_Referencia" name="No_Referencia" 
                                           value="{{ old('No_Referencia') }}" maxlength="6">
                                    @error('No_Referencia')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="Id_MomentoSOE" class="form-label">Momento SOE</label>
                                    <select class="form-control select2" id="Id_MomentoSOE" name="Id_MomentoSOE">
                                        <option value="">Seleccione momento</option>
                                        @foreach($momentosSOE as $momento)
                                            <option value="{{ $momento->{'Id MomentoSOE'} }}" {{ old('Id_MomentoSOE') == $momento->{'Id MomentoSOE'} ? 'selected' : '' }}>
                                                {{ $momento->{'Momento SOE'} }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('Id_MomentoSOE')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="Id_Linea_credito" class="form-label">Línea de Crédito</label>
                                    <select class="form-control select2" id="Id_Linea_credito" name="Id_Linea_credito">
                                        <option value="">Seleccione línea</option>
                                        @foreach($lineasCredito as $linea)
                                            <option value="{{ $linea->{'Id Lineacredito'} }}" {{ old('Id_Linea_credito') == $linea->{'Id Lineacredito'} ? 'selected' : '' }}>
                                                {{ $linea->{'Linea de Crédito'} }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('Id_Linea_credito')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="Año_finan" class="form-label">Año Financiero</label>
                                    <input type="number" class="form-control" id="Año_finan" name="Año_finan" 
                                           value="{{ old('Año_finan', date('Y')) }}">
                                    @error('Año_finan')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="Forma_de_Pago" class="form-label">Forma de Pago</label>
                                    <input type="text" class="form-control" id="Forma_de_Pago" name="Forma_de_Pago" 
                                           value="{{ old('Forma_de_Pago') }}" maxlength="255">
                                    @error('Forma_de_Pago')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <!-- Fechas Importantes -->
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="Fecha_CAD_Gescons" class="form-label">Fecha CAD Gescons</label>
                                    <input type="datetime-local" class="form-control" id="Fecha_CAD_Gescons" name="Fecha_CAD_Gescons" 
                                           value="{{ old('Fecha_CAD_Gescons') }}">
                                    @error('Fecha_CAD_Gescons')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="Fecha_CAD_MICONS" class="form-label">Fecha CAD MICONS</label>
                                    <input type="datetime-local" class="form-control" id="Fecha_CAD_MICONS" name="Fecha_CAD_MICONS" 
                                           value="{{ old('Fecha_CAD_MICONS') }}">
                                    @error('Fecha_CAD_MICONS')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="No_Acta_MICONS" class="form-label">No. Acta MICONS</label>
                                    <input type="text" class="form-control" id="No_Acta_MICONS" name="No_Acta_MICONS" 
                                           value="{{ old('No_Acta_MICONS') }}" maxlength="20">
                                    @error('No_Acta_MICONS')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <!-- Campos Adicionales -->
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="Fecha_firma_Ctto" class="form-label">Fecha Firma Contrato</label>
                                    <input type="datetime-local" class="form-control" id="Fecha_firma_Ctto" name="Fecha_firma_Ctto" 
                                           value="{{ old('Fecha_firma_Ctto') }}">
                                    @error('Fecha_firma_Ctto')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="Fecha_emision_certif" class="form-label">Fecha Emisión Certificado</label>
                                    <input type="datetime-local" class="form-control" id="Fecha_emision_certif" name="Fecha_emision_certif" 
                                           value="{{ old('Fecha_emision_certif') }}">
                                    @error('Fecha_emision_certif')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="Total_embarques" class="form-label">Total Embarques</label>
                                    <input type="number" class="form-control" id="Total_embarques" name="Total_embarques" 
                                           value="{{ old('Total_embarques') }}">
                                    @error('Total_embarques')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <!-- Pendientes Financieros -->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="Pendiente_finan_CUC" class="form-label">Pendiente Financiero CUC</label>
                                    <input type="number" step="0.01" class="form-control" id="Pendiente_finan_CUC" name="Pendiente_finan_CUC" 
                                           value="{{ old('Pendiente_finan_CUC') }}">
                                    @error('Pendiente_finan_CUC')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="Pendiente_finan_CUP" class="form-label">Pendiente Financiero CUP</label>
                                    <input type="number" step="0.01" class="form-control" id="Pendiente_finan_CUP" name="Pendiente_finan_CUP" 
                                           value="{{ old('Pendiente_finan_CUP') }}">
                                    @error('Pendiente_finan_CUP')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <!-- Observaciones -->
                        <div class="mb-3">
                            <label for="Observaciones_Juridico" class="form-label">Observaciones Jurídico</label>
                            <textarea class="form-control" id="Observaciones_Juridico" name="Observaciones_Juridico" rows="2">{{ old('Observaciones_Juridico') }}</textarea>
                            @error('Observaciones_Juridico')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="Observaciones_SOE" class="form-label">Observaciones SOE</label>
                            <textarea class="form-control" id="Observaciones_SOE" name="Observaciones_SOE" rows="2">{{ old('Observaciones_SOE') }}</textarea>
                            @error('Observaciones_SOE')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="Observaciones_Especialista" class="form-label">Observaciones Especialista</label>
                            <textarea class="form-control" id="Observaciones_Especialista" name="Observaciones_Especialista" rows="2">{{ old('Observaciones_Especialista') }}</textarea>
                            @error('Observaciones_Especialista')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="Observaciones" class="form-label">Observaciones Generales</label>
                            <textarea class="form-control" id="Observaciones" name="Observaciones" rows="3">{{ old('Observaciones') }}</textarea>
                            @error('Observaciones')
                                <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Checkboxes -->
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="Cancelado_SOE" name="Cancelado_SOE" value="1" {{ old('Cancelado_SOE') ? 'checked' : '' }}>
                                    <label class="form-check-label" for="Cancelado_SOE">
                                        Cancelado SOE
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="Anular_Valores" name="Anular_Valores" value="1" {{ old('Anular_Valores') ? 'checked' : '' }}>
                                    <label class="form-check-label" for="Anular_Valores">
                                        Anular Valores
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Guardar SOE
                            </button>
                            <a href="{{ route('datos-soe.index') }}" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancelar
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
    .select2-container--bootstrap-5 .select2-selection {
        border: 1px solid #ced4da;
    }
    .select2-container--bootstrap-5.select2-container--focus .select2-selection,
    .select2-container--bootstrap-5.select2-container--open .select2-selection {
        border-color: #86b7fe;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
    }
</style>
@endpush

@push('scripts')
<script>
$(document).ready(function() {
    // Inicializar Select2
    $('.select2').select2({
        theme: 'bootstrap-5',
        width: '100%'
    });

    // Calcular pendientes si se modifica valor
    $('#Valor_Ctto_CUC').on('change', function() {
        const valorCUC = parseFloat($(this).val()) || 0;
        $('#Pendiente_finan_CUC').val(valorCUC);
    });

    // Auto-calcular fecha de firma si se selecciona contrato
    $('#Id_Ctto').on('change', function() {
        const contratoId = $(this).val();
        if (contratoId) {
            // Podrías hacer una llamada AJAX para obtener información del contrato
            // Por ahora, dejamos que el usuario complete manualmente
        }
    });
});
</script>
@endpush