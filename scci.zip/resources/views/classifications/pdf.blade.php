<!DOCTYPE html>
<html>
<head>
    <title>Clasificaciones - PDF</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; }
        .header h1 { margin: 0; }
        .header .date { color: #666; }
        .filters { margin-bottom: 15px; padding: 10px; background: #f5f5f5; border-radius: 5px; }
        .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .table th, .table td { border: 1px solid #ddd; padding: 8px; }
        .table th { background-color: #f8f9fa; text-align: left; }
        .table tr:nth-child(even) { background-color: #f2f2f2; }
        .footer { margin-top: 30px; text-align: center; font-size: 10px; color: #666; }
        .badge { padding: 2px 6px; border-radius: 4px; font-size: 11px; }
        .badge-yes { background-color: #ffc107; color: #000; }
        .badge-no { background-color: #6c757d; color: #fff; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Reporte de Clasificaciones</h1>
        <div class="date">Generado: {{ date('d/m/Y H:i:s') }}</div>
        @if(!empty($filtros))
        <div class="filters">
            <strong>Filtros aplicados:</strong><br>
            @foreach($filtros as $filtro)
            • {{ $filtro }}<br>
            @endforeach
        </div>
        @endif
        <div class="date">Total de registros: {{ $items->count() }}</div>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>ID Clasificación</th>
                <th>Clasificación</th>
                <th>Con Valor Contrato</th>
                <th>Orden</th>
            </tr>
        </thead>
        <tbody>
            @foreach($items as $item)
                <tr>
                    <td>{{ $item->{'Id Clasificacion'} }}</td>
                    <td>{{ $item->Clasificacion }}</td>
                    <td>
                        <span class="badge {{ $item->{'Con Valor Ctto'} ? 'badge-yes' : 'badge-no' }}">
                            {{ $item->{'Con Valor Ctto'} ? 'Sí' : 'No' }}
                        </span>
                    </td>
                    <td>{{ $item->Orden }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <div class="footer">
        <p>Sistema SCCI - IMECO</p>
    </div>
</body>
</html>