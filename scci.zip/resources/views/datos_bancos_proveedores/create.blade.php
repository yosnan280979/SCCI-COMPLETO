@extends('layouts.app')

@section('title','Nuevo Registro Bancario')

@section('content')
<div class="container-fluid">
    @include('partials.messages')

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Nuevo Registro Bancario</h5>
            <a href="{{ route('datos-bancos-proveedores.index') }}" class="btn btn-secondary btn-sm">⬅️ Volver</a>
        </div>

        <div class="card-body">
            <form action="{{ route('datos-bancos-proveedores.store') }}" method="POST">
                @csrf
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Proveedor</label>
                        <select name="Id proveedor" class="form-select" required>
                            @foreach($proveedores as $prov)
                                <option value="{{ $prov->{'Id Proveedor'} }}">{{ $prov->{'Proveedor'} }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Banco</label>
                        <select name="Id Banco" class="form-select" required>
                            @foreach($bancos as $banco)
                                <option value="{{ $banco->{'Id Banco'} }}">{{ $banco->{'Banco'} }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Moneda</label>
                        <select name="Id Moneda" class="form-select" required>
                            @foreach($monedas as $moneda)
                                <option value="{{ $moneda->{'Id Moneda'} }}">{{ $moneda->{'Moneda'} }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Número de Cuenta</label>
                        <input type="text" name="Numero Cuenta" class="form-control" maxlength="50" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Titular</label>
                        <input type="text" name="Titular" class="form-control" maxlength="255">
                    </div>
                </div>

                <div class="mt-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary">💾 Guardar</button>
                    <a href="{{ route('datos-bancos-proveedores.index') }}" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
